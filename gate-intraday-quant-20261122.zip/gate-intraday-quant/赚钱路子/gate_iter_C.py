#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gate 迭代 C：发明 3 个新方向（全模拟，不下单、不开户、不碰真钱）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
已读完三份前置报告，不再重复测的 12 个家族（180 天全亏）：
  ORB突破、VWAP均值回归、EMA动量、ORB+VWAP+ATR组合、止盈3x、
  去VWAP出场、ORB改窗口、成交量过滤、资金费率结算点套利、
  亚盘突破、配对BTC/ETH、波动率扩张、RSI极端反转、资金费率极值反转。
前置共性结论：毛利基本为零，亏损约等于手续费；再换方向参数大概率过拟合。

本次 3 个新家族 —— 假设在写代码前定好（写在下面），不是看数据后挑的。
每个策略只测一组事先定好的参数，无网格寻优。

  C1 高波动日门控 + 开盘动量延续（C1-hivol）
     赌的假设：趋势只在高波动日才延续，低波动日的“趋势”全是噪音。
     和已试家族的本质不同：前面所有策略每天都做（或每天必判信号），
     C1 先用“当天是不是高波动日”做门控，低波动日全天空仓，用“少做”
     攻击成本问题；门控本身是新维度，入场只是用来隔离门控效果的
     对照（开盘 2h 方向延续），不是又一个 ORB 变体。
     规则（事先定死）：
       * 当天前 4 根 30m（00:00-02:00）开盘 2h 振幅 R0 = 最高-最低。
       * R0 >= 1.3 x 前 20 个完整日同窗口振幅的中位数 -> 高波动日，
         否则当天全天空仓。需 20 天热身。
       * 高波动日才看方向：02:00 收盘价 vs 00:00 开盘价，涨幅 >= +0.15%
         做多，跌幅 <= -0.15% 做空，中间不开仓。
       * 入场：02:00 那根 bar（04 号 bar）开盘价；止损 1xATR、止盈 2xATR；
         每天每币最多 1 笔（上限是 2 笔，本策略主动只用 1 笔以压低换手），
         23:30 强制平仓。

  C2 跨币种轮动：每天只做 1 个币（C2-rotation，组合口径）
     赌的假设：三个币每天的相对强弱有延续性，当天开盘后最强/最弱的
     那个币的动量最值得跟；把火力集中在 1 个币上，比三个币全做省
     2/3 成本，且避开当天最弱的币。
     和已试家族的本质不同：前面全是每币独立决策、三个币全做；C2 是
     跨币种选择问题，每天全组合只有 1 笔，决策单位是“哪个币”而不
     是“做不做这个币”。
     规则（事先定死）：
       * 每天 00:00-04:00（前 8 根 30m）收盘后，算三币 4h 涨跌幅
         r = close(04:00)/open(00:00)-1，取 |r| 最大的 1 个币，方向 =
         r 的符号；|r| < 0.25% 则当天空仓。
       * 入场：04:00 那根 bar 开盘价；止损 1xATR、止盈 2xATR；
         每天全组合最多 1 笔，23:30 强制平仓。
       * 口径：单一组合 10 万 USDT 虚拟权益（不是每币 10 万），
         每笔保证金 10% 权益。

  C3 日内资金费率 + 价格背离（C3-fund-diverge）
     赌的假设：费率极端本身不等于价格马上反转（S4 已证伪：胜率 46%
     但盈亏比 0.34-0.46）；只有当费率极端、价格却“没跟”——即
     拥挤方向的价格在 8 小时里根本没走出来——背离才说明拥挤
     的多头/空头是弱的，反转才值得赌。
     和 S4 的本质不同：S4 只看费率、任何价格状态都做；C3 要求
     费率极端 AND 价格 8h 不跟随，两个条件缺一不开仓。
     规则（事先定死）：
       * 用当前 bar 时间之前最新公布的资金费率（无前视）。
       * 做空：最新费率 >= +0.010%，且过去 8h（16 根）价格涨幅 <= +0.10%。
       * 做多：最新费率 <= -0.010%，且过去 8h 价格跌幅 >= -0.10%
         （即跌幅不超过 0.10%，价格没跟跌）。
       * 只在 00:00-20:00 UTC 发信号；止损 1xATR、止盈 1xATR
         （反转短命，不贪 2 倍）；最多持有 4 小时；每天每币最多 2 笔，
         同一币两次入场之间至少间隔 2 小时；23:30 强制平仓。

统一口径（与前置一致）：
  数据：data/gate_30m_180d_{BTC,ETH,SOL}_USDT.csv（2026-05-20~11-15，
  180 个完整 UTC 日），资金费率 data/gate_funding_180d_{...}.json。
  只用缓存，不重新取数。
  成本：一轮开平名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
  资金费按实际费率计（08:00/16:00 结算点，多头付、空头收）。
  仓位：每笔保证金 10% 权益，杠杆 1x；每天每币最多 2 笔（C1/C2
  主动只用 1 笔）；当天最后一根 30m（23:30）收盘强制平仓、不过夜。
  执行：收盘价触发信号、下一根开盘价成交；止损/止盈用盘中高低价
  触发（同根 K 线同时碰到止损和止盈时先判止损，与前置同款约定，
  偏保守、结果可比）。单日 -2% 熔断（前置同款，实测极少触发）。
  窗口：前 90 天 2026-05-20~08-17 / 后 90 天 2026-08-18~11-15 /
  全 180 天，各重置 10 万 USDT 虚拟权益。

运行：python3 gate_iter_C.py
输出：终端打印全部表 + data/gate_iter_C_summary.json
      + data/gate_iter_C_trades.csv
"""
import bisect
import csv
import json
import os
import statistics
from datetime import datetime, timezone, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005}
ROUNDTRIP_COST = 0.0025
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
START_DAY = datetime(2026, 5, 20, tzinfo=timezone.utc)
SPLIT_DAY = datetime(2026, 8, 18, tzinfo=timezone.utc)
ATR_PERIOD = 14


def load_bars(symbol):
    path = os.path.join(DATA_DIR, f"gate_30m_180d_{symbol}.csv")
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    path = os.path.join(DATA_DIR, f"gate_funding_180d_{symbol}.json")
    with open(path) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day=48):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def summarize(equity, start, trades, label):
    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] <= 0]
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0.0
    avg_loss = abs(sum(t["pnl"] for t in losses) / len(losses)) if losses else 0.0
    return {"label": label, "trades": len(trades),
            "win_rate": round(len(wins) / len(trades), 4) if trades else None,
            "net_return": round((equity - start) / start, 4),
            "final_equity": round(equity, 2),
            "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
            "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
            "total_pnl": round(sum(t["pnl"] for t in trades), 2),
            "liquidations": sum(1 for t in trades if t.get("liquidated"))}


def add_mdd(result, curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    result["max_dd"] = round(mdd, 4)
    return result


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def make_engine(symbol, funding, leverage=1):
    """返回 close 用的通用字段：维持保证金对应的爆仓反向波动。"""
    maint = MAINT_RATE[symbol]
    return 1.0 / leverage - maint


# ---------------------------------------------------------------- C1 高波动日门控
def run_c1(bars, funding, symbol, days_subset, label="C1-hivol"):
    atr = atr_wilder(bars)
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 48)
    day_list = sorted(days)
    # 每日开盘 2h 振幅（前 4 根）
    open_range = {}
    for d in day_list:
        db = days[d]
        open_range[d] = max(b["h"] for b in db[:4]) - min(b["l"] for b in db[:4])
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    liq_move = make_engine(symbol, funding)
    equity = START_EQUITY
    trades = []
    curve = [equity]
    stats = {"hivol_days": 0, "days_seen": 0}
    for day, day_bars in days.items():
        stats["days_seen"] += 1
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        traded_today = False
        # 门控：需前 20 个完整日（不含今天）的开盘振幅中位数
        pos_in_list = day_list.index(day)
        if pos_in_list < 20:
            continue
        prior = [open_range[d] for d in day_list[pos_in_list - 20:pos_in_list]]
        med = statistics.median(prior)
        r0 = open_range[day]
        if r0 < 1.3 * med or med == 0:
            continue  # 低波动日：全天空仓
        stats["hivol_days"] += 1
        # 方向：02:00 收盘 vs 00:00 开盘
        ret2h = day_bars[3]["c"] / day_bars[0]["o"] - 1
        if ret2h >= 0.0015:
            sig = 1
        elif ret2h <= -0.0015:
            sig = -1
        else:
            continue
        gi4 = idx_of_t[day_bars[4]["t"]]
        a = atr[gi4]
        if a is None:
            continue
        entry = day_bars[4]["o"]
        margin = MARGIN_FRAC * equity
        notional = margin * 1  # 杠杆 1x
        if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
            continue
        pos = {"symbol": symbol, "variant": label, "direction": sig,
               "entry_t": day_bars[4]["t"], "entry": entry,
               "stop": entry - a if sig == 1 else entry + a,
               "tp": entry + 2 * a if sig == 1 else entry - 2 * a,
               "atr": a, "notional": notional, "margin": margin,
               "exit_t": None, "exit": None, "pnl": 0.0,
               "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
               "cost_usdt": 0.0, "price_pnl": 0.0, "hold_min": None,
               "pnl_pct_equity": 0.0}
        traded_today = True

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        # 从第 5 根 bar（02:30）起检查出场；入场 bar（02:00）本身也可能盘中触及
        for i in range(4, len(day_bars)):
            b = day_bars[i]
            if pos is None:
                break
            if pos["direction"] == 1:
                adv = (pos["entry"] - b["l"]) / pos["entry"]
            else:
                adv = (b["h"] - pos["entry"]) / pos["entry"]
            if adv >= liq_move:
                close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                pos = None
                break
            exited = False
            if pos["direction"] == 1:
                if b["l"] <= pos["stop"]:
                    close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                elif b["h"] >= pos["tp"]:
                    close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
            else:
                if b["h"] >= pos["stop"]:
                    close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                elif b["l"] <= pos["tp"]:
                    close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
            if exited:
                pos = None
                break
            if i == len(day_bars) - 1:
                close_trade(pos, b["t"], b["c"], "eod")
                pos = None
                break
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    res = summarize(equity, START_EQUITY, trades, label)
    res["symbol"] = symbol
    res["days"] = stats["days_seen"]
    res["hivol_days"] = stats["hivol_days"]
    res["avg_hold_min"] = round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None
    add_mdd(res, curve)
    return res, trades


# ---------------------------------------------------------------- C2 跨币种轮动（组合口径）
def run_c2(data, days_subset, label="C2-rotation"):
    # data: {symbol: (bars, funding)}；atr 按币分别算
    atrs = {}
    days_by_sym = {}
    for sym, (bars, funding) in data.items():
        atrs[sym] = atr_wilder(bars)
        days_by_sym[sym] = group_days(bars, 48)
    ref_days = sorted(days_by_sym[SYMBOLS[0]])
    if days_subset is not None:
        ref_days = [d for d in ref_days if d in days_subset]
    equity = START_EQUITY
    trades = []
    curve = [equity]
    picks = {}
    for day in ref_days:
        day_start_equity = equity
        day_pnl = 0.0
        # 00:00-04:00（前 8 根）4h 涨跌幅
        rets = {}
        for sym in SYMBOLS:
            db = days_by_sym[sym][day]
            rets[sym] = db[7]["c"] / db[0]["o"] - 1
        pick = max(rets, key=lambda s: abs(rets[s]))
        r = rets[pick]
        if abs(r) < 0.0025:
            continue
        sig = 1 if r > 0 else -1
        picks[pick] = picks.get(pick, 0) + 1
        bars, funding = data[pick]
        db = days_by_sym[pick][day]
        idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
        gi = idx_of_t[db[8]["t"]]
        a = atrs[pick][gi]
        if a is None:
            continue
        entry = db[8]["o"]
        margin = MARGIN_FRAC * equity
        notional = margin * 1
        if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
            continue
        liq_move = make_engine(pick, funding)
        pos = {"symbol": pick, "variant": label, "direction": sig,
               "entry_t": db[8]["t"], "entry": entry,
               "stop": entry - a if sig == 1 else entry + a,
               "tp": entry + 2 * a if sig == 1 else entry - 2 * a,
               "atr": a, "notional": notional, "margin": margin,
               "exit_t": None, "exit": None, "pnl": 0.0,
               "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
               "cost_usdt": 0.0, "price_pnl": 0.0, "hold_min": None,
               "pnl_pct_equity": 0.0, "pick_4h_ret": round(r, 4)}

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i in range(8, len(db)):
            b = db[i]
            if pos["direction"] == 1:
                adv = (pos["entry"] - b["l"]) / pos["entry"]
            else:
                adv = (b["h"] - pos["entry"]) / pos["entry"]
            if adv >= liq_move:
                close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                break
            exited = False
            if pos["direction"] == 1:
                if b["l"] <= pos["stop"]:
                    close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                elif b["h"] >= pos["tp"]:
                    close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
            else:
                if b["h"] >= pos["stop"]:
                    close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                elif b["l"] <= pos["tp"]:
                    close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
            if exited:
                break
            if i == len(db) - 1:
                close_trade(pos, b["t"], b["c"], "eod")
                break
    res = summarize(equity, START_EQUITY, trades, label)
    res["symbol"] = "portfolio-1pick/day"
    res["days"] = len(ref_days)
    res["picks"] = picks
    res["avg_hold_min"] = round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None
    add_mdd(res, curve)
    return res, trades


# ---------------------------------------------------------------- C3 资金费率 + 价格背离
def run_c3(bars, funding, symbol, days_subset, label="C3-fund-diverge"):
    atr = atr_wilder(bars)
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 48)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    liq_move = make_engine(symbol, funding)
    fund_times = sorted(funding.keys())

    def latest_funding(t):
        i = bisect.bisect_right(fund_times, t) - 1
        return funding[fund_times[i]] if i >= 0 else 0.0

    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        last_exit_t = None
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl, last_exit_t
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            last_exit_t = exit_t
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                if pos["direction"] == 1:
                    adv = (pos["entry"] - b["l"]) / pos["entry"]
                else:
                    adv = (b["h"] - pos["entry"]) / pos["entry"]
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if (b["t"] - pos["entry_t"]) >= 4 * 3600:
                    close_trade(pos, b["t"], b["c"], "time_expiry"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if last_exit_t is not None and (b["t"] - last_exit_t) < 2 * 3600:
                    continue
                if not (0.0 <= hour < 20.0):
                    continue
                if a is None or gi < 16:
                    continue
                fr = latest_funding(b["t"])
                ret8h = bars[gi]["c"] / bars[gi - 16]["c"] - 1
                sig = 0
                if fr >= 0.00010 and ret8h <= 0.0010:
                    sig = -1
                elif fr <= -0.00010 and ret8h >= -0.0010:
                    sig = 1
                if sig == 0:
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry,
                       "stop": entry - a if sig == 1 else entry + a,
                       "tp": entry + a if sig == 1 else entry - a,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "price_pnl": 0.0, "hold_min": None,
                       "pnl_pct_equity": 0.0, "funding_at_signal": fr,
                       "ret8h_at_signal": round(ret8h, 4)}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    res = summarize(equity, START_EQUITY, trades, label)
    res["symbol"] = symbol
    res["days"] = len(days)
    res["avg_hold_min"] = round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None
    add_mdd(res, curve)
    return res, trades


# ---------------------------------------------------------------- 主流程
def main():
    print("Gate 迭代 C：3 个新方向（30m、180 天、全模拟，1x）")
    print(f"窗口：{START_DAY.date()}~2026-11-15，前 90 天 {START_DAY.date()}~2026-08-17，"
          f"后 90 天 2026-08-18~2026-11-15")
    data = {}
    for sym in SYMBOLS:
        bars = load_bars(sym)
        funding = load_funding(sym)
        data[sym] = (bars, funding)
        days = group_days(bars, 48)
        print(f"[{sym}] 完整交易日：{len(days)} 天，首日 {min(days)} 末日 {max(days)}，"
              f"资金费率 {len(funding)} 条")
    all_results = []
    all_trades = []

    def collect(res, trades, label, split_name):
        res["split"] = split_name
        all_results.append(res)
        if split_name == "180d":
            for t in trades:
                t["variant"] = label
                t["split"] = "180d"
            all_trades.extend(trades)
        extra = ""
        if "hivol_days" in res:
            extra = f" 高波动日={res['hivol_days']}/{res['days']}"
        if "picks" in res:
            extra = f" 选中分布={res['picks']}"
        print(f"[{label} {res.get('symbol','')} {split_name}] 笔数={res['trades']} "
              f"胜率={res['win_rate']} 净收益={res['net_return']*100:+.2f}% "
              f"盈亏比={res['profit_factor']} 最大回撤={res['max_dd']*100:.2f}% "
              f"平均持仓={res['avg_hold_min']}分钟 爆仓={res['liquidations']}{extra}")
        return res

    for sym in SYMBOLS:
        bars, funding = data[sym]
        days_all = set(group_days(bars, 48).keys())
        days_a = {d for d in days_all if d < SPLIT_DAY.date()}
        days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
        for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
            res, trades = run_c1(bars, funding, sym, subset)
            collect(res, trades, "C1-hivol", split_name)
    for sym in SYMBOLS:
        bars, funding = data[sym]
        days_all = set(group_days(bars, 48).keys())
        days_a = {d for d in days_all if d < SPLIT_DAY.date()}
        days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
        for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
            res, trades = run_c3(bars, funding, sym, subset)
            collect(res, trades, "C3-fund-diverge", split_name)
    # C2：组合口径，三窗口各跑一次
    days_all = set(group_days(data["BTC_USDT"][0], 48).keys())
    days_a = {d for d in days_all if d < SPLIT_DAY.date()}
    days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
    for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
        res, trades = run_c2(data, subset)
        collect(res, trades, "C2-rotation", split_name)

    print("\n=== 汇总：三币平均净收益 1x（C1/C3 各币独立 10 万；C2 为单一组合）===")
    for label in ["C1-hivol", "C3-fund-diverge", "C2-rotation"]:
        for split_name in ["180d", "前90d", "后90d"]:
            rs = [r for r in all_results if r["label"] == label and r["split"] == split_name]
            if not rs:
                continue
            avg = sum(r["net_return"] for r in rs) / len(rs)
            tot = sum(r["trades"] for r in rs)
            wrs = [r["win_rate"] for r in rs if r["win_rate"] is not None]
            pfs = [r["profit_factor"] for r in rs if r["profit_factor"] is not None]
            mdds = [r["max_dd"] for r in rs]
            print(f"{label} {split_name}：平均净收益 {avg*100:+.2f}%  总笔数 {tot}  "
                  f"胜率 {min(wrs)*100:.1f}%~{max(wrs)*100:.1f}%  "
                  f"盈亏比 {min(pfs) if pfs else None}~{max(pfs) if pfs else None}  "
                  f"最大回撤 {min(mdds)*100:.2f}%~{max(mdds)*100:.2f}%")

    print("\n=== 成本拆解（全 180 天，1x）：毛利（扣资金费后）vs 成本拖累 ===")
    for label in ["C1-hivol", "C3-fund-diverge"]:
        for sym in SYMBOLS:
            ts = [t for t in all_trades if t.get("variant") == label and t.get("symbol") == sym]
            if not ts:
                continue
            gross = sum(t.get("price_pnl", 0) - t.get("funding_cost_usdt", 0) for t in ts)
            cost = sum(t.get("cost_usdt", 0) for t in ts)
            print(f"[{label} {sym}] 笔数={len(ts)} 毛利={gross:+.0f} USDT "
                  f"成本=-{cost:.0f} USDT 净={gross-cost:+.0f} USDT")
    ts = [t for t in all_trades if t.get("variant") == "C2-rotation"]
    if ts:
        gross = sum(t.get("price_pnl", 0) - t.get("funding_cost_usdt", 0) for t in ts)
        cost = sum(t.get("cost_usdt", 0) for t in ts)
        print(f"[C2-rotation 组合] 笔数={len(ts)} 毛利={gross:+.0f} USDT "
              f"成本=-{cost:.0f} USDT 净={gross-cost:+.0f} USDT")

    print("\n=== 出场原因分布（全 180 天）===")
    for label in ["C1-hivol", "C2-rotation", "C3-fund-diverge"]:
        ts = [t for t in all_trades if t.get("variant") == label]
        from collections import Counter
        print(f"{label}: {dict(Counter(t.get('reason') for t in ts))}")

    with open(os.path.join(DATA_DIR, "gate_iter_C_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_C_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "split", "symbol", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_usdt", "price_pnl_usdt",
                    "cost_usdt", "funding_cost_usdt", "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x.get("symbol", ""), x.get("variant", ""))):
            w.writerow([t.get("variant", ""), t.get("split", ""), t.get("symbol", ""),
                        "LONG" if t.get("direction") == 1 else ("SHORT" if t.get("direction") == -1 else t.get("variant", "")),
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t.get("entry"), t.get("exit"), t.get("notional"),
                        round(t["pnl"], 2), round(t.get("price_pnl", 0), 2),
                        round(t.get("cost_usdt", 0), 2), round(t.get("funding_cost_usdt", 0), 2),
                        t.get("reason", ""), t.get("liquidated", False), t.get("hold_min")])
    print("\n汇总已写入：data/gate_iter_C_summary.json")
    print("明细已写入：data/gate_iter_C_trades.csv")
    print("模拟结束：本脚本不下单、不开户、不碰真钱。")


if __name__ == "__main__":
    main()
