#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十五轮：历史验证 2026-11-17 八条纸面计划的模板
=================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（用户指出）：“可以用历史数据去判断啊。”不要等今晚 23:00 UTC
计划到期再验——8 条计划本身只是一天的样本，样本太小；直接用历史
数据验证这 8 条计划背后的模板有没有 edge。正在跑的那份盘中验证
检查不用停，它照常出结果；本轮是另开的历史验证，两件事不混。

抽象方法：读 SMC主观分析-2026-11-17.md 里的 8 条计划，把每条的
触发逻辑原样抽象成模板——不要照抄当天的具体价格，价格是那天的，
逻辑是通用的。三个模板各跑一个组合，共 3 个组合。

  模板 A（BTC 计划：扫荡反转做多）：
    ① 15m 影线刺破 48h 滚动最低（等低流动性）；
    ② 随后一根 15m 收盘回到该水平上方（收回确认）；
    ③ 再一根 15m 收盘上破扫荡+收回段的最高点（CHOCH 确认）；
    ④ 入场为 CHOCH 完成根的下一根 15m 开盘价；只在 Killzone 内入场。
  模板 B（SOL 计划：FVG 回踩做多）：
    ① 15m 回踩进 1h 看涨 FVG 区间；
    ② 随后一根 15m 收盘回到 FVG 上沿上方（踩住确认）；
    ③ 入场为确认根的下一根 15m 开盘价；只在 Killzone 内入场。
  模板 C（ETH/LINK/XRP/BNB/ADA/DOGE 计划：供给拒绝做空）：
    ① 15m 摸进 1h 供给区（看跌 FVG，或等高位带）；
    ② 随后一根 15m 收盘回到供给区下沿下方（拒绝确认）；
    ③ 入场为确认根的下一根 15m 开盘价；只在 Killzone 内入场。

锁定的通用规则（跑前定死，单组参数，不用全样本挑参数）：
  数据：1h 用 365 天缓存（2025-11-16 00:00~2026-11-16 00:00，8,761 根/币），
    其中末根 11-16 00:00 是取数时未走完的半根（第八轮已有记录），改用 15m
    合成的已完成根，并补 11-16 01:00~23:00 共 24 根（合成前先校验重叠段
    与缓存 1h 一致，半根除外），合并后 8,784 根/币；15m 用 103 天缓存
    （2026-08-06~2026-11-16，9,888 根/币）。1h 只做结构/水平/ATR，
    交易全部在 15m 上执行，所以三个模板的窗口都是 103 天 15m，
    前半段 2026-08-06~09-25（51 天）、后半段 2026-09-26~11-16
    （52 天）。各窗口重置 10 万 USDT 虚拟权益（每币独立）。
  止损 1xATR、止盈 2xATR（用户要求的 1:2）。ATR 用 1h Wilder ATR14，
    取入场根时刻之前最后一个已收盘 1h 根的 ATR（与纸面计划口径一致）。
  成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
    双边）；资金费按 Gate 实际费率序列计入；单日 -2% 熔断；单笔最坏
    情况 (ATR+成本) > 1% 权益跳过；每天每币最多 2 笔；最长持有 96 根
    15m（= 一整天，约等于无最长持有，以当天收盘强制平仓为准）；
    持仓不过夜。
  Killzone：伦敦 08:00–11:00 UTC、纽约 13:00–16:00 UTC。只对入场
    根判定（入场根开盘小时落在 Killzone 内才进）；扫荡/触及/确认步
    本身不限时段。Killzone 外完成的确认计入 killzone_skipped，不进场。
  确认的严格读法（与 11-17 盘中检查 08:44 UTC 的口径一致）：触及与
    确认永远是不同根——确认根必须严格晚于触及根；同根收盘不算“随后”。
    模板 A 里收回根严格晚于扫荡根、CHOCH 根严格晚于收回根。
  只用已收盘的根：1h 结构（摆动点、FVG、等高）只用已收盘的 1h 根；
    15m 触发只用已收盘的 15m 根；入场永远是确认根的下一根 15m 开盘价。

  模板 A 细则（扫荡反转做多，只做多）：
    水平 L：48h 滚动最低 = 此前 48h 内已收盘 1h 根的最低点（1h 最低
      点即其四根 15m 的最低点，故与 15m 口径一致）。每根 15m 根按
      其开盘时刻之前最后一个已收盘 1h 根确定 L（同一小时内 L 不变）。
    扫荡：15m 根 i 的最低价 < L（影线刺破），且该水平是开盘前已
      确定的 48h 最低。扫荡根当根只记扫荡，不判收回。
    收回：扫荡根之后 16 根内（i+1..i+16，4h），出现一根收盘价 > L
      的 15m 根 j。记 H = 扫荡根 i 至收回根 j（含）各根最高价的最大值。
    CHOCH：收回根之后、扫荡根之后 16 根内，出现一根收盘价 > H 的
      15m 根 m。入场根 = m+1。16 根内未完成任一步则过期，状态机复位。
    等待期间出现更深的新扫荡不覆盖旧 setup（先到先得，复位后才重算）。

  模板 B 细则（FVG 回踩做多，只做多）：
    看涨 FVG（1h）：连续三根 A、B、C，C 最低 > A 最高，区间
      [A 最高, C 最低]，宽度 >= 0.5xATR（1h Wilder ATR14，取 C 根
      的 ATR；0.5xATR 是主观分析“大 FVG”的口径，SOL 计划那根是
      0.84xATR）。形成时刻 = C 根收盘时刻；此后 24h 内有效。
    失效：1h 收盘价跌破区间下沿则该 FVG 作废（以整点收盘的 15m 根
      即 :45 根的收盘价判定，与 1h 收盘价同一口径）。
    候选：空闲时取最新形成、未失效、未过期、且位于现价下方或包含
      现价的 FVG（上沿 <= 上一根收盘价，或区间包含上一根收盘价；
      多个取上沿最高者、再取最新形成者）。
    触及：15m 根 i 的最低价 <= FVG 上沿且收盘价 >= FVG 下沿
      （踩进区间且未收破下沿）。触及根当根不判确认。
    确认：触及后 8 根内（i+1..i+8，2h），出现一根收盘价 > FVG 上沿
      的 15m 根 j。入场根 = j+1。8 根内未确认则该次触及过期，FVG
      本身仍可被再次触及。触及后、确认前若某根收盘价 < FVG 下沿，
      则该次触及作废（FVG 本身只在 1h 收盘跌破下沿时才作废）。

  模板 C 细则（供给拒绝做空，只做空）：
    供给区有两种，同按 [下沿 lo, 上沿 hi] 的区间处理：
      (a) 看跌 FVG（1h）：连续三根 A、B、C，C 最高 < A 最低，区间
          [C 最高, A 最低]，宽度 >= 0.5xATR（取 C 根的 ATR）。
          形成时刻 = C 根收盘时刻；此后 24h 内有效。
      (b) 等高位带（1h）：N=3 摆动高（检测器定义：h[i] 严格大于左
          3 根、不低于右 3 根，确认于 i+3 根收盘时）。新摆动高与
          锚点（簇内第一个摆动高）价差 <= 0.1xATR（取新摆动高确认
          根的 1h ATR；0.1xATR 是检测器等高容差口径），且与簇内
          上一个成员间隔 <= 48h，则并入该簇；否则另起一簇。簇有
          >= 2 个成员时成为供给区，区间 = [簇内最低价, 簇内最高价]，
          自最后一个成员确认时刻起 48h 内有效。
    失效：1h 收盘价上破区间上沿则该供给区作废（以 :45 根收盘价判定）。
    候选：空闲时取最新形成、未失效、未过期、且位于现价上方或包含
      现价的供给区（下沿 >= 上一根收盘价，或区间包含上一根收盘价；
      多个取下沿最低者、再取最新形成者）。
    触及：看跌 FVG 要求 15m 根 i 的最高价 >= lo 且最低价 <= hi
      （摸进区间）且收盘价 <= hi（未收穿上沿）；等高位带要求
      15m 根 i 的最高价 > hi（影线刺破带顶）且收盘价 <= hi。
      触及根当根不判确认。
    确认：触及后 8 根内（i+1..i+8），出现一根收盘价 < lo 的 15m 根
      j。入场根 = j+1。8 根内未确认则该次触及过期，供给区本身仍可
      被再次触及。触及后、确认前若某根收盘价 > hi，则该次触及作废
      （供给区本身只在 1h 收盘上破上沿时才作废）。

  与之前轮次的异同（先写在代码头，报告 §5 再展开）：
    A vs 第十一轮 S1（扫荡+CHOCH）：同为扫荡后反转，但 S1 在 1h 上
      用 N=2 摆动点、CHOCH 是收盘破反向摆动点、无收回水平这一步、
      无 Killzone；本轮在 15m 上、水平是 48h 滚动最低、多一步“收盘
      回到水平上方”的收回确认、CHOCH 对照的是扫荡+收回段的最高点、
      加 Killzone。
    B vs 第十一轮 S2（OB 回踩）/ S3（FVG 回补+4h 趋势）：同为回踩
      入场，但 S2 的主区间是 OB（FVG 只是兜底且 1,905 次 BOS 里一次
      都没触发）、S3 是 1h 上触及即入场、无确认步；本轮主区间就是
      FVG（>= 0.5xATR）、必须收盘回到上沿上方才确认、15m 执行。
    C vs 第十一轮 S2c（BOS 直接追）/ 第十二轮 S2（1h 结构+15m 入场，
      OB 回踩）/ 第十四轮 B（MSS 两步确认）：C 与 S2c 方向相反（等
      拒绝而不是追突破）；与十二轮 S2 同为 1h 结构+15m 入场，但
      区间是供给 FVG/等高位而不是 OB、确认是收盘回到下沿下方而不
      是 MSS 两步；与十四轮 B 同为“触及+确认”，但确认只是收盘回到
      区间下沿下方，不要求 MSS 位移证据，且不要求诱导和三条件 OB。
    三个模板的逻辑都来自 2026-11-17 当天 8 条计划（价格除外）；抽象
    参数（48h、0.5xATR、8/16 根、24h/48h 有效期）是本轮跑前定死
    的单组参数，未做网格搜索，未用本轮回测结果回头调参。但要诚实
    写明：这些参数是在已知 11-17 计划写法、且已知前十四轮结论的
    情况下选的，不是盲选；本轮验证的是“这套抽象出来的模板”，不是
    “11-17 当天那 8 条计划本身”。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

前视防控（写死在代码里）：
  - 1h 结构、FVG、等高、48h 水平全部只用已收盘的 1h 根；15m 触发
    只用已收盘的 15m 根；入场永远是确认根的下一根 15m 开盘价。
  - FVG/等高位在形成根收盘之后才可用；失效用 1h 收盘价判定。
  - 触及与确认永远是不同根；Killzone 只对入场根判定。

引擎复用：通用模拟、成本、资金费、汇总函数复用 gate_iter_round11.py
  的已验证函数（simulate_generic、summarize、atr_wilder、synthesize、
  load_bars、load_funding、group_days、t_value），口径零漂移；新信号
  逻辑（48h 滚动最低、1h FVG、等高簇、三模板状态机）写在本脚本里。

运行：python3 gate_iter_round15.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round15_summary.json
      + data/gate_iter_round15_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import bisect
import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round11 as R11  # 复用第十一轮已验证的通用引擎与成本口径

DATA_DIR = os.path.join(SCRIPT_DIR, "data")
SYMBOLS = R11.SYMBOLS
START_EQUITY = R11.START_EQUITY
SPLIT_15M = R11.SPLIT_15M

# ---- 锁定的参数（跑前定死，单组参数）----
SL_MULT = 1.0
TP_MULT = 2.0
SWING_N = 3            # 摆动点 N=3（检测器默认）
FVG_MIN_ATR = 0.5      # 模板 B/C 的 FVG 最小尺寸：0.5xATR（主观分析“大 FVG”口径）
ROLL_LOW_HOURS = 48    # 模板 A：48h 滚动最低（以 1h 根计 48 根）
SEQ_WINDOW = 16        # 扫荡/收回/CHOCH 序列总窗口：16 根 15m（4h）
CONFIRM_WINDOW = 8     # 触及后确认窗口：8 根 15m（2h）
ZONE_VALID_HOURS = 24  # FVG 有效期 24h
EQH_VALID_HOURS = 48   # 等高位有效期 48h
EQH_TOL_ATR = 0.1      # 等高容差 0.1xATR（检测器口径）
KILLZONE_HOURS = {8, 9, 10, 13, 14, 15}  # 伦敦/纽约 Killzone（UTC 小时）
MAX_HOLD_15M = 96      # 约等于无最长持有（日内 EOD 平仓为准）
MAX_PER_DAY = 2


# ----------------------------------------------------------------------
# 1h 合成与校验：缓存 1h（至 11-15）+ 15m 合成的 11-16 当天 24 根
# ----------------------------------------------------------------------
def build_1h_combined():
    """返回 {sym: (bars1h_combined, atr1h)}，并校验重叠段合成 1h 与缓存一致。"""
    out = {}
    max_rel_err = 0.0
    for sym in SYMBOLS:
        cached = R11.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        bars15 = R11.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        synth = R11.synthesize(bars15, 4, 3600)
        # 重叠段校验：合成 1h 与缓存 1h 在同一时间戳上 OHLC 应一致。
        # 已知例外（第八轮报告已有记录）：缓存 1h 的末根 2026-11-16 00:00
        # 是取数时未走完的半根（o=h=l=c 同价），与 15m 合成的已完成根不同，
        # 该根不参与校验、也不进入合并序列，改用合成根。
        cache_by_t = {b["t"]: b for b in cached}
        last_t = cached[-1]["t"]
        for b in synth:
            if b["t"] in cache_by_t and b["t"] != last_t:
                c = cache_by_t[b["t"]]
                for k in ("o", "h", "l", "c"):
                    denom = abs(c[k]) if c[k] != 0 else 1.0
                    err = abs(b[k] - c[k]) / denom
                    max_rel_err = max(max_rel_err, err)
        # 合并：缓存去掉末根半根 + 合成中 t >= 末根时刻的根（11-16 当天 24 根）
        extra = [b for b in synth if b["t"] >= last_t]
        assert len(extra) == 24, f"{sym} 合成 1h 补 11-16 应为 24 根，实际 {len(extra)}"
        assert extra[0]["t"] == last_t and extra[-1]["t"] == last_t + 23 * 3600
        combined = cached[:-1] + extra
        assert all(combined[i]["t"] < combined[i + 1]["t"] for i in range(len(combined) - 1))
        out[sym] = (combined, R11.atr_wilder(combined))
    print(f"1h 合成校验：重叠段合成 1h vs 缓存 1h 的最大相对误差 {max_rel_err:.2e}；"
          f"合并后每币 {len(out['BTC_USDT'][0])} 根 1h。")
    assert max_rel_err < 1e-9, "合成 1h 与缓存 1h 不一致，停止！"
    return out


def atr1h_at(bars1h, atr1h, t_entry):
    """入场根开盘时刻 t_entry 之前最后一个已收盘 1h 根的 ATR。
    1h 根 k 的收盘时刻 = t_k + 3600。"""
    close_ts = [b["t"] + 3600 for b in bars1h]
    idx = bisect.bisect_right(close_ts, t_entry) - 1
    if idx < 0:
        return None
    return atr1h[idx]


def in_killzone(t):
    return datetime.fromtimestamp(t, timezone.utc).hour in KILLZONE_HOURS


# ----------------------------------------------------------------------
# 1h 结构：FVG、N=3 摆动高、等高簇
# ----------------------------------------------------------------------
def fvgs_1h(bars, atr, direction):
    """返回 [{lo, hi, c_idx, formed_close_t}]，按形成时间排序。
    direction=+1 看涨（C 最低 > A 最高），-1 看跌（C 最高 < A 最低）。
    宽度 >= 0.5xATR（取 C 根的 1h ATR）。"""
    out = []
    for c in range(2, len(bars)):
        if atr[c] is None:
            continue
        A, C = bars[c - 2], bars[c]
        if direction == 1:
            if C["l"] > A["h"]:
                lo, hi = A["h"], C["l"]
                if hi - lo >= FVG_MIN_ATR * atr[c]:
                    out.append({"lo": lo, "hi": hi, "c_idx": c,
                                "formed_close_t": C["t"] + 3600})
        else:
            if C["h"] < A["l"]:
                lo, hi = C["h"], A["l"]
                if hi - lo >= FVG_MIN_ATR * atr[c]:
                    out.append({"lo": lo, "hi": hi, "c_idx": c,
                                "formed_close_t": C["t"] + 3600})
    return out


def swing_highs_n3(bars):
    """检测器定义 N=3 摆动高：h[i] 严格大于左 3 根、不低于右 3 根。
    返回 [{price, idx, conf_close_t}]，确认于 i+3 根收盘时。"""
    out = []
    n = len(bars)
    for i in range(3, n - 3):
        h = bars[i]["h"]
        if all(h > bars[j]["h"] for j in range(i - 3, i)) and \
           all(h >= bars[j]["h"] for j in range(i + 1, i + 4)):
            out.append({"price": h, "idx": i,
                        "conf_close_t": bars[i + 3]["t"] + 3600})
    return out


def eqhigh_zones(bars, atr):
    """等高位带：摆动高按锚点聚簇（价差 <= 0.1xATR、与簇内上一个成员
    间隔 <= 48h），>= 2 个成员成区，区间=[簇内最低, 簇内最高]。
    返回 [{lo, hi, avail_t, last_conf_t}]，avail_t = 第 2 个成员确认时刻。"""
    swings = swing_highs_n3(bars)
    clusters = []  # 每簇 {anchor, members:[{price, conf_close_t}], ...}
    for s in swings:
        a = atr[s["idx"] + 3]  # 确认根的 ATR（确认根下标 i+3）
        placed = False
        for cl in clusters:
            last = cl["members"][-1]
            if abs(s["price"] - cl["anchor"]) <= EQH_TOL_ATR * (a if a else 0.0) and \
               s["conf_close_t"] - last["conf_close_t"] <= EQH_VALID_HOURS * 3600:
                cl["members"].append(s)
                placed = True
                break
        if not placed:
            clusters.append({"anchor": s["price"], "members": [s]})
    zones = []
    for cl in clusters:
        m = cl["members"]
        if len(m) < 2:
            continue
        prices = [x["price"] for x in m]
        zones.append({"lo": min(prices), "hi": max(prices),
                      "avail_t": m[1]["conf_close_t"],
                      "last_conf_t": m[-1]["conf_close_t"]})
    zones.sort(key=lambda z: z["avail_t"])
    return zones


def roll_low_48h(bars1h):
    """对每个 1h 根下标 k，返回此前 48 根 1h 根的最低点
    （即此前 48h 的滚动最低），k < 48 时用已有根。"""
    out = []
    for k in range(len(bars1h)):
        lo = min(b["l"] for b in bars1h[max(0, k - ROLL_LOW_HOURS):k]) \
            if k > 0 else None
        out.append(lo)
    return out


# ----------------------------------------------------------------------
# 模板 A：扫荡反转做多（15m）
# ----------------------------------------------------------------------
def build_A(bars15, bars1h, atr1h):
    n = len(bars15)
    low48 = roll_low_48h(bars1h)
    close_ts_1h = [b["t"] + 3600 for b in bars1h]

    def level_at(t):
        """15m 根开盘时刻 t 之前最后一个已收盘 1h 根对应的 48h 滚动最低。"""
        k = bisect.bisect_right(close_ts_1h, t) - 1
        if k < 0:
            return None
        return low48[k]

    signals = {}
    fun = Counter()
    state = "idle"  # idle / swept / reclaimed
    lvl = sweep_i = rec_j = H = deadline = None
    for i in range(n):
        b = bars15[i]
        t = b["t"]
        if state != "idle" and i > deadline:
            fun["expired"] += 1
            state = "idle"
            lvl = sweep_i = rec_j = H = deadline = None
        if state == "idle":
            L = level_at(t)
            if L is not None and b["l"] < L:
                state, lvl, sweep_i = "swept", L, i
                deadline = i + SEQ_WINDOW
                fun["sweeps"] += 1
        elif state == "swept":
            if b["c"] > lvl:
                state, rec_j = "reclaimed", i
                H = max(x["h"] for x in bars15[sweep_i:i + 1])
                fun["reclaims"] += 1
        elif state == "reclaimed":
            if b["c"] > H:
                fun["choch"] += 1
                if i + 1 < n:
                    et = bars15[i + 1]["t"]
                    if in_killzone(et):
                        a = atr1h_at(bars1h, atr1h, et)
                        if a is not None:
                            signals[et] = {"direction": 1, "atr": a, "tag": "R15-A"}
                            fun["signals"] += 1
                        else:
                            fun["signal_no_atr"] += 1
                    else:
                        fun["killzone_skipped"] += 1
                else:
                    fun["signal_no_entry_bar"] += 1
                state = "idle"
                lvl = sweep_i = rec_j = H = deadline = None
    return signals, fun


# ----------------------------------------------------------------------
# 模板 B：FVG 回踩做多（15m）
# ----------------------------------------------------------------------
def build_B(bars15, bars1h, atr1h):
    n = len(bars15)
    fvg_list = fvgs_1h(bars1h, atr1h, +1)
    fun = Counter({"fvgs_formed": len(fvg_list)})
    signals = {}
    # 活跃 FVG：按形成时刻排序；逐根推进时维护
    fvg_by_t = sorted(fvg_list, key=lambda z: z["formed_close_t"])
    active = []  # 未失效、未过期的 FVG（dict 引用）
    fi = 0
    state = "idle"  # idle / touched
    cur = None  # 当前 FVG
    touch_i = None
    deadline = None
    for i in range(n):
        b = bars15[i]
        t = b["t"]
        # 纳入新形成且已收盘的 FVG
        while fi < len(fvg_by_t) and fvg_by_t[fi]["formed_close_t"] <= t:
            active.append(dict(fvg_by_t[fi]))
            fi += 1
        # 过期：形成超过 24h
        active = [z for z in active if t < z["formed_close_t"] + ZONE_VALID_HOURS * 3600]
        # 失效：整点收盘（:45 根）收盘价跌破下沿
        if (t + 900) % 3600 == 0:
            still = []
            for z in active:
                if b["c"] < z["lo"]:
                    fun["voided_1h_close"] += 1
                    if state == "touched" and cur is z:
                        state, cur, touch_i, deadline = "idle", None, None, None
                        fun["voided_while_touched"] += 1
                else:
                    still.append(z)
            active = still
        prev_c = bars15[i - 1]["c"] if i > 0 else None
        if state == "touched" and not any(cur is z for z in active):
            # FVG 在触及后、确认前过期或被 1h 收盘作废：该次触及作废
            fun["expired_zone_gone"] += 1
            state, cur, touch_i, deadline = "idle", None, None, None
        if state == "idle":
            # 候选：位于现价下方或包含现价；取上沿最高者、再取最新形成者
            cands = [z for z in active
                     if z["hi"] <= prev_c or (z["lo"] <= prev_c <= z["hi"])] \
                if prev_c is not None else []
            if not cands:
                continue
            cur = max(cands, key=lambda z: (z["hi"], z["formed_close_t"]))
            if b["l"] <= cur["hi"] and b["c"] >= cur["lo"]:
                state, touch_i = "touched", i
                deadline = i + CONFIRM_WINDOW
                fun["touches"] += 1
            else:
                cur = None
        elif state == "touched":
            if i > deadline:
                fun["expired_no_confirm"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] < cur["lo"]:
                fun["voided_seq_close_below"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] > cur["hi"]:
                fun["confirms"] += 1
                if i + 1 < n:
                    et = bars15[i + 1]["t"]
                    if in_killzone(et):
                        a = atr1h_at(bars1h, atr1h, et)
                        if a is not None:
                            signals[et] = {"direction": 1, "atr": a, "tag": "R15-B"}
                            fun["signals"] += 1
                        else:
                            fun["signal_no_atr"] += 1
                    else:
                        fun["killzone_skipped"] += 1
                else:
                    fun["signal_no_entry_bar"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
    return signals, fun


# ----------------------------------------------------------------------
# 模板 C：供给拒绝做空（15m）
# ----------------------------------------------------------------------
def build_C(bars15, bars1h, atr1h):
    n = len(bars15)
    fvg_list = fvgs_1h(bars1h, atr1h, -1)
    eq_list = eqhigh_zones(bars1h, atr1h)
    zones_all = []
    for z in fvg_list:
        zones_all.append({"lo": z["lo"], "hi": z["hi"], "kind": "fvg",
                          "avail_t": z["formed_close_t"],
                          "expire_t": z["formed_close_t"] + ZONE_VALID_HOURS * 3600})
    for z in eq_list:
        zones_all.append({"lo": z["lo"], "hi": z["hi"], "kind": "eqhigh",
                          "avail_t": z["avail_t"],
                          "expire_t": z["last_conf_t"] + EQH_VALID_HOURS * 3600})
    zones_all.sort(key=lambda z: z["avail_t"])
    fun = Counter({"zones_formed_fvg": len(fvg_list),
                   "zones_formed_eqhigh": len(eq_list)})
    signals = {}
    active = []
    zi = 0
    state = "idle"  # idle / touched
    cur = None
    touch_i = None
    deadline = None
    for i in range(n):
        b = bars15[i]
        t = b["t"]
        while zi < len(zones_all) and zones_all[zi]["avail_t"] <= t:
            active.append(dict(zones_all[zi]))
            zi += 1
        active = [z for z in active if t < z["expire_t"]]
        # 失效：整点收盘（:45 根）收盘价上破上沿
        if (t + 900) % 3600 == 0:
            still = []
            for z in active:
                if b["c"] > z["hi"]:
                    fun["voided_1h_close"] += 1
                    if state == "touched" and cur is z:
                        state, cur, touch_i, deadline = "idle", None, None, None
                        fun["voided_while_touched"] += 1
                else:
                    still.append(z)
            active = still
        prev_c = bars15[i - 1]["c"] if i > 0 else None
        if state == "touched" and not any(cur is z for z in active):
            # 供给区在触及后、确认前过期或被 1h 收盘作废：该次触及作废
            fun["expired_zone_gone"] += 1
            state, cur, touch_i, deadline = "idle", None, None, None
        if state == "idle":
            cands = [z for z in active
                     if z["lo"] >= prev_c or (z["lo"] <= prev_c <= z["hi"])] \
                if prev_c is not None else []
            if not cands:
                continue
            cur = min(cands, key=lambda z: (z["lo"], -z["avail_t"]))
            touched = False
            if cur["kind"] == "fvg":
                touched = b["h"] >= cur["lo"] and b["l"] <= cur["hi"] and b["c"] <= cur["hi"]
            else:  # eqhigh：影线刺破带顶且收盘未收穿
                touched = b["h"] > cur["hi"] and b["c"] <= cur["hi"]
            if touched:
                state, touch_i = "touched", i
                deadline = i + CONFIRM_WINDOW
                fun["touches"] += 1
                fun[f"touches_{cur['kind']}"] += 1
            else:
                cur = None
        elif state == "touched":
            if i > deadline:
                fun["expired_no_confirm"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] > cur["hi"]:
                fun["voided_seq_close_above"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] < cur["lo"]:
                fun["confirms"] += 1
                fun[f"confirms_{cur['kind']}"] += 1
                if i + 1 < n:
                    et = bars15[i + 1]["t"]
                    if in_killzone(et):
                        a = atr1h_at(bars1h, atr1h, et)
                        if a is not None:
                            signals[et] = {"direction": -1, "atr": a, "tag": "R15-C"}
                            fun["signals"] += 1
                        else:
                            fun["signal_no_atr"] += 1
                    else:
                        fun["killzone_skipped"] += 1
                else:
                    fun["signal_no_entry_bar"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
    return signals, fun


# ----------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------
def main():
    print("盈利策略迭代 · 第十五轮：历史验证 2026-11-17 八条纸面计划的模板")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    print("模板 A 扫荡反转做多 / 模板 B FVG 回踩做多 / 模板 C 供给拒绝做空；"
          "1h 做结构、15m 做触发；止损 1xATR / 止盈 2xATR。")

    # ---- 数据校验（只读本地缓存，不联网）----
    data1h = build_1h_combined()
    data15 = {}
    for sym in SYMBOLS:
        bars = R11.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R11.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R11.group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 9,888 根 15m / 103 天；1h 合并后每币 "
          f"{len(data1h['BTC_USDT'][0])} 根；时间戳对齐、零缺口。")

    days_all_15 = set(R11.group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def _fmt(x, spec):
        return "—" if x is None else format(x, spec)

    all_results, all_trades = [], []
    pooled = {}

    def record(res, trades_full, family, variant, gran, funnel_by_sym=None):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        if funnel_by_sym is not None:
            res["setup_stats"] = {s: dict(c) for s, c in funnel_by_sym.items()}
        all_results.append(res)
        if trades_full is not None:
            pooled.setdefault(family, [])
            for t in trades_full:
                pooled[family].append(t["pnl"] / START_EQUITY)
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_15(t["entry_t"])
                all_trades.append(t2)

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={_fmt(res['win_rate'], '.4f')} "
              f"盈亏比={_fmt(res['profit_factor'], '.2f')} 平均赢={_fmt(res['avg_win_usdt'], '+.0f')} "
              f"平均亏={_fmt(res['avg_loss_usdt'], '.0f')} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={_fmt(res['t_taker'], '.2f')}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={_fmt(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={_fmt(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    def show_funnel(label, funnel_by_sym):
        tot = Counter()
        for c in funnel_by_sym.values():
            tot.update(c)
        print(f"[{label}] 漏斗（8 币合计）：{dict(sorted(tot.items()))}")
        per_sym = " / ".join(
            f"{s.replace('_USDT', '')}:信号{c.get('signals', 0)}"
            for s, c in funnel_by_sym.items())
        print(f"[{label}] 分币信号数：{per_sym}")

    def run_family(family, label, signals_by_sym, funnel_by_sym):
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
                trades, curve, ndays = R11.simulate_generic(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    MAX_PER_DAY, MAX_HOLD_15M, label, 96)
                res = R11.summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if subset is None else None, family, label, "15m",
                       funnel_by_sym={sym: funnel_by_sym[sym]} if subset is None else None)
                show(res, sym, wname)

    builders = [("A", "R15-A 扫荡反转做多", build_A),
                ("B", "R15-B FVG 回踩做多", build_B),
                ("C", "R15-C 供给拒绝做空", build_C)]
    for fam, label, builder in builders:
        print(f"\n=== {label}（103d 15m，8 币）===")
        sig, fun = {}, {}
        for sym in SYMBOLS:
            bars1h, atr1h = data1h[sym]
            sig[sym], fun[sym] = builder(data15[sym][0], bars1h, atr1h)
        show_funnel(label, fun)
        run_family(fam, label, sig, fun)

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for fam, wnames in [("A", ["103d", "前51d", "后52d"]),
                        ("B", ["103d", "前51d", "后52d"]),
                        ("C", ["103d", "前51d", "后52d"])]:
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["split"] == wname]
            n_tr = sum(r["trades"] for r in rs)
            avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
            avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
            avg_g = sum(r["gross_usdt"] for r in rs)
            avg_c = sum(r["taker_cost_sum"] for r in rs)
            n_pos = sum(1 for r in rs if r["taker_net_pct"] > 0)
            print(f"[{fam} {wname}] 币均 Taker {avg_t*100:+.2f}% | "
                  f"M2 {avg_m2*100:+.2f}% | 笔数 {n_tr} | 为正币数 {n_pos}/8 | "
                  f"毛利合计 {avg_g:+.0f} | 成本合计 {avg_c:+.0f}")

    # ---- 前后两半都为正的币数 ----
    print("\n=== 前后两半都为正的币数 ===")
    for fam in ["A", "B", "C"]:
        both = 0
        for sym in SYMBOLS:
            rf = [r for r in all_results if r["family"] == fam and r["symbol"] == sym
                  and r["split"] == "前51d"]
            rb = [r for r in all_results if r["family"] == fam and r["symbol"] == sym
                  and r["split"] == "后52d"]
            if rf and rb and rf[0]["taker_net_pct"] > 0 and rb[0]["taker_net_pct"] > 0:
                both += 1
        print(f"[{fam}] 前后两半都为正的币数：{both}/8")

    # ---- pooled t（全期逐笔，Taker）----
    print("\n=== Pooled t（全期逐笔，Taker，1x）===")
    for fam in ["A", "B", "C"]:
        pnls = pooled.get(fam, [])
        print(f"[{fam}] n={len(pnls)} pooled t={R11.t_value(pnls)}")

    # ---- 写文件 ----
    out_sum = os.path.join(DATA_DIR, "gate_iter_round15_summary.json")
    out_tr = os.path.join(DATA_DIR, "gate_iter_round15_trades.csv")
    with open(out_sum, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    if all_trades:
        keys = list(all_trades[0].keys())
        with open(out_tr, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(all_trades)
    else:
        with open(out_tr, "w", newline="") as f:
            f.write("")
    print(f"\n写出：{out_sum}（{len(all_results)} 条）")
    print(f"写出：{out_tr}（{len(all_trades)} 笔）")


if __name__ == "__main__":
    main()
