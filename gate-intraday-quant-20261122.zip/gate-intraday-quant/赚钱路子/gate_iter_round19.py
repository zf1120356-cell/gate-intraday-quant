#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十九轮：SMT 背离作 BTC 破位否决器（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因：学习笔记方向 5（SMT 背离，教程进阶 A9）。
教程原文（06-进阶概念与入场模型.md §A9，ICT 口径，smc-ai-tutor）：
  “两个高度相关 的品种，一个创了新低（或新高），另一个没有。
   例子：EURUSD 创新低、GBPUSD 没有创新低 → 下方的新低更可能只是
   一次扫流动性，而不是真跌。常见配对：EURUSD/GBPUSD、纳指/标普、
   BTC/ETH。用法：作为‘清扫 vs 真突破’的额外证据，不单独作为入场信号。”
学习笔记方向 5 原文（§3 方向 5）：
  “赌的假设：BTC 单独突破而 ETH 不跟，大概率是扫流动性而不是真突破；
   双币确认的突破才值得跟。……否决器：以 BTC 的破位根收盘时刻为基准，
   往前/往后各 3 根 1h 内，ETH 必须出现同方向的收盘破位；否则 BTC 的破位
   按‘疑似清扫’处理。只做 BTC 的信号（ETH 只作验证器，不单独开仓）。
   分两组汇报：双币确认组 vs 单币否决组，比较两组的每笔毛利和胜率。”
  本轮任务书对方向 5 的写法做了两处收窄（以任务书为准，见下），其余
  仍按笔记原文：否决器只作否决、不单独开单；基础信号取 F1 + S3 两个。

----------------------------------------------------------------------
SMT 背离定义（按教程口径，跑前写死 —— 本轮唯一新规则）
----------------------------------------------------------------------
配对：BTC 与每个山寨币配对。交易 BTC 时配对币取 ETH（教程常见配对
  BTC/ETH）；交易 ETH 时配对仍是 BTC/ETH（同一配对，BTC 为参照币、
  ETH 为对照币）；交易其余山寨 X 时配对为 BTC/X。
摆动点：分形 N=2（与第十一轮同款）：第 j 根为摆动高当且仅当
  h[j] 严格大于 h[j-1]、h[j-2]，且不低于 h[j+1]、h[j+2]；摆动低镜像。
  摆动点在第 j+2 根收完才确认 —— 否决判定在信号根 i 收盘时做，只用
  j+2 <= i 的已确认摆动点，无前视。
窗口：最近 20 根 1h（任务书示例值，写死）。15m 版按时间等价：最近
  80 根 15m（= 20 小时），与 1h 版同一时间窗口，不是同一根数。
  要求“创新高/新低”那一次摆动发生在窗口内（最新摆动点下标 >= i-窗口+1）。
背离（取两币各自最近两个已确认摆动点比较）：
  看跌背离（否决做多信号）：BTC 最新摆动高 > BTC 上一个摆动高
    （BTC 创新高），且对照币最新摆动高 <= 对照币上一个摆动高
    （对照币未创新高）。
  看涨背离（否决做空信号）：BTC 最新摆动低 < BTC 上一个摆动低
    （BTC 创新低），且对照币最新摆动低 >= 对照币上一个摆动低
    （对照币未创新低）。
  任一币摆动点不足两个 → 无背离 → 不否决。
否决器用法：SMT 只作否决，不单独开单。基础信号方向与 SMT 背离方向
  冲突时跳过该信号，不冲突时执行。做多信号只看看跌背离，做空信号
  只看看涨背离（同向背离不否决：例如做多信号遇看涨背离，那是确认，
  不是冲突）。

与 F1 的关系（任务书要求先确认，不要测成同一个东西）：
  F1（第七轮）是“跟随”：BTC 2h 大涨且山寨 2h 没跟上 → 赌山寨随后
    跟上，顺 BTC 方向做山寨，信号本身就是“山寨滞后”。
  SMT 是“背离否决”：BTC 在关键结构位创新高/低而对照币没创新高/低
    → 怀疑 BTC 这次突破是扫流动性，否决掉与之冲突的基础信号。
  两者看的不是同一件事：F1 看 2 根内的收益差（动量滞后），SMT 看
  最近 20 根内两币摆动高/低点的相对位置（结构确认）。本轮 SMT 叠加
  在 F1 之上，测的是“在 F1 已经要求山寨滞后的前提下，再要求 BTC 的
  突破得到结构确认，有没有增值”——如果 SMT 把 F1 信号大面积否决掉，
  那正是两者重叠的证据，要在报告里写明，而不是把否决率藏起来。

----------------------------------------------------------------------
锁定的规则（跑前定死，单组参数，不用全样本挑）
----------------------------------------------------------------------
基础信号（两个，引擎复用第九轮 gate_iter_round9.py，一字不变）：
  (1) F1 BTC 领涨-山寨跟随（第七轮 build_f1_signals + simulate_f1）：
      信号根 08:00~19:00 收盘：BTC 2h 收益 |rBTC| >= 0.5%，且山寨自身
      2h 收益 |rALT| < 0.5*|rBTC|；方向 = sign(rBTC)；下一根开盘进；
      止损 1xATR、止盈 2xATR；最多持 4h（1h 版 4 根，15m 版 16 根）；
      每天每币最多 2 笔；当天最后一根收盘强制平仓；单日 -2% 熔断；
      同根同时碰到先判止损；只做 7 个山寨，不做 BTC。
      1h 版 ATR(14,1h)、lookback 2 根；15m 版 ATR(14,15m)、lookback 8 根。
  (2) S3 RSI 20/80 低换手版（第三轮 run_s3_1h，365 天 1h，8 币）：
      RSI(14,Wilder) 收盘 <20 做多、>80 做空；08:00-20:00 UTC；
      本根振幅 > 前 20 根中位数；每天每币最多 2 笔；
      出场 RSI 回 50 / 止损 1xATR / 止盈 2xATR / 当天 23:00 收盘
      强制平仓；每笔保证金 10% 权益、1x；收盘触发、下一根开盘成交；
      同根同时碰到先判止损；单日 -2% 熔断；
      单笔最坏情况 (ATR+成本) > 1% 权益跳过。
      本轮唯一改动：run_s3_1h 复制为 run_s3_1h_veto，增加 veto_fn
      钩子（信号成立后、开仓前调用，返回 True 则跳过该信号）；其余
      逐行与第九轮一致。对照 1（veto_fn 恒 False）必须复现第九轮
      TP=2.0 已发表数字，否则本轮全部作废。
对照（三个 + 一个诊断臂）：
  对照 1（C1）：原版 F1-1h / F1-15m / S3-1h，无否决。
  对照 2（C2）：只加 SMT 否决到 F1 上（F1-1h+SMT、F1-15m+SMT）。
  对照 3（C3）：只加 SMT 否决到 S3 上（S3-1h+SMT）。
  诊断臂（D）：只做被 SMT 否决掉的信号（F1-1h/15m、S3-1h 各一），
    不作候选策略，只用来回答“被否掉的信号是不是真的更差”——否决器
    有没有用，看的就是这一组。注意：诊断臂与通过臂各自独立跑引擎
    （每日 2 笔上限、持仓重叠都在臂内单独算），所以通过臂笔数 +
    否决臂笔数 ≈ 对照 1 笔数（有微小出入时以引擎实际为准，报告写明）。
止损 1xATR、止盈 2xATR（用户要求的 1:2），全臂一致。
成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
  双边）；资金费按实际费率计（08:00/16:00 结算点，前半段 2026-05-21
  之前无数据按 0 计）。M1/M2 只做对照（第九轮同款），主口径是 Taker。

窗口：
  1h：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~2026-05-19
    （185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  15m：全 103 天 2026-08-06~2026-11-16；前半段 2026-08-06~09-25
    （51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

运行：python3 gate_iter_round19.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round19_summary.json
      + data/gate_iter_round19_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
复核：对照 1（TP=2.0）必须复现第九轮 TP=2.0 已发表数字（22 个
  币×组合格，容差 0.05pp），见脚本末尾 checks。
首信号人工核对：脚本打印 F1-1h 与 S3-1h 各自第一个信号的 SMT 输入
  （两币最近两个摆动高/低、窗口、判定结果），报告里手工复核。
"""
import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round9 as r9

SYMBOLS = r9.SYMBOLS
ALTS = r9.ALTS
START_EQUITY = r9.START_EQUITY
SPLIT_1H = r9.SPLIT_1H
SPLIT_15M = r9.SPLIT_15M
TP_MULT = 2.0
SL_MULT = 1.0

# ---- SMT 否决器：跑前写死的参数 ----
SMT_SWING_N = 2        # 摆动点分形半宽 N=2（第十一轮同款）
SMT_WINDOW_1H = 20     # 最近 20 根 1h
SMT_WINDOW_15M = 80    # 15m 版时间等价：80 根 15m = 20 小时

load_bars = r9.load_bars
load_funding = r9.load_funding
group_days = r9.group_days
atr_wilder = r9.atr_wilder
summarize = r9.summarize
t_value = r9.t_value


# ----------------------------------------------------------------------
# SMT 背离：摆动点 + 背离判定（只用信号根收盘时已确认的摆动点，无前视）
# ----------------------------------------------------------------------
def swing_points(bars, n=SMT_SWING_N):
    """返回 (swing_highs, swing_lows)，每项为 (index, price)。
    摆动高：h[j] 严格大于左右 n 根的 h，且不低于其余 n 根的 h；摆动低镜像。
    注意：调用方只取 j+2 <= i 的点（确认根已收完），此处不过滤。"""
    highs, lows = [], []
    for j in range(n, len(bars) - n):
        h, l = bars[j]["h"], bars[j]["l"]
        if all(h > bars[k]["h"] for k in range(j - n, j)) and \
           all(h >= bars[k]["h"] for k in range(j + 1, j + n + 1)):
            highs.append((j, h))
        if all(l < bars[k]["l"] for k in range(j - n, j)) and \
           all(l <= bars[k]["l"] for k in range(j + 1, j + n + 1)):
            lows.append((j, l))
    return highs, lows


def smt_conflicts(ref_bars, alt_bars, i, window, direction,
                  ref_swings=None, alt_swings=None):
    """在信号根 i（收盘时）判定 SMT 背离是否与信号方向冲突。
    ref_bars：BTC；alt_bars：对照币（与 ref_bars 时间戳对齐，同一 index）。
    direction=+1 做多 / -1 做空。返回 True=背离与方向冲突（应否决）。
    只用 j+2 <= i 的已确认摆动点；最新摆动点须落在窗口内（j >= i-window+1）。"""
    if ref_swings is None:
        ref_swings = swing_points(ref_bars)
    if alt_swings is None:
        alt_swings = swing_points(alt_bars)
    rh, rl = ref_swings
    ah, al = alt_swings
    # 已确认且下标 <= i 的摆动点（j+2<=i 即 j<=i-2）；取最近两个
    rh_c = [(j, p) for j, p in rh if j <= i - 2]
    ah_c = [(j, p) for j, p in ah if j <= i - 2]
    rl_c = [(j, p) for j, p in rl if j <= i - 2]
    al_c = [(j, p) for j, p in al if j <= i - 2]
    if direction == 1:
        # 看跌背离：BTC 创新高而对照币未创新高
        if len(rh_c) < 2 or len(ah_c) < 2:
            return False
        (j1, p1), (j0, p0) = rh_c[-1], rh_c[-2]
        (k1, q1), (k0, q0) = ah_c[-1], ah_c[-2]
        if j1 < i - window + 1:
            return False
        return p1 > p0 and q1 <= q0
    else:
        # 看涨背离：BTC 创新低而对照币未创新低
        if len(rl_c) < 2 or len(al_c) < 2:
            return False
        (j1, p1), (j0, p0) = rl_c[-1], rl_c[-2]
        (k1, q1), (k0, q0) = al_c[-1], al_c[-2]
        if j1 < i - window + 1:
            return False
        return p1 < p0 and q1 >= q0


class VetoCounter:
    """记录否决器在引擎决策点看到的信号数与否决数。"""
    def __init__(self):
        self.seen = 0
        self.vetoed = 0

    def rate(self):
        return round(self.vetoed / self.seen, 4) if self.seen else None


# ----------------------------------------------------------------------
# S3 引擎：第九轮 run_s3_1h 逐行复制，唯一改动是增加 veto_fn 钩子。
# veto_fn(gi, direction) -> True 表示跳过该信号；None 表示不过滤。
# 对照 1 用 veto_fn=None 以外的恒 False 记录函数跑，行为与第九轮一致。
# ----------------------------------------------------------------------
def run_s3_1h_veto(bars, funding, symbol, days_subset, tp_mult, label, veto_fn=None):
    atr = atr_wilder(bars)
    rsi = r9.rsi_wilder([b["c"] for b in bars])
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 24)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = r9.MAINT_RATE[symbol]
    liq_move = 1.0 / 1 - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = r9.funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * r9.ROUNDTRIP_COST
            tr["cost_maker_usdt"] = r9.maker_cost(tr["notional"], reason)
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                       else (b["h"] - pos["entry"]) / pos["entry"])
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                r = rsi[gi]
                if r is not None:
                    if pos["direction"] == 1 and r >= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                    if pos["direction"] == -1 and r <= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if not (8.0 <= hour < 20.0):
                    continue
                r = rsi[gi]
                if r is None or gi < 20:
                    continue
                ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                    continue
                sig = 0
                if r < r9.RSI_LO:
                    sig = 1
                elif r > r9.RSI_HI:
                    sig = -1
                if sig == 0:
                    continue
                # ---- 本轮唯一新增：SMT 否决钩子（信号成立后、开仓前） ----
                if veto_fn is not None and veto_fn(gi, sig):
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = r9.MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + r9.ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - SL_MULT * a if sig == 1 else entry + SL_MULT * a
                tp = entry + tp_mult * a if sig == 1 else entry - tp_mult * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def main():
    print("盈利策略迭代 · 第十九轮：SMT 背离作 BTC 破位否决器（全模拟）")
    print("基础信号 F1 + S3，止损 1xATR / 止盈 2xATR；达标：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- SMT 摆动点预计算（每币每粒度一次）----
    swings1h = {s: swing_points(data1h[s][0]) for s in SYMBOLS}
    swings15 = {s: swing_points(data15[s][0]) for s in SYMBOLS}
    btc_sw1h = swings1h["BTC_USDT"]
    btc_sw15 = swings15["BTC_USDT"]
    print(f"摆动点（N=2）：1h BTC 高 {len(btc_sw1h[0])} / 低 {len(btc_sw1h[1])}；"
          f"15m BTC 高 {len(btc_sw15[0])} / 低 {len(btc_sw15[1])}。")

    def pair_alt(sym):
        # 交易 BTC 或 ETH 时对照币取 ETH（教程配对 BTC/ETH）；其余山寨取自身
        return "ETH_USDT" if sym in ("BTC_USDT", "ETH_USDT") else sym

    # ---- F1 信号：与止盈/否决无关，同一粒度只生成一次 ----
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig1h, sig15 = {}, {}
    for sym in ALTS:
        sig1h[sym] = r9.build_f1_signals(data1h[sym][0], data1h["BTC_USDT"][0],
                                         atr1h[sym], 2, 4, TP_MULT)
        sig15[sym] = r9.build_f1_signals(data15[sym][0], data15["BTC_USDT"][0],
                                         atr15[sym], 8, 16, TP_MULT)
    print(f"[F1] 信号数（与止盈/否决无关）：1h 合计 {sum(len(v) for v in sig1h.values())}，"
          f"15m 合计 {sum(len(v) for v in sig15.values())}。")

    # ---- F1 信号按 SMT 分流：通过 / 被否决（信号根 = 入场根前一根）----
    f1_pass1h, f1_veto1h, f1_pass15, f1_veto15 = {}, {}, {}, {}
    f1_veto_stats = {}  # (gran, sym) -> (n_sig, n_vetoed)
    for sym in ALTS:
        alt = pair_alt(sym)
        for gran, sigdict, bars, window, ref_sw, alt_sw in [
                ("1h", sig1h[sym], data1h[sym][0], SMT_WINDOW_1H, btc_sw1h, swings1h[alt]),
                ("15m", sig15[sym], data15[sym][0], SMT_WINDOW_15M, btc_sw15, swings15[alt])]:
            idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
            passed, vetoed = {}, {}
            for entry_t, sig in sigdict.items():
                gi = idx_of_t[entry_t] - 1
                if smt_conflicts(data1h["BTC_USDT"][0] if gran == "1h" else data15["BTC_USDT"][0],
                                 bars, gi, window, sig["direction"],
                                 ref_sw, alt_sw):
                    vetoed[entry_t] = sig
                else:
                    passed[entry_t] = sig
            if gran == "1h":
                f1_pass1h[sym], f1_veto1h[sym] = passed, vetoed
            else:
                f1_pass15[sym], f1_veto15[sym] = passed, vetoed
            f1_veto_stats[(gran, sym)] = (len(sigdict), len(vetoed))
    print("[F1] SMT 否决率（被否决信号 / 全部信号）：")
    for gran in ("1h", "15m"):
        tot = sum(f1_veto_stats[(gran, s)][0] for s in ALTS)
        vet = sum(f1_veto_stats[(gran, s)][1] for s in ALTS)
        print(f"  F1-{gran}：{vet}/{tot} = {vet/tot:.1%}；"
              + " ".join(f"{s.split('_')[0]}:{f1_veto_stats[(gran, s)][1]}/{f1_veto_stats[(gran, s)][0]}"
                         for s in ALTS))

    # ---- 首信号人工核对材料（F1-1h 第一个信号 + S3-1h 第一个信号）----
    first_sym = min(f1_pass1h, key=lambda s: min(list(f1_pass1h[s]) + list(f1_veto1h[s])))
    first_entry_t = min(list(f1_pass1h[first_sym]) + list(f1_veto1h[first_sym]))
    bars_f = data1h[first_sym][0]
    idx_f = {b["t"]: i for i, b in enumerate(bars_f)}
    gi_f = idx_f[first_entry_t] - 1
    merged_first = {**f1_pass1h[first_sym], **f1_veto1h[first_sym]}
    sig_f = merged_first.get(first_entry_t)
    btc_bars = data1h["BTC_USDT"][0]
    rh = [(j, p) for j, p in btc_sw1h[0] if j <= gi_f - 2]
    rl = [(j, p) for j, p in btc_sw1h[1] if j <= gi_f - 2]
    alt_sw = swings1h[pair_alt(first_sym)]
    ah = [(j, p) for j, p in alt_sw[0] if j <= gi_f - 2]
    al = [(j, p) for j, p in alt_sw[1] if j <= gi_f - 2]
    print("\n[首信号核对 F1-1h] "
          f"{first_sym} 信号根 {datetime.fromtimestamp(bars_f[gi_f]['t'], timezone.utc).isoformat()} "
          f"方向 {'LONG' if sig_f['direction'] == 1 else 'SHORT'} "
          f"BTC收 {btc_bars[gi_f]['c']:.2f} / {first_sym.split('_')[0]}收 {bars_f[gi_f]['c']:.4f}")
    print(f"  BTC 最近两摆动高 {rh[-2:]} / 最近两摆动低 {rl[-2:]}")
    print(f"  {pair_alt(first_sym)} 最近两摆动高 {ah[-2:]} / 最近两摆动低 {al[-2:]}")
    print(f"  SMT 判定：{'否决' if first_entry_t in f1_veto1h[first_sym] else '通过'}"
          f"（窗口 20 根，最新摆动须 >= {gi_f - 19}）")

    all_results, all_trades = [], []

    def record(res, trades_full, family, variant, gran, split_fn, veto_info=None):
        res["family"] = family
        res["variant"] = variant
        res["tp_mult"] = TP_MULT
        res["granularity"] = gran
        if veto_info is not None:
            res["signals_seen"], res["signals_vetoed"], res["veto_rate"] = veto_info
        all_results.append(res)
        if trades_full is not None:
            for t in trades_full:
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["tp_mult"] = TP_MULT
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def line(label, res):
        def f(v, fmt):
            return ("--" if v is None else format(v, fmt))
        print(f"[{label} {res['symbol']} {res['split']}] n={res['trades']} 胜率={f(res['win_rate'], '.4f')} "
              f"盈亏比={f(res['profit_factor'], '.2f')} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={f(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={f(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    def split_fn_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_fn_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    # ================= S3-1h：对照 1 / 对照 3 / 诊断臂 =================
    print("\n=== S3 RSI 20/80（365d 1h，8 币）===")
    for arm, label in [("C1", "R19-S3-C1-orig"), ("C3", "R19-S3-C3-SMT"),
                       ("D", "R19-S3-D-vetoed-only")]:
        for sym in SYMBOLS:
            bars, funding = data1h[sym]
            alt = pair_alt(sym)
            alt_bars = data1h[alt][0]
            alt_sw = swings1h[alt]

            def make_veto(arm=arm, alt_sw=alt_sw):
                counter = VetoCounter()

                def veto_fn(gi, sig):
                    counter.seen += 1
                    conf = smt_conflicts(btc_bars, alt_bars, gi, SMT_WINDOW_1H, sig,
                                         btc_sw1h, alt_sw)
                    if arm == "C1":
                        return False
                    if arm == "C3":
                        if conf:
                            counter.vetoed += 1
                        return conf
                    # 诊断臂：只做被否决的信号
                    if conf:
                        counter.vetoed += 1
                        return False
                    return True

                return veto_fn, counter

            full_counter = None
            for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
                veto_fn, counter = make_veto()  # 每个窗口独立计数，避免重复累加
                if wname == "365d":
                    full_counter = counter
                trades, curve, ndays = run_s3_1h_veto(bars, funding, sym, subset, TP_MULT, label, veto_fn)
                res = summarize(sym, trades, curve, label)
                res["split"] = wname
                res["days"] = ndays
                if wname == "365d":
                    vi = (counter.seen, counter.vetoed, counter.rate())
                    record(res, trades, "S3", label, "1h", split_fn_1h, vi)
                else:
                    record(res, None, "S3", label, "1h", split_fn_1h, None)
                line(label, res)
            print(f"  [S3 {label} {sym}] 全期引擎决策点信号 seen={full_counter.seen} vetoed={full_counter.vetoed}")

    # ================= F1-1h / F1-15m：对照 1 / 对照 2 / 诊断臂 =================
    print("\n=== F1 BTC 领涨-山寨跟随（365d 1h + 103d 15m，7 山寨）===")
    for gran, sig_pass, sig_veto, data, subset_front, subset_back, wnames, sfn, bpd in [
            ("1h", f1_pass1h, f1_veto1h, data1h, front_1h, back_1h,
             ["365d", "前185d", "后180d"], split_fn_1h, 24),
            ("15m", f1_pass15, f1_veto15, data15, front_15, back_15,
             ["103d", "前51d", "后52d"], split_fn_15, 96)]:
        for arm, label, sigmap in [
                ("C1", f"R19-F1-{gran}-C1-orig", None),
                ("C2", f"R19-F1-{gran}-C2-SMT", sig_pass),
                ("D", f"R19-F1-{gran}-D-vetoed-only", sig_veto)]:
            for sym in ALTS:
                bars, funding = data[sym]
                if arm == "C1":
                    sigs = dict(sorted({**sig_pass[sym], **sig_veto[sym]}.items()))
                elif arm == "C2":
                    sigs = sig_pass[sym]
                else:
                    sigs = sig_veto[sym]
                n_sig, n_vet = f1_veto_stats[(gran, sym)]
                vi = None if arm == "C1" else (n_sig, n_vet, round(n_vet / n_sig, 4) if n_sig else None)
                for wname, subset in [(wnames[0], None), (wnames[1], subset_front), (wnames[2], subset_back)]:
                    trades, curve, ndays = r9.simulate_f1(sym, bars, sigs, funding, subset, 2, label, bpd)
                    res = summarize(sym, trades, curve, label,
                                    len(sig_pass[sym]) + len(sig_veto[sym]))
                    res["split"] = wname
                    res["days"] = ndays
                    record(res, trades if wname == wnames[0] else None, "F1", label, gran, sfn,
                           vi if wname == wnames[0] else None)
                    line(label, res)

    # (S3 各窗口独立计数，365d 行即全期数，无需事后修正)

    # ---- 汇总：平均净收益 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, syms, wnames) in [
            ("S3", "1h", SYMBOLS, ["365d", "前185d", "后180d"]),
            ("F1", "1h", ALTS, ["365d", "前185d", "后180d"]),
            ("F1", "15m", ALTS, ["103d", "前51d", "后52d"])]:
        arms = sorted({r["variant"] for r in all_results
                       if r["family"] == fam and r["granularity"] == gran})
        for variant in arms:
            for wname in wnames:
                rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["variant"] == variant and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                print(f"  {variant} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                      f"每笔毛利 {gt/nt:+.2f} USDT" if nt else
                      f"  {variant} {wname}：无交易")

    # ---- pooled t ----
    print("\n=== Pooled t 值（逐笔净收益占权益 %，全期明细）===")
    for (fam, gran, wnames, full) in [
            ("S3", "1h", ["365d", "前185d", "后180d"], "365d"),
            ("F1", "1h", ["365d", "前185d", "后180d"], "365d"),
            ("F1", "15m", ["103d", "前51d", "后52d"], "103d")]:
        arms = sorted({r["variant"] for r in all_results
                       if r["family"] == fam and r["granularity"] == gran})
        for variant in arms:
            sub = [t for t in all_trades if t["family"] == fam and t["granularity"] == gran
                   and t["variant"] == variant]
            for wname in wnames:
                s2 = [t for t in sub if wname == full or t["split"] == wname]
                vals = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
                vals_t = [t["pnl"] / START_EQUITY for t in s2]
                print(f"  {variant} {wname}：n={len(vals)} "
                      f"pooled t(M1)={t_value(vals)} pooled t(Taker)={t_value(vals_t)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    for (fam, gran, syms, wnames) in [
            ("S3", "1h", SYMBOLS, ["前185d", "后180d", "365d"]),
            ("F1", "1h", ALTS, ["前185d", "后180d", "365d"]),
            ("F1", "15m", ALTS, ["前51d", "后52d", "103d"])]:
        arms = sorted({r["variant"] for r in all_results
                       if r["family"] == fam and r["granularity"] == gran
                       and "-D-" not in r["variant"]})
        for variant in arms:
            row = {}
            for wname in wnames:
                rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["variant"] == variant and r["split"] == wname]
                row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            good = row[wnames[0]] > 0 and row[wnames[1]] > 0 and row[wnames[2]] > 0.02
            print(f"  {variant} Taker：前 {row[wnames[0]]*100:+.2f}% / "
                  f"后 {row[wnames[1]]*100:+.2f}% / 全 {row[wnames[2]]*100:+.2f}% → "
                  f"{'达标' if good else '不达标'}")
            for sym in syms:
                rf = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["variant"] == variant and r["symbol"] == sym and r["split"] == wnames[0]][0]
                rb = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["variant"] == variant and r["symbol"] == sym and r["split"] == wnames[1]][0]
                both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
                print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                      f"后 {rb['taker_net_pct']*100:+.2f}% → "
                      f"{'★ 两半都为正' if both else ''}")

    # ---- 复核：对照 1（TP=2.0）vs 第九轮已发表数字 ----
    print("\n=== 复核：对照 1（TP=2.0）vs 第九轮 TP=2.0 已发表数字（Taker，全期）===")
    checks = {
        ("S3", "1h", "BTC_USDT"): -0.0150, ("S3", "1h", "ETH_USDT"): -0.0068,
        ("S3", "1h", "SOL_USDT"): -0.0176, ("S3", "1h", "DOGE_USDT"): -0.0089,
        ("S3", "1h", "LINK_USDT"): -0.0086, ("S3", "1h", "XRP_USDT"): -0.0073,
        ("S3", "1h", "BNB_USDT"): -0.0100, ("S3", "1h", "ADA_USDT"): -0.0190,
        ("F1", "1h", "ETH_USDT"): 0.0010, ("F1", "1h", "SOL_USDT"): -0.0129,
        ("F1", "1h", "DOGE_USDT"): -0.0372, ("F1", "1h", "LINK_USDT"): -0.0421,
        ("F1", "1h", "XRP_USDT"): -0.0366, ("F1", "1h", "BNB_USDT"): -0.0500,
        ("F1", "1h", "ADA_USDT"): -0.0093,
        ("F1", "15m", "ETH_USDT"): -0.0066, ("F1", "15m", "SOL_USDT"): -0.0145,
        ("F1", "15m", "DOGE_USDT"): -0.0124, ("F1", "15m", "LINK_USDT"): -0.0083,
        ("F1", "15m", "XRP_USDT"): -0.0177, ("F1", "15m", "BNB_USDT"): -0.0171,
        ("F1", "15m", "ADA_USDT"): -0.0062,
    }
    full_name = {("S3", "1h"): "365d", ("F1", "1h"): "365d", ("F1", "15m"): "103d"}
    c1_label = {("S3", "1h"): "R19-S3-C1-orig", ("F1", "1h"): "R19-F1-1h-C1-orig",
                ("F1", "15m"): "R19-F1-15m-C1-orig"}
    bad = 0
    for (fam, gran, sym), expect in sorted(checks.items()):
        r = [x for x in all_results if x["family"] == fam and x["granularity"] == gran
             and x["variant"] == c1_label[(fam, gran)] and x["symbol"] == sym
             and x["split"] == full_name[(fam, gran)]][0]
        ok = abs(r["taker_net_pct"] - expect) < 0.0005
        bad += 0 if ok else 1
        print(f"  {fam}-{gran} {sym}: 本轮 {r['taker_net_pct']*100:+.2f}% vs 第九轮 "
              f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核结果：{len(checks)-bad}/{len(checks)} 一致" + ("（全部通过）" if bad == 0 else "（有出入，见报告）"))

    with open(os.path.join(DATA_DIR, "gate_iter_round19_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round19_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "exit_time_utc", "entry", "exit",
                    "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt", "price_pnl_usdt",
                    "cost_taker_usdt", "cost_maker_usdt", "funding_cost_usdt",
                    "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["family"], x["granularity"], x["variant"], x["symbol"])):
            w.writerow([t["family"], t["variant"], t["tp_mult"], t["granularity"], t["split"],
                        t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t.get("liquidated", False), t["hold_min"]])
    print(f"\n汇总已写入：data/gate_iter_round19_summary.json ({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round19_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益.")


if __name__ == "__main__":
    main()
