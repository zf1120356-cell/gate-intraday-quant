#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三轮：365 天窗口验证 A+B + 扩到多币种（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。

本轮只做一件事：把第二轮的 A+B 组合（S3 RSI 20/80 + Maker 混合现实成本）
放到 365 天窗口里验证，并扩到多币种。不调参、不挑单币。

A+B 规则锁定不变（直接套用，不重新选型）：
  A（见 iteration_A_S3_lowturnover.md / gate_iter_A.py）：
    RSI(14, Wilder) 收盘 <20 做多、>80 做空；08:00-20:00 UTC；
    本根振幅 > 前 20 根振幅中位数；每天每币最多 2 笔；
    出场 RSI 回 50 / 止损 1xATR / 止盈 1.5xATR / 当天收盘强制平仓；
    每笔保证金 10% 权益、1x；收盘触发、下一根开盘成交；
    止损/止盈用盘中高低价触发（同根同时碰到先判止损，原版同款约定）；
    单日 -2% 熔断；单笔最坏情况（ATR+成本）>1% 权益跳过。
  B（见 iteration_B_maker.md / gate_iter_round2.py Part 1）：
    入场 Maker -0.01% 名义；出场止损/EOD 只能市价 Taker 0.125%/边
    （0.075% 费 + 0.05% 滑点），止盈可用限价 Maker -0.01%。
    每笔 Maker 混合成本 = 名义 x (-0.0001 + 出场费率)，止盈笔 -0.02%，
    止损/EOD 笔 +0.115%。成交率 f 与逆向惩罚直接读
    data/gate_iter_B_summary.json（BTC/ETH/SOL 实测值，不手抄）。
    新币种（DOGE/LINK/XRP/BNB/ADA）没有 B 实测值：统一用 SOL 的实测值
    （f=0.9865、惩罚 0.006% 名义）作保守代理——SOL 是三币里成交率最低、
    惩罚最高的，代理只会让新币种的结果更保守，不会更乐观。报告里点名。
  M2（主口径）：net_M2 = f * (gross_sum - penalty * notional_sum - maker_cost_sum)
  M1（上界对照）：Maker 成本、100% 成交、无惩罚，逐笔重算权益曲线与最大回撤。
  Taker（基线对照）：一轮名义 x 0.25%。

粒度变化（必须先说清，不能假装同一根 K 线）：
  Gate 30m 接口最多取 10,000 根（约 208 天），365 天 30m 取不到；
  15m 更取不到（约 104 天）。本轮改用 1h K 线：
  365 天 x 24 根 = 8,760 根 < 10,000，实测可取。
  1h 版是 30m 版的同逻辑平移：RSI(14)/ATR(14) 改为 1h 序列，
  振幅过滤用前 20 根 1h 振幅中位数，EOD 为 23:00 那根收盘，
  其他（时间窗口、阈值、止损止盈倍数、仓位、熔断、成本）全部不变。
  但 1h 的数字不能直接说成 30m 的数字：本轮另做交叉对照——
  同一 1h 引擎跑后 180 天（2026-05-20~11-15）Taker 口径，
  与 30m 版 A 在同一窗口的 Taker 数字并排比较，量化粒度效应。

窗口（UTC 自然日，完整日才算）：
  全 365 天：2025-11-16 ~ 2026-11-15（365 天）
  前半段：2025-11-16 ~ 2026-05-19（185 天，全新样本——A+B 规则
    是在后 180 天数据上选出来的，前半段规则从未见过，是纯样本外）
  后半段：2026-05-20 ~ 2026-11-15（180 天，即前两轮的窗口）
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

多币种挑选标准（回测前定死，2026-11-17 约 06:50 UTC 实测，不看涨幅）：
  在用户点的 DOGE/LINK/XRP/BNB/ADA 五个候选里，按 Gate 24h 成交额
  （quote volume）排序；全部通过可交易性检查才入选：
  (1) 24h 成交额：DOGE 1.196 亿美元、XRP 0.405 亿、BNB 0.173 亿、
      ADA 0.133 亿、LINK 0.035 亿；
  (2) 买卖价差（top of book）：DOGE 0.0168%、LINK 0.0109%、
      XRP 0.0104%、BNB 0.0084%、ADA 0.0651%，全部 ≤0.07%；
  (3) 1h 历史连续回溯到 2025-11-16、无上市缺口（脚本内校验，
      缺口会在报告里点名，缺口日不计入）。
  五个全部入选，共 8 个币。DOGE 标注为 Meme 币：滑点/脱锚风险
  高于主流币，本回测只算 0.05% 固定滑点，未计脱锚，DOGE 的真实
  净收益折扣会比其他币大——报告里单独标注。

资金费率（局限，必须写清）：
  Gate 资金费率接口 from 早于 180 天会报错（实测 2026-05-20 报错、
  05-21 可取），所以 2026-05-21 之前取不到资金费率，前半段
  2025-11-16~2026-05-20 的资金费按 0 计。依据：前两轮 111 笔的
  资金费合计只有 -2.09 USDT（A 报告），日内持仓平均约 1 小时，
  很少跨 08:00/16:00 结算点；本轮会在后半段单独汇报资金费合计，
  若后半段资金费占比可忽略，则前半段按 0 计的偏差也可忽略。

达标标准（与第二轮一致，搬到 365 天）：
  前后两半都为正且全 365 天 1 倍净收益 >2% 才算达标，否则不达标。
  达标只看三币平均和八币平均两个口径同时成立；单个币两半都为正
  会单独拎出来说，不藏在平均数里。

运行：python3 gate_iter_round3.py
输出：终端打印全部表 + data/gate_iter_round3_summary.json
      + data/gate_iter_round3_trades.csv（M1 逐笔，365 天，split 列）
      + data/gate_1h_365d_{SYM}.csv + data/gate_funding_365d_{SYM}.json
"""
import csv
import json
import math
import os
import statistics
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone, date

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
BASE = "https://api.gateio.ws/api/v4"

# ---- 币种：BTC/ETH/SOL + 新入选 5 个（挑选标准见文件头，回测前定死）----
SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MEME = {"DOGE_USDT"}  # 单独标注滑点/脱锚风险
# 维持保证金率：Gate API 2026-11-17 实测（contracts 端点）
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005,
              "DOGE_USDT": 0.008333, "LINK_USDT": 0.0065, "XRP_USDT": 0.005,
              "BNB_USDT": 0.0066, "ADA_USDT": 0.0066}

START_DAY = datetime(2025, 11, 16, tzinfo=timezone.utc)
END_DAY = datetime(2026, 11, 16, tzinfo=timezone.utc)  # 取到 11-16 00:00，完整日止于 11-15
SPLIT_DAY = datetime(2026, 5, 20, tzinfo=timezone.utc)  # 前半段止于 05-19，后半段起于 05-20
FUNDING_START = datetime(2026, 5, 21, tzinfo=timezone.utc)  # 资金费率接口 180 天限制

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
RSI_LO, RSI_HI = 20, 80
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
# 新币种：SOL 保守代理（成交率最低、惩罚最高），报告里点名
for _sym in SYMBOLS:
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "gate-r3/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles_1h(contract):
    path = os.path.join(DATA_DIR, f"gate_1h_365d_{contract}.csv")
    if os.path.exists(path):
        with open(path, newline="") as f:
            rows = list(csv.DictReader(f))
        bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
                 "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
                 "sum": float(r["sum"])} for r in rows]
        if bars and bars[0]["t"] <= int(START_DAY.timestamp()) + 3600 and \
                bars[-1]["t"] >= int((END_DAY - timedelta(hours=1)).timestamp()):
            print(f"[{contract}] 1h K 线用缓存：{len(bars)} 根 "
                  f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
                  f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
            return bars
    bars = []
    cur = START_DAY
    while cur < END_DAY:
        nxt = min(cur + timedelta(days=7), END_DAY)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=1h"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] 1h K 线已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
    return bars


def fetch_funding(contract):
    path = os.path.join(DATA_DIR, f"gate_funding_365d_{contract}.json")
    if os.path.exists(path):
        with open(path) as f:
            raw = json.load(f)
        out = {int(k): float(v) for k, v in raw.items()}
        if out and min(out) <= int(datetime(2026, 5, 22, tzinfo=timezone.utc).timestamp()):
            print(f"[{contract}] 资金费率用缓存：{len(out)} 条 "
                  f"（2026-05-21 起可取，之前按 0 计）")
            return out
    out = {}
    cur = FUNDING_START
    while cur < END_DAY:
        nxt = min(cur + timedelta(days=30), END_DAY)
        url = (f"{BASE}/futures/usdt/funding_rate?contract={contract}&limit=100"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            t = int(d["t"])
            t = (t // 28800) * 28800
            out[t] = float(d["r"])
        cur = nxt
        time.sleep(0.3)
    with open(path, "w") as f:
        json.dump(out, f)
    print(f"[{contract}] 资金费率已取：{len(out)} 条 "
          f"{datetime.fromtimestamp(min(out), timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(max(out), timezone.utc).date()}（之前按 0 计）")
    return out


def load_bars(symbol):
    with open(os.path.join(DATA_DIR, f"gate_1h_365d_{symbol}.csv"), newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def group_days(bars, bars_per_day=24):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def rsi_wilder(closes, period=14):
    rsi = [None] * len(closes)
    if len(closes) <= period:
        return rsi
    gains, losses = [], []
    for i in range(1, period + 1):
        ch = closes[i] - closes[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    avg_g = sum(gains) / period
    avg_l = sum(losses) / period
    rsi[period] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    for i in range(period + 1, len(closes)):
        ch = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(ch, 0.0)) / period
        avg_l = (avg_l * (period - 1) + max(-ch, 0.0)) / period
        rsi[i] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    return rsi


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason in ("stop_loss", "eod"):
        exit_rate = TAKER_EXIT
    elif reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def run_s3_1h(bars, funding, symbol, days_subset, label="R3-S3-20/80-1h"):
    """A 的 S3 引擎（gate_iter_A.py run_s3）按 1h 平移：bars_per_day=24，
    EOD 为 23:00 那根收盘；其余逻辑一字不变。"""
    atr = atr_wilder(bars)
    rsi = rsi_wilder([b["c"] for b in bars])
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 24)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / 1 - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                       else (b["h"] - pos["entry"]) / pos["entry"])
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                r = rsi[gi]
                if r is not None:
                    if pos["direction"] == 1 and r >= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                    if pos["direction"] == -1 and r <= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if not (8.0 <= hour < 20.0):
                    continue
                r = rsi[gi]
                if r is None or gi < 20:
                    continue
                ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                    continue
                sig = 0
                if r < RSI_LO:
                    sig = 1
                elif r > RSI_HI:
                    sig = -1
                if sig == 0:
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - a if sig == 1 else entry + a
                tp = entry + 1.5 * a if sig == 1 else entry - 1.5 * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def t_value(pnls_pct):
    """逐笔净收益（占权益 %）的 t 值：mean / (sd / sqrt(n))，样本标准差。"""
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def summarize_window(sym, trades, curve, label):
    """对一组交易算 Taker / M1 / M2 三档。trades 是 Taker 口径的明细
    （pnl 已扣 Taker 成本与资金费）；M1/M2 由 gross 与 maker 成本重算。"""
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    # M1：逐笔 Maker 成本，100% 成交，重算权益曲线与最大回撤、t 值
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins += 1 if pnl_m1 > 0 else 0
    peak, mdd = m1_curve[0], 0.0
    for v in m1_curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins / n, 4) if n else None,
        "m1_max_dd": round(mdd, 4),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": sum(1 for t in trades if t.get("liquidated")),
    }


def regime_table(bars):
    """窗口 regime：首收→末收涨跌幅、区间振幅、日收益年化波动。"""
    days = group_days(bars, 24)
    dlist = sorted(days)
    first_o = days[dlist[0]][0]["o"]
    last_c = days[dlist[-1]][-1]["c"]
    hi = max(b["h"] for b in bars)
    lo = min(b["l"] for b in bars)
    closes = [days[d][-1]["c"] for d in dlist]
    rets = [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes))]
    vol = statistics.pstdev(rets) * math.sqrt(365) if len(rets) > 1 else None
    return {"days": len(dlist),
            "start": str(dlist[0]), "end": str(dlist[-1]),
            "change_pct": round((last_c / first_o - 1) * 100, 2),
            "amplitude_pct": round((hi / lo - 1) * 100, 2),
            "daily_vol_ann": round(vol * 100, 1) if vol else None}


def main():
    print("盈利策略迭代 · 第三轮：365 天验证 A+B + 多币种（全模拟）")
    print("规则锁定：S3 RSI 20/80 + Maker 混合现实成本；粒度 1h；只用 1x。")
    print("达标标准：前后两半都为正且全 365 天 1 倍净收益 >2%（三币平均与八币平均同时看）。")
    data = {}
    for sym in SYMBOLS:
        bars = fetch_candles_1h(sym)
        funding = fetch_funding(sym)
        data[sym] = (bars, funding)
        days = group_days(bars, 24)
        print(f"[{sym}] 完整交易日：{len(days)} 天，首日 {min(days)} 末日 {max(days)}"
              f"（Meme 币标注：{'是' if sym in MEME else '否'}）")
        assert len(days) == 365, f"{sym} 完整日应为 365 天，实际 {len(days)}"

    # ---- regime 表 ----
    print("\n=== Regime（1h 数据，UTC 自然日）===")
    for sym in SYMBOLS:
        bars, _ = data[sym]
        days_all = set(group_days(bars, 24).keys())
        for wname, subset in [("全365d", None),
                              ("前185d", {d for d in days_all if d < SPLIT_DAY.date()}),
                              ("后180d", {d for d in days_all if d >= SPLIT_DAY.date()})]:
            sub_bars = [b for b in bars
                        if subset is None or datetime.fromtimestamp(b["t"], timezone.utc).date() in subset]
            r = regime_table(sub_bars)
            print(f"  {sym} {wname}：{r['days']} 天 {r['start']}~{r['end']} "
                  f"涨跌 {r['change_pct']:+.2f}% 振幅 {r['amplitude_pct']:.1f}% "
                  f"日波动年化 {r['daily_vol_ann']}%")

    # ---- 主回测：每币 x 三窗口 ----
    print("\n=== 主回测：A+B（S3 20/80 + Maker 混合现实，1h，1x）===")
    all_results, all_trades_m1 = [], []
    for sym in SYMBOLS:
        bars, funding = data[sym]
        days_all = set(group_days(bars, 24).keys())
        days_front = {d for d in days_all if d < SPLIT_DAY.date()}
        days_back = {d for d in days_all if d >= SPLIT_DAY.date()}
        for wname, subset in [("365d", None), ("前185d", days_front), ("后180d", days_back)]:
            trades, curve, ndays = run_s3_1h(bars, funding, sym, subset)
            res = summarize_window(sym, trades, curve, "R3-A+B-1h")
            res["split"] = wname
            res["days"] = ndays
            all_results.append(res)
            if wname == "365d":
                for t in trades:
                    t2 = dict(t)
                    t2["variant"] = "R3-A+B-1h"
                    t2["split"] = "前185d" if datetime.fromtimestamp(
                        t["entry_t"], timezone.utc).date() < SPLIT_DAY.date() else "后180d"
                    all_trades_m1.append(t2)
            print(f"[R3 {sym} {wname}] n={res['trades']} 胜率={res['win_rate']} "
                  f"Taker {res['taker_net_pct']*100:+.2f}% | M1 {res['m1_net_pct']*100:+.2f}% "
                  f"(t={res['m1_t']}, MDD {res['m1_max_dd']*100:.2f}%) | "
                  f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                  f"资金费={res['funding_cost_sum']:+.2f} 平均持仓={res['avg_hold_min']}分钟 "
                  f"爆仓={res['liquidations']}")

    # ---- 汇总：三币平均 / 八币平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x）===")
    for wname in ["365d", "前185d", "后180d"]:
        for scope, syms in [("三币", CORE3), ("八币", SYMBOLS)]:
            rs = [r for r in all_results if r["split"] == wname and r["symbol"] in syms]
            for key in ("taker_net_pct", "m1_net_pct", "m2_net_pct"):
                avg = sum(r[key] for r in rs) / len(rs)
                print(f"  {wname} {scope} {key} 平均 {avg*100:+.2f}%  "
                      f"（{' / '.join(f'{r['symbol'][:4]} {r[key]*100:+.2f}%' for r in rs)}）")
        # pooled t（全部交易逐笔 M1 净收益占权益 %）
        pnls = []
    # pooled t：用 365d 明细逐笔 M1 净收益
    print("\n=== Pooled t 值（M1 逐笔净收益占权益 %，365d 明细）===")
    for wname in ["365d", "前185d", "后180d"]:
        sub = [t for t in all_trades_m1 if wname == "365d" or t["split"] == wname]
        # 注意：前/后半段的 M1 逐笔 pnl 是在 365d 权益曲线上跑出来的，
        # 与分窗口重置权益跑出来的 M1 有微小差异（权益基数不同），
        # 这里只作 pooled t 的参考口径，分窗口的 t 以 summarize_window 的 m1_t 为准。
        vals = [t["pnl_maker_m1"] / START_EQUITY for t in sub]
        print(f"  {wname}：n={len(vals)} pooled t={t_value(vals)}")

    # ---- 交叉对照：1h 后 180 天 Taker vs 30m 版 A 同窗口 Taker ----
    print("\n=== 交叉对照：1h 后 180 天 Taker vs 30m 版 A 同窗口 Taker ===")
    a_sum = json.load(open(os.path.join(DATA_DIR, "gate_iter_A_summary.json")))
    a_lookup = {(d["symbol"], d["split"]): d for d in a_sum}
    for sym in CORE3:
        r1h = [r for r in all_results if r["symbol"] == sym and r["split"] == "后180d"][0]
        ra = a_lookup[(sym, "180d")]
        print(f"  {sym} 2026-05-20~11-15（同一窗口）：1h Taker {r1h['taker_net_pct']*100:+.2f}% n={r1h['trades']} "
              f"| 30m A Taker {ra['net_return']*100:+.2f}% n={ra['trades']} "
              f"（30m 版 A 全 180 天的数字；粒度从 30m 换成 1h 的效应 = 两者之差）")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 M2）===")
    ok = True
    for scope, syms in [("三币平均", CORE3), ("八币平均", SYMBOLS)]:
        row = {}
        for wname in ["前185d", "后180d", "365d"]:
            rs = [r for r in all_results if r["split"] == wname and r["symbol"] in syms]
            row[wname] = sum(r["m2_net_pct"] for r in rs) / len(rs)
        good = row["前185d"] > 0 and row["后180d"] > 0 and row["365d"] > 0.02
        ok = ok and good
        print(f"  {scope} M2：前185d {row['前185d']*100:+.2f}% / 后180d {row['后180d']*100:+.2f}% / "
              f"全365d {row['365d']*100:+.2f}% → {'达标' if good else '不达标'}")
    print(f"  总体：{'达标' if ok else '不达标'}")
    # 单独拎出两半都为正的币
    print("  单币检查（M2，两半都为正的币）：")
    for sym in SYMBOLS:
        rf = [r for r in all_results if r["symbol"] == sym and r["split"] == "前185d"][0]
        rb = [r for r in all_results if r["symbol"] == sym and r["split"] == "后180d"][0]
        r365 = [r for r in all_results if r["symbol"] == sym and r["split"] == "365d"][0]
        flag = "★ 两半都为正" if (rf["m2_net_pct"] > 0 and rb["m2_net_pct"] > 0) else ""
        print(f"    {sym}: 前 {rf['m2_net_pct']*100:+.2f}% / 后 {rb['m2_net_pct']*100:+.2f}% / "
              f"全 {r365['m2_net_pct']*100:+.2f}% (n={r365['trades']}, t={r365['m1_t']}) {flag}")

    with open(os.path.join(DATA_DIR, "gate_iter_round3_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round3_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "split", "symbol", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades_m1, key=lambda x: (x["entry_t"], x["symbol"])):
            w.writerow(["R3-A+B-1h", t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["liquidated"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round3_summary.json")
    print("明细已写入：data/gate_iter_round3_trades.csv（M1 逐笔，365 天）")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
