"""
盈利策略迭代 · 第八轮：F1（BTC 领涨-山寨跟随）的 15m 版复核（全模拟）

只做合约、只做日内、只做 Gate（gate.io）虚拟币永续合约。不做资金费率套利。
全程模拟，不动真钱、不开户、不交易、不建议投真钱、不承诺收益。

动因（第七轮 §6 第 1 条）：F1 在 1h 上是 19 个家族里唯二毛利为正的家族
（+4,832 USDT），但毛利只有成本的约 1/5。报告推测山寨跟随很可能发生在
同一小时之内，1h 收盘才进场已经晚了。本轮只做这一件事：F1 的 15m 版复核。

规则（与第七轮 F1 一模一样，只换粒度，按时间对齐；不换参数、不重新挑阈值）：
  信号根（15m）：UTC 08:00~19:00（bar 时间戳的小时，与第七轮同款约定）；
  BTC 2h 收益 rBTC = c[i]/c[i-8]-1（8 根 15m = 2h），|rBTC| >= 0.5%；
  山寨自身 2h 收益 rALT = c[i]/c[i-8]-1，|rALT| < 0.5*|rBTC|（还没跟上）；
  方向 = sign(rBTC)；下一根 15m 开盘进场；
  止损 1xATR、止盈 1.5xATR（ATR(14, 15m)，信号根）；
  最多持 16 根 15m（= 4h，与 1h 版 4 根对齐）；每天每币最多 2 笔；
  当天最后一根 15m（23:45）收盘强制平仓（= 午夜，与 1h 版 23:00 根收盘对齐）；
  单日 -2% 熔断后不再开新仓；同根同时碰止损和止盈先判止损（前置同款约定）。
  只做 7 个山寨，不做 BTC 本身。
成本：主口径 Taker，一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
  Maker 只做上限对照 M1 与混合现实 M2（沿用第三轮公式与 B 实测成交率/
  逆向惩罚，新币种用 SOL 保守代理；与第七轮同款）。
资金费：复用第三轮本地缓存 gate_funding_365d_{SYM}.json（2026-05-21 起），
  本窗口全部在 2026-05-21 之后，资金费正常计（08:00/16:00 结算点，同第七轮）。

窗口：Gate 15m 接口只允许最近 10,000 根（实测：from/to 超出会报
  "Candlestick too long ago. Maximum 10000 points recently are allowed"）。
  取数时（2026-11-17 07:00 UTC）最早可取的 15m 根为 2026-08-05 03:15，
  故最长干净完整日窗口为 2026-08-06~2026-11-16，共 103 个完整 UTC 日
  （9,888 根/币 <= 10,000）。前半段 2026-08-06~09-25（51 天），
  后半段 2026-09-26~11-16（52 天）。
对照：同一窗口的 1h 版 F1（规则、参数、引擎全部与第七轮相同，只换粒度），
  用第三轮本地 1h 缓存 + 新取的 2026-11-16 当天 1h 补齐；只做对照，
  不做挑选。比较口径：每笔毛利、毛利/成本、净收益——不是毛利绝对值
  （15m 窗口只有 103 天，绝对毛利天然小于 1h 版 365 天的 +4,832）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，否则
  诚实写不达标。15m 版毛利若仍为正且每笔毛利明显放大，说明跟随确实在
  小时内；若毛利消失或变负，诚实写 F1 这条线索也断了。

运行：python3 gate_iter_round8.py（首次联网取 15m；之后只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round8_summary.json
      + data/gate_iter_round8_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import hashlib
import json
import math
import os
import statistics
import time
import urllib.request
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
ALTS = [s for s in SYMBOLS if s != "BTC_USDT"]
MEME = {"DOGE_USDT"}  # 单独标注 Meme 币风险

BASE = "https://api.gateio.ws/api/v4"
START_DAY = datetime(2026, 8, 6, tzinfo=timezone.utc)   # 含，103 个完整日之首
END_DAY = datetime(2026, 11, 17, tzinfo=timezone.utc)   # 不含（11-17 未走完）
SPLIT_DAY = datetime(2026, 9, 26, tzinfo=timezone.utc)  # 前半段止于 09-25
N_DAYS = 103

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in ["BTC_USDT", "ETH_USDT", "SOL_USDT"]:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "gate-r8/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_15m(contract):
    """15m K 线，2026-08-06~2026-11-16（103 个完整日，9,888 根）。
    from/to 按 7 天分页；端点会多返回边界根，去重处理。"""
    path = os.path.join(DATA_DIR, f"gate_15m_103d_{contract}.csv")
    if os.path.exists(path):
        with open(path, newline="") as f:
            rows = list(csv.DictReader(f))
        bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
                 "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
                 "sum": float(r["sum"])} for r in rows]
        if (bars and bars[0]["t"] == int(START_DAY.timestamp())
                and bars[-1]["t"] == int((END_DAY - timedelta(minutes=15)).timestamp())
                and len(bars) == N_DAYS * 96):
            print(f"[{contract}] 15m 用缓存：{len(bars)} 根 "
                  f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
                  f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
            return bars
    bars = []
    cur = START_DAY
    while cur < END_DAY:
        nxt = min(cur + timedelta(days=7), END_DAY)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=15m"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    bars = [b for b in bars
            if int(START_DAY.timestamp()) <= b["t"] < int(END_DAY.timestamp())]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] 15m 已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
    return bars


def fetch_1h_day(contract, day):
    """取某一天的 1h K 线（用于补齐 1h 对照的 2026-11-16 当天）。"""
    nxt = day + timedelta(days=1)
    url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=1h"
           f"&from={int(day.timestamp())}&to={int(nxt.timestamp())}")
    data = http_get(url)
    out = [{"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
            "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
            "sum": float(d["sum"])} for d in data]
    time.sleep(0.3)
    return sorted({b["t"]: b for b in out}.values(), key=lambda b: b["t"])


def load_bars_1h_control(symbol):
    """1h 对照：第三轮本地缓存（2025-11-16~2026-11-16 00:00 根）+
    新取 2026-11-16 当天 24 根；截到与 15m 相同的 103 天窗口。"""
    with open(os.path.join(DATA_DIR, f"gate_1h_365d_{symbol}.csv"), newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    extra = fetch_1h_day(symbol, datetime(2026, 11, 16, tzinfo=timezone.utc))
    merged = sorted({b["t"]: b for b in bars + extra}.values(), key=lambda b: b["t"])
    out = [b for b in merged
           if int(START_DAY.timestamp()) <= b["t"] < int(END_DAY.timestamp())]
    return out


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason in ("stop_loss", "eod", "max_hold"):
        exit_rate = TAKER_EXIT
    elif reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def simulate(symbol, signals, funding, days_subset, max_per_day, label, bars_per_day):
    """通用日内引擎（第七轮同款，参数化 bars_per_day）。
    信号：{entry_t: {direction, atr, sl_mult, tp_mult, max_hold（根数）}}。
    入场价 = 入场根开盘价；止损/止盈按入场价与信号根 ATR 现算；
    同根同时碰到先判止损；持满 max_hold 根在该根收盘平仓；当天
    最后一根收盘强制平仓；单日 -2% 熔断后不再开新仓。"""
    bars = simulate.BARS[symbol]
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= pos["max_hold"] - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": sig["max_hold"]}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def build_f1_signals(alt_bars, btc_bars, alt_atr, lookback, max_hold):
    """F1：BTC 2h 大波动 + 山寨没跟上 -> 顺 BTC 方向做山寨。
    15m 版：lookback=8（8 根 15m = 2h），max_hold=16（16 根 15m = 4h）。
    1h 对照版：lookback=2，max_hold=4（第七轮原样）。其余一字不改。"""
    sigs = {}
    for i in range(lookback, len(alt_bars)):
        b = alt_bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour <= 19):
            continue
        if alt_atr[i] is None:
            continue
        r_btc = btc_bars[i]["c"] / btc_bars[i - lookback]["c"] - 1
        if abs(r_btc) < 0.005:
            continue
        r_alt = alt_bars[i]["c"] / alt_bars[i - lookback]["c"] - 1
        if abs(r_alt) >= 0.5 * abs(r_btc):
            continue  # 山寨已经跟上了，没有滞后可吃
        if i + 1 >= len(alt_bars):
            continue
        entry_t = alt_bars[i + 1]["t"]  # 下一根开盘进场
        sigs[entry_t] = {"direction": 1 if r_btc > 0 else -1,
                         "atr": alt_atr[i], "sl_mult": 1.0, "tp_mult": 1.5,
                         "max_hold": max_hold}
    return sigs


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def summarize_window(sym, trades, curve, label, n_signals):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins += 1 if pnl_m1 > 0 else 0
    peak, mdd = m1_curve[0], 0.0
    for v in m1_curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n, "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins / n, 4) if n else None,
        "m1_max_dd": round(mdd, 4),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
    }


def main():
    print("盈利策略迭代 · 第八轮：F1（BTC 领涨-山寨跟随）15m 版复核（全模拟）")
    print("达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 取 15m 数据 ----
    data15 = {}
    for sym in SYMBOLS:
        bars = fetch_15m(sym)
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == N_DAYS, f"{sym} 完整日应为 {N_DAYS} 天，实际 {len(days)}"
        assert len(bars) == N_DAYS * 96, f"{sym} 应为 {N_DAYS * 96} 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts, f"{sym} 时间戳与 BTC 不对齐"
    print(f"数据校验通过：8 币各 {N_DAYS * 96} 根 15m、{N_DAYS} 个完整 UTC 日、"
          "时间戳完全对齐、零缺口。")
    # 与旧 90 天 15m 缓存重叠校验（BTC/ETH/SOL）
    for sym in ["BTC_USDT", "ETH_USDT", "SOL_USDT"]:
        old_path = os.path.join(DATA_DIR, f"gate_15m_{sym}.csv")
        if os.path.exists(old_path):
            with open(old_path, newline="") as f:
                old = {int(r["t"]): (float(r["o"]), float(r["h"]), float(r["l"]),
                                     float(r["c"])) for r in csv.DictReader(f)}
            new = {b["t"]: (b["o"], b["h"], b["l"], b["c"]) for b in data15[sym][0]}
            overlap = sorted(set(old) & set(new))
            mismatch = [t for t in overlap if old[t] != new[t]]
            print(f"[{sym}] 与旧 90 天缓存重叠 {len(overlap)} 根，不一致 {len(mismatch)} 根")
            # 允许的唯一不一致：旧缓存最后一根（2026-11-16 00:00）是取数时
            # 尚未走完的 K 线（o=h=l=c=开盘价），新取的是走完后的完整根——
            # 三个币同一时间戳、同一形态，确认为未完成根，不是数据错误。
            assert all(t == max(old) for t in mismatch), \
                f"{sym} 新取数据与旧缓存在非末根上不一致"
            for t in mismatch:
                print(f"    仅末根不一致 t={t}（旧 o=h=l=c={old[t]}，新 {new[t]}）："
                      "旧缓存取数时该根未走完")

    # ---- 1h 对照数据（同一窗口）----
    data1h = {}
    for sym in SYMBOLS:
        bars = load_bars_1h_control(sym)
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == N_DAYS, f"1h {sym} 完整日应为 {N_DAYS} 天，实际 {len(days)}"
        assert len(bars) == N_DAYS * 24, f"1h {sym} 应为 {N_DAYS * 24} 根，实际 {len(bars)}"
    base_ts_1h = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts_1h, f"1h {sym} 时间戳与 BTC 不对齐"
    print(f"1h 对照校验通过：8 币各 {N_DAYS * 24} 根 1h、同一 {N_DAYS} 天窗口。")

    days_all = set(group_days(data15["BTC_USDT"][0], 96).keys())
    days_front = {d for d in days_all if d < SPLIT_DAY.date()}
    days_back = {d for d in days_all if d >= SPLIT_DAY.date()}
    print(f"窗口：全 {len(days_all)} 天（2026-08-06~2026-11-16）；"
          f"前 {len(days_front)} 天 / 后 {len(days_back)} 天。")

    # ---- 生成信号 ----
    signals15, signals1h = {}, {}
    for sym in ALTS:
        btc15 = data15["BTC_USDT"][0]
        signals15[sym] = build_f1_signals(
            data15[sym][0], btc15, atr_wilder(data15[sym][0]), 8, 16)
        btc1h = data1h["BTC_USDT"][0]
        signals1h[sym] = build_f1_signals(
            data1h[sym][0], btc1h, atr_wilder(data1h[sym][0]), 2, 4)
    tot15 = sum(len(v) for v in signals15.values())
    tot1h = sum(len(v) for v in signals1h.values())
    print(f"[F1-15m] 全窗口信号数合计：{tot15}；[F1-1h 对照] 信号数合计：{tot1h}")

    windows = [("103d", None), ("前51d", days_front), ("后52d", days_back)]
    all_results, all_trades = [], []

    def run_variant(tag, label, data, sigs, bars_per_day):
        simulate.BARS = {s: data[s][0] for s in SYMBOLS}
        for sym in ALTS:
            bars, funding = data[sym]
            for wname, subset in windows:
                trades, curve, ndays = simulate(
                    sym, sigs[sym], funding, subset, 2, label, bars_per_day)
                res = summarize_window(sym, trades, curve, label, len(sigs[sym]))
                res["split"] = wname
                res["days"] = ndays
                res["variant"] = tag
                all_results.append(res)
                if wname == "103d":
                    for t in trades:
                        t2 = dict(t)
                        t2["variant"] = tag
                        t2["family"] = "F1"
                        t2["split"] = ("前51d" if datetime.fromtimestamp(
                            t["entry_t"], timezone.utc).date() < SPLIT_DAY.date() else "后52d")
                        all_trades.append(t2)
                print(f"[{tag} {sym} {wname}] n={res['trades']} 信号={res['signals']} "
                      f"胜率={res['win_rate']} 盈亏比={res['profit_factor']} "
                      f"Taker {res['taker_net_pct']*100:+.2f}% | M1 {res['m1_net_pct']*100:+.2f}% "
                      f"(t={res['m1_t']}, MDD {res['m1_max_dd']*100:.2f}%) | "
                      f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={res['gross_per_trade_usdt']:+.2f} "
                      f"成本={res['taker_cost_sum']:+.0f} 平均持仓={res['avg_hold_min']}分钟")

    print("\n=== F1-15m（主）===")
    run_variant("F1-15m", "F1-15m-BTC-lead-lag", data15, signals15, 96)
    print("\n=== F1-1h（同一窗口对照，第七轮原样）===")
    run_variant("F1-1h", "F1-1h-BTC-lead-lag", data1h, signals1h, 24)

    # ---- 汇总平均 ----
    print("\n=== 汇总：七山寨平均净收益（各币独立 10 万 USDT，1x）===")
    for tag in ("F1-15m", "F1-1h"):
        for wname, _ in windows:
            rs = [r for r in all_results if r["variant"] == tag and r["split"] == wname]
            gt = sum(r["gross_usdt"] for r in rs)
            ct = sum(r["taker_cost_sum"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            print(f"  {tag} {wname} 七山寨 Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                  f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                  f"每笔毛利 {gt/nt:+.2f} USDT")

    # ---- pooled t（全期明细，M1 逐笔）----
    print("\n=== Pooled t 值（M1 逐笔净收益占权益 %，全期明细）===")
    for tag in ("F1-15m", "F1-1h"):
        sub = [t for t in all_trades if t["variant"] == tag]
        for wname in ("103d", "前51d", "后52d"):
            s2 = [t for t in sub if wname == "103d" or t["split"] == wname]
            vals = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
            print(f"  {tag} {wname}：n={len(vals)} pooled t={t_value(vals)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker；M2 同时列出）===")
    for tag in ("F1-15m", "F1-1h"):
        row_t, row_m2 = {}, {}
        for wname, _ in windows:
            rs = [r for r in all_results if r["variant"] == tag and r["split"] == wname]
            row_t[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            row_m2[wname] = sum(r["m2_net_pct"] for r in rs) / len(rs)
        good_t = row_t["前51d"] > 0 and row_t["后52d"] > 0 and row_t["103d"] > 0.02
        good_m2 = row_m2["前51d"] > 0 and row_m2["后52d"] > 0 and row_m2["103d"] > 0.02
        print(f"  {tag} Taker：前 {row_t['前51d']*100:+.2f}% / 后 {row_t['后52d']*100:+.2f}% / "
              f"全 {row_t['103d']*100:+.2f}% → {'达标' if good_t else '不达标'}；"
              f"M2：前 {row_m2['前51d']*100:+.2f}% / 后 {row_m2['后52d']*100:+.2f}% / "
              f"全 {row_m2['103d']*100:+.2f}% → {'达标' if good_m2 else '不达标'}")
        for sym in ALTS:
            rf = [r for r in all_results if r["variant"] == tag and r["symbol"] == sym
                  and r["split"] == "前51d"][0]
            rb = [r for r in all_results if r["variant"] == tag and r["symbol"] == sym
                  and r["split"] == "后52d"][0]
            both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
            print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                  f"后 {rb['taker_net_pct']*100:+.2f}% → "
                  f"{'两半都为正' if both else '不达标'}")

    with open(os.path.join(DATA_DIR, "gate_iter_round8_summary.json"), "w") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=1)
    fields = ["variant", "family", "symbol", "split", "direction", "entry_t", "entry",
              "exit_t", "exit", "reason", "hold_min", "notional", "margin",
              "price_pnl", "funding_cost_usdt", "cost_usdt", "cost_maker_usdt",
              "pnl", "pnl_maker_m1", "pnl_pct_equity", "atr", "stop", "tp", "max_hold"]
    with open(os.path.join(DATA_DIR, "gate_iter_round8_trades.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for t in all_trades:
            w.writerow({k: t.get(k) for k in fields})
    print("\n已写 data/gate_iter_round8_summary.json / data/gate_iter_round8_trades.csv")


if __name__ == "__main__":
    main()
