#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十三轮：SUB-15m v1.2——跟踪止盈版（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

背景（预注册检验，不是事后挑参）：
  第三十一轮（SUB v1.0，固定止盈 2xATR、23:00 强制平仓）不达标：
  全期 Taker -5.25%，1,598 笔，每笔毛利 -1.29 USDT，毛利本身为负。
  2026-11-20 用户指示分系统取消 23:00 强平、改跟踪止盈。
  引擎 paper_engine.py 已按 v1.2 改好（只改分系统，主观层不动），
  本轮回测与引擎 v1.2 同口径。
  编号注意：第三十二轮是主窗口的主系统三模板改跟踪止盈版（正在跑），
  本轮分系统跟踪版编为第三十三轮，两轮不要混淆、文件不要互碰。

跑前写死的规则（单组参数，v1.2）：
  宇宙：8 个币全做，包括 BTC（BTC 也做自己的动量）：BTC、ETH、SOL、
    DOGE、LINK、XRP、BNB、ADA。
  数据：data/gate_15m_103d_{币}_USDT.csv（各 9,888 根 15m，
    2026-08-06~2026-11-16，103 天），用 15m 收盘价。
  信号：任意已收盘 15m 根（v1.2 取消 22:30 最晚信号限制，信号可跨夜），
    本币自己的 2h 收益 r = close[-1]/close[-9] - 1（8 根 15m）。
    若 |r| ≥ 0.5%，方向 = sign(r)。不看 BTC、不看其他币、不设 Killzone。
  不开新单时段（v1.1 已有，v1.2 保留，主臂）：北京时间 01:00–07:00
    不开新单，即入场时刻落在 UTC 17:00–23:00 的信号作废。
  入场：信号根下一根 15m 开盘价。初始止损 = 入场价 ± 1xATR(15m,14
    Wilder)，ATR 与第二十轮 MAIN-15m 同口径。
  取消固定止盈 2xATR（tp=None）。跟踪止损：只按已收盘 15m 根更新；
    极值 peak 初始为入场成交价，做多取入场以来已收盘 15m 最高价、
    做空取最低价；有利浮动 ≥ 1xATR 时激活，止损先移到成本价（入场价），
    之后止损 = peak ∓ 1xATR（做多 peak-1xATR，做空 peak+1xATR），
    只朝有利方向棘轮，ATR 用入场时数值；未激活前止损保持初始 1xATR。
    与第三十二轮主系统版的区别：第三十二轮无激活门槛、从入场起就按
    peak ∓ 1xATR 跟踪；本轮 v1.2 有 +1xATR 激活门槛，以引擎为准。
  出场：当根 15m 最低价 ≤ 止损（做多）/ 最高价 ≥ 止损（做空）即按
    止损价平，原因记 trailing_stop（已激活）或 stop_loss（未激活）；
    出场执行按止损市价单口径（与第三十一轮的止损成本同口径）。
  最多持 16 根（4h，与第三十一轮同口径：入场后第 15 根收盘即平，
    原因 max_hold）；取消 23:00 强制平仓，持仓可跨 00:00 UTC（最多
    持 4h 封顶）；数据末尾仍有持仓时按最后一根收盘价平，原因 data_end。
  每天每币最多 2 笔（按入场 UTC 日期计）；单币单日 -2000 USDT 熔断
    （按平仓实现盈亏的 UTC 日期计，与引擎 sub_day_pnl 口径一致）。
  口径：每笔名义 10,000、1 倍；成本按标准回测口径 Taker 双边 0.25%
    名义（每笔固定 25 USDT），同时记毛利（价差毛利 − 资金费，未扣
    交易成本）以便算毛利/成本比。资金费：与引擎 funding_cost_between
    一字相同，只计 08:00/16:00 结算点（00:00 结算点不计，与第三十一轮
    同口径），入场日与入场日+1 两天内 entry_t < 结算点 <= exit_t 的
    点按 Gate 实际费率计（gate_funding_365d）；2026-11-16 三个结算点
    无费率数据，按 0 计并在报告中注明。
  前后两半：前半 2026-08-06~09-20、后半 2026-09-21~11-16（与第三十一轮
    同一切法，实际为前 46 天 / 后 57 天）。

两个臂（同一脚本内跑，信号/出场以外全部相同）：
  主臂 SUB-v1.2：完整 v1.2（含夜间禁单时段）。
  诊断臂 SUB-v1.2-diag：只改跟踪止盈、不加夜间禁单时段，用于分离
    两个改动的效果。诊断臂不参与达标判定。

达标标准（写死，跑完对照，不许事后改）：只有同时满足“全期 1x 净
  收益 >2% 且前后两半都为正”才算通过；否则判定不达标。主口径
  Taker。8 币平均（各币独立 10 万 USDT，1x）。只看主臂。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) 数据校验：8 币各 9,888 根 15m / 103 天，时间戳对齐、零缺口；
      全量流式模拟，不截断。
  (b) 信号数人工抽查：任取一币，抽一根 |r|≥0.5% 的信号根核对
      r、方向、入场时刻与初始止损；抽一个落在夜间禁单时段的信号
      核对它被拦掉。
  (c) 首笔交易与一笔 trailing_stop 交易人工核对触发链、入场价、
      极值、激活点、出场原因与原始 K 线一致。
  (d) 账目核对：笔数 x 25 = Taker 成本合计；毛利 − 成本 = Taker 净。

运行：python3 gate_iter_round33.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round33_summary.json
      + data/gate_iter_round33_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""

import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]

# ---- 预注册、跑前写死：单组参数，不许改 ----
TP_MULT = None           # v1.2：取消固定止盈 2xATR（跟踪止盈替代）
SL_MULT = 1.0            # 止损 1xATR
SPLIT_R31 = datetime(2026, 9, 21, tzinfo=timezone.utc)  # 前半段止于 09-20
LOOKBACK = 8             # 2h = 8 根 15m
MAX_HOLD = 16            # 最多持 16 根（4h）
MAX_PER_DAY = 2          # 每天每币最多 2 笔
# v1.2：取消最晚信号 22:30 限制（23:00 强平已取消，信号可跨夜）
TRAIL_ATR_MULT = 1.0      # 跟踪距离：极值回撤 1xATR 即触发跟踪止损
TRAIL_ACTIVATE_MULT = 1.0  # 激活门槛：有利浮动 ≥1xATR 才开始跟踪
DAILY_HALT = -2000.0       # 单币单日 -2000 USDT 熔断（2% x 10 万权益）

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
NOTIONAL = 10_000.0      # 每笔固定名义（任务书）；每笔成本恰为固定 25 USDT
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, entry_t, exit_t, notional, direction):
    """与引擎 paper_engine.funding_cost_between 一字相同：只计 08:00/16:00
    结算点（00:00 结算点不计，与第三十一轮同口径），入场日与入场日+1
    两天内 entry_t < 结算点 <= exit_t 的点按实际费率计。"""
    if not funding:
        return 0.0
    cost = 0.0
    day = datetime.fromtimestamp(entry_t, timezone.utc).date()
    for d_offset in (0, 1):
        ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc) + timedelta(days=d_offset)
        for h in (8, 16):
            s = int((ds + timedelta(hours=h)).timestamp())
            if entry_t < s <= exit_t and s in funding:
                cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def _entry_in_no_new_window(entry_t):
    """入场时刻（UTC 时间戳）是否落在北京时间 01:00–07:00 不开新单时段。
    与引擎 _sub_entry_in_no_new_window 同口径：北京时间小时 = (UTC 小时 + 8) % 24。"""
    dt_utc = datetime.fromtimestamp(entry_t, timezone.utc)
    beijing_hour = (dt_utc.hour + 8) % 24
    return 1 <= beijing_hour < 7


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def entry_hour_utc(entry_t):
    """入场小时：入场时间戳的 UTC 小时。"""
    return datetime.fromtimestamp(entry_t, timezone.utc).hour


# ----------------------------------------------------------------------
# SUB 信号：本币自己的 2h 动量跟随（不看 BTC、不看其他币）
# ----------------------------------------------------------------------
def build_sub_signals(bars, atr, lookback, night_block):
    """信号根：任意已收盘 15m（v1.2 取消 22:30 最晚信号限制，信号可跨夜）；
    本币 2h 收益 r = close[-1]/close[-9] - 1；|r| ≥ 0.5% 则方向 = sign(r)；
    入场为信号根下一根开盘价。night_block=True 时，入场时刻落在北京时间
    01:00–07:00（UTC 17:00–23:00）的信号作废。
    返回 (信号字典 keyed by 入场时刻, 被禁单时段拦掉的信号数)。"""
    sigs = {}
    blocked = 0
    for i in range(lookback, len(bars)):
        b = bars[i]
        if atr[i] is None:
            continue
        r = bars[i]["c"] / bars[i - lookback]["c"] - 1
        if abs(r) < 0.005:
            continue
        if i + 1 >= len(bars):
            continue
        entry_t = bars[i + 1]["t"]
        if night_block and _entry_in_no_new_window(entry_t):
            blocked += 1
            continue
        sigs[entry_t] = {"direction": 1 if r > 0 else -1,
                         "atr": atr[i], "r": r}
    return sigs, blocked


# ----------------------------------------------------------------------
# 流式模拟：v1.2 跟踪止盈版（整条 9,888 根连续走，不按天截断）
# ----------------------------------------------------------------------
def simulate_stream(symbol, bars, signals, funding, max_per_day, label):
    """取消 23:00 强制平仓，持仓可跨 00:00 UTC，最多持 16 根封顶。
    每根处理顺序与引擎回放一致：
      (1) 已持仓先判止损（跟踪已激活记 trailing_stop，未激活记 stop_loss；
          用上一根收盘后更新的止损）；
      (2) 判持满 16 根（入场后第 15 根收盘平，原因 max_hold）；
      (3) 用本根高低更新极值与跟踪止损（激活门槛 +1xATR，棘轮只朝有利方向）；
      (4) 无持仓时按信号入场（本根开盘价）。
    出场发生在当根之内，故 exit_t 记本根开盘时刻（与第三十一轮同口径）。
    每天每币最多 2 笔按入场 UTC 日期计；单币单日 -2000 熔断按平仓实现
    盈亏的 UTC 日期计（与引擎 sub_day_pnl 口径一致）。
    入场开盘价已穿初始止损（跳空）时跳过，与引擎 sub_entry_skipped_gap_stop
    同口径。某根收盘平掉一笔后，当根不再开新仓（与第三十一轮 simulate_sub
    的 continue 口径一致）。"""
    trades = []
    curve = [START_EQUITY]
    equity = START_EQUITY
    trades_by_entry_date = {}
    day_pnl = {}          # 平仓 UTC 日期 -> 已实现 Taker 净盈亏合计
    pos = None
    n_skip_open = 0       # 信号来时已有持仓，跳过
    n_skip_cap = 0        # 当天已满 2 笔，跳过
    n_skip_breaker = 0    # 当天已实现盈亏 <= -2000，跳过

    def close_trade(tr, exit_t, exit_price, reason):
        nonlocal equity
        tr["exit_t"], tr["exit"] = exit_t, exit_price
        tr["reason"] = reason
        tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
        tr["funding_cost_usdt"] = funding_cost_between(
            funding, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
        tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
        tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
        move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
        tr["price_pnl"] = tr["notional"] * move
        tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
        tr["pnl_pct_equity"] = tr["pnl"] / START_EQUITY
        tr["peak"] = tr.get("peak")
        tr["trail_active"] = tr.get("trail_active", False)
        tr["max_favour_usdt"] = (((tr["peak"] - tr["entry"]) / tr["entry"]) * tr["direction"]
                                 * tr["notional"]) if tr.get("peak") is not None else 0.0
        equity += tr["pnl"]
        exit_date = datetime.fromtimestamp(exit_t, timezone.utc).date()
        day_pnl[exit_date] = day_pnl.get(exit_date, 0.0) + tr["pnl"]
        trades.append(tr)
        curve.append(equity)

    for gi, b in enumerate(bars):
        if pos is not None and b["t"] in signals:
            n_skip_open += 1
        just_closed = False
        if pos is not None:
            d = pos["direction"]
            exited = False
            if d == 1:
                if b["l"] <= pos["stop"]:
                    reason = "trailing_stop" if pos["trail_active"] else "stop_loss"
                    close_trade(pos, b["t"], pos["stop"], reason)
                    exited = True
            else:
                if b["h"] >= pos["stop"]:
                    reason = "trailing_stop" if pos["trail_active"] else "stop_loss"
                    close_trade(pos, b["t"], pos["stop"], reason)
                    exited = True
            if exited:
                pos = None
                just_closed = True
            elif gi - pos["entry_gi"] >= MAX_HOLD - 1:
                close_trade(pos, b["t"], b["c"], "max_hold")
                pos = None
                just_closed = True
            else:
                # 用本根收盘更新极值与跟踪止损（出场判定在前，移动在后）
                a = pos["atr"]
                if d == 1:
                    if b["h"] > pos["peak"]:
                        pos["peak"] = b["h"]
                else:
                    if b["l"] < pos["peak"]:
                        pos["peak"] = b["l"]
                if not pos["trail_active"]:
                    favour = (pos["peak"] - pos["entry"]) * d
                    if favour >= TRAIL_ACTIVATE_MULT * a:
                        pos["trail_active"] = True
                if pos["trail_active"]:
                    cand = (pos["peak"] - TRAIL_ATR_MULT * a if d == 1
                            else pos["peak"] + TRAIL_ATR_MULT * a)
                    if d == 1:
                        if cand > pos["stop"]:
                            pos["stop"] = cand
                    else:
                        if cand < pos["stop"]:
                            pos["stop"] = cand
        if pos is None and not just_closed:
            sig = signals.get(b["t"])
            if sig is None:
                continue
            entry_date = datetime.fromtimestamp(b["t"], timezone.utc).date()
            if trades_by_entry_date.get(entry_date, 0) >= max_per_day:
                n_skip_cap += 1
                continue
            if day_pnl.get(entry_date, 0.0) <= DAILY_HALT:
                n_skip_breaker += 1
                continue
            entry = b["o"]
            a = sig["atr"]
            stop = entry - SL_MULT * a if sig["direction"] == 1 else entry + SL_MULT * a
            if (sig["direction"] == 1 and entry <= stop) or (sig["direction"] == -1 and entry >= stop):
                continue
            pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                   "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                   "stop": stop, "tp": None, "atr": a,
                   "peak": entry, "trail_active": False,
                   "notional": NOTIONAL, "margin": 0.10 * NOTIONAL,
                   "exit_t": None, "exit": None, "pnl": 0.0,
                   "reason": "", "funding_cost_usdt": 0.0,
                   "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                   "hold_min": None, "pnl_pct_equity": 0.0,
                   "max_hold": MAX_HOLD}
            trades_by_entry_date[entry_date] = trades_by_entry_date.get(entry_date, 0) + 1
    if pos is not None:
        close_trade(pos, bars[-1]["t"], bars[-1]["c"], "data_end")
        pos = None
    stats = {"skip_open": n_skip_open, "skip_cap": n_skip_cap,
             "skip_breaker": n_skip_breaker}
    return trades, curve, stats



def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "gross_cost_ratio": round(gross_sum / taker_cost_sum, 4) if taker_cost_sum else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def main():
    print("盈利策略迭代 · 第三十三轮：SUB-15m v1.2——跟踪止盈版（全模拟）")
    print("8 币全做（各做自己的 2h 动量）；不看 BTC、不设 Killzone；取消固定止盈 2xATR 与 23:00 强平。")
    print("初始止损 1xATR(15m,14)；有利浮动 ≥1xATR 激活跟踪，止损按极值 ∓1xATR 棘轮；最多持 16 根；")
    print("主臂含北京时间 01:00–07:00（UTC 17:00–23:00）不开新单；诊断臂只改跟踪止盈、不加禁单时段。")
    print("达标标准：前后两半都为正且全期 1x 净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data15 = {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    # ---- 资金费覆盖检查：2026-11-16 三个结算点无数据，按 0 计 ----
    miss_days = set()
    for sym in SYMBOLS:
        funding = data15[sym][1]
        for h in (0, 8, 16):
            s = int((datetime(2026, 11, 16, tzinfo=timezone.utc) + timedelta(hours=h)).timestamp())
            if s not in funding:
                miss_days.add((sym, h))
    print(f"资金费缺失：2026-11-16 的 00:00/08:00/16:00 三个结算点在全部 8 币的费率数据里都不存在"
          f"（费率数据止于 2026-11-15 16:00），共 {len(miss_days)} 个（币，结算点）按 0 计；"
          f"其余结算点均按实际费率计。")

    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_R31.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_R31.date()}
    print(f"窗口：全 103d（前 {len(front_15)} 天 2026-08-06~09-20 / "
          f"后 {len(back_15)} 天 2026-09-21~11-16）。")

    windows = [("103d", None), ("前46d", front_15), ("后57d", back_15)]
    split_fn = lambda et: ("前46d" if datetime.fromtimestamp(et, timezone.utc).date()
                           < SPLIT_R31.date() else "后57d")

    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}

    arms = [("SUB-v1.2", "SUB-15m-v1.2", True),
            ("SUB-v1.2-diag", "SUB-15m-v1.2-diag", False)]
    all_results, all_trades = [], []
    arm_agg = {}
    arm_blocked = {}
    for arm, variant, night_block in arms:
        sig = {}
        blocked_map = {}
        blocked_total = 0
        for sym in SYMBOLS:
            s, blocked = build_sub_signals(data15[sym][0], atr15[sym], LOOKBACK, night_block)
            sig[sym] = s
            blocked_map[sym] = blocked
            blocked_total += blocked
        arm_blocked[arm] = blocked_map
        print(f"[{arm}] 信号数（入场时刻）：8 币合计 {sum(len(v) for v in sig.values())}；"
              + "、".join(f"{s.replace('_USDT', '')} {len(sig[s])}" for s in SYMBOLS)
              + (f"；夜间禁单时段拦掉 {blocked_total} 个信号" if night_block else "；无夜间禁单过滤") + "。")
        arm_trades = []
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            trades, curve, stats = simulate_stream(sym, bars, sig[sym], funding, MAX_PER_DAY, variant)
            arm_trades.extend(trades)
            print(f"[{arm} {sym} 全期] n={len(trades)} 跳过信号：持仓中 {stats['skip_open']} / "
                  f"满2笔 {stats['skip_cap']} / 熔断 {stats['skip_breaker']}")
        arm_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
        for sym in SYMBOLS:
            st = [t for t in arm_trades if t["symbol"] == sym]
            for wname, _ in windows:
                wt = [t for t in st if wname == "103d" or split_fn(t["entry_t"]) == wname]
                wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                eq = START_EQUITY
                wcurve = [eq]
                for t in wt_sorted:
                    eq += t["pnl"]
                    wcurve.append(eq)
                res = summarize(sym, wt_sorted, wcurve, variant, len(sig[sym]))
                res["arm"] = arm
                res["variant"] = variant
                res["family"] = "SUB"
                res["tp_mult"] = TP_MULT
                res["granularity"] = "15m"
                res["split"] = wname
                res["days"] = 103 if wname == "103d" else (46 if wname == "前46d" else 57)
                res["signals_total"] = len(sig[sym])
                res["signals_pass"] = len(sig[sym])
                res["signal_pass_rate"] = 1.0
                res["signals_blocked_night"] = blocked_map[sym]
                all_results.append(res)
                print(f"[{arm} {sym} {wname}] n={res['trades']} "
                      f"胜率={res['win_rate']} 盈亏比={res['profit_factor']} "
                      f"Taker {res['taker_net_pct']*100:+.2f}% "
                      f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                      f"毛利={res['gross_usdt']:+.0f} 每笔毛利={res['gross_per_trade_usdt']:+.2f} "
                      f"毛利/成本={res['gross_cost_ratio']} 成本={res['taker_cost_sum']:+.0f} "
                      f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")
        print(f"\n=== 汇总：{arm} 平均净收益（8 币独立 10 万 USDT，1x，主口径 Taker）===")
        agg = {}
        for wname, _ in windows:
            rs = [r for r in all_results if r["arm"] == arm and r["split"] == wname]
            gt = sum(r["gross_usdt"] for r in rs)
            ct = sum(r["taker_cost_sum"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
            avg_pct = sum(r["taker_net_pct"] for r in rs) / len(rs)
            agg[wname] = avg_pct
            print(f"  {arm} {wname}：Taker 平均 {avg_pct*100:+.2f}% / "
                  f"M1 平均 {sum(r['m1_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                  f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                  f"每笔毛利 {gt/nt:+.2f} USDT 毛利/成本 {gt/ct:.3f} "
                  f"胜率 {wr:.3f}")
        arm_agg[arm] = agg
        print(f"\n=== Pooled t 值（{arm}，全期明细，逐笔净收益占权益 %）===")
        for wname, _ in windows:
            s2 = arm_trades if wname == "103d" else [t for t in arm_trades if split_fn(t["entry_t"]) == wname]
            vt = [t["pnl"] / START_EQUITY for t in s2]
            vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in s2]
            print(f"  {arm} {wname}：n={len(s2)} pooled t(Taker)={t_value(vt)} "
                  f"pooled t(毛利)={t_value(vg)}")
        ftot = sum(t["funding_cost_usdt"] for t in arm_trades)
        fcross = sum(1 for t in arm_trades if t["funding_cost_usdt"] != 0)
        print(f"\n资金费（{arm}）：全期合计 {ftot:+.2f} USDT（{fcross}/{len(arm_trades)} 笔跨结算点被计费）。")
        for t in arm_trades:
            t2 = dict(t)
            t2["arm"] = arm
            t2["variant"] = variant
            t2["family"] = "SUB"
            t2["tp_mult"] = TP_MULT
            t2["granularity"] = "15m"
            t2["split"] = split_fn(t["entry_t"])
            t2["entry_hour_utc"] = entry_hour_utc(t["entry_t"])
            all_trades.append(t2)

    # ---- 达标判定（主臂）----
    print("\n=== 达标判定（主口径 Taker，主臂 SUB-v1.2）===")
    agg = arm_agg["SUB-v1.2"]
    good = agg["前46d"] > 0 and agg["后57d"] > 0 and agg["103d"] > 0.02
    print(f"  SUB-v1.2 Taker：前 {agg['前46d']*100:+.2f}% / "
          f"后 {agg['后57d']*100:+.2f}% / 全 {agg['103d']*100:+.2f}% → "
          f"{'达标' if good else '不达标'}")
    for sym in SYMBOLS:
        rf = [r for r in all_results if r["arm"] == "SUB-v1.2" and r["symbol"] == sym and r["split"] == "前46d"][0]
        rb = [r for r in all_results if r["arm"] == "SUB-v1.2" and r["symbol"] == sym and r["split"] == "后57d"][0]
        both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
        print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
              f"后 {rb['taker_net_pct']*100:+.2f}% → "
              f"{'★ 两半都为正' if both else ''}")
    print(f"\n  本轮判定：{'通过' if good else '不通过'}")

    # ---- 诊断：出场原因、跟踪止盈效果、夜间禁单、跨夜持仓 ----
    print("\n=== 诊断 ===")
    for arm, _, _ in arms:
        at = [t for t in all_trades if t["arm"] == arm]
        rc = Counter(t["reason"] for t in at)
        print(f"  [{arm}] 出场原因：{dict(sorted(rc.items()))}（共 {len(at)} 笔）")

        def _s(ts):
            return (f"n={len(ts)} 净={sum(t['pnl'] for t in ts):+.0f} "
                    f"胜={sum(1 for t in ts if t['pnl'] > 0)} "
                    f"毛利={sum(t['price_pnl'] - t['funding_cost_usdt'] for t in ts):+.0f}")
        tr = [t for t in at if t["reason"] == "trailing_stop"]
        sl = [t for t in at if t["reason"] == "stop_loss"]
        mh = [t for t in at if t["reason"] == "max_hold"]
        de = [t for t in at if t["reason"] == "data_end"]
        print(f"    trailing_stop：{_s(tr)}；stop_loss：{_s(sl)}；"
              f"max_hold：{_s(mh)}；data_end：{_s(de)}")
        if tr:
            gb = sum(t["max_favour_usdt"] - t["price_pnl"] for t in tr)
            print(f"    跟踪止盈笔均：峰值有利毛利 "
                  f"{sum(t['max_favour_usdt'] for t in tr)/len(tr):+.2f} / "
                  f"实际价差毛利 {sum(t['price_pnl'] for t in tr)/len(tr):+.2f} / "
                  f"平均回吐 {gb/len(tr):+.2f} USDT；"
                  f"跟踪出场里盈利笔 {sum(1 for t in tr if t['pnl'] > 0)}/{len(tr)}")
        ovn = [t for t in at
               if datetime.fromtimestamp(t["exit_t"], timezone.utc).date()
               > datetime.fromtimestamp(t["entry_t"], timezone.utc).date()]
        print(f"    跨夜持仓（出场日期晚于入场日期）：{len(ovn)} 笔，"
              f"净 {sum(t['pnl'] for t in ovn):+.0f}，"
              f"毛利 {sum(t['price_pnl'] - t['funding_cost_usdt'] for t in ovn):+.0f}")
        hours = Counter(t["entry_hour_utc"] for t in at)
        early = sum(v for h, v in hours.items() if 0 <= h <= 5)
        print(f"    入场小时分布（UTC）：{dict(sorted(hours.items()))}；"
              f"00:00–05:00 UTC 占 {early/len(at)*100:.1f}%")
    m = [t for t in all_trades if t["arm"] == "SUB-v1.2"]
    d = [t for t in all_trades if t["arm"] == "SUB-v1.2-diag"]
    print(f"\n  夜间禁单时段的影响（主臂 − 诊断臂）：笔数 {len(m)-len(d):+d}，"
          f"Taker 净 {sum(t['pnl'] for t in m)-sum(t['pnl'] for t in d):+.0f}，"
          f"毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in m)-sum(t['price_pnl']-t['funding_cost_usdt'] for t in d):+.0f}；"
          f"主臂拦掉信号合计 {sum(arm_blocked['SUB-v1.2'].values())} 个")
    # 多空拆分（主臂）
    for arm, _, _ in arms:
        at = [t for t in all_trades if t["arm"] == arm]
        lo = [t for t in at if t["direction"] == 1]
        sh = [t for t in at if t["direction"] == -1]
        print(f"  [{arm}] 多空拆分：LONG n={len(lo)} 净 {sum(t['pnl'] for t in lo):+.0f} "
              f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in lo)/len(lo):+.2f} "
              f"胜率 {sum(1 for t in lo if t['pnl'] > 0)/len(lo):.3f}；"
              f"SHORT n={len(sh)} 净 {sum(t['pnl'] for t in sh):+.0f} "
              f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in sh)/len(sh):+.2f} "
              f"胜率 {sum(1 for t in sh if t['pnl'] > 0)/len(sh):.3f}")

    with open(os.path.join(DATA_DIR, "gate_iter_round33_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round33_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min", "peak", "trail_active",
                    "max_favour_usdt"])
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"], t.get("peak"), t.get("trail_active"),
                        round(t.get("max_favour_usdt", 0.0), 2)])
    print("\n汇总已写入：data/gate_iter_round33_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round33_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
