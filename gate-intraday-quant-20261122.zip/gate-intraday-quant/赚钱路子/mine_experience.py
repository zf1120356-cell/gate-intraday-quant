#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回测经验挖掘（描述性挖掘，不开新轮、不调参、不重跑回测）
数据：~/workspace/赚钱路子/data/gate_iter_round*_trades*.csv（第1-35轮）
口径：毛利 = 价差盈亏 - 资金费；Taker净 = 毛利 - Taker成本；成本线约25 USDT/笔
排除：gate_iter_round32_trades_v1_entry_trail.csv（第三十二轮初版，规则误读，已作废）
      第1轮（无trades文件）、第5/6轮（资金费套利，无逐笔文件）——记为算不出
输出：/tmp/mine_out.json（全部数字）+ 打印关键表
"""
import csv, glob, json, math, os, statistics
from datetime import datetime, timezone
from collections import defaultdict

DATA = os.path.expanduser('~/workspace/赚钱路子/data')
COST_LINE = 25.0

def parse_dt(s):
    if s is None or s == '':
        return None
    s = s.strip()
    try:
        return datetime.fromtimestamp(float(s), tz=timezone.utc)
    except Exception:
        pass
    try:
        return datetime.fromisoformat(s.replace('Z', '+00:00'))
    except Exception:
        return None

def load_trades():
    trades = []
    files = sorted(glob.glob(os.path.join(DATA, 'gate_iter_round*_trades*.csv')))
    for f in files:
        base = os.path.basename(f)
        if 'round32_trades_v1_entry_trail' in base:
            continue  # 已作废的初版
        import re
        m = re.search(r'round(\d+)', base)
        rnd = int(m.group(1))
        with open(f, newline='', encoding='utf-8') as fh:
            for row in csv.DictReader(fh):
                t = {'round': rnd, 'file': base}
                sym = (row.get('symbol') or '').replace('_USDT', '')
                t['symbol'] = sym
                d = (row.get('direction') or '').strip()
                t['direction'] = 1 if d in ('1', 'LONG', 'long') else (-1 if d in ('-1', 'SHORT', 'short') else 0)
                # gross
                if 'gross_usdt' in row and row.get('gross_usdt') not in (None, ''):
                    gross = float(row['gross_usdt'])
                    fund = 0.0  # round2 gross_usdt 已是扣资金费后的毛利（与报告口径一致，见核对）
                else:
                    pp = row.get('price_pnl') or row.get('price_pnl_usdt')
                    fund = float(row.get('funding_cost_usdt') or 0)
                    gross = float(pp) - fund
                t['gross'] = gross
                t['funding'] = fund
                cost = row.get('cost_usdt') or row.get('cost_taker_usdt')
                t['cost'] = float(cost) if cost not in (None, '') else 0.0
                t['net'] = gross - t['cost']
                et = parse_dt(row.get('entry_t') or row.get('entry_time_utc'))
                t['entry_dt'] = et
                t['entry_hour'] = et.hour if et else None
                t['month'] = et.strftime('%Y-%m') if et else None
                t['reason'] = (row.get('reason') or '').strip()
                try:
                    t['hold_min'] = float(row.get('hold_min') or 0)
                except Exception:
                    t['hold_min'] = 0.0
                t['granularity'] = (row.get('granularity') or '').strip()
                t['family_col'] = (row.get('family') or '').strip()
                t['arm'] = (row.get('arm') or '').strip()
                t['variant'] = (row.get('variant') or '').strip()
                sp = (row.get('split') or '').strip()
                if sp.startswith('前') or sp == 'front':
                    t['half'] = 'front'
                elif sp.startswith('后') or sp == 'back':
                    t['half'] = 'back'
                else:
                    t['half'] = 'full'
                # 家族键：轮次-信号家族-臂-粒度
                fam = t['family_col'] or t['variant']
                key = f"R{rnd}-{fam}"
                if t['arm']:
                    key += f"-{t['arm']}"
                if t['granularity']:
                    key += f"-{t['granularity']}"
                t['famkey'] = key
                t['entry_price'] = row.get('entry')
                trades.append(t)
    return trades

def tstat(xs):
    n = len(xs)
    if n < 2:
        return float('nan')
    m = statistics.mean(xs)
    sd = statistics.pstdev(xs) if n > 1 else 0.0
    # 样本标准差口径的 t（与各轮报告的 pooled t 同口径：mean/(sd/sqrt(n))，sd 为样本标准差）
    sd_s = statistics.stdev(xs) if n > 1 else 0.0
    if sd_s == 0:
        return float('nan')
    return m / (sd_s / math.sqrt(n))

def dist_stats(gs):
    n = len(gs)
    s = sorted(gs)
    def pct(p):
        if n == 0:
            return float('nan')
        i = min(n - 1, max(0, int(p * n)))
        return s[i]
    pos = [g for g in gs if g > 0]
    pos_sum = sum(pos)
    k5 = max(1, int(math.ceil(0.05 * n)))
    top5 = sum(s[-k5:])
    top5_share = (top5 / pos_sum) if pos_sum > 0 else float('nan')
    mean = statistics.mean(gs) if n else float('nan')
    med = statistics.median(gs) if n else float('nan')
    # 偏度
    if n >= 3:
        sd = statistics.pstdev(gs)
        skew = (sum((g - mean) ** 3 for g in gs) / n / sd ** 3) if sd > 0 else float('nan')
    else:
        skew = float('nan')
    return dict(n=n, mean=mean, median=med, p90=pct(0.90), p99=pct(0.99),
                max=max(gs) if n else float('nan'), min=min(gs) if n else float('nan'),
                frac_gt25=sum(1 for g in gs if g > 25) / n if n else float('nan'),
                frac_gt0=sum(1 for g in gs if g > 0) / n if n else float('nan'),
                frac_gt100=sum(1 for g in gs if g > 100) / n if n else float('nan'),
                top5_share=top5_share, skew=skew,
                t=tstat(gs), total=sum(gs))

def main():
    trades = load_trades()
    print(f"TOTAL trades loaded: {len(trades)}")
    out = {}
    # ---------- Q1: 每家族毛利分布 ----------
    byfam = defaultdict(list)
    for t in trades:
        byfam[t['famkey']].append(t['gross'])
    q1 = []
    for k, gs in sorted(byfam.items()):
        d = dist_stats(gs)
        d['family'] = k
        q1.append(d)
    out['q1_families'] = q1
    print("\n=== Q1 家族毛利分布（n>=30，按mean排序）===")
    print(f"{'family':38s} {'n':>5} {'mean':>8} {'med':>8} {'p90':>8} {'p99':>8} {'max':>9} {'>25%':>6} {'>0%':>6} {'top5%':>6} {'skew':>6} {'t':>6}")
    for d in sorted([x for x in q1 if x['n'] >= 30], key=lambda x: -x['mean']):
        print(f"{d['family']:38s} {d['n']:5d} {d['mean']:8.2f} {d['median']:8.2f} {d['p90']:8.2f} {d['p99']:8.2f} {d['max']:9.1f} {d['frac_gt25']:6.2f} {d['frac_gt0']:6.2f} {d['top5_share']:6.2f} {d['skew']:6.2f} {d['t']:6.2f}")
    print("\n=== Q1 小样本家族（n<30，mean>0 的）===")
    for d in sorted([x for x in q1 if x['n'] < 30 and x['mean'] > 0], key=lambda x: -x['mean']):
        print(f"{d['family']:38s} n={d['n']:3d} mean={d['mean']:8.2f} med={d['median']:8.2f} p99={d['p99']:8.2f} max={d['max']:9.1f} >25%={d['frac_gt25']:.2f} t={d['t']:.2f}")

    # ---------- Q2a: 每币跨轮一致性 ----------
    bycoin_round = defaultdict(list)   # (coin, round) -> gross list
    bycoin_fam = defaultdict(list)     # (coin, famkey) -> gross list
    for t in trades:
        bycoin_round[(t['symbol'], t['round'])].append(t['gross'])
        bycoin_fam[(t['symbol'], t['famkey'])].append(t['gross'])
    coin_rounds = defaultdict(list)
    for (coin, rnd), gs in bycoin_round.items():
        if len(gs) >= 10:
            coin_rounds[coin].append((rnd, len(gs), statistics.mean(gs), tstat(gs)))
    q2coin = []
    for coin, lst in sorted(coin_rounds.items()):
        pos = [x for x in lst if x[2] > 0]
        q2coin.append(dict(coin=coin, n_rounds=len(lst), n_pos=len(pos),
                           pos_rounds=[x[0] for x in pos],
                           detail=[(r, n, round(m, 2)) for r, n, m, _ in sorted(lst)]))
    out['q2_coin'] = q2coin
    print("\n=== Q2a 每币跨轮：正毛利的轮次数（n>=10/轮）===")
    for c in sorted(q2coin, key=lambda x: (-x['n_pos'], -x['n_rounds'])):
        print(f"{c['coin']:6s} rounds={c['n_rounds']:2d} pos_rounds={c['n_pos']:2d} {c['pos_rounds']}  detail={c['detail']}")

    # ---------- Q2b: 每小时（UTC）汇总 ----------
    byhour = defaultdict(list)
    for t in trades:
        if t['entry_hour'] is not None:
            byhour[t['entry_hour']].append(t['gross'])
    q2h = []
    for h in range(24):
        gs = byhour.get(h, [])
        if gs:
            d = dist_stats(gs); d['hour'] = h
            q2h.append(d)
    out['q2_hour'] = q2h
    print("\n=== Q2b 全部交易按入场小时（UTC）===")
    print(f"{'hour':>4} {'n':>6} {'mean':>8} {'med':>7} {'>25%':>6} {'t':>6}")
    for d in q2h:
        print(f"{d['hour']:4d} {d['n']:6d} {d['mean']:8.2f} {d['median']:7.2f} {d['frac_gt25']:6.2f} {d['t']:6.2f}")

    # ---------- Q2c: 17:00 逐轮复核 ----------
    print("\n=== Q2c 17:00 UTC 逐轮复核（1h vs 15m）===")
    h17 = []
    for t in trades:
        if t['entry_hour'] == 17:
            h17.append(t)
    byg = defaultdict(list)
    for t in h17:
        byg[(t['round'], t['granularity'])].append(t['gross'])
    for (rnd, gran), gs in sorted(byg.items()):
        print(f"R{rnd} {gran or '-':4s} n={len(gs):4d} mean={statistics.mean(gs):8.2f} med={statistics.median(gs):8.2f} >25%={sum(1 for g in gs if g>25)/len(gs):.2f} t={tstat(gs):6.2f}")
    # 17:00 vs 其他小时（同一轮内对照）：取主要轮次
    print("--- 17:00 vs 同轮其他小时（主要轮次，1h/15m分开）---")
    for rnd in (20, 24, 23, 16, 15):
        for gran in ('1h', '15m'):
            sel17 = [t['gross'] for t in trades if t['round'] == rnd and t['granularity'] == gran and t['entry_hour'] == 17]
            selo = [t['gross'] for t in trades if t['round'] == rnd and t['granularity'] == gran and t['entry_hour'] != 17]
            if sel17 and selo:
                print(f"R{rnd} {gran}: 17:00 n={len(sel17):4d} mean={statistics.mean(sel17):7.2f} | other n={len(selo):5d} mean={statistics.mean(selo):7.2f}")

    # ---------- Q2d: ZEC 全面复核 ----------
    print("\n=== Q2d ZEC 全部交易复核 ===")
    zec = [t for t in trades if t['symbol'] == 'ZEC']
    print(f"ZEC total n={len(zec)}")
    byz = defaultdict(list)
    for t in zec:
        byz[(t['round'], t['famkey'], t['half'])].append(t['gross'])
    for (rnd, fk, half), gs in sorted(byz.items()):
        print(f"R{rnd} {fk} {half}: n={len(gs):3d} mean={statistics.mean(gs):8.2f} med={statistics.median(gs):8.2f} total={sum(gs):9.1f} t={tstat(gs):6.2f}")
    byg2 = defaultdict(list)
    for t in zec:
        byg2[(t['round'], t['granularity'])].append(t['gross'])
    print("--- ZEC 按轮次×粒度汇总 ---")
    for (rnd, gran), gs in sorted(byg2.items()):
        net = sum(gs) - 25.0 * len(gs)
        print(f"R{rnd} {gran or '-':4s}: n={len(gs):3d} mean_gross={statistics.mean(gs):8.2f} taker_net_total={net:9.1f} t={tstat(gs):6.2f}")

    # ---------- Q2e: ADA 全面复核（E13/E27/E35 的币） ----------
    print("\n=== Q2e ADA 全部交易复核（按轮次）===")
    ada = [t for t in trades if t['symbol'] == 'ADA']
    bya = defaultdict(list)
    for t in ada:
        bya[t['round']].append(t['gross'])
    for rnd, gs in sorted(bya.items()):
        print(f"R{rnd}: n={len(gs):4d} mean={statistics.mean(gs):8.2f} med={statistics.median(gs):8.2f} total={sum(gs):9.1f} t={tstat(gs):6.2f}")

    with open('/tmp/mine_out.json', 'w', encoding='utf-8') as fh:
        json.dump(out, fh, ensure_ascii=False, default=str)
    print("\nwrote /tmp/mine_out.json")

if __name__ == '__main__':
    main()
