#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十六轮：Premium/Discount + OTE 立场过滤，叠加在 S3 和 F1 上
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因：学习笔记“方向 4”（Premium/Discount + OTE）是 5 个方向里唯一没测过、
且与之前零件重叠最少的（立场过滤 + 斐波那契回撤位，而不是触发结构）。
教程地位：Premium/Discount 是九模块之一，“位置先对，信号再看”；
OTE 0.62–0.79 是“便宜区里更便宜的位置”，只是位置过滤、不是入场信号。
赌的假设：之前所有家族亏钱，部分原因是贵区找多、便宜区找空做反了。

锁定的规则（跑前定死，写死在文件头，单组参数，不用全样本挑参数）：
  信号源（只加过滤、不改信号本身）：
    (1) S3 RSI 20/80 低换手版（365 天 1h，8 币）：引擎 = 第九轮 run_s3_1h
        （即第三轮 S3 引擎 1h 版），一字不变，只把止盈固定为 2xATR。
        RSI(14,Wilder) 收盘 <20 做多、>80 做空；08:00-20:00 UTC；
        本根振幅 > 前 20 根振幅中位数；每天每币最多 2 笔；
        出场 RSI 回 50 / 止损 1xATR / 止盈 2xATR / 当天 23:00 收盘强制平仓；
        每笔保证金 10% 权益、1x；收盘触发、下一根开盘成交；单日 -2% 熔断；
        单笔最坏情况 (ATR+成本) > 1% 权益跳过。
    (2) F1 BTC 领涨-山寨跟随（365 天 1h + 103 天 15m，7 个山寨）：
        引擎 = 第九轮 simulate_f1 + build_f1_signals（第七/八轮），一字不变，
        只把止盈固定为 2xATR。信号根 08:00~19:00 收盘：BTC 2h 收益
        |rBTC| >= 0.5%，且山寨自身 2h 收益 |rALT| < 0.5*|rBTC|；方向 = sign(rBTC)；
        下一根开盘进场；止损 1xATR、止盈 2xATR；最多持 4h；
        每天每币最多 2 笔；当天最后一根收盘强制平仓；单日 -2% 熔断。
  过滤器（两层，C2 缺一不可；C1 只用第一层）：
    (a) Premium/Discount 立场——dealing range 取信号根及之前最近 20 根
        已收盘 1h 的高低点（滚动 20 根 1h 窗口，含信号根），均衡线 =
        (窗口最高价 + 窗口最低价) / 2。做多只在入场价 < 均衡线时（Discount），
        做空只在入场价 > 均衡线时（Premium）；入场价恰等于均衡线算不通过。
        F1-15m 的结构同样取 1h（信号根收盘时刻之前最后一个已收盘 1h 根）。
    (b) OTE——取最近一次同方向位移腿：1h 摆动点 N=3（检测器定义：h[i] 严格
        大于左 3 根、不低于右 3 根，低点镜像，确认于 i+3 根收盘时）；某根
        收盘价越过最近已确认摆动高（低）点即一次上行（下行）BOS；腿起点 =
        破位根收盘时最近一个已确认的反向摆动点价（上行腿取最近摆动低，
        下行腿取最近摆动高）；腿终点 = 破位根至信号根之间已收盘 K 线的
        极值（上行腿取最高价，下行腿取最低价）。OTE 区 = 自腿终点往回量
        0.62–0.79 回撤：上行腿 [终点-0.79*腿长, 终点-0.62*腿长]，
        下行腿 [终点+0.62*腿长, 终点+0.79*腿长]，含边界。做多要求入场价
        落在最近上行腿的 OTE 区内，做空要求落在最近下行腿的 OTE 区内；
        信号根收盘时还没有同方向腿，算不通过。腿终点随信号根推进而更新，
        但只用信号根及之前已收盘的 K 线。
    入场价 = 信号根下一根开盘价（入场时刻可观测，不用未来根）。
    三个变体：C0 原版（无过滤）、C1 只加 (a)、C2 (a)+(b) 都加。
    止损 1xATR、止盈 2xATR 不变。
  与方向 4 原文的出入（跑前写明，不是事后改口）：
    原文 (a) 取“最近一次 4h 结构突破的那段推动”画 50% 线，(b) OTE 量
    同一段推动。本轮把两层拆开写死：(a) 用最近 20 根 1h 高低点（任务示例
    的写法），(b) 用最近一次 1h BOS 位移腿。拆开的原因：(a)(b) 若取同一
    段腿，做多的 OTE 区天然全在 50% 线之下，(a) 会被 (b) 蕴含、失去独立
    检验意义；拆开后 C1 能单独回答“立场有没有用”，C2 减 C1 能回答
    “OTE 有没有增值”。4h 改 1h 的原因：信号本身是 1h/15m 尺度，4h 腿
    更新过慢且与信号尺度脱节；腿的构造（起点→破位后极值）与原文一致。
    这是本轮预注册的操作化定义，跑完不改。
  防前视：dealing range、均衡线、摆动点、BOS 腿、OTE 区全部只用信号根
    及之前已收盘的 K 线计算；摆动点确认后才可用；入场永远是信号根下一根
    开盘价；F1-15m 的 1h 状态取信号根收盘时刻之前最后一个已收盘 1h 根。

窗口：
  S3 / F1-1h：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  F1-15m：全 103 天 2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

成本：主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
  资金费按实际费率计（S3/F1 同第九轮：08:00/16:00 结算点）。
  M1/M2 只做对照（第九轮同款公式与 B 实测成交率/逆向惩罚），主口径是 Taker。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

复核：C0 对照必须复现第九轮 TP=2.0 档的已发表数字（S3 8 币 + F1-1h 7 币
  + F1-15m 7 币，全期 Taker），误差 <0.05pp，否则先修引擎再出报告。
  本脚本运行时自动从 data/gate_iter_round9_summary.json 读第九轮数字比对。

运行：python3 gate_iter_round16.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round16_summary.json
      + data/gate_iter_round16_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import bisect
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
ALTS = [s for s in SYMBOLS if s != "BTC_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005,
              "DOGE_USDT": 0.008333, "LINK_USDT": 0.0065, "XRP_USDT": 0.005,
              "BNB_USDT": 0.0066, "ADA_USDT": 0.0066}

# ---- 锁定的对照档位：只改止盈，止损 1xATR 不变 ----
TP_MULTS = [1.5, 2.0, 3.0]
SL_MULT = 1.0
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)    # 前半段止于 05-19
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)   # 前半段止于 09-25

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
RSI_LO, RSI_HI = 20, 80
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


# ----------------------------------------------------------------------
# Premium/Discount + OTE 过滤器（第十六轮新增，跑前写死）
# 全部状态只用 1h 已收盘 K 线；入场价是信号根下一根开盘价（入场时刻可观测）。
# ----------------------------------------------------------------------
class PDOTEFilter:
    def __init__(self, bars1h):
        self.bars = bars1h
        n = len(bars1h)
        self.close_ts = [b["t"] + 3600 for b in bars1h]
        # (a) 均衡线：最近 20 根已收盘 1h（含信号根）的高低点
        self.eq = [None] * n
        for s in range(n):
            w = bars1h[max(0, s - 19):s + 1]
            self.eq[s] = (max(b["h"] for b in w) + min(b["l"] for b in w)) / 2.0
        # N=3 摆动点（检测器定义），确认于 i+3 根收盘时
        sh, sl = {}, {}
        for i in range(3, n - 3):
            h = bars1h[i]["h"]
            if all(h > bars1h[j]["h"] for j in range(i - 3, i)) and \
               all(h >= bars1h[j]["h"] for j in range(i + 1, i + 4)):
                sh[i] = h
            lo = bars1h[i]["l"]
            if all(lo < bars1h[j]["l"] for j in range(i - 3, i)) and \
               all(lo <= bars1h[j]["l"] for j in range(i + 1, i + 4)):
                sl[i] = lo
        events = sorted([(i + 3, "H", i, p) for i, p in sh.items()] +
                        [(i + 3, "L", i, p) for i, p in sl.items()])
        self.up_leg = [None] * n    # (起点价, 破位根下标)
        self.up_end = [None] * n    # 破位根至本根的最高价
        self.down_leg = [None] * n
        self.down_end = [None] * n  # 破位根至本根的最低价
        last_sh, last_sl = None, None  # (price, idx)
        cur_up, cur_down = None, None
        run_hi, run_lo = None, None
        ev = 0
        for s in range(n):
            while ev < len(events) and events[ev][0] <= s:
                _, kind, i, p = events[ev]
                if kind == "H":
                    last_sh = (p, i)
                else:
                    last_sl = (p, i)
                ev += 1
            c = bars1h[s]["c"]
            if last_sh is not None and c > last_sh[0]:
                # 上行 BOS：腿起点 = 破位时最近已确认摆动低
                if last_sl is not None:
                    cur_up = (last_sl[0], s)
                    run_hi = bars1h[s]["h"]
                last_sh = None
            elif last_sl is not None and c < last_sl[0]:
                # 下行 BOS：腿起点 = 破位时最近已确认摆动高
                if last_sh is not None:
                    cur_down = (last_sh[0], s)
                    run_lo = bars1h[s]["l"]
                last_sl = None
            if cur_up is not None:
                run_hi = max(run_hi, bars1h[s]["h"])
                self.up_leg[s] = cur_up
                self.up_end[s] = run_hi
            if cur_down is not None:
                run_lo = min(run_lo, bars1h[s]["l"])
                self.down_leg[s] = cur_down
                self.down_end[s] = run_lo

    def check_idx(self, s, entry_price, direction):
        """s: 信号根在 1h 序列中的下标（已收盘）。
        返回 {"pd": 立场是否一致, "ote": 是否落在 OTE 区, "reason": 原因}。"""
        if s < 0 or s >= len(self.bars):
            return {"pd": False, "ote": False, "reason": "no_state"}
        eq = self.eq[s]
        if direction == 1:
            pd = entry_price < eq
            leg, end = self.up_leg[s], self.up_end[s]
            if leg is None:
                return {"pd": pd, "ote": False, "reason": "no_leg_up"}
            rng = end - leg[0]
            if rng <= 0:
                return {"pd": pd, "ote": False, "reason": "bad_leg_up"}
            ote = (end - 0.79 * rng) <= entry_price <= (end - 0.62 * rng)
            return {"pd": pd, "ote": ote,
                    "reason": "pass" if (pd and ote) else ("ote_outside" if pd else "pd_fail")}
        pd = entry_price > eq
        leg, end = self.down_leg[s], self.down_end[s]
        if leg is None:
            return {"pd": pd, "ote": False, "reason": "no_leg_down"}
        rng = leg[0] - end
        if rng <= 0:
            return {"pd": pd, "ote": False, "reason": "bad_leg_down"}
        ote = (end + 0.62 * rng) <= entry_price <= (end + 0.79 * rng)
        return {"pd": pd, "ote": ote,
                "reason": "pass" if (pd and ote) else ("ote_outside" if pd else "pd_fail")}

    def check_time(self, sig_close_t, entry_price, direction):
        """按信号根收盘时刻取之前最后一个已收盘 1h 根（F1-15m 用）。"""
        s = bisect.bisect_right(self.close_ts, sig_close_t) - 1
        if s < 0:
            return {"pd": False, "ote": False, "reason": "no_state"}
        return self.check_idx(s, entry_price, direction)


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def rsi_wilder(closes, period=14):
    rsi = [None] * len(closes)
    if len(closes) <= period:
        return rsi
    gains, losses = [], []
    for i in range(1, period + 1):
        ch = closes[i] - closes[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    avg_g = sum(gains) / period
    avg_l = sum(losses) / period
    rsi[period] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    for i in range(period + 1, len(closes)):
        ch = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(ch, 0.0)) / period
        avg_l = (avg_l * (period - 1) + max(-ch, 0.0)) / period
        rsi[i] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    return rsi


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    # 止盈出场可用限价 Maker -0.01%；其余（止损/EOD/到期/RSI 回中/爆仓）
    # 只能市价 Taker 0.125%/边；入场 Maker -0.01%（第三轮/第七轮同款）。
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


# ----------------------------------------------------------------------
# S3 引擎：第三轮 run_s3_1h 一字不变，只把止盈倍数做成参数 tp_mult
# ----------------------------------------------------------------------
def run_s3_1h(bars, funding, symbol, days_subset, tp_mult, label,
              filt=None, variant="C0", funnel=None):
    atr = atr_wilder(bars)
    rsi = rsi_wilder([b["c"] for b in bars])
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 24)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / 1 - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                       else (b["h"] - pos["entry"]) / pos["entry"])
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                r = rsi[gi]
                if r is not None:
                    if pos["direction"] == 1 and r >= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                    if pos["direction"] == -1 and r <= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if not (8.0 <= hour < 20.0):
                    continue
                r = rsi[gi]
                if r is None or gi < 20:
                    continue
                ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                    continue
                sig = 0
                if r < RSI_LO:
                    sig = 1
                elif r > RSI_HI:
                    sig = -1
                if sig == 0:
                    continue
                if funnel is not None:
                    funnel["raw_signals"] += 1
                nxt = day_bars[i + 1]
                if filt is not None:
                    verdict = filt.check_idx(gi, nxt["o"], sig)
                    if funnel is not None:
                        funnel["pd_pass" if verdict["pd"] else "pd_fail"] += 1
                        if verdict["pd"]:
                            funnel["ote_pass" if verdict["ote"] else "ote_fail"] += 1
                        funnel["ote_pass_all" if verdict["ote"] else "ote_fail_all"] += 1
                        funnel["reason_" + verdict["reason"]] += 1
                    if variant == "C1" and not verdict["pd"]:
                        continue
                    if variant == "C2" and not (verdict["pd"] and verdict["ote"]):
                        continue
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - SL_MULT * a if sig == 1 else entry + SL_MULT * a
                tp = entry + tp_mult * a if sig == 1 else entry - tp_mult * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


# ----------------------------------------------------------------------
# F1 引擎：第七轮 simulate + build_f1_signals（第八轮粒度换算），
# 一字不变，只把止盈倍数做成参数 tp_mult
# ----------------------------------------------------------------------
def build_f1_signals(alt_bars, btc_bars, alt_atr, lookback, max_hold, tp_mult,
                     filt=None, variant="C0", funnel=None, bar_seconds=3600):
    sigs = {}
    for i in range(lookback, len(alt_bars)):
        b = alt_bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour <= 19):
            continue
        if alt_atr[i] is None:
            continue
        r_btc = btc_bars[i]["c"] / btc_bars[i - lookback]["c"] - 1
        if abs(r_btc) < 0.005:
            continue
        r_alt = alt_bars[i]["c"] / alt_bars[i - lookback]["c"] - 1
        if abs(r_alt) >= 0.5 * abs(r_btc):
            continue
        if i + 1 >= len(alt_bars):
            continue
        entry_t = alt_bars[i + 1]["t"]
        entry_price = alt_bars[i + 1]["o"]
        direction = 1 if r_btc > 0 else -1
        if funnel is not None:
            funnel["raw_signals"] += 1
        if filt is not None:
            verdict = filt.check_time(alt_bars[i]["t"] + bar_seconds,
                                    entry_price, direction)
            if funnel is not None:
                funnel["pd_pass" if verdict["pd"] else "pd_fail"] += 1
                if verdict["pd"]:
                    funnel["ote_pass" if verdict["ote"] else "ote_fail"] += 1
                funnel["ote_pass_all" if verdict["ote"] else "ote_fail_all"] += 1
                funnel["reason_" + verdict["reason"]] += 1
            if variant == "C1" and not verdict["pd"]:
                continue
            if variant == "C2" and not (verdict["pd"] and verdict["ote"]):
                continue
        sigs[entry_t] = {"direction": direction,
                         "atr": alt_atr[i], "sl_mult": SL_MULT, "tp_mult": tp_mult,
                         "max_hold": max_hold}
    return sigs


def simulate_f1(symbol, bars, signals, funding, days_subset, max_per_day, label, bars_per_day):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= pos["max_hold"] - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": sig["max_hold"]}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": sum(1 for t in trades if t.get("liquidated")),
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def main():
    print("盈利策略迭代 · 第十六轮：Premium/Discount + OTE 立场过滤（叠加 S3 / F1）")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "止损 1xATR / 止盈 2xATR；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    print("对照：C0 原版（无过滤）/ C1 只加 Premium/Discount / C2 两层都加。")
    # ---- 数据校验（只读本地缓存，不联网；与第九轮同一套）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- 过滤器：每币一个，全部只用 1h 已收盘 K 线 ----
    filters1h = {s: PDOTEFilter(data1h[s][0]) for s in SYMBOLS}
    for sym in SYMBOLS:
        f = filters1h[sym]
        n_up = len({leg[1] for leg in f.up_leg if leg is not None})
        n_dn = len({leg[1] for leg in f.down_leg if leg is not None})
        print(f"[过滤器 {sym}] 上行 BOS 腿 {n_up} 条 / 下行 BOS 腿 {n_dn} 条（365 天 1h，N=3 摆动点）。")

    VARIANTS = ["C0", "C1", "C2"]
    VARIANT_LABEL = {"C0": "原版无过滤", "C1": "只加 Premium/Discount",
                     "C2": "Premium/Discount+OTE"}
    TP = 2.0
    funnels = {}
    all_results, all_trades = [], []

    def split_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def record(res, trades_full, family, variant, gran, split_fn, funnel_key=None):
        res["family"] = family
        res["variant"] = variant
        res["tp_mult"] = TP
        res["granularity"] = gran
        if funnel_key is not None and funnel_key in funnels:
            fn = funnels[funnel_key]
            res["funnel"] = dict(fn)
            raw = fn.get("raw_signals", 0)
            res["filter_pass_rate"] = round(fn.get("reason_pass", 0) / raw, 4) if raw else None
            res["pd_pass_rate"] = round(fn.get("pd_pass", 0) / raw, 4) if raw else None
            res["ote_pass_rate_among_pd"] = (round(fn.get("ote_pass", 0) / fn["pd_pass"], 4)
                                             if fn.get("pd_pass") else None)
        all_results.append(res)
        if trades_full is not None:
            for t in trades_full:
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["tp_mult"] = TP
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def _fmt(x, spec):
        return "—" if x is None else format(x, spec)

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={_fmt(res['win_rate'], '.4f')} "
              f"盈亏比={_fmt(res['profit_factor'], '.2f')} 平均赢={_fmt(res['avg_win_usdt'], '+.0f')} "
              f"平均亏={_fmt(res['avg_loss_usdt'], '.0f')} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={_fmt(res['t_taker'], '.2f')}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={_fmt(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={_fmt(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    # ---- F1 信号：三档变体各生成一次（过滤在生成时按信号根判定）----
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig1h, sig15 = {}, {}
    for variant in VARIANTS:
        sig1h[variant], sig15[variant] = {}, {}
        for sym in ALTS:
            f1 = Counter()
            sig1h[variant][sym] = build_f1_signals(
                data1h[sym][0], data1h["BTC_USDT"][0], atr1h[sym], 2, 4, TP,
                filt=filters1h[sym], variant=variant, funnel=f1, bar_seconds=3600)
            funnels[("F1", "1h", variant, sym)] = dict(f1)
            f15 = Counter()
            sig15[variant][sym] = build_f1_signals(
                data15[sym][0], data15["BTC_USDT"][0], atr15[sym], 8, 16, TP,
                filt=filters1h[sym], variant=variant, funnel=f15, bar_seconds=900)
            funnels[("F1", "15m", variant, sym)] = dict(f15)
    print(f"[F1] 原始信号数（C0）：1h 合计 {sum(len(v) for v in sig1h['C0'].values())}，"
          f"15m 合计 {sum(len(v) for v in sig15['C0'].values())}。")

    # ================= S3：8 币 x 3 变体 x 3 窗口 =================
    print("\n=== S3 RSI 20/80（365d 1h，8 币，止盈 2xATR）===")
    for variant in VARIANTS:
        label = f"R16-S3-{variant}"
        for sym in SYMBOLS:
            bars, funding = data1h[sym]
            for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
                funnel = Counter() if subset is None else None
                trades, curve, ndays = run_s3_1h(
                    bars, funding, sym, subset, TP, label,
                    filt=filters1h[sym], variant=variant, funnel=funnel)
                if funnel is not None:
                    funnels[("S3", "1h", variant, sym)] = dict(funnel)
                res = summarize(sym, trades, curve, label)
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if wname == "365d" else None, "S3", variant, "1h",
                       split_1h, funnel_key=("S3", "1h", variant, sym) if wname == "365d" else None)
                show(res, sym, wname)

    # ================= F1-1h：7 山寨 x 3 变体 x 3 窗口 =================
    print("\n=== F1 BTC 领涨-山寨跟随（365d 1h，7 山寨，止盈 2xATR）===")
    for variant in VARIANTS:
        label = f"R16-F1-1h-{variant}"
        for sym in ALTS:
            bars, funding = data1h[sym]
            for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
                trades, curve, ndays = simulate_f1(
                    sym, bars, sig1h[variant][sym], funding, subset, 2, label, 24)
                res = summarize(sym, trades, curve, label, len(sig1h[variant][sym]))
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if wname == "365d" else None, "F1", variant, "1h",
                       split_1h, funnel_key=("F1", "1h", variant, sym) if wname == "365d" else None)
                show(res, sym, wname)

    # ================= F1-15m：7 山寨 x 3 变体 x 3 窗口 =================
    print("\n=== F1 BTC 领涨-山寨跟随（103d 15m，7 山寨，止盈 2xATR）===")
    for variant in VARIANTS:
        label = f"R16-F1-15m-{variant}"
        for sym in ALTS:
            bars, funding = data15[sym]
            for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
                trades, curve, ndays = simulate_f1(
                    sym, bars, sig15[variant][sym], funding, subset, 2, label, 96)
                res = summarize(sym, trades, curve, label, len(sig15[variant][sym]))
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if wname == "103d" else None, "F1", variant, "15m",
                       split_15, funnel_key=("F1", "15m", variant, sym) if wname == "103d" else None)
                show(res, sym, wname)

    # ---- 漏斗总表 ----
    print("\n=== 漏斗：过滤通过率（全期原始信号合计）===")
    for (fam, gran) in [("S3", "1h"), ("F1", "1h"), ("F1", "15m")]:
        syms = SYMBOLS if fam == "S3" else ALTS
        for variant in ["C1", "C2"]:
            tot = Counter()
            for sym in syms:
                tot.update(funnels[(fam, gran, variant, sym)])
            raw = tot.get("raw_signals", 0)
            pdp = tot.get("pd_pass", 0)
            otep = tot.get("ote_pass", 0)
            reasons = {k: v for k, v in sorted(tot.items())
                       if k.startswith("reason_")}
            print(f"  {fam}-{gran} {variant}（{VARIANT_LABEL[variant]}）：原始信号 {raw} → "
                  f"P/D 通过 {pdp}（{pdp/raw*100:.1f}%）→ OTE 通过（P/D 通过者中） "
                  f"{otep}（{otep/pdp*100:.1f}%）→ 两层都通过 {tot.get('reason_pass', 0)}"
                  f"（{tot.get('reason_pass', 0)/raw*100:.1f}%）；筛掉原因：{reasons}")

    # ---- 分币过滤通过率（C2）----
    print("\n=== 分币过滤通过率（C2，两层都加）===")
    for (fam, gran) in [("S3", "1h"), ("F1", "1h"), ("F1", "15m")]:
        syms = SYMBOLS if fam == "S3" else ALTS
        for sym in syms:
            fn = funnels[(fam, gran, "C2", sym)]
            raw = fn.get("raw_signals", 0)
            n_exec = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["variant"] == "C2" and r["symbol"] == sym and r["split"] in ("365d", "103d")][0]["trades"]
            print(f"  {fam}-{gran} {sym}: 原始 {raw} → P/D 通过 "
                  f"{fn.get('pd_pass', 0)}（{fn.get('pd_pass', 0)/raw*100:.1f}%）→ "
                  f"两层都通过 {fn.get('pass', 0)}（{fn.get('pass', 0)/raw*100:.1f}%）→ "
                  f"执行 {n_exec} 笔")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, syms, wnames) in [
            ("S3", "1h", SYMBOLS, ["365d", "前185d", "后180d"]),
            ("F1", "1h", ALTS, ["365d", "前185d", "后180d"]),
            ("F1", "15m", ALTS, ["103d", "前51d", "后52d"])]:
        for variant in VARIANTS:
            for wname in wnames:
                rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["variant"] == variant and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                npos = sum(1 for r in rs if r["taker_net_pct"] > 0)
                print(f"  {fam}-{gran} {variant} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                      f"每笔毛利 {(gt/nt if nt else 0.0):+.2f} USDT 为正币数 {npos}/{len(rs)}")

    # ---- pooled t（全期逐笔）----
    print("\n=== Pooled t 值（全期逐笔净收益占权益 %）===")
    for (fam, gran) in [("S3", "1h"), ("F1", "1h"), ("F1", "15m")]:
        for variant in VARIANTS:
            sub = [t for t in all_trades if t["family"] == fam and t["granularity"] == gran
                   and t["variant"] == variant]
            vals_m1 = [t["pnl_maker_m1"] / START_EQUITY for t in sub]
            vals_t = [t["pnl"] / START_EQUITY for t in sub]
            # 价差毛利逐笔 t（信号本身，不扣成本）：用 price_pnl - funding
            vals_g = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in sub]
            print(f"  {fam}-{gran} {variant}：n={len(vals_t)} "
                  f"pooled t(M1)={t_value(vals_m1)} pooled t(Taker)={t_value(vals_t)} "
                  f"pooled t(毛利)={t_value(vals_g)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    for (fam, gran, syms, wnames) in [
            ("S3", "1h", SYMBOLS, ["前185d", "后180d", "365d"]),
            ("F1", "1h", ALTS, ["前185d", "后180d", "365d"]),
            ("F1", "15m", ALTS, ["前51d", "后52d", "103d"])]:
        for variant in VARIANTS:
            row = {}
            for wname in wnames:
                rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["variant"] == variant and r["split"] == wname]
                row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            good = row[wnames[0]] > 0 and row[wnames[1]] > 0 and row[wnames[2]] > 0.02
            both = sum(1 for sym in syms
                       if [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                          and r["variant"] == variant and r["symbol"] == sym
                          and r["split"] == wnames[0]][0]["taker_net_pct"] > 0
                       and [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                            and r["variant"] == variant and r["symbol"] == sym
                            and r["split"] == wnames[1]][0]["taker_net_pct"] > 0)
            print(f"  {fam}-{gran} {variant} Taker：前 {row[wnames[0]]*100:+.2f}% / "
                  f"后 {row[wnames[1]]*100:+.2f}% / 全 {row[wnames[2]]*100:+.2f}% "
                  f"两半都正 {both}/{len(syms)} → {'达标' if good else '不达标'}")

    # ---- 复核 C0 vs 第九轮 TP=2.0 ----
    print("\n=== 复核：C0 对照 vs 第九轮 TP=2.0 已发表数字（Taker，全期）===")
    with open(os.path.join(DATA_DIR, "gate_iter_round9_summary.json")) as f:
        r9 = json.load(f)
    expect = {}
    for r in r9:
        if r.get("tp_mult") == 2.0 and r["split"] in ("365d", "103d"):
            expect[(r["family"], r["granularity"], r["symbol"])] = r["taker_net_pct"]
    bad = 0
    for (fam, gran, sym), exp in sorted(expect.items()):
        full = "365d" if gran == "1h" else "103d"
        r = [x for x in all_results if x["family"] == fam and x["granularity"] == gran
             and x["variant"] == "C0" and x["symbol"] == sym and x["split"] == full][0]
        ok = abs(r["taker_net_pct"] - exp) < 0.0005
        bad += 0 if ok else 1
        print(f"  {fam}-{gran} {sym}: 本轮 C0 {r['taker_net_pct']*100:+.2f}% vs 第九轮 "
              f"{exp*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核结果：{len(expect)-bad}/{len(expect)} 一致" + ("（全部通过）" if bad == 0 else "（有出入，见报告）"))

    with open(os.path.join(DATA_DIR, "gate_iter_round16_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round16_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "exit_time_utc", "entry", "exit",
                    "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt", "price_pnl_usdt",
                    "cost_taker_usdt", "cost_maker_usdt", "funding_cost_usdt",
                    "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["family"], x["granularity"], x["variant"], x["symbol"])):
            w.writerow([t["family"], t["variant"], t["tp_mult"], t["granularity"], t["split"],
                        t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t.get("liquidated", False), t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round16_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round16_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益.")


if __name__ == "__main__":
    main()
