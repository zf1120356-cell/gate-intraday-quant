#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十四轮：MAIN-15m 时段限制 F1 在扩大币种宇宙上的泛化检验（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（预注册泛化检验，不是调参）：
  第二十轮 MAIN-15m（F1 + 只在 09:00/15:00 UTC 入场）是全系列离盈亏
  平衡最近的一次（Taker -0.01%，每笔毛利 +24.34 USDT，毛利逐笔 t
  +3.72 显著为正），但只在 8 个币上测过。本轮问：这个时段效应在更多
  币上还成立吗，还是只是 8 个币里挑出来的？新币种上的结果无论正负
  都如实报告。

跑前写死的规则（单组参数，不许用全样本挑，不许换币）：
  信号源 F1（第七轮原版规则一字不变，引擎照抄第九轮/第二十轮
  build_f1_signals + simulate_f1，只把 tp_mult 固定为 2.0）：
    信号根 08:00~19:00 UTC 收盘：BTC 2h 收益 |rBTC| >= 0.5%，且山寨
    自身 2h 收益 |rALT| < 0.5*|rBTC|；方向 = sign(rBTC)；
    下一根开盘进场；止损 1xATR、止盈 2xATR；最多持 4h（1h 版 4 根，
    15m 版 16 根）；每天每币最多 2 笔；当天最后一根收盘强制平仓
    （1h 版 23:00，15m 版 23:45）；单日 -2% 熔断；同根同时碰止损
    和止盈先判止损；只做跟随标的，不做 BTC 本身。
    1h 版 ATR(14,1h)、lookback 2 根；15m 版 ATR(14,15m)、lookback 8 根。
  三臂（主臂与对照 1 只做新币种，对照 2 只做原 8 币）：
    MAIN  主臂：新 12 币，F1 + 只在入场 UTC 小时 ∈ {9, 15} 执行。
    CTRL1 对照 1：新 12 币，原版 F1，无时段限制（判断时段限制在
          新币种上有没有增值）。
    CTRL2 对照 2：原 7 山寨，F1 + 只在入场 UTC 小时 ∈ {9, 15} 执行，
          即第二十轮 MAIN 原样重跑（引擎零口径漂移复核）。
  成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
  双边）；M1/M2 对照同第七/九/二十轮；资金费按实际费率计
  （08:00/16:00 结算点；原币 2026-05-21 之前、新币 2026-05-22
  之前无数据按 0 计——新币资金费接口 180 天保留期边界实测为
  05-22，见取数脚本注释）。

币种选择（跑前写死，见报告 §0 与 data/gate_iter_round24_selection.json）：
  2026-11-17 17:12 UTC 拉 Gate /futures/usdt/tickers（1,034 个合约），
  按 volume_24h_quote（USDT 计价 24h 成交量）降序；原 8 币除外；
  依次检查 spread（(最低卖-最高买)/中间价，tickers 快照）<=0.07%、
  1h 历史连续 365 天（2025-11-16 起首周有 K 线初筛 + 全量 8,761 根复核）、
  15m 历史连续 103 天（全量 9,888 根复核）；不满足的跳过并记录原因。
  入选 12 个（按成交量排名）：ZEC(#10)、EVAA(#16)、HYPE(#18)、LTC(#23)、
  BLESS(#26)、XLM(#27)、AKE(#28)、NEAR(#32)、PEPE(#33)、UNI(#34)、
  SUI(#39)、XAUT(#44)。
  注意：排名靠前的代币化股票/ETF/指数/贵金属合约（SOXL、SNDK、SOXS、
  XAG、NVDA、XAU、SKHYNIX、SNXX、QQQ、INTC、SPCX、MU、SKHY、OPENAI、
  CL、MUU、BZ、BTW、CRCL、GOOGL、KORU、SPY、BREV、CXMT、SAMSUNG、MSTR、
  AMD、UNITREE、NBIS、SQQQ、AAOI、LITE 等）全部因“2025-11-16~23 首周
  无 1h K 线、不满足 365 天连续历史”被跳过（上线晚于窗口起点），
  其中 MUU 另有 spread 0.0740%>0.07%、BREV 另有 spread 0.1030%>0.07%。
  XAUT（Tether Gold，黄金背书代币）按四条成文标准全部通过，按规则入选
  为第 12 个币；报告里单独标注其非山寨属性，并给出剔除 XAUT 的敏感性。
  15m 连续性在取数后全量复核：12 币全部 9,888 根、103 个完整日、时间戳
  与 BTC 对齐（见终端“数据校验通过”）。

窗口：
  F1-1h：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  F1-15m：全 103 天 2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。主臂按粒度分别判定（新币 MAIN-1h、
MAIN-15m 各为一个组合）；两个粒度都通过才算整轮通过。
若新币种上 MAIN 达标，仍需在原 8 币 + 新币种合并样本（19 个跟随标的）
上再验证一次才能算通过——本脚本打印合并样本 MAIN 均值，报告里写清。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) CTRL2（原 7 山寨 MAIN 原样重跑）vs 第二十轮已发表 MAIN 数字：
      14/14 一致（7 币 × 2 粒度，全期 Taker，误差 <0.05pp）。
      第二十轮 MAIN-1h：ETH -0.06% / SOL +0.41% / DOGE -0.58% /
      LINK -0.50% / XRP +0.29% / BNB -0.88% / ADA +0.59%；
      MAIN-15m：ETH -0.13% / SOL -0.47% / DOGE -0.13% / LINK +0.05% /
      XRP +0.30% / BNB -0.48% / ADA +0.76%。
      以 data/gate_iter_round20_summary.json 里的 MAIN 全期 taker_net_pct
      为准做程序比对。
  (b) 脚本跑两遍，summary 与 trades 的 md5 两次运行完全一致。
  (c) 主臂首笔新币交易人工核对触发链、入场小时、止损/止盈、PnL。

运行：python3 gate_iter_round24.py（回测本身不联网，只读本地缓存；
      新币种缓存由 gate_iter_round24_fetch.py 预先拉取）
输出：终端打印全部表 + data/gate_iter_round24_summary.json
      + data/gate_iter_round24_trades.csv
      + data/gate_iter_round24_hour_diag.json（CTRL1 新币 24 小时诊断）
      + data/gate_iter_round24_selection.json（币种选择记录）
复现：跑两遍，summary 与 trades 两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

ORIG_SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
                "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
ORIG_ALTS = [s for s in ORIG_SYMBOLS if s != "BTC_USDT"]
# 新币种（跑前写死，按 Gate 24h 成交量排名，见文件头与 selection.json）
NEW_SYMBOLS = ["ZEC_USDT", "EVAA_USDT", "HYPE_USDT", "LTC_USDT",
               "BLESS_USDT", "XLM_USDT", "AKE_USDT", "NEAR_USDT",
               "PEPE_USDT", "UNI_USDT", "SUI_USDT", "XAUT_USDT"]
SYMBOLS = ORIG_SYMBOLS + NEW_SYMBOLS
ALTS = ORIG_ALTS + NEW_SYMBOLS
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]

# ---- 币种选择记录（2026-11-17 17:12 UTC tickers 快照；rank 为全市场排名）----
# vol 为 volume_24h_quote（USDT）；spread 为 (最低卖-最高买)/中间价。
SELECTION = {
    "fetch_time_utc": "2026-11-17T17:12:08Z",
    "source": "GET /futures/usdt/tickers（1,034 个合约），按 volume_24h_quote 降序",
    "rule": "原 8 币除外；依次检查 spread<=0.07%、1h 连续 365 天、15m 连续 103 天；不满足跳过并记录原因",
    "selected": [
        {"rank": 10, "symbol": "ZEC_USDT", "vol_24h_quote_usdt": 119827688, "spread_pct": 0.0097},
        {"rank": 16, "symbol": "EVAA_USDT", "vol_24h_quote_usdt": 43208985, "spread_pct": 0.0237},
        {"rank": 18, "symbol": "HYPE_USDT", "vol_24h_quote_usdt": 37325593, "spread_pct": 0.0029},
        {"rank": 23, "symbol": "LTC_USDT", "vol_24h_quote_usdt": 26172533, "spread_pct": 0.0226},
        {"rank": 26, "symbol": "BLESS_USDT", "vol_24h_quote_usdt": 18671648, "spread_pct": 0.0401},
        {"rank": 27, "symbol": "XLM_USDT", "vol_24h_quote_usdt": 18410365, "spread_pct": 0.0073},
        {"rank": 28, "symbol": "AKE_USDT", "vol_24h_quote_usdt": 17435729, "spread_pct": 0.0168},
        {"rank": 32, "symbol": "NEAR_USDT", "vol_24h_quote_usdt": 13368805, "spread_pct": 0.0126},
        {"rank": 33, "symbol": "PEPE_USDT", "vol_24h_quote_usdt": 12135643, "spread_pct": 0.0268},
        {"rank": 34, "symbol": "UNI_USDT", "vol_24h_quote_usdt": 11859917, "spread_pct": 0.0189},
        {"rank": 39, "symbol": "SUI_USDT", "vol_24h_quote_usdt": 9848443, "spread_pct": 0.0139},
        {"rank": 44, "symbol": "XAUT_USDT", "vol_24h_quote_usdt": 7839776, "spread_pct": 0.0003,
         "note": "Tether Gold（黄金背书代币），按四条成文标准全部通过入选；非加密山寨，报告单独标注并做剔除敏感性"},
    ],
    "skipped": [
        {"rank": 3, "symbol": "SOXL_USDT", "vol_24h_quote_usdt": 602752877, "spread_pct": 0.0422, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 4, "symbol": "SNDK_USDT", "vol_24h_quote_usdt": 254864577, "spread_pct": 0.0089, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 5, "symbol": "SOXS_USDT", "vol_24h_quote_usdt": 221493681, "spread_pct": 0.0329, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 7, "symbol": "XAG_USDT", "vol_24h_quote_usdt": 179860300, "spread_pct": 0.0209, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 8, "symbol": "NVDA_USDT", "vol_24h_quote_usdt": 153025016, "spread_pct": 0.0065, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 9, "symbol": "XAU_USDT", "vol_24h_quote_usdt": 137085783, "spread_pct": 0.0003, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 12, "symbol": "SKHYNIX_USDT", "vol_24h_quote_usdt": 69225349, "spread_pct": 0.0110, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 13, "symbol": "SNXX_USDT", "vol_24h_quote_usdt": 62045037, "spread_pct": 0.0360, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 14, "symbol": "QQQ_USDT", "vol_24h_quote_usdt": 56432939, "spread_pct": 0.0015, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 15, "symbol": "INTC_USDT", "vol_24h_quote_usdt": 43237402, "spread_pct": 0.0371, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 17, "symbol": "SPCX_USDT", "vol_24h_quote_usdt": 41943241, "spread_pct": 0.0071, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 19, "symbol": "MU_USDT", "vol_24h_quote_usdt": 34845732, "spread_pct": 0.0014, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 20, "symbol": "SKHY_USDT", "vol_24h_quote_usdt": 28986630, "spread_pct": 0.0082, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 22, "symbol": "OPENAI_USDT", "vol_24h_quote_usdt": 27174637, "spread_pct": 0.0024, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 24, "symbol": "CL_USDT", "vol_24h_quote_usdt": 25844768, "spread_pct": 0.0118, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 25, "symbol": "MUU_USDT", "vol_24h_quote_usdt": 19040826, "spread_pct": 0.0740, "reason": "spread 0.0740%>0.07%（且 2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史）"},
        {"rank": 29, "symbol": "BZ_USDT", "vol_24h_quote_usdt": 14238767, "spread_pct": 0.0110, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 30, "symbol": "BTW_USDT", "vol_24h_quote_usdt": 13901996, "spread_pct": 0.0096, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 31, "symbol": "CRCL_USDT", "vol_24h_quote_usdt": 13827306, "spread_pct": 0.0183, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 35, "symbol": "GOOGL_USDT", "vol_24h_quote_usdt": 11776432, "spread_pct": 0.0106, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 36, "symbol": "KORU_USDT", "vol_24h_quote_usdt": 11567697, "spread_pct": 0.0158, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 37, "symbol": "SPY_USDT", "vol_24h_quote_usdt": 10724394, "spread_pct": 0.0027, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 38, "symbol": "BREV_USDT", "vol_24h_quote_usdt": 10270015, "spread_pct": 0.1030, "reason": "spread 0.1030%>0.07%（且 2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史）"},
        {"rank": 40, "symbol": "CXMT_USDT", "vol_24h_quote_usdt": 9734768, "spread_pct": 0.0574, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
        {"rank": 43, "symbol": "SAMSUNG_USDT", "vol_24h_quote_usdt": 8780136, "spread_pct": 0.0141, "reason": "2025-11-16~23 首周无 1h K 线，不满足 365 天连续历史"},
    ],
    "excluded_original_8": ORIG_SYMBOLS,
    "note_xaut": "XAUT 按成文标准入选；其余被跳过的排名靠前合约多为 2026 年新上的代币化股票/ETF/贵金属合约，上线晚于 2025-11-16，故无 365 天历史——跳过原因是历史连续性，不是主观分类。",
}

# ---- 预注册、跑前写死：唯一时段，不许换 ----
TARGET_HOURS = {9, 15}   # E23 发现的两个 UTC 小时
TP_MULT = 2.0            # 止盈 2xATR（用户要求的 1:2）
SL_MULT = 1.0            # 止损 1xATR
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)    # 前半段止于 05-19
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)   # 前半段止于 09-25

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def entry_hour_utc(entry_t):
    """入场小时：与 E23 切分口径一致，入场时间戳的 UTC 小时。"""
    return datetime.fromtimestamp(entry_t, timezone.utc).hour


# ----------------------------------------------------------------------
# F1 引擎：第九轮 simulate_f1 + build_f1_signals 一字不变，
# 只把 tp_mult 固定为 2.0（第九轮 TP=2.0 档）
# ----------------------------------------------------------------------
def build_f1_signals(alt_bars, btc_bars, alt_atr, lookback, max_hold, tp_mult):
    sigs = {}
    for i in range(lookback, len(alt_bars)):
        b = alt_bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour <= 19):
            continue
        if alt_atr[i] is None:
            continue
        r_btc = btc_bars[i]["c"] / btc_bars[i - lookback]["c"] - 1
        if abs(r_btc) < 0.005:
            continue
        r_alt = alt_bars[i]["c"] / alt_bars[i - lookback]["c"] - 1
        if abs(r_alt) >= 0.5 * abs(r_btc):
            continue
        if i + 1 >= len(alt_bars):
            continue
        entry_t = alt_bars[i + 1]["t"]
        sigs[entry_t] = {"direction": 1 if r_btc > 0 else -1,
                         "atr": alt_atr[i], "sl_mult": SL_MULT, "tp_mult": tp_mult,
                         "max_hold": max_hold}
    return sigs


def simulate_f1(symbol, bars, signals, funding, days_subset, max_per_day, label, bars_per_day):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= pos["max_hold"] - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": sig["max_hold"]}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def hour_table(trades, label):
    """24 小时诊断表：每笔毛利（价差毛利）与 Taker 净，逐笔 t。"""
    rows = []
    for h in range(24):
        sub = [t for t in trades
               if datetime.fromtimestamp(t["entry_t"], timezone.utc).hour == h]
        n = len(sub)
        if n == 0:
            rows.append({"hour_utc": h, "trades": 0, "gross_usdt": 0.0,
                         "gross_per_trade_usdt": None, "gross_t": None,
                         "taker_net_usdt": 0.0, "taker_net_per_trade_usdt": None,
                         "taker_t": None, "win_rate": None})
            continue
        gross = [t["price_pnl"] - t["funding_cost_usdt"] for t in sub]
        taker = [t["pnl"] for t in sub]
        rows.append({
            "hour_utc": h, "trades": n,
            "gross_usdt": round(sum(gross), 2),
            "gross_per_trade_usdt": round(sum(gross) / n, 2),
            "gross_t": t_value([g / START_EQUITY for g in gross]),
            "taker_net_usdt": round(sum(taker), 2),
            "taker_net_per_trade_usdt": round(sum(taker) / n, 2),
            "taker_t": t_value([p / START_EQUITY for p in taker]),
            "win_rate": round(sum(1 for p in taker if p > 0) / n, 4),
        })
    print(f"\n--- {label}：24 小时诊断（入场 UTC 小时）---")
    print(f"  {'小时':>4} {'笔数':>5} {'每笔毛利':>9} {'毛利t':>7} "
          f"{'每笔Taker净':>11} {'Taker t':>8} {'胜率':>6}")
    for r in rows:
        gp = f"{r['gross_per_trade_usdt']:+.2f}" if r["gross_per_trade_usdt"] is not None else "—"
        gt = f"{r['gross_t']:+.2f}" if r["gross_t"] is not None else "—"
        tp = f"{r['taker_net_per_trade_usdt']:+.2f}" if r["taker_net_per_trade_usdt"] is not None else "—"
        tt = f"{r['taker_t']:+.2f}" if r["taker_t"] is not None else "—"
        wr = f"{r['win_rate']:.3f}" if r["win_rate"] is not None else "—"
        mark = " ★09/15" if r["hour_utc"] in TARGET_HOURS else ""
        print(f"  {r['hour_utc']:>4} {r['trades']:>5} {gp:>9} {gt:>7} {tp:>11} {tt:>8} {wr:>6}{mark}")
    return rows


def main():
    print("盈利策略迭代 · 第二十四轮：MAIN-15m 时段限制 F1 在扩大币种宇宙上的泛化检验（全模拟）")
    print("主臂 F1 + 只在 09:00/15:00 UTC 入场（新 12 币）；对照 1 新 12 币原版 F1；对照 2 原 7 山寨 MAIN 原样重跑。")
    print("止损 1xATR / 止盈 2xATR；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网；新币种缓存由 gate_iter_round24_fetch.py 预取）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：20 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")
    print("新 12 币资金费率自 2026-05-22 起（接口 180 天保留期边界；05-21 按 0 计），原 8 币自 2026-05-21 起。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- F1 信号：同一粒度只生成一次，三臂共用同一组信号 ----
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig1h, sig15 = {}, {}
    for sym in ALTS:
        sig1h[sym] = build_f1_signals(data1h[sym][0], data1h["BTC_USDT"][0],
                                      atr1h[sym], 2, 4, TP_MULT)
        sig15[sym] = build_f1_signals(data15[sym][0], data15["BTC_USDT"][0],
                                      atr15[sym], 8, 16, TP_MULT)
    print(f"[F1] 信号数（与时段无关，三臂共用）：1h 合计 "
          f"{sum(len(v) for v in sig1h.values())}，15m 合计 "
          f"{sum(len(v) for v in sig15.values())}。")

    def filter_signals(sigs, keep):
        """keep(entry_hour) -> bool。时段过滤在信号层执行。"""
        return {t: v for t, v in sigs.items() if keep(entry_hour_utc(t))}

    ARMS = [
        ("MAIN", "F1-hours-0915", lambda h: h in TARGET_HOURS, NEW_SYMBOLS),
        ("CTRL1", "F1-nofilter", lambda h: True, NEW_SYMBOLS),
        ("CTRL2", "F1-hours-0915-orig8", lambda h: h in TARGET_HOURS, ORIG_ALTS),
    ]
    GRANS = [
        ("1h", data1h, sig1h, 24,
         [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
        ("15m", data15, sig15, 96,
         [("103d", None), ("前51d", front_15), ("后52d", back_15)],
         lambda et: "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"),
    ]

    all_results, all_trades = [], []
    pass_stats = {}  # (arm, gran, sym) -> (n_sig_total, n_sig_pass)
    for arm, label, keep, syms in ARMS:
        for gran, data, sigs_all, bpd, windows, split_fn in GRANS:
            print(f"\n=== {arm} {label} · F1-{gran}（TP {TP_MULT}，SL {SL_MULT}，{len(syms)} 币）===")
            for sym in syms:
                sigs_full = sigs_all[sym]
                sigs = filter_signals(sigs_full, keep)
                pass_stats[(arm, gran, sym)] = (len(sigs_full), len(sigs))
                for wname, subset in windows:
                    bars, funding = data[sym]
                    trades, curve, ndays = simulate_f1(
                        sym, bars, sigs, funding, subset, 2, label, bpd)
                    res = summarize(sym, trades, curve, label, len(sigs))
                    res["arm"] = arm
                    res["variant"] = label
                    res["family"] = "F1"
                    res["tp_mult"] = TP_MULT
                    res["granularity"] = gran
                    res["split"] = wname
                    res["days"] = ndays
                    res["signals_total"] = len(sigs_full)
                    res["signals_pass"] = len(sigs)
                    res["signal_pass_rate"] = round(len(sigs) / len(sigs_full), 4) if sigs_full else None
                    all_results.append(res)
                    if wname in ("365d", "103d"):
                        for t in trades:
                            t2 = dict(t)
                            t2["arm"] = arm
                            t2["variant"] = label
                            t2["family"] = "F1"
                            t2["tp_mult"] = TP_MULT
                            t2["granularity"] = gran
                            t2["split"] = split_fn(t["entry_t"])
                            t2["entry_hour_utc"] = entry_hour_utc(t["entry_t"])
                            all_trades.append(t2)
                    print(f"[{arm} F1-{gran} {sym} {wname}] n={res['trades']} "
                          f"信号 {len(sigs)}/{len(sigs_full)} 胜率={res['win_rate']} "
                          f"盈亏比={res['profit_factor']} Taker {res['taker_net_pct']*100:+.2f}% "
                          f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                          f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                          f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                          f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label, _, syms in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            for wname, _ in windows:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
                print(f"  {arm} F1-{gran} {wname}（{len(rs)} 币）：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                      f"每笔毛利 {gt/nt:+.2f} USDT 胜率 {wr:.3f}" if wr is not None else
                      f"  {arm} F1-{gran} {wname}（{len(rs)} 币）：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} 每笔毛利 — 胜率 —")

    # ---- 时段通过率（信号层 + 成交层）----
    print("\n=== 时段通过率 ===")
    for arm, label, _, syms in ARMS:
        for gran, _, _, _, _, _ in GRANS:
            st = sum(pass_stats[(arm, gran, s)][0] for s in syms)
            sp = sum(pass_stats[(arm, gran, s)][1] for s in syms)
            nt_arm = sum(r["trades"] for r in all_results if r["arm"] == arm
                         and r["granularity"] == gran and r["split"] in ("365d", "103d"))
            nt_c1 = sum(r["trades"] for r in all_results if r["arm"] == "CTRL1"
                        and r["granularity"] == gran and r["split"] in ("365d", "103d"))
            base = nt_arm if arm == "CTRL1" else nt_c1
            print(f"  {arm} F1-{gran}：信号通过 {sp}/{st} = {sp/st*100:.1f}%；"
                  f"成交笔数 {nt_arm}（相对 CTRL1 新币 {nt_arm/nt_c1*100:.1f}%）" if arm != "CTRL1" else
                  f"  {arm} F1-{gran}：信号通过 {sp}/{st} = {sp/st*100:.1f}%；成交笔数 {nt_arm}")

    # ---- pooled t（全期明细，Taker 与 M1）----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for arm, label, _, syms in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            full = windows[0][0]
            sub = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
            for wname, _ in windows:
                s2 = [t for t in sub if wname == full or t["split"] == wname]
                vt = [t["pnl"] / START_EQUITY for t in s2]
                vm = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
                print(f"  {arm} F1-{gran} {wname}：n={len(s2)} "
                      f"pooled t(Taker)={t_value(vt)} pooled t(M1)={t_value(vm)}")

    # ---- 达标判定（主臂 = 新 12 币）----
    print("\n=== 达标判定（主口径 Taker；主臂为新 12 币）===")
    verdict = {}
    for arm, label, _, syms in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            wnames = [w for w, _ in windows]
            row = {}
            for wname in wnames:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            good = row[wnames[1]] > 0 and row[wnames[2]] > 0 and row[wnames[0]] > 0.02
            verdict[(arm, gran)] = good
            print(f"  {arm} F1-{gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
                  f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}% → "
                  f"{'达标' if good else '不达标'}")
            for sym in syms:
                rf = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                      and r["symbol"] == sym and r["split"] == wnames[1]][0]
                rb = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                      and r["symbol"] == sym and r["split"] == wnames[2]][0]
                both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
                print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                      f"后 {rb['taker_net_pct']*100:+.2f}% → "
                      f"{'★ 两半都为正' if both else ''}")
    main_pass = verdict[("MAIN", "1h")] and verdict[("MAIN", "15m")]
    print(f"\n  主臂（新 12 币）整轮判定：1h {'达标' if verdict[('MAIN','1h')] else '不达标'}、"
          f"15m {'达标' if verdict[('MAIN','15m')] else '不达标'} → "
          f"{'通过' if main_pass else '不通过'}")

    # ---- 合并样本 MAIN（原 7 山寨 CTRL2 + 新 12 币 MAIN，共 19 个跟随标的）----
    print("\n=== 合并样本 MAIN（原 8 币 + 新币种，19 个跟随标的；若新币达标，此为第二关）===")
    for gran, _, _, _, windows, _ in GRANS:
        wnames = [w for w, _ in windows]
        row = {}
        for wname in wnames:
            rs = [r for r in all_results if r["granularity"] == gran and r["split"] == wname
                  and ((r["arm"] == "MAIN") or (r["arm"] == "CTRL2"))]
            row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
        good = row[wnames[1]] > 0 and row[wnames[2]] > 0 and row[wnames[0]] > 0.02
        print(f"  合并 MAIN F1-{gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
              f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}% → "
              f"{'达标' if good else '不达标'}")

    # ---- XAUT 敏感性：主臂新币剔除 XAUT（11 币）----
    print("\n=== 敏感性：主臂新币剔除 XAUT（11 币；XAUT 为黄金背书代币）===")
    for gran, _, _, _, windows, _ in GRANS:
        wnames = [w for w, _ in windows]
        row = {}
        for wname in wnames:
            rs = [r for r in all_results if r["arm"] == "MAIN" and r["granularity"] == gran
                  and r["split"] == wname and r["symbol"] != "XAUT_USDT"]
            row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
        print(f"  MAIN(除 XAUT) F1-{gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
              f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}%")

    # ---- 复核 (a)：CTRL2（原 7 山寨 MAIN 原样重跑）vs 第二十轮已发表 MAIN 数字 ----
    print("\n=== 复核 (a)：CTRL2 vs 第二十轮 MAIN 已发表数字（Taker，全期，14/14）===")
    with open(os.path.join(DATA_DIR, "gate_iter_round20_summary.json")) as f:
        r20 = json.load(f)
    r20_main = {(r["granularity"], r["symbol"]): r["taker_net_pct"]
                for r in r20 if r["arm"] == "MAIN" and r["split"] in ("365d", "103d")}
    full_name = {"1h": "365d", "15m": "103d"}
    bad = 0
    for gran in ("1h", "15m"):
        for sym in ORIG_ALTS:
            expect = r20_main[(gran, sym)]
            r = [x for x in all_results if x["arm"] == "CTRL2" and x["granularity"] == gran
                 and x["symbol"] == sym and x["split"] == full_name[gran]][0]
            ok = abs(r["taker_net_pct"] - expect) < 0.0005
            bad += 0 if ok else 1
            print(f"  CTRL2 F1-{gran} {sym}: 本轮 {r['taker_net_pct']*100:+.2f}% vs 第二十轮 "
                  f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核 (a) 结果：{14-bad}/14 一致"
          + ("（全部通过，引擎零口径漂移）" if bad == 0 else "（有出入，见报告）"))

    # ---- 诊断：24 小时全表（CTRL1 新币全期明细；混池 + 分粒度）----
    ctrl1_all = [t for t in all_trades if t["arm"] == "CTRL1"]
    hour_rows_pooled = hour_table(ctrl1_all, "CTRL1 新币 混池（1h+15m）")
    hour_rows_1h = hour_table([t for t in ctrl1_all if t["granularity"] == "1h"],
                              "CTRL1 新币 仅 1h")
    hour_rows_15m = hour_table([t for t in ctrl1_all if t["granularity"] == "15m"],
                               "CTRL1 新币 仅 15m")

    # ---- 主臂 vs 对照 1：时段限制在新币上有没有增值 ----
    print("\n=== 主臂 vs 对照 1（新币，每笔毛利对照）===")
    for gran, _, _, _, windows, _ in GRANS:
        full = windows[0][0]
        for arm, label, _, _ in ARMS[:2]:
            rs = [r for r in all_results if r["arm"] == arm
                  and r["granularity"] == gran and r["split"] == full]
            gt = sum(r["gross_usdt"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            print(f"  {arm} F1-{gran} 全期：n={nt} 每笔毛利 {gt/nt:+.2f} USDT "
                  f"毛利合计 {gt:+.0f} Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}%")

    # ---- 主臂首笔新币交易（供报告人工核对）----
    main_trades = sorted([t for t in all_trades if t["arm"] == "MAIN"],
                         key=lambda x: x["entry_t"])
    if main_trades:
        t0 = main_trades[0]
        print("\n=== 主臂首笔新币交易（人工核对用）===")
        print(f"  {t0['granularity']} {t0['symbol']} "
              f"{'LONG' if t0['direction'] == 1 else 'SHORT'} 入场 "
              f"{datetime.fromtimestamp(t0['entry_t'], timezone.utc).isoformat()} "
              f"(小时 {t0['entry_hour_utc']}) @ {t0['entry']} → 出场 "
              f"{datetime.fromtimestamp(t0['exit_t'], timezone.utc).isoformat()} "
              f"@ {t0['exit']} 原因 {t0['reason']} 持仓 {t0['hold_min']} 分钟 "
              f"价差 PnL {t0['price_pnl']:+.2f} Taker 净 {t0['pnl']:+.2f}")

    with open(os.path.join(DATA_DIR, "gate_iter_round24_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round24_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["arm"], x["granularity"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round24_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round24_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")

    hour_diag = {
        "pooled_1h_15m": hour_rows_pooled,
        "only_1h": hour_rows_1h,
        "only_15m": hour_rows_15m,
        "target_hours": sorted(TARGET_HOURS),
        "note": "CTRL1 新币全期明细按入场 UTC 小时切分；gross 为价差毛利（扣资金费、不扣交易成本）。",
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round24_hour_diag.json"), "w") as f:
        json.dump(hour_diag, f, indent=2, ensure_ascii=False)
    print("小时诊断已写入：data/gate_iter_round24_hour_diag.json")
    with open(os.path.join(DATA_DIR, "gate_iter_round24_selection.json"), "w") as f:
        json.dump(SELECTION, f, indent=2, ensure_ascii=False)
    print("币种选择记录已写入：data/gate_iter_round24_selection.json")


if __name__ == "__main__":
    main()
