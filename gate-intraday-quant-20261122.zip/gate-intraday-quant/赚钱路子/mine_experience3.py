#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回测经验挖掘 Part 3：三节分析（信号 / 止盈止损 / 机械规则）
发现阶段一律去标识化：发现池 = 去重后、排除 ZEC 与 17:00 UTC、只留结构特征。
验证阶段再解开币种/时间/家族。只描述，不重算出场、不调参、不宣称 edge。
"""
import csv, glob, json, math, os, pickle, re, statistics, sys
from collections import Counter, defaultdict
from datetime import datetime

sys.path.insert(0, os.path.expanduser('~/workspace/赚钱路子'))
from mine_experience import dist_stats, tstat, load_trades, parse_dt
from mine_experience2 import bucket_report

DATA = os.path.expanduser('~/workspace/赚钱路子/data')
COST_LINE = 25.0
OUT = {}

ded = pickle.load(open('/tmp/mine2_pool.pkl', 'rb'))
disc = [t for t in ded if t['symbol'] != 'ZEC' and t['entry_hour'] != 17]
pool = [t for t in disc if t.get('feat')]
print(f"deduped={len(ded)} discovery={len(disc)} pool_with_feat={len(pool)}")
# 时间中位数（验证用前后两半）
times = sorted(t['entry_dt'] for t in pool if t['entry_dt'])
MED_T = times[len(times) // 2]
print(f"median entry time (pool): {MED_T}")

def keyfn_groups(trades, fn):
    g = defaultdict(list)
    for t in trades:
        k = fn(t)
        if k is not None:
            g[k].append(t['gross'])
    return g

def flag_candidates(res, min_n=100):
    return [d for d in res if d['n'] >= min_n and d['mean'] > COST_LINE and d['t'] > 2]

def validate_bucket(name, pred, pool_all):
    """解开验证：币种、时间前后半、家族构成、加回 ZEC/17:00"""
    inside = [t for t in pool_all if t.get('feat') and pred(t)]
    d = dist_stats([t['gross'] for t in inside])
    print(f"\n--- validation: {name} ---")
    print(f"pool bucket: n={d['n']} mean={d['mean']:.2f} med={d['median']:.2f} >25%={d['frac_gt25']:.2f} t={d['t']:.2f}")
    # 币种
    by_coin = defaultdict(list)
    for t in inside:
        by_coin[t['symbol']].append(t['gross'])
    coin_rows = [(c, len(v), statistics.mean(v)) for c, v in by_coin.items() if len(v) >= 20]
    coin_rows.sort(key=lambda r: -r[1])
    pos_coins = sum(1 for _, n, m in coin_rows if m > 0)
    print(f"coins n>=20: {len(coin_rows)} (of {len(by_coin)} coins in bucket); positive-mean coins: {pos_coins}")
    for c, n, m in coin_rows[:8]:
        print(f"   {c}: n={n} mean={m:.2f}")
    # 时间前后半（中位数切）
    fr = [t['gross'] for t in inside if t['entry_dt'] and t['entry_dt'] < MED_T]
    bk = [t['gross'] for t in inside if t['entry_dt'] and t['entry_dt'] >= MED_T]
    df, db = dist_stats(fr), dist_stats(bk)
    print(f"time halves: front n={df['n']} mean={df['mean']:.2f} t={df['t']:.2f} | back n={db['n']} mean={db['mean']:.2f} t={db['t']:.2f}")
    # 家族构成
    fam = Counter(t['famkey'] for t in inside)
    print(f"families in bucket: {len(fam)}; top: {fam.most_common(5)}")
    # 加回 ZEC 与 17:00
    excl = [t for t in ded if t.get('feat') and (t['symbol'] == 'ZEC' or t['entry_hour'] == 17) and pred(t)]
    if excl:
        allg = [t['gross'] for t in inside] + [t['gross'] for t in excl]
        da = dist_stats(allg)
        print(f"with ZEC+17:00 added back: n={da['n']} mean={da['mean']:.2f} (excluded n={len(excl)}, their mean={statistics.mean([t['gross'] for t in excl]):.2f})")
    return dict(bucket=d, coins=[(c, n, round(m, 2)) for c, n, m in coin_rows],
                front=df, back=db, fams=fam.most_common(5))

# ================= 第一节：信号（去标识发现） =================
print("\n########## SECTION 1: SIGNAL (de-identified discovery) ##########")
def binned(x, edges):
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return None
    for i, e in enumerate(edges):
        if x < e:
            return f"<{e}"
    return f">={edges[-1]}"

# A. 方向 × 入场前 2h 自身收益
resA = bucket_report("A. direction x prior-2h own-coin return (%)",
    keyfn_groups(pool, lambda t: (('LONG' if t['direction'] == 1 else 'SHORT'),
                                  binned(t['feat']['own_2h'] * 100, [-2, -1, -0.5, 0, 0.5, 1, 2]))))
OUT['A'] = resA
# B. 方向 × 入场前 2h BTC 收益
resB = bucket_report("B. direction x prior-2h BTC return (%)",
    keyfn_groups(pool, lambda t: (('LONG' if t['direction'] == 1 else 'SHORT'),
                                  binned(t['feat']['btc_2h'] * 100, [-2, -1, -0.5, 0, 0.5, 1, 2]))))
OUT['B'] = resB
# C. 追涨/追跌幅度（|前2h自身|）× 方向
resC = bucket_report("C. chasing: direction x |prior-2h own| (%)",
    keyfn_groups(pool, lambda t: (('LONG' if t['direction'] == 1 else 'SHORT'),
                                  binned(abs(t['feat']['own_2h']) * 100, [0.5, 1, 2]))))
OUT['C'] = resC
# D. 波动比 × 方向
resD = bucket_report("D. direction x vol ratio (ATR / median ATR)",
    keyfn_groups(pool, lambda t: (('LONG' if t['direction'] == 1 else 'SHORT'),
                                  binned(t['feat']['vol_ratio'], [0.8, 1.25]))))
OUT['D'] = resD
# E. 粒度 × 方向
resE = bucket_report("E. granularity x direction",
    keyfn_groups(pool, lambda t: (t['granularity'] or '?', 'LONG' if t['direction'] == 1 else 'SHORT')))
OUT['E'] = resE
# F. 确认强度：入场前一根 1h 的逆向影线（ATR单位）× 方向
resF = bucket_report("F. direction x rejection wick before entry (ATR units)",
    keyfn_groups(pool, lambda t: (('LONG' if t['direction'] == 1 else 'SHORT'),
                                  binned(t['feat']['wick_dir'], [0, 0.5, 1, 2]))))
OUT['F'] = resF
# G. 实体强度
resG = bucket_report("G. direction x body of last closed 1h bar (ATR units)",
    keyfn_groups(pool, lambda t: (('LONG' if t['direction'] == 1 else 'SHORT'),
                                  binned(t['feat']['body'], [0.5, 1, 2]))))
OUT['G'] = resG
# H. 信号强度：BTC 2h 动量幅度 × 顺/逆 BTC
def align(t):
    b = t['feat']['btc_2h']
    s = 'withBTC' if (t['direction'] == 1 and b > 0) or (t['direction'] == -1 and b < 0) else 'againstBTC'
    return (s, binned(abs(b) * 100, [0.5, 1, 2]))
resH = bucket_report("H. signal strength: with/against BTC x |BTC 2h| (%)",
    keyfn_groups(pool, align))
OUT['H'] = resH
# I. 市况（BTC 月度趋势 × 波动）
resI = bucket_report("I. BTC monthly regime (trend x vol)",
    keyfn_groups(pool, lambda t: ((t['regime'].get('trend') or '?') + '/' + (t['regime'].get('volcls') or '?'))))
OUT['I'] = resI
# J. 实现 R 分布（描述）
rs = sorted(t['feat']['r_mult'] for t in pool if t['feat'].get('r_mult') == t['feat'].get('r_mult'))
def pct(v, q):
    return v[int(q * (len(v) - 1))]
print("\n=== J. realized R (gross / 1h-ATR$) ===")
print(f"n={len(rs)} p1={pct(rs,0.01):.2f} p5={pct(rs,0.05):.2f} p25={pct(rs,0.25):.2f} "
      f"med={pct(rs,0.5):.2f} p75={pct(rs,0.75):.2f} p95={pct(rs,0.95):.2f} p99={pct(rs,0.99):.2f} max={rs[-1]:.2f}")
print(f"frac <= -1R: {sum(1 for r in rs if r<=-1)/len(rs):.3f}; frac >= +2R: {sum(1 for r in rs if r>=2)/len(rs):.3f}; "
      f"frac >= +1R: {sum(1 for r in rs if r>=1)/len(rs):.3f}")
OUT['J'] = dict(n=len(rs), p1=pct(rs,0.01), p5=pct(rs,0.05), p25=pct(rs,0.25), med=pct(rs,0.5),
                p75=pct(rs,0.75), p95=pct(rs,0.95), p99=pct(rs,0.99), max=rs[-1],
                frac_le_m1=sum(1 for r in rs if r<=-1)/len(rs),
                frac_ge_p2=sum(1 for r in rs if r>=2)/len(rs),
                frac_ge_p1=sum(1 for r in rs if r>=1)/len(rs))
# K. 家族表（去重后）
resK = bucket_report("K. family gross distribution (DEDUPED, n>=30)",
    {k: v for k, v in keyfn_groups(ded, lambda t: t['famkey']).items() if len(v) >= 30}, min_n=30)
OUT['K'] = resK

cands = []
for tag, res in [('A', resA), ('B', resB), ('C', resC), ('D', resD), ('E', resE), ('F', resF), ('G', resG), ('H', resH), ('I', resI)]:
    for d in flag_candidates(res):
        cands.append((tag, d))
print(f"\nflagged discovery buckets (mean>25, n>=100, t>2): {len(cands)}")
for tag, d in cands:
    print(f"  {tag} {d['bucket']}: n={d['n']} mean={d['mean']:.2f} t={d['t']:.2f}")
OUT['flagged'] = [(tag, d) for tag, d in cands]
json.dump(OUT, open('/tmp/mine3_part1.json', 'w', encoding='utf-8'), ensure_ascii=False, default=str)
print("saved /tmp/mine3_part1.json")
