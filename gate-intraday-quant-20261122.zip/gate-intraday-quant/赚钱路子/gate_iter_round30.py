#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十轮：新发明方向——F1 + 资金费率立场过滤（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利（本轮是方向策略里的资金费过滤，不是现货+永续对冲套利）。

动因（预注册，单组参数，不许用全样本挑）：
  全系列 41 个方向里，资金费率只被当成信号用过（S4 费率水平极值反转
  -2.87%、F4 费率变化驱动 -1.97%、第六轮纯永续价差 -18.57%），从来没被
  当成“持仓成本过滤器”。经济学动机是直接的：做多一个资金费率为正的币，
  持仓跨过 08:00/16:00 UTC 结算点要付费；做空则收钱（Gate 约定：费率>0
  时多头付费，见第七轮引擎 funding_cost_between：long 付 +rate*名义，
  short 付 -rate*名义）。本轮问题：只在资金费率对你有利的方向上做 F1
  跟随，能不能把净收益抬过成本线？

跑前写死的规则（单组参数）：
  信号源 F1（第七轮原版规则一字不变，引擎 import 第二十轮
  build_f1_signals + simulate_f1，tp_mult 固定 2.0）：
    信号根 08:00~19:00 UTC 收盘：BTC 2h 收益 |rBTC| >= 0.5%，且山寨
    自身 2h 收益 |rALT| < 0.5*|rBTC|；方向 = sign(rBTC)；
    下一根开盘进场；止损 1xATR、止盈 2xATR；最多持 4h（1h 版 4 根，
    15m 版 16 根）；每天每币最多 2 笔；当天最后一根收盘强制平仓
    （1h 版 23:00，15m 版 23:45）；单日 -2% 熔断；同根同时碰止损
    和止盈先判止损；只做 7 个山寨，不做 BTC 本身。
    1h 版 ATR(14,1h)、lookback 2 根；15m 版 ATR(14,15m)、lookback 8 根。
  资金费率过滤（信号层执行：被滤掉的信号直接丢弃，不占每日 2 笔上限、
  不占持仓；与第二十轮时段过滤同一处理）：
    过滤值 = 信号根收盘时刻（=入场时刻 entry_t）之前最近一次 Gate
    已结算资金费率，即 funding 字典里 <= entry_t 的最大时间戳对应的
    费率。无未来函数：只用决策时刻已知的已结算费率。
    唯一同时刻情形：入场恰为 16:00 整点时，16:00 结算的费率与 16:00
    开盘价同时产生——该费率在 16:00:00 已结算公布，不属未来信息；
    本轮仍按 <= 取用，并在报告 §0.4 披露；另做敏感性：改用严格 <
    entry_t 时主臂结果的变化（只影响 16:00 入场的信号）。
    MAIN  主臂（有利方向）：做多只在费率 <= 0 时入场，做空只在费率
          >= 0 时入场；费率 = 0 时两边都放行。
    CTRL1 对照 1：原版 F1，无过滤。
    CTRL2 对照 2（反向过滤）：做多只在费率 > 0 时、做空只在费率 < 0
          时（即故意付费的方向），判断过滤的方向性是否真的来自资金费
          成本、而不是换手下降。
    CTRL3 对照 3：主臂 + 时段限制（只在 09:00/15:00 UTC 入场，第二十轮
          MAIN 的叠加写法）。第二层检验：主结论以无时段版为准；若主臂
          本身不达标，对照 3 无论正负都不算通过。
  成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
  M1/M2 对照同第七/九轮；资金费按实际费率计（08:00/16:00 结算点，
  日内持仓 23:00 前强制平仓、永不跨 00:00 结算点）。

窗口（资金费接口保留期边界决定主窗口）：
  F1-1h 主窗口：179 天 2026-05-21~2026-11-15；前 90 天 05-21~08-18 /
    后 89 天 08-19~11-15（与第七轮 F4 的分半一致）。
  F1-15m 稳健性：103 天 2026-08-06~2026-11-16；前 51 天 08-06~09-25 /
    后 52 天 09-26~11-16（与第二十轮 15m 分半一致）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。
  另跑 CTRL1 全 365 天 1h（与 15m 全 103 天）作复核，对照第九轮 TP=2.0
  已发表数字（不计入主结论）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。主臂按粒度分别判定（1h 主臂、15m 主臂
各为一个组合）；两个粒度都通过才算整轮通过。

三项分解（第十轮教训的分解写法，MAIN vs CTRL1，混池）：
  Δ净 = [每笔价差毛利变化项] + [换手×毛利项] + [资金费收支项] + [少做省成本项]
  其中 价差毛利 = Σ price_pnl（不含资金费、不含交易成本）；
  每笔毛利变化项 = n_main * (g_main - g_ctrl)，g = 每笔价差毛利；
  换手×毛利项 = (n_main - n_ctrl) * g_ctrl（少做本身带走/省下的毛利）；
  资金费收支项 = -(funding_main - funding_ctrl)；
  少做省成本项 = -(taker_cost_main - taker_cost_ctrl)。
  四项之和恒等于 Δ净（恒等式，脚本内 assert）。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) CTRL1 全 365 天 1h Taker 逐币对照第九轮 TP=2.0 已发表数字
      （ETH +0.10% / SOL -1.29% / DOGE -3.72% / LINK -4.21% /
      XRP -3.66% / BNB -5.00% / ADA -0.93%），误差 <0.05pp。
  (b) CTRL1 全 103 天 15m Taker 逐币对照第九轮 TP=2.0 已发表数字
      （ETH -0.66% / SOL -1.45% / DOGE -1.24% / LINK -0.83% /
      XRP -1.77% / BNB -1.71% / ADA -0.62%），误差 <0.05pp。
  (c) 主臂首笔交易人工核对：过滤值取数、方向与费率符号、入场/止损/止盈。
  (d) 分解恒等式 assert；脚本跑两遍 md5 一致。

运行：python3 gate_iter_round30.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round30_summary.json
      + data/gate_iter_round30_trades.csv + data/gate_iter_round30_funding_diag.json
复现：跑两遍，三个文件的 md5 应完全一致。
"""
import bisect
import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import date, datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round20 as r20

SYMBOLS = r20.SYMBOLS
ALTS = r20.ALTS
TP_MULT = 2.0
SL_MULT = 1.0
TARGET_HOURS = {9, 15}

START_EQUITY = r20.START_EQUITY

# ---- 预注册窗口（写死）----
FUND_START = date(2026, 5, 21)     # 资金费接口最早日期
FUND_END = date(2026, 11, 15)      # 1h 缓存末日
SPLIT_1H_FUND = date(2026, 8, 19)  # 1h 后半段起点（前 90 天 / 后 89 天）
SPLIT_15M = date(2026, 9, 26)      # 15m 后半段起点（前 51 天 / 后 52 天）

FIRST_FUND_TS = 1779321600  # 2026-05-21 00:00 UTC
LAST_FUND_TS = 1794758400   # 2026-11-15 16:00 UTC


def last_funding_le(fund_ts_sorted, funding, t):
    """决策时刻 t 之前最近一次已结算资金费率（<= t，无未来函数）。"""
    i = bisect.bisect_right(fund_ts_sorted, t) - 1
    if i < 0:
        return None
    return funding[fund_ts_sorted[i]]


def filter_fav(sigs, fund_ts_sorted, funding):
    """主臂：有利方向。做多要求费率<=0，做空要求费率>=0；费率=0 两边放行。"""
    out = {}
    for et, s in sigs.items():
        r = last_funding_le(fund_ts_sorted, funding, et)
        if r is None:
            continue
        if s["direction"] == 1 and r <= 0:
            out[et] = s
        elif s["direction"] == -1 and r >= 0:
            out[et] = s
    return out


def filter_rev(sigs, fund_ts_sorted, funding):
    """对照 2：反向过滤。做多要求费率>0，做空要求费率<0（故意付费的方向）。"""
    out = {}
    for et, s in sigs.items():
        r = last_funding_le(fund_ts_sorted, funding, et)
        if r is None:
            continue
        if s["direction"] == 1 and r > 0:
            out[et] = s
        elif s["direction"] == -1 and r < 0:
            out[et] = s
    return out


def filter_time(sigs):
    """第二十轮时段过滤：只在入场 UTC 小时 ∈ {9, 15} 执行。"""
    return {t: v for t, v in sigs.items()
            if r20.entry_hour_utc(t) in TARGET_HOURS}


def filter_main_time(sigs, fund_ts_sorted, funding):
    """对照 3：主臂过滤 + 时段限制。"""
    return filter_time(filter_fav(sigs, fund_ts_sorted, funding))


def fmt(x, spec="+.2f"):
    return format(x, spec) if x is not None else "—"


def filter_stats(sigs, fund_ts_sorted, funding):
    """信号层统计：总数、方向拆分、费率状态拆分、通过率（主臂/反向）。"""
    tot = len(sigs)
    longs = sum(1 for s in sigs.values() if s["direction"] == 1)
    shorts = tot - longs
    pos = neg = zero = 0
    fav_pass = rev_pass = 0
    fav_long = fav_short = rev_long = rev_short = 0
    for et, s in sigs.items():
        r = last_funding_le(fund_ts_sorted, funding, et)
        if r is None:
            continue
        if r > 0:
            pos += 1
        elif r < 0:
            neg += 1
        else:
            zero += 1
        fav = (s["direction"] == 1 and r <= 0) or (s["direction"] == -1 and r >= 0)
        rev = (s["direction"] == 1 and r > 0) or (s["direction"] == -1 and r < 0)
        if fav:
            fav_pass += 1
            if s["direction"] == 1:
                fav_long += 1
            else:
                fav_short += 1
        if rev:
            rev_pass += 1
            if s["direction"] == 1:
                rev_long += 1
            else:
                rev_short += 1
    return {
        "signals_total": tot, "signals_long": longs, "signals_short": shorts,
        "funding_pos": pos, "funding_neg": neg, "funding_zero": zero,
        "fav_pass": fav_pass, "fav_pass_rate": round(fav_pass / tot, 4) if tot else None,
        "fav_long_pass": fav_long,
        "fav_long_pass_rate": round(fav_long / longs, 4) if longs else None,
        "fav_short_pass": fav_short,
        "fav_short_pass_rate": round(fav_short / shorts, 4) if shorts else None,
        "rev_pass": rev_pass, "rev_pass_rate": round(rev_pass / tot, 4) if tot else None,
        "rev_long_pass": rev_long,
        "rev_long_pass_rate": round(rev_long / longs, 4) if longs else None,
        "rev_short_pass": rev_short,
        "rev_short_pass_rate": round(rev_short / shorts, 4) if shorts else None,
    }


def decompose(main_trades, ctrl_trades):
    """MAIN vs CTRL1 三项分解（+换手×毛利项，四项之和恒等于 Δ净）。"""
    def agg(trs):
        n = len(trs)
        pg = sum(t["price_pnl"] for t in trs)
        fd = sum(t["funding_cost_usdt"] for t in trs)
        tc = sum(t["cost_usdt"] for t in trs)
        return n, pg, fd, tc, pg - fd - tc
    nm, pgm, fdm, tcm, netm = agg(main_trades)
    nc, pgc, fdc, tcc, netc = agg(ctrl_trades)
    gm = pgm / nm if nm else 0.0
    gc = pgc / nc if nc else 0.0
    comp_gross_per_trade = nm * (gm - gc)          # 每笔毛利变化项
    comp_turnover_gross = (nm - nc) * gc           # 换手×毛利项
    comp_funding = -(fdm - fdc)                    # 资金费收支项
    comp_cost = -(tcm - tcc)                       # 少做省成本项
    delta = netm - netc
    assert abs((comp_gross_per_trade + comp_turnover_gross
                + comp_funding + comp_cost) - delta) < 0.01, "分解恒等式不成立"
    return {
        "n_main": nm, "n_ctrl": nc,
        "price_gross_main": round(pgm, 2), "price_gross_ctrl": round(pgc, 2),
        "price_gross_per_trade_main": round(gm, 2),
        "price_gross_per_trade_ctrl": round(gc, 2),
        "funding_main": round(fdm, 2), "funding_ctrl": round(fdc, 2),
        "funding_per_trade_main": round(fdm / nm, 2) if nm else None,
        "funding_per_trade_ctrl": round(fdc / nc, 2) if nc else None,
        "taker_cost_main": round(tcm, 2), "taker_cost_ctrl": round(tcc, 2),
        "net_main": round(netm, 2), "net_ctrl": round(netc, 2),
        "delta_net": round(delta, 2),
        "comp_gross_per_trade": round(comp_gross_per_trade, 2),
        "comp_turnover_gross": round(comp_turnover_gross, 2),
        "comp_funding": round(comp_funding, 2),
        "comp_cost_saving": round(comp_cost, 2),
    }


def main():
    print("盈利策略迭代 · 第三十轮：F1 + 资金费率立场过滤（全模拟）")
    print("主臂 F1 + 有利资金费方向；对照 1 原版 F1；对照 2 反向过滤；对照 3 主臂+时段。")
    print("止损 1xATR / 止盈 2xATR；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = r20.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = r20.load_funding(sym)
        data1h[sym] = (bars, funding)
        days = r20.group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
        fts = sorted(funding)
        assert len(fts) == 537, f"{sym} 资金费应为 537 条，实际 {len(fts)}"
        assert fts[0] == FIRST_FUND_TS, f"{sym} 资金费首条时间戳异常 {fts[0]}"
        assert fts[-1] == LAST_FUND_TS, f"{sym} 资金费末条时间戳异常 {fts[-1]}"
        assert all(b - a == 28800 for a, b in zip(fts, fts[1:])), f"{sym} 资金费非 8h 等距"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = r20.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = r20.load_funding(sym)
        data15[sym] = (bars, funding)
        days = r20.group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；"
          "各 537 条资金费（2026-05-21 00:00~11-15 16:00，8h 等距）；时间戳对齐、零缺口。")

    days_all_1h = set(r20.group_days(data1h["BTC_USDT"][0], 24).keys())
    full_179 = {d for d in days_all_1h if FUND_START <= d <= FUND_END}
    front_90 = {d for d in full_179 if d < SPLIT_1H_FUND}
    back_89 = {d for d in full_179 if d >= SPLIT_1H_FUND}
    days_all_15 = set(r20.group_days(data15["BTC_USDT"][0], 96).keys())
    front_51 = {d for d in days_all_15 if d < SPLIT_15M}
    back_52 = {d for d in days_all_15 if d >= SPLIT_15M}
    print(f"窗口：1h 主窗口 179d（前 {len(front_90)} 天 / 后 {len(back_89)} 天）；"
          f"15m 全 103d（前 {len(front_51)} 天 / 后 {len(back_52)} 天）。")

    # ---- F1 信号：同一粒度只生成一次，四臂共用同一组信号 ----
    atr1h = {s: r20.atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: r20.atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig1h, sig15 = {}, {}
    fund_ts = {s: sorted(data1h[s][1]) for s in SYMBOLS}
    for sym in ALTS:
        sig1h[sym] = r20.build_f1_signals(data1h[sym][0], data1h["BTC_USDT"][0],
                                          atr1h[sym], 2, 4, TP_MULT)
        sig15[sym] = r20.build_f1_signals(data15[sym][0], data15["BTC_USDT"][0],
                                          atr15[sym], 8, 16, TP_MULT)
    print(f"[F1] 信号数（与过滤无关，四臂共用）：1h 合计 "
          f"{sum(len(v) for v in sig1h.values())}，15m 合计 "
          f"{sum(len(v) for v in sig15.values())}。")

    # ---- 资金费率状态诊断（信号层，179d/103d 窗口内信号）----
    # 注意：1h 信号集覆盖全 365 天，但资金费只从 2026-05-21 起才有；
    # 诊断与通过率的分母一律用窗口内信号数（1h：entry_t >= 2026-05-21 00:00 UTC），
    # 否则前 05-21 的无费率信号会把通过率稀释掉约一半。
    print("\n=== 信号层资金费率状态诊断（F1 信号，过滤前；分母=窗口内信号）===")
    fstats = {}
    sig_win = {}
    win_start = {"1h": int(datetime(2026, 5, 21, tzinfo=timezone.utc).timestamp()),
                 "15m": 0}
    for gran, sigs_all in (("1h", sig1h), ("15m", sig15)):
        for sym in ALTS:
            w = {et: s for et, s in sigs_all[sym].items() if et >= win_start[gran]}
            sig_win[(gran, sym)] = w
            fts = fund_ts[sym]
            fd = data1h[sym][1]
            st = filter_stats(w, fts, fd)
            fstats[(gran, sym)] = st
            print(f"  F1-{gran} {sym}：信号 {st['signals_total']}（多 {st['signals_long']} / "
                  f"空 {st['signals_short']}）；信号时费率>0 {st['funding_pos']} / =0 "
                  f"{st['funding_zero']} / <0 {st['funding_neg']}；主臂通过 "
                  f"{st['fav_pass']}（{st['fav_pass_rate']*100:.1f}%；多 "
                  f"{st['fav_long_pass_rate']*100:.1f}% / 空 "
                  f"{st['fav_short_pass_rate']*100:.1f}%）；反向通过 "
                  f"{st['rev_pass']}（{st['rev_pass_rate']*100:.1f}%）")

    def apply_filter(arm, sigs, sym):
        fts = fund_ts[sym]
        fd = data1h[sym][1]
        if arm == "MAIN":
            return filter_fav(sigs, fts, fd)
        if arm == "CTRL1":
            return dict(sigs)
        if arm == "CTRL2":
            return filter_rev(sigs, fts, fd)
        if arm == "CTRL3":
            return filter_main_time(sigs, fts, fd)
        raise ValueError(arm)

    ARMS = [
        ("MAIN", "F1-fundfav"),
        ("CTRL1", "F1-nofilter"),
        ("CTRL2", "F1-fundrev"),
        ("CTRL3", "F1-fundfav-hours0915"),
    ]
    GRANS = [
        ("1h", data1h, sig1h, 24,
         [("179d", full_179), ("前90d", front_90), ("后89d", back_89)],
         lambda et: "前90d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H_FUND else "后89d"),
        ("15m", data15, sig15, 96,
         [("103d", None), ("前51d", front_51), ("后52d", back_52)],
         lambda et: "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M else "后52d"),
    ]

    all_results, all_trades = [], []
    pass_stats = {}
    fund_rate_of = {}  # (gran, sym, entry_t) -> 过滤值费率（供明细标注）
    for gran, sigs_all in (("1h", sig1h), ("15m", sig15)):
        for sym in ALTS:
            fts = fund_ts[sym]
            fd = data1h[sym][1]
            for et in sigs_all[sym]:
                fund_rate_of[(gran, sym, et)] = last_funding_le(fts, fd, et)

    for arm, label in ARMS:
        for gran, data, sigs_all, bpd, windows, split_fn in GRANS:
            print(f"\n=== {arm} {label} · F1-{gran}（TP {TP_MULT}，SL {SL_MULT}）===")
            for sym in ALTS:
                sigs_full = sig_win[(gran, sym)]  # 窗口内信号（1h 仅 179d 内）
                sigs = apply_filter(arm, sigs_full, sym)
                pass_stats[(arm, gran, sym)] = (len(sigs_full), len(sigs))
                for wname, subset in windows:
                    bars, funding = data[sym]
                    trades, curve, ndays = r20.simulate_f1(
                        sym, bars, sigs, funding, subset, 2, label, bpd)
                    res = r20.summarize(sym, trades, curve, label, len(sigs))
                    res["arm"] = arm
                    res["variant"] = label
                    res["family"] = "F1"
                    res["tp_mult"] = TP_MULT
                    res["granularity"] = gran
                    res["split"] = wname
                    res["days"] = ndays
                    res["signals_total"] = len(sigs_full)
                    res["signals_pass"] = len(sigs)
                    res["signal_pass_rate"] = round(len(sigs) / len(sigs_full), 4) if sigs_full else None
                    # 价差毛利（不含资金费）与每笔资金费收支
                    res["price_gross_usdt"] = round(
                        res["gross_usdt"] + res["funding_cost_sum"], 2)
                    res["price_gross_per_trade_usdt"] = round(
                        res["price_gross_usdt"] / res["trades"], 2) if res["trades"] else None
                    res["funding_per_trade_usdt"] = round(
                        res["funding_cost_sum"] / res["trades"], 2) if res["trades"] else None
                    res["funding_nonzero_trades"] = sum(
                        1 for t in trades if t["funding_cost_usdt"] != 0)
                    all_results.append(res)
                    if wname in ("179d", "103d"):
                        for t in trades:
                            t2 = dict(t)
                            t2["arm"] = arm
                            t2["variant"] = label
                            t2["family"] = "F1"
                            t2["tp_mult"] = TP_MULT
                            t2["granularity"] = gran
                            t2["split"] = split_fn(t["entry_t"])
                            t2["entry_hour_utc"] = r20.entry_hour_utc(t["entry_t"])
                            t2["funding_rate_filter"] = fund_rate_of.get((gran, sym, t["entry_t"]))
                            all_trades.append(t2)
                    print(f"[{arm} F1-{gran} {sym} {wname}] n={res['trades']} "
                          f"信号 {len(sigs)}/{len(sigs_full)} 胜率={res['win_rate']} "
                          f"盈亏比={res['profit_factor']} Taker {res['taker_net_pct']*100:+.2f}% "
                          f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                          f"M2 {res['m2_net_pct']*100:+.2f}% 价差毛利={res['price_gross_usdt']:+.0f} "
                          f"每笔价差毛利={fmt(res['price_gross_per_trade_usdt'])} "
                          f"资金费/笔={fmt(res['funding_per_trade_usdt'])} "
                          f"成本={res['taker_cost_sum']:+.0f} 持仓={res['avg_hold_min']}分钟 "
                          f"出场={res['reason_counts']}")

    # ---- 汇总：平均净收益 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            for wname, _ in windows:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                gt = sum(r["price_gross_usdt"] for r in rs)
                fd = sum(r["funding_cost_sum"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                wr = (sum((r["win_rate"] or 0) * r["trades"] for r in rs) / nt) if nt else None
                print(f"  {arm} F1-{gran} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"价差毛利 {gt:+.0f} 资金费 {fd:+.0f} 成本 {ct:+.0f} 笔数 {nt} "
                      f"每笔价差毛利 {gt/nt:+.2f} 每笔资金费 {fd/nt:+.2f} "
                      f"胜率 {wr:.3f}" if wr is not None else
                      f"  {arm} F1-{gran} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"价差毛利 {gt:+.0f} 资金费 {fd:+.0f} 成本 {ct:+.0f} 笔数 {nt} "
                      f"每笔价差毛利 — 每笔资金费 — 胜率 —")

    # ---- 通过率（信号层 + 成交层）----
    print("\n=== 过滤通过率 ===")
    for arm, label in ARMS:
        for gran, _, _, _, _, _ in GRANS:
            st = sum(pass_stats[(arm, gran, s)][0] for s in ALTS)
            sp = sum(pass_stats[(arm, gran, s)][1] for s in ALTS)
            nt_arm = sum(r["trades"] for r in all_results if r["arm"] == arm
                         and r["granularity"] == gran and r["split"] in ("179d", "103d"))
            nt_c1 = sum(r["trades"] for r in all_results if r["arm"] == "CTRL1"
                        and r["granularity"] == gran and r["split"] in ("179d", "103d"))
            print(f"  {arm} F1-{gran}：信号通过 {sp}/{st} = {sp/st*100:.1f}%；"
                  f"成交笔数 {nt_arm}/{nt_c1} = {nt_arm/nt_c1*100:.1f}%（相对 CTRL1）")

    # ---- 三项分解：MAIN vs CTRL1（全期混池）----
    print("\n=== 三项分解：MAIN vs CTRL1（全期混池，USDT）===")
    decomps = {}
    for gran, full in (("1h", "179d"), ("15m", "103d")):
        m_tr = [t for t in all_trades if t["arm"] == "MAIN" and t["granularity"] == gran]
        c_tr = [t for t in all_trades if t["arm"] == "CTRL1" and t["granularity"] == gran]
        d = decompose(m_tr, c_tr)
        decomps[gran] = d
        print(f"  F1-{gran}：Δ净 {d['delta_net']:+.2f} = 每笔毛利变化 "
              f"{d['comp_gross_per_trade']:+.2f} + 换手×毛利 {d['comp_turnover_gross']:+.2f} "
              f"+ 资金费收支 {d['comp_funding']:+.2f} + 少做省成本 "
              f"{d['comp_cost_saving']:+.2f}（n {d['n_main']}/{d['n_ctrl']}；"
              f"每笔价差毛利 {d['price_gross_per_trade_main']:+.2f} vs "
              f"{d['price_gross_per_trade_ctrl']:+.2f}；每笔资金费 "
              f"{d['funding_per_trade_main']:+.2f} vs {d['funding_per_trade_ctrl']:+.2f}）")
        # 反向臂同款分解（CTRL2 vs CTRL1）：判断方向性
        r_tr = [t for t in all_trades if t["arm"] == "CTRL2" and t["granularity"] == gran]
        d2 = decompose(r_tr, c_tr)
        print(f"  CTRL2-{gran} vs CTRL1：Δ净 {d2['delta_net']:+.2f} = 每笔毛利变化 "
              f"{d2['comp_gross_per_trade']:+.2f} + 换手×毛利 {d2['comp_turnover_gross']:+.2f} "
              f"+ 资金费收支 {d2['comp_funding']:+.2f} + 少做省成本 "
              f"{d2['comp_cost_saving']:+.2f}（n {d2['n_main']}/{d2['n_ctrl']}）")

    # ---- pooled t（全期明细，Taker 与毛利）----
    print("\n=== Pooled t 值（全期明细）===")
    for arm, label in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            full = windows[0][0]
            sub = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
            for wname, _ in windows:
                s2 = [t for t in sub if wname == full or t["split"] == wname]
                vt = [t["pnl"] / START_EQUITY for t in s2]
                vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in s2]
                vm = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
                print(f"  {arm} F1-{gran} {wname}：n={len(s2)} "
                      f"pooled t(Taker)={r20.t_value(vt)} pooled t(毛利)={r20.t_value(vg)} "
                      f"pooled t(M1)={r20.t_value(vm)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    verdict = {}
    for arm, label in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            wnames = [w for w, _ in windows]
            row = {}
            for wname in wnames:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            good = row[wnames[1]] > 0 and row[wnames[2]] > 0 and row[wnames[0]] > 0.02
            verdict[(arm, gran)] = good
            print(f"  {arm} F1-{gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
                  f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}% → "
                  f"{'达标' if good else '不达标'}")
            for sym in ALTS:
                rf = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                      and r["symbol"] == sym and r["split"] == wnames[1]][0]
                rb = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                      and r["symbol"] == sym and r["split"] == wnames[2]][0]
                both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
                print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                      f"后 {rb['taker_net_pct']*100:+.2f}% → "
                      f"{'★ 两半都为正' if both else ''}")
    print(f"\n  主臂整轮判定：1h {'达标' if verdict[('MAIN','1h')] else '不达标'}、"
          f"15m {'达标' if verdict[('MAIN','15m')] else '不达标'} → "
          f"{'通过' if verdict[('MAIN','1h')] and verdict[('MAIN','15m')] else '不通过'}")

    # ---- 复核 (a)(b)：CTRL1 vs 第九轮 TP=2.0 已发表数字 ----
    print("\n=== 复核 (a)(b)：CTRL1 vs 第九轮 TP=2.0 已发表数字（Taker，全期）===")
    checks_1h = {
        "ETH_USDT": 0.0010, "SOL_USDT": -0.0129, "DOGE_USDT": -0.0372,
        "LINK_USDT": -0.0421, "XRP_USDT": -0.0366, "BNB_USDT": -0.0500,
        "ADA_USDT": -0.0093,
    }
    checks_15m = {
        "ETH_USDT": -0.0066, "SOL_USDT": -0.0145, "DOGE_USDT": -0.0124,
        "LINK_USDT": -0.0083, "XRP_USDT": -0.0177, "BNB_USDT": -0.0171,
        "ADA_USDT": -0.0062,
    }
    bad = 0
    for sym, expect in sorted(checks_1h.items()):
        bars, funding = data1h[sym]
        sigs = sig1h[sym]
        trades, curve, ndays = r20.simulate_f1(sym, bars, sigs, funding, None, 2,
                                               "F1-nofilter", 24)
        res = r20.summarize(sym, trades, curve, "F1-nofilter", len(sigs))
        ok = abs(res["taker_net_pct"] - expect) < 0.0005
        bad += 0 if ok else 1
        print(f"  CTRL1 F1-1h 365d {sym}: 本轮 {res['taker_net_pct']*100:+.2f}% vs 第九轮 "
              f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    for sym, expect in sorted(checks_15m.items()):
        r = [x for x in all_results if x["arm"] == "CTRL1" and x["granularity"] == "15m"
             and x["symbol"] == sym and x["split"] == "103d"][0]
        ok = abs(r["taker_net_pct"] - expect) < 0.0005
        bad += 0 if ok else 1
        print(f"  CTRL1 F1-15m 103d {sym}: 本轮 {r['taker_net_pct']*100:+.2f}% vs 第九轮 "
              f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核 (a)(b) 结果：{14-bad}/14 一致"
          + ("（全部通过）" if bad == 0 else "（有出入，见报告）"))

    # ---- 敏感性：16:00 同时刻取数（严格 < entry_t）对主臂的影响 ----
    print("\n=== 敏感性：过滤值改用严格 < entry_t（16:00 信号改用 08:00 费率）===")
    def filter_fav_strict(sigs, fund_ts_sorted, funding):
        out = {}
        for et, s in sigs.items():
            i = bisect.bisect_left(fund_ts_sorted, et) - 1
            if i < 0:
                continue
            r = funding[fund_ts_sorted[i]]
            if s["direction"] == 1 and r <= 0:
                out[et] = s
            elif s["direction"] == -1 and r >= 0:
                out[et] = s
        return out
    for gran, data, sigs_all, bpd, windows, _ in GRANS:
        full = windows[0][0]
        subset = windows[0][1]
        tot_n = tot_net = 0.0
        for sym in ALTS:
            sigs = filter_fav_strict(sigs_all[sym], fund_ts[sym], data[sym][1])
            bars, funding = data[sym]
            trades, curve, _ = r20.simulate_f1(sym, bars, sigs, funding, subset, 2,
                                               "F1-fundfav-strict", bpd)
            res = r20.summarize(sym, trades, curve, "F1-fundfav-strict", len(sigs))
            tot_n += res["trades"]
            tot_net += res["taker_net_pct"]
        m = [r for r in all_results if r["arm"] == "MAIN" and r["granularity"] == gran
             and r["split"] == full]
        main_avg = sum(r["taker_net_pct"] for r in m) / len(m)
        print(f"  F1-{gran} 主臂严格<版：全期 Taker 平均 {tot_net/len(ALTS)*100:+.2f}% "
              f"（n={int(tot_n)}）vs <=版 {main_avg*100:+.2f}%")

    # ---- 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round30_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round30_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "funding_rate_filter", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["arm"], x["granularity"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t.get("funding_rate_filter"), t["reason"], t["hold_min"]])
    fund_diag = {
        "filter_rule": "过滤值 = 信号根收盘时刻（=入场时刻 entry_t）之前最近一次已结算资金费率"
                       "（funding 字典里 <= entry_t 的最大时间戳）；MAIN 做多要求费率<=0、"
                       "做空要求费率>=0；CTRL2 反向。",
        "signal_stats": {f"{g}|{s}": v for (g, s), v in fstats.items()},
        "decomposition_main_vs_ctrl1": decomps,
        "note": "gross_usdt（summarize 口径）= 价差毛利 - 资金费；"
                "price_gross_usdt = gross_usdt + funding_cost_sum = Σprice_pnl。",
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round30_funding_diag.json"), "w") as f:
        json.dump(fund_diag, f, indent=2, ensure_ascii=False)
    print("\n汇总已写入：data/gate_iter_round30_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round30_trades.csv ({len(all_trades)} 笔)")
    print("资金费诊断已写入：data/gate_iter_round30_funding_diag.json")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
