#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第四十轮：4h 背景过滤（分系统 SUB-SMC，全新币种宇宙验证）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

预注册（跑前写死，不可改；来源：盈利策略迭代-分系统回测挖掘.md §2.4 第四队；
用户 2026-11-21 硬性要求：后续回测一律用未回测过的币种）：
  测什么：4h 结构方向作过滤，只做顺 4h 方向的 SUB 模板信号
  （A/B 只做 4h 看多时、C 只做 4h 看空时）。
  本轮是四队排完后的最后一队。36 轮时段拆分证伪（测量轮，不计方向）、
  37 轮多币同发证伪（新宇宙验证，计 1 方向）、39 轮强度分档证伪
  （测量轮，不计方向）；38 轮是主系统 S1 验证（不属于分系统队列）。
  累计 48 个方向、0 达标。本轮计 1 个方向（“4h 背景过滤有效”）。

  背景定义（二选一，跑前定死，选 (a)，不事后换）：
    (a) 4h 收盘价在 4h 前 20 根区间中位线上方为看多、下方为看空；
    (b) 4h 均线方向。
    选 (a)。理由：(a) 是本系统自己的 Premium/Discount 均衡价规则
    （20 根区间中位线为均衡价）换到 4h 上，不是从系统外引进指标；
    (b) 均线方向要另选周期、是与 SMC 框架无关的滞后趋势代理。
    精确定义（跑前写死）：
      - 4h 合成：4h 根由合并后 1h（build_1h_combined_new 的输出，
        即 builders 看到的同一条 1h 序列）每 4 根合成，UTC 00:00/
        04:00/08:00/12:00/16:00/20:00 对齐；t = 开盘时刻，o = 首根 1h
        开，h = 4 根最高，l = 4 根最低，c = 末根 1h 收，close_t = t+4h。
        合成前断言 1h 连续（逐根差 3600 秒）且起点对齐 4h 边界、
        根数可被 4 整除；合成后断言 4h 连续无缺口；有缺口则停下来
        查，不补数、不编数。
      - 决策时刻 = 信号入场根时刻 entry_t（确认根 15m 收盘 = 入场根
        开盘，与 builders / simulate_stream 的口径一致）。
      - 背景根 = close_t <= entry_t 的最后一根 4h（恰好在 entry_t 收盘
        的那根算已收盘——与 builders 把确认根当作 entry_t 时已收盘
        的口径一致；收盘晚 1 秒的根不用，是未来数据）。
      - 中位线 mid =（20 根里最高 h + 最低 l）/ 2，窗口为最近 20 根
        已收盘 4h（含背景根本身——与系统 P/D“20 根区间中位线”
        含当前根的口径一致）。
      - 方向：背景根收盘价 > mid 为看多，< mid 为看空，== mid 为
        未定义（信号跳过并计数；浮点相等测度为零，但规则写死）。
      - 预热：决策时刻已收盘 4h 不足 20 根 → 未定义（信号跳过并计数；
        窗口内不可能发生——1h 历史自 2025-11-16 起，2026-08-09 时
        已有约 2,190 根 4h——但守卫代码与计数必须在，万一触发要留痕）。
      - 过滤：A/B（做多）只留看多背景的信号，C（做空）只留看空背景
        的信号；未定义背景的信号跳过并计数。过滤在信号层面做
        （夜禁 + ATR 预热之后、simulate_stream 之前），每天 2 笔上限
        与持仓中跳过在过滤后的信号上自然作用。
  数据：新宇宙 8 币 MMT/WLD/PIEVERSE/AVAX/PAXG/ARB/FIL/TAO
  （37 轮名单，data/gate_iter_round37_selection.json），窗口
  2026-08-09~11-16（100 天，9,600 根 15m）。与挖掘报告 §2.4 写
  的“数据同 35 轮”不同——按用户 2026-11-21 硬性要求，后续回测
  一律用未回测过的币种，本轮直接在新宇宙上测，不在旧宇宙上重测；
  报告 §0 写明这一处偏差及原因。
  信号与出场：35 轮三模板的信号定义一字不改（复用 R15 builders）；
  出场跟踪止盈 2xATR 激活、成本、熔断、每天每币 2 笔上限、夜禁
  （UTC 17:00–23:00）、16 根持满上限，全部与 35 轮主臂一字相同
  （隔离背景过滤的效应，不与 SUB-SMC v1.1 的“取消持满上限”混在一起）。
  对照臂：先在新宇宙上复现 37 轮 FULL 全量结果（A -0.54%/229 笔/
  净 -4,297.32、B -1.03%/481 笔/净 -8,238.44、C -1.59%/534 笔），
  笔数须一字相同、净须在 0.05 USDT 内；对不上就停下来查，不要继续。
  报什么：每模板 x（加背景过滤 / 全量对照）：笔数、全期 Taker 净
  （币均）、前/后半段 Taker 净（切点 09-21，与 35/37 轮同）、每笔毛利、
  毛利/成本、P(到 1xATR)、P(到 2x|到 1x)、R1 三项分解（过滤臂 vs 全量臂）。
  通过标准（与 36/37 轮同，不放宽）：某模板的过滤臂同时满足
  (i) 全期 1 倍 Taker 净 > +2%（币均），(ii) 前后两半都为正，
  (iii) 每笔毛利 > 25 USDT 且两半都 > 25，(iv) R1 省成本占比 ≤ 80%
  ——四项全过才算“4h 背景过滤有效”。
  证伪：没有一个模板的过滤臂四项全过，则 4h 背景过滤证伪，不进判断层。
  定位：本轮是验证轮（新假设、新宇宙第一次测），不是测量轮；若某模板
  通过，它仍只是在一个新宇宙上的一次通过，按 R2 不得换另一批新币重验
  同一发现，后续验证须在 2026-11-16 之后的实盘纸面数据上看
  （12 月 18 日月度复核时判）。
  预期（跑前写死）：按挖掘报告 §2.4，背景过滤大概率只是再少做
  （R1 风险最高的一类候选），预期不通过。

无未来数据（用户 2026-11-21 硬性要求，执行前自查，写死在代码里）：
  - 信号只用已收盘 K 线（R15 builders 一字不改）；入场一律下一根
    15m 开盘；背景只用决策时刻已收盘的 4h 根（close_t <= entry_t，
    含恰好在 entry_t 收盘的那根；晚 1 秒的根不用）。
  - 4h 合成只用 builders 看到的同一条合并 1h；中位线窗口含背景根
    本身（P/D 口径），不含任何决策时刻之后的根。
  - 模拟复用 gate_iter_round35.simulate_stream 一字不改；资金费只计
    入场日与入场日+1 的 08:00/16:00 结算点。
  数据绝对不能做假：算不出就写算不出（33 轮缺 atr 列即是先例）。

运行：python3 gate_iter_round40.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round40_summary.json
      + data/gate_iter_round40_cells.json + data/gate_iter_round40_trades.csv
复现：跑两遍，三个文件的 md5 应完全一致。
"""

import bisect
import csv
import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round15 as R15  # 三个 SMC 模板 builders（原样恢复）
import gate_iter_round35 as R35  # 复用 35 轮引擎：load / atr / simulate_stream / summarize
import gate_iter_round37 as R37  # 复用 37 轮新宇宙 1h 合并函数与格子统计

DATA_DIR = os.path.join(SCRIPT_DIR, "data")

# ---- 新宇宙（跑前定死；37 轮名单，见 data/gate_iter_round37_selection.json）----
SYMBOLS = R37.NEW_SYMBOLS
assert SYMBOLS == ["MMT_USDT", "WLD_USDT", "PIEVERSE_USDT", "AVAX_USDT",
                   "PAXG_USDT", "ARB_USDT", "FIL_USDT", "TAO_USDT"], "新宇宙名单与 37 轮不一致"
SPLIT_R35 = R35.SPLIT_R35  # 2026-09-21；前半段 08-09~09-20（43 天）/ 后 57 天
START_EQUITY = R35.START_EQUITY
NOTIONAL = R35.NOTIONAL
MAX_PER_DAY = R35.MAX_PER_DAY

BG_WINDOW = 20  # 4h 背景窗口：最近 20 根已收盘 4h（含背景根本身），与系统 P/D 的 20 根口径一致
TEMPLATES = [("A", "R15-A 扫荡反转做多", R15.build_A),
             ("B", "R15-B FVG 回踩做多", R15.build_B),
             ("C", "R15-C 供给拒绝做空", R15.build_C)]
# 方向：A/B 做多（+1）只留看多背景；C 做空（-1）只留看空背景。

# ---- 对照臂复现目标（37 轮报告 §2，全量臂；笔数一字相同、净在 0.05 内）----
FULL_EXPECTED = {
    "A": {"n": 229, "net": -4297.32, "coin_mean_pct": -0.0054},
    "B": {"n": 481, "net": -8238.44, "coin_mean_pct": -0.0103},
    "C": {"n": 534, "net": -12732.91, "coin_mean_pct": -0.0159},
}


def synthesize_4h(bars1h):
    """1h -> 4h（UTC 00:00/04:00/08:00/12:00/16:00/20:00 对齐）。
    输入须为 builders 看到的同一条合并 1h（连续、无缺口）。
    返回 [{t, o, h, l, c, close_t}]，t = 开盘时刻，close_t = t + 4h。"""
    assert bars1h, "1h 为空，无法合成 4h"
    assert all(bars1h[i + 1]["t"] - bars1h[i]["t"] == 3600
               for i in range(len(bars1h) - 1)), "1h 不连续，无法合成 4h"
    assert bars1h[0]["t"] % 14400 == 0, f"1h 起点 {bars1h[0]['t']} 不对齐 4h 边界"
    assert len(bars1h) % 4 == 0, f"1h 根数 {len(bars1h)} 不能被 4 整除"
    out = []
    for k in range(0, len(bars1h), 4):
        g = bars1h[k:k + 4]
        assert g[0]["t"] % 14400 == 0, f"4h 分组不对齐：{g[0]['t']}"
        out.append({"t": g[0]["t"], "o": g[0]["o"],
                    "h": max(x["h"] for x in g), "l": min(x["l"] for x in g),
                    "c": g[3]["c"], "close_t": g[0]["t"] + 14400})
    assert all(out[i + 1]["t"] - out[i]["t"] == 14400 for i in range(len(out) - 1)), \
        "合成 4h 有缺口"
    return out


def bg_at(entry_t, bars4h, closes, window=BG_WINDOW):
    """决策时刻 entry_t 的 4h 背景。
    背景根 = close_t <= entry_t 的最后一根 4h（恰好在 entry_t 收盘的算已收盘，
    与 builders 把确认根当作 entry_t 时已收盘的口径一致；晚 1 秒的根不用）。
    中位线 = 最近 window 根已收盘 4h（含背景根本身）的（最高 h + 最低 l）/ 2。
    返回 (direction, mid, close, status)，direction ∈ {'BULL','BEAR',None}，
    status ∈ {'OK','WARMUP','TIE'}。未定义时信号跳过并计数。"""
    j = bisect.bisect_right(closes, entry_t) - 1
    if j < window - 1:
        return None, None, None, "WARMUP"
    seg = bars4h[j - window + 1:j + 1]
    mid = (max(b["h"] for b in seg) + min(b["l"] for b in seg)) / 2.0
    c = bars4h[j]["c"]
    if c > mid:
        return "BULL", mid, c, "OK"
    if c < mid:
        return "BEAR", mid, c, "OK"
    return None, mid, c, "TIE"


def _selftest_bg():
    """4h 背景自测（合成例子，不读任何真实数据）。
    24 根合成 4h：0–18 根 h=110/l=90/c=100；19 根 h=120/l=100/c=102；
    20 根 h=110/l=90/c=99；21 根 h=110/l=90/c=105；22–23 根 h=110/l=90/c=100。
    预期：
      (1) entry_t 恰在 19 根收盘时刻 → 背景根=19 根，窗口 0–19，
          mid=(120+90)/2=105，收 102 < 105 → BEAR（证明中位线含背景根本身：
          若不含，窗口 0–18 的 mid=100，收 102 会判 BULL；也证明恰在 entry_t
          收盘的那根算已收盘）。
      (2) entry_t 在 19 根收盘前 1 秒 → 背景根=18 根，不足 20 根 → WARMUP
          （收盘晚 1 秒的根不用，是未来数据）。
      (3) entry_t 恰在 20 根收盘时刻 → 窗口 1–20，mid=105，收 99 → BEAR。
      (4) entry_t 恰在 21 根收盘时刻 → 窗口 2–21，mid=105，收 105 → TIE（未定义）。
      (5) entry_t 在 5 根收盘时刻 → WARMUP。"""
    t0 = 1760000000 - (1760000000 % 14400)
    bars = []
    for i in range(24):
        t = t0 + i * 14400
        if i < 19:
            bars.append({"t": t, "o": 100, "h": 110, "l": 90, "c": 100, "close_t": t + 14400})
        elif i == 19:
            bars.append({"t": t, "o": 100, "h": 120, "l": 100, "c": 102, "close_t": t + 14400})
        elif i == 20:
            bars.append({"t": t, "o": 100, "h": 110, "l": 90, "c": 99, "close_t": t + 14400})
        elif i == 21:
            bars.append({"t": t, "o": 100, "h": 110, "l": 90, "c": 105, "close_t": t + 14400})
        else:
            bars.append({"t": t, "o": 100, "h": 110, "l": 90, "c": 100, "close_t": t + 14400})
    closes = [b["close_t"] for b in bars]
    d, mid, c, st = bg_at(bars[19]["close_t"], bars, closes)
    assert (d, mid, st) == ("BEAR", 105.0, "OK"), f"自测(1) 失败：{(d, mid, st)}"
    d, mid, c, st = bg_at(bars[19]["close_t"] - 1, bars, closes)
    assert (d, st) == (None, "WARMUP"), f"自测(2) 失败：{(d, st)}"
    d, mid, c, st = bg_at(bars[20]["close_t"], bars, closes)
    assert (d, mid, st) == ("BEAR", 105.0, "OK"), f"自测(3) 失败：{(d, mid, st)}"
    d, mid, c, st = bg_at(bars[21]["close_t"], bars, closes)
    assert (d, st) == (None, "TIE") and mid == 105.0, f"自测(4) 失败：{(d, mid, st)}"
    d, mid, c, st = bg_at(bars[5]["close_t"], bars, closes)
    assert (d, st) == (None, "WARMUP"), f"自测(5) 失败：{(d, st)}"
    print("[4h 背景自测 ✓] 中位线含背景根本身、边界收盘算已收盘、"
          "晚 1 秒不用、平中位线未定义、不足 20 根未定义均正确")


def fav_atr(t):
    """峰值有利浮动（ATR 倍数）。与 35/36/37 轮诊断同口径：
    max_favour_usdt / (10,000 x ATR / 入场价)。"""
    if not t.get("atr"):
        return 0.0
    return (t.get("max_favour_usdt", 0.0) / NOTIONAL) / (t["atr"] / t["entry"])


def split_of(et):
    return ("前43d" if datetime.fromtimestamp(et, timezone.utc).date()
            < SPLIT_R35.date() else "后57d")


def session_of(entry_t):
    return R37.session_of(entry_t)


def main():
    _selftest_bg()
    assert len(SYMBOLS) == 8, f"新宇宙应为 8 个币，实际 {len(SYMBOLS)}"
    print("盈利策略迭代 · 第四十轮：4h 背景过滤（分系统 SUB-SMC，全新币种宇宙验证）")
    print(f"新宇宙：{', '.join(s.replace('_USDT', '') for s in SYMBOLS)}")
    print("背景定义（跑前定死）：4h 收盘价 vs 最近 20 根已收盘 4h 区间中位线"
          "（高于为看多、低于为看空、等于未定义）；A/B 只做看多时、C 只做看空时。")
    print("通过标准（四项全过才算）：(i) 全期币均 Taker 净 > +2%，(ii) 前后两半都为正，"
          "(iii) 每笔毛利 > 25 USDT 且两半都 > 25，(iv) R1 省成本占比 ≤ 80%。")

    # ---- 数据校验（与 37 轮同口径，窗口 2026-08-09~11-16，100 天）----
    data15 = {}
    for sym in SYMBOLS:
        bars = R35.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R35.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R35.group_days(bars, 96)
        assert len(days) == 100, f"{sym} 15m 完整日应为 100 天，实际 {len(days)}"
        assert len(bars) == 100 * 96, f"{sym} 15m 应为 {100*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15[SYMBOLS[0]][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 {SYMBOLS[0]} 不对齐"
    print("数据校验通过：8 币各 9,600 根 15m / 100 天；时间戳对齐、零缺口。")

    # 1h 合并（复用 37 轮函数，合并规则一字相同）+ 4h 合成
    data1h = R37.build_1h_combined_new(SYMBOLS)
    data4h = {}
    for sym in SYMBOLS:
        bars1h, _a1h = data1h[sym]
        b4 = synthesize_4h(bars1h)
        data4h[sym] = (b4, [b["close_t"] for b in b4])
        first_close = datetime.fromtimestamp(b4[0]["close_t"], timezone.utc).date()
        print(f"  [{sym.replace('_USDT', '')}] 4h 合成 {len(b4)} 根"
              f"（{b4[0]['t'] and datetime.fromtimestamp(b4[0]['t'], timezone.utc).date()} ~ "
              f"{datetime.fromtimestamp(b4[-1]['t'], timezone.utc).date()}），"
              f"首根收盘 {first_close}；窗口起点 2026-08-09 时已收盘 4h 约 "
              f"{sum(1 for c in data4h[sym][1] if c <= int(datetime(2026, 8, 9, tzinfo=timezone.utc).timestamp()))} 根。")
    days_all_15 = set(R35.group_days(data15[SYMBOLS[0]][0], 96).keys())
    front_43 = {d for d in days_all_15 if d < SPLIT_R35.date()}
    back_57 = {d for d in days_all_15 if d >= SPLIT_R35.date()}
    print(f"窗口：全 100d（前 {len(front_43)} 天 2026-08-09~09-20 / "
          f"后 {len(back_57)} 天 2026-09-21~11-16）。")

    windows = [("100d", None), ("前43d", front_43), ("后57d", back_57)]
    atr15 = {s: R35.atr_wilder(data15[s][0]) for s in SYMBOLS}
    idx_of_t = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in SYMBOLS}

    # ---- 主臂信号：与 37 轮 §1 一字相同（去 Killzone → 夜禁过滤 → 15m ATR）----
    R15.in_killzone = lambda t: True
    main_sig_raw = {}
    for fam, label, builder in TEMPLATES:
        sig = {}
        for sym in SYMBOLS:
            bars1h, a1h = data1h[sym]
            sig[sym], _fun = builder(data15[sym][0], bars1h, a1h)
        main_sig_raw[fam] = sig
        print(f"[主臂信号 {fam}] 去 Killzone 后信号数：8 币合计 {sum(len(v) for v in sig.values())}")

    main_sig, night_blocked, warmup_blocked = {}, {}, {}
    for fam, label, builder in TEMPLATES:
        ms, nb, wb = {}, {}, {}
        for sym in SYMBOLS:
            ms[sym], nb[sym], wb[sym] = {}, 0, 0
            for et, s in main_sig_raw[fam][sym].items():
                if R35._entry_in_no_new_window(et):
                    nb[sym] += 1
                    continue
                gi = idx_of_t[sym][et]
                a15 = atr15[sym][gi - 1] if gi - 1 >= 0 else None
                if a15 is None:
                    wb[sym] += 1
                    continue
                ms[sym][et] = {"direction": s["direction"], "atr": a15,
                               "atr_basis": "15m", "tag": s.get("tag", "")}
        main_sig[fam] = ms
        night_blocked[fam] = nb
        warmup_blocked[fam] = wb
        print(f"[主臂信号 {fam}] 夜间禁单时段拦掉 {sum(nb.values())} 个信号；"
              f"ATR 未预热跳过 {sum(wb.values())} 个信号；"
              f"入场信号 {sum(len(v) for v in ms.values())} 个。")

    # ---- 4h 背景：逐信号查背景（只用决策时刻已收盘的 4h 根），信号层面过滤 ----
    # bg_info[(fam, sym, entry_t)] = (direction, mid, close, status)
    bg_info = {}
    bg_blocked, bg_undef = {}, {}
    filter_sig = {}
    for fam, label, builder in TEMPLATES:
        want = "BULL" if fam in ("A", "B") else "BEAR"
        fs, bb, bu = {}, {}, {}
        for sym in SYMBOLS:
            fs[sym], bb[sym], bu[sym] = {}, 0, 0
            bars4h, closes4h = data4h[sym]
            for et, s in main_sig[fam][sym].items():
                d, mid, c, st = bg_at(et, bars4h, closes4h)
                bg_info[(fam, sym, et)] = (d, mid, c, st)
                if st != "OK":
                    bu[sym] += 1
                    continue
                if d != want:
                    bb[sym] += 1
                    continue
                fs[sym][et] = dict(s)
        filter_sig[fam] = fs
        bg_blocked[fam] = bb
        bg_undef[fam] = bu
        print(f"[4h 背景过滤 {fam}] 要 {want}：背景不符拦掉 {sum(bb.values())} 个信号；"
              f"背景未定义跳过 {sum(bu.values())} 个信号；"
              f"剩余入场信号 {sum(len(v) for v in fs.values())} 个。")

    # ---- 模拟：对照臂（全量）+ 过滤臂 ----
    all_results, all_trades = [], []
    arm_trades = {}   # (arm, fam) -> trades

    def run_arm(arm, sig_by_fam):
        for fam, label, builder in TEMPLATES:
            fam_trades = []
            skip_tot = Counter()
            for sym in SYMBOLS:
                bars, funding = data15[sym]
                trades, curve, stats = R35.simulate_stream(
                    sym, bars, sig_by_fam[fam][sym], funding, MAX_PER_DAY,
                    f"R40-{arm}-{fam}")
                for t in trades:
                    d, mid, c, st = bg_info[(fam, sym, t["entry_t"])]
                    t["bg_4h"] = d if d else st
                    t["bg_mid"] = round(mid, 6) if mid is not None else None
                    t["bg_close"] = c
                fam_trades.extend(trades)
                skip_tot.update(stats)
            fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
            arm_trades[(arm, fam)] = fam_trades
            print(f"[{arm} {fam}] 全期 n={len(fam_trades)}；跳过信号：持仓中 {skip_tot['skip_open']} / "
                  f"满2笔 {skip_tot['skip_cap']} / 熔断 {skip_tot['skip_breaker']}")
            for sym in SYMBOLS:
                st = [t for t in fam_trades if t["symbol"] == sym]
                for wname, _ in windows:
                    wt = [t for t in st if wname == "100d" or split_of(t["entry_t"]) == wname]
                    wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                    eq = START_EQUITY
                    wcurve = [eq]
                    for t in wt_sorted:
                        eq += t["pnl"]
                        wcurve.append(eq)
                    res = R35.summarize(sym, wt_sorted, wcurve,
                                        f"R40-{arm}-{fam}", len(sig_by_fam[fam][sym]))
                    res["arm"] = arm
                    res["family"] = fam
                    res["template"] = fam
                    res["variant"] = f"R40-{arm}"
                    res["granularity"] = "15m"
                    res["atr_basis"] = "15m"
                    res["split"] = wname
                    res["days"] = 100 if wname == "100d" else (43 if wname == "前43d" else 57)
                    res["signals_total"] = len(sig_by_fam[fam][sym])
                    res["signals_blocked_night"] = night_blocked[fam][sym]
                    res["signals_blocked_warmup"] = warmup_blocked[fam][sym]
                    res["signals_blocked_bg"] = bg_blocked[fam][sym]
                    res["signals_blocked_bg_undef"] = bg_undef[fam][sym]
                    res["group"] = arm
                    all_results.append(res)
            for t in fam_trades:
                t2 = dict(t)
                t2["arm"] = arm
                t2["family"] = fam
                t2["template"] = fam
                t2["variant"] = f"R40-{arm}"
                t2["granularity"] = "15m"
                t2["atr_basis"] = "15m"
                t2["split"] = split_of(t["entry_t"])
                t2["entry_hour_utc"] = R35.entry_hour_utc(t["entry_t"])
                t2["session"] = session_of(t["entry_t"])
                t2["group"] = arm
                d, mid, c, st = bg_info[(fam, t["symbol"], t["entry_t"])]
                t2["bg_4h"] = d if d else st
                t2["bg_mid"] = round(mid, 6) if mid is not None else None
                t2["bg_close"] = c
                all_trades.append(t2)

    print("\n=== 对照臂：全量（= 37 轮 FULL，复现校验）===")
    run_arm("FULL", main_sig)
    # ---- 对照臂复现断言：笔数一字相同、净在 0.05 USDT 内；对不上就停 ----
    print("\n=== 对照臂复现核对（vs 37 轮报告 §2）===")
    for fam in ("A", "B", "C"):
        ftr = arm_trades[("FULL", fam)]
        net = sum(t["pnl"] for t in ftr)
        per_coin_pct = {sym: sum(t["pnl"] for t in ftr if t["symbol"] == sym) / START_EQUITY
                        for sym in SYMBOLS}
        coin_mean = sum(per_coin_pct.values()) / len(SYMBOLS)
        exp = FULL_EXPECTED[fam]
        ok_n = len(ftr) == exp["n"]
        ok_net = abs(net - exp["net"]) <= 0.05
        ok_pct = abs(coin_mean - exp["coin_mean_pct"]) <= 0.0005
        print(f"  [{fam}] n={len(ftr)}（预期 {exp['n']}）{'✓' if ok_n else '✗'}；"
              f"净 {net:+.2f}（预期 {exp['net']:+.2f}）{'✓' if ok_net else '✗'}；"
              f"币均 {coin_mean*100:+.2f}%（预期 {exp['coin_mean_pct']*100:+.2f}%）{'✓' if ok_pct else '✗'}")
        assert ok_n and ok_net and ok_pct, \
            f"对照臂复现失败：{fam} 与 37 轮 FULL 对不上，停止，不要继续！"
    print("对照臂复现通过：三模板笔数、净、币均与 37 轮 FULL 一致。")

    print("\n=== 过滤臂：4h 背景过滤 ===")
    run_arm("FILTER", filter_sig)

    # ---- 格子统计：3 模板 × 过滤臂，基准 = 同模板全量臂 ----
    print("\n=== 格子统计（每模板 × 过滤臂）===")
    cells = []
    for fam, label, builder in TEMPLATES:
        ftr = arm_trades[("FULL", fam)]
        bench = {"net": sum(t["pnl"] for t in ftr),
                 "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ftr),
                 "cost": sum(t["cost_usdt"] for t in ftr)}
        print(f"  [基准 FULL {fam}] n={len(ftr)} 毛利 {bench['gross']:+.2f} "
              f"成本 {bench['cost']:.2f} 净 {bench['net']:+.2f}")
        st = arm_trades[("FILTER", fam)]
        c = R37.cell_stats(fam, "FILTER", st, bench)
        cells.append(c)
        print(f"  [{fam} FILTER] n={c['n']}（前 {c['n_front']} / 后 {c['n_back']}）"
              f"币均 Taker 全 {c['coin_mean_pct_full']*100:+.2f}% / 前 {c['coin_mean_pct_front']*100:+.2f}% / "
              f"后 {c['coin_mean_pct_back']*100:+.2f}% | 每笔毛利 {c['gross_per_trade']} "
              f"（前 {c['gross_per_trade_front']} / 后 {c['gross_per_trade_back']}）"
              f"毛利/成本 {c['gross_cost_ratio']} | P(1x)={c['p_reach_1x']} "
              f"P(2x|1x)={c['p_reach_2x_given_1x']} | R1 Δ净 {c['r1_d_net']:+.0f} "
              f"Δ毛利 {c['r1_d_gross']:+.0f} 省成本 {c['r1_saved_cost']:+.0f} "
              f"占比 {c['r1_saved_share'] if c['r1_saved_share'] is not None else '—'} | "
              f"四项 {'✓ 全过' if c['pass_all'] else '✗ 不过'} "
              f"(i){'✓' if c['pass_c1_net_gt_2pct'] else '✗'} "
              f"(ii){'✓' if c['pass_c2_both_halves_pos'] else '✗'} "
              f"(iii){'✓' if c['pass_c3_gross_per_trade_gt_25'] else '✗'} "
              f"(iv){'✓' if c['pass_c4_r1_le_80pct'] else '✗'}")

    # ---- 诊断：出场原因、跨夜、激活、背景分布 ----
    print("\n=== 诊断 ===")
    for arm in ["FULL", "FILTER"]:
        for fam in ["A", "B", "C"]:
            at = arm_trades[(arm, fam)]
            rc = Counter(t["reason"] for t in at)
            ovn = [t for t in at
                   if datetime.fromtimestamp(t["exit_t"], timezone.utc).date()
                   > datetime.fromtimestamp(t["entry_t"], timezone.utc).date()]
            act = [t for t in at if t.get("trail_active")]
            if at:
                print(f"  [{arm} {fam}] 出场：{dict(sorted(rc.items()))}（共 {len(at)} 笔）；"
                      f"激活 {len(act)}/{len(at)}（{len(act)/len(at)*100:.1f}%）；"
                      f"跨夜 {len(ovn)} 笔净 {sum(t['pnl'] for t in ovn):+.0f}；"
                      f"资金费 {sum(t['funding_cost_usdt'] for t in at):+.2f}")
            else:
                print(f"  [{arm} {fam}] 0 笔")
    print("\n=== 诊断：全量臂执行笔的背景分布（过滤臂省掉了什么）===")
    for fam in ["A", "B", "C"]:
        at = arm_trades[("FULL", fam)]
        want = "BULL" if fam in ("A", "B") else "BEAR"
        with_bg = [t for t in at if t["bg_4h"] == want]
        against = [t for t in at if t["bg_4h"] not in (want, "WARMUP", "TIE")]
        undef = [t for t in at if t["bg_4h"] in ("WARMUP", "TIE")]
        if at:
            print(f"  [FULL {fam}] 顺背景 {len(with_bg)} 笔（毛利/笔 "
                  f"{sum(t['price_pnl'] - t['funding_cost_usdt'] for t in with_bg)/len(with_bg):+.2f}）；"
                  f"逆背景 {len(against)} 笔（毛利/笔 "
                  f"{sum(t['price_pnl'] - t['funding_cost_usdt'] for t in against)/len(against):+.2f}）；"
                  f"背景未定义 {len(undef)} 笔。")
        else:
            print(f"  [FULL {fam}] 0 笔")

    # ---- 首笔人工核对（过滤臂每模板首笔）----
    print("\n=== 首笔人工核对（过滤臂每模板首笔）===")
    for fam in ["A", "B", "C"]:
        at = sorted(arm_trades[("FILTER", fam)], key=lambda t: t["entry_t"])
        if not at:
            print(f"  [{fam}] 过滤臂 0 笔")
            continue
        t = at[0]
        print(f"  [{fam}] 首笔 {t['symbol']} {'做多' if t['direction'] == 1 else '做空'} "
              f"入场 {datetime.fromtimestamp(t['entry_t'], timezone.utc).isoformat()} "
              f"价 {t['entry']} ATR {t['atr']:.4g} 背景 {t['bg_4h']}（中位线 {t['bg_mid']}）出场 "
              f"{datetime.fromtimestamp(t['exit_t'], timezone.utc).isoformat()} 价 {t['exit']} "
              f"原因 {t['reason']} 净 {t['pnl']:+.2f}")

    # ---- 账目核对 ----
    print("\n=== 账目核对 ===")
    for arm in ["FULL", "FILTER"]:
        for fam in ["A", "B", "C"]:
            ts = arm_trades[(arm, fam)]
            cost = sum(t["cost_usdt"] for t in ts)
            gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ts)
            net = sum(t["pnl"] for t in ts)
            assert abs(cost - len(ts) * 25.0) < 0.01, f"账目不对：{arm} {fam} 成本 {cost} ≠ 笔数x25"
            assert abs(gross - cost - net) < 0.01, f"账目不对：{arm} {fam} 毛利-成本≠净"
            print(f"  [{arm} {fam}] 笔数 {len(ts)} x 25 = {len(ts)*25:.0f} = 成本合计 {cost:.2f} ✓；"
                  f"毛利 {gross:+.2f} − 成本 {cost:.2f} = 净 {net:+.2f} ✓")

    # ---- 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round40_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round40_cells.json"), "w") as f:
        json.dump(cells, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round40_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "template", "variant", "atr_basis", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "session", "group", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min", "peak", "trail_active",
                    "max_favour_usdt", "atr", "bg_4h", "bg_mid", "bg_close"])
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["family"], x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["template"], t["variant"], t.get("atr_basis", ""),
                        t["granularity"], t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"], t["session"], t["group"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"], t.get("peak"), t.get("trail_active"),
                        round(t.get("max_favour_usdt", 0.0), 2), t.get("atr"),
                        t.get("bg_4h", ""), t.get("bg_mid", ""), t.get("bg_close", "")])
    print(f"\n汇总已写入：data/gate_iter_round40_summary.json ({len(all_results)} 条)")
    print(f"格子已写入：data/gate_iter_round40_cells.json ({len(cells)} 个格子)")
    print(f"明细已写入：data/gate_iter_round40_trades.csv ({len(all_trades)} 笔)")

    print("\n=== 最终判定（4h 背景过滤，四项全过才算）===")
    n_pass = sum(1 for c in cells if c["pass_all"])
    for c in cells:
        print(f"  {c['family']}–FILTER：{'通过' if c['pass_all'] else '不通过'}"
              f"（币均 Taker {c['coin_mean_pct_full']*100:+.2f}%，"
              f"每笔毛利 {c['gross_per_trade']}，R1 省成本占比 "
              f"{c['r1_saved_share'] if c['r1_saved_share'] is not None else '—'}）")
    if n_pass == 0:
        print("  没有一个模板的过滤臂四项全过 → 4h 背景过滤证伪：不进判断层。")
    else:
        print(f"  {n_pass} 个模板的过滤臂四项全过 → 仍只是在一个新宇宙上的一次通过："
              "按 R2 不得换另一批新币重验同一发现，后续验证须在 2026-11-16 之后"
              "的实盘纸面数据上看（12 月 18 日月度复核时判）。")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
