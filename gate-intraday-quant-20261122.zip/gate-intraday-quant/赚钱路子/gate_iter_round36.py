#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十六轮：时段拆分测量轮（分系统 SUB-SMC，测量轮不是验证轮）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

预注册（跑前写死，不可改；来源：盈利策略迭代-分系统回测挖掘.md §2.1）：
  测什么：35 轮三模板（A 扫荡反转做多 / B FVG 回踩做多 / C 供给拒绝做空）
  的信号，按入场时段拆成三段（亚洲 00:00–08:00 UTC、欧洲 08:00–16:00 UTC、
  美盘 16:00–24:00 UTC）分别算净收益与毛利/成本。直接回答“哪个时段的
  SMC setup 值得判”。
  数据：与 35 轮同一批（8 币、103 天 15m 缓存 2026-08-06~11-16、1h 结构
  合成、资金费文件）；信号：复用 gate_iter_round35.py 的 builders 与
  simulate_stream，不改信号定义。
  唯一改动：入场时刻限制在指定时段内（其余时段的信号作废）。
  出场（跟踪止盈 2xATR 激活）、成本（Taker 0.075% + 真实成本模型口径与
  35 轮一致）、熔断、每天每币 2 笔上限、夜禁（UTC 17:00–23:00）全部与
  35 轮主臂相同，包括 16 根持满上限——为隔离时段效应，不与 v1.1 的
  “取消持满上限”混在一起。
  先跑复现臂复现 35 轮主臂数字（A -0.20% / B -1.31% / C -1.51%），
  对不上就停下来查，不要继续。
  报什么：每模板 × 每时段：笔数、全期 Taker 净（币均）、前/后半段 Taker
  净、每笔毛利、毛利/成本、P(到 1xATR)、P(到 2x|到 1x)、R1 三项分解
  （该时段 vs 全时段）。
  通过标准（四项全过才算，不放宽）：(i) 全期 1 倍 Taker 净 > +2%（币均），
  (ii) 前后两半都为正，(iii) 每笔毛利 > 25 USDT 且两半都 > 25，
  (iv) R1 省成本占比 ≤ 80%。
  证伪：9 个格子没有一个四项全过，则时段假设证伪，判断层不得给任何时段
  加偏好权重，三时段同等对待；美盘的“差”只作为“美盘不加分”的依据，
  不作为“美盘禁判”的依据。
  这轮的定位：测量轮，不是验证轮——同一批数据、同一批信号，只换一个
  切面，量出来的时段效应不能当作 edge。真正的验证在之后：若有格子通过，
  只在全新币种宇宙上检验一次（R2）或在 2026-11-16 之后的实盘纸面数据上看。
  测量轮通过 ≠ 可以上判断层。
  预期（跑前写死）：按挖掘报告 §1.2 的描述数字，最好的格子（A–欧洲）
  全期净只有 +270，离 +2% 差两个量级，预期是不通过；这轮的价值是给每时段
  判断层一个干净的时段数字（包括每天 2 笔上限与持仓中跳过的交互效应），
  不是找 edge。

注意：本轮是在信号层面做时段过滤后重新模拟（被过滤掉的信号不占每天
2 笔上限、不产生“持仓中跳过”），与挖掘报告 §1.2 对 35 轮逐笔 CSV 按
入场小时切的描述性数字不是同一口径——描述切面里的执行笔已被上限与
持仓跳过扭曲，本轮的数字才是干净的时段测量。

运行：python3 gate_iter_round36.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round36_summary.json
      + data/gate_iter_round36_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""

import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round15 as R15  # 三个 SMC 模板 builders（原样恢复）
import gate_iter_round35 as R35  # 复用 35 轮引擎：load / atr / simulate_stream / summarize

DATA_DIR = os.path.join(SCRIPT_DIR, "data")
SYMBOLS = R35.SYMBOLS
SPLIT_R35 = R35.SPLIT_R35
START_EQUITY = R35.START_EQUITY
NOTIONAL = R35.NOTIONAL
MAX_PER_DAY = R35.MAX_PER_DAY

SESSIONS = [
    ("ASIA", "亚洲 00:00–08:00 UTC", 0, 8),
    ("EURO", "欧洲 08:00–16:00 UTC", 8, 16),
    ("US", "美盘 16:00–24:00 UTC", 16, 24),
]
TEMPLATES = [("A", "R15-A 扫荡反转做多", R15.build_A),
             ("B", "R15-B FVG 回踩做多", R15.build_B),
             ("C", "R15-C 供给拒绝做空", R15.build_C)]


def session_of(entry_t):
    h = datetime.fromtimestamp(entry_t, timezone.utc).hour
    if 0 <= h < 8:
        return "ASIA"
    if 8 <= h < 16:
        return "EURO"
    return "US"


def fav_atr(t):
    """峰值有利浮动（ATR 倍数）。与 35 轮诊断同口径：
    max_favour_usdt / (10,000 x ATR / 入场价)。"""
    if not t.get("atr"):
        return 0.0
    return (t.get("max_favour_usdt", 0.0) / NOTIONAL) / (t["atr"] / t["entry"])


def split_of(et):
    return ("前46d" if datetime.fromtimestamp(et, timezone.utc).date()
            < SPLIT_R35.date() else "后57d")


def cell_stats(fam, session, trades, bench):
    """一个模板 x 时段格子的全部上报数字。bench = 同模板全时段复现臂的
    USDT 合计（净/毛利/成本），用于 R1 三项分解。"""
    n = len(trades)
    gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    cost = sum(t["cost_usdt"] for t in trades)
    net = sum(t["pnl"] for t in trades)
    # 币均 Taker 净 %：每币 (净/10万) 再平均（与 35 轮汇总同口径）
    per_coin_pct = {}
    for sym in SYMBOLS:
        st = [t for t in trades if t["symbol"] == sym]
        per_coin_pct[sym] = sum(t["pnl"] for t in st) / START_EQUITY
    coin_mean_pct = sum(per_coin_pct.values()) / len(SYMBOLS)
    # 半段
    half = {}
    for w in ("前46d", "后57d"):
        wt = [t for t in trades if split_of(t["entry_t"]) == w]
        wg = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in wt)
        wpc = {}
        for sym in SYMBOLS:
            st = [t for t in wt if t["symbol"] == sym]
            wpc[sym] = sum(t["pnl"] for t in st) / START_EQUITY
        half[w] = {
            "n": len(wt),
            "gross": wg,
            "gross_per_trade": (wg / len(wt)) if wt else None,
            "coin_mean_pct": sum(wpc.values()) / len(SYMBOLS),
            "net_usdt": sum(t["pnl"] for t in wt),
        }
    # 跟进概率
    n1 = sum(1 for t in trades if fav_atr(t) >= 1.0 - 1e-9)
    n2 = sum(1 for t in trades if fav_atr(t) >= 2.0 - 1e-9)
    p1 = (n1 / n) if n else None
    p2_given_1 = (n2 / n1) if n1 else None
    # R1 三项分解（该时段 vs 全时段，USDT 合计）
    d_net = net - bench["net"]
    d_gross = gross - bench["gross"]
    saved_cost = bench["cost"] - cost
    if abs(d_net - (d_gross + saved_cost)) > 0.01:
        raise AssertionError(f"R1 账目不对：{fam} {session} Δ净 {d_net} ≠ Δ毛利 {d_gross} + 省成本 {saved_cost}")
    saved_share = (saved_cost / d_net) if d_net > 0 else None
    # 四项标准
    c1 = coin_mean_pct > 0.02
    c2 = half["前46d"]["coin_mean_pct"] > 0 and half["后57d"]["coin_mean_pct"] > 0
    gpt = (gross / n) if n else None
    c3 = (gpt is not None and gpt > 25
          and half["前46d"]["gross_per_trade"] is not None and half["前46d"]["gross_per_trade"] > 25
          and half["后57d"]["gross_per_trade"] is not None and half["后57d"]["gross_per_trade"] > 25)
    c4 = (d_net > 0 and saved_share is not None and saved_share <= 0.80)
    return {
        "family": fam, "session": session, "n": n,
        "gross_usdt": round(gross, 2), "cost_usdt": round(cost, 2),
        "net_usdt": round(net, 2),
        "gross_per_trade": round(gpt, 2) if gpt is not None else None,
        "gross_cost_ratio": round(gross / cost, 4) if cost else None,
        "coin_mean_pct_full": round(coin_mean_pct, 4),
        "coin_mean_pct_front": round(half["前46d"]["coin_mean_pct"], 4),
        "coin_mean_pct_back": round(half["后57d"]["coin_mean_pct"], 4),
        "gross_per_trade_front": (round(half["前46d"]["gross_per_trade"], 2)
                                  if half["前46d"]["gross_per_trade"] is not None else None),
        "gross_per_trade_back": (round(half["后57d"]["gross_per_trade"], 2)
                                 if half["后57d"]["gross_per_trade"] is not None else None),
        "n_front": half["前46d"]["n"], "n_back": half["后57d"]["n"],
        "p_reach_1x": round(p1, 4) if p1 is not None else None,
        "p_reach_2x_given_1x": round(p2_given_1, 4) if p2_given_1 is not None else None,
        "n_reach_1x": n1, "n_reach_2x": n2,
        "r1_d_net": round(d_net, 2), "r1_d_gross": round(d_gross, 2),
        "r1_saved_cost": round(saved_cost, 2),
        "r1_saved_share": round(saved_share, 4) if saved_share is not None else None,
        "pass_c1_net_gt_2pct": c1, "pass_c2_both_halves_pos": c2,
        "pass_c3_gross_per_trade_gt_25": c3, "pass_c4_r1_le_80pct": c4,
        "pass_all": bool(c1 and c2 and c3 and c4),
    }


def main():
    print("盈利策略迭代 · 第三十六轮：时段拆分测量轮（测量轮，不是验证轮）")
    print("35 轮三模板信号 × 亚洲/欧洲/美盘三时段，信号层面过滤后重新模拟。")
    print("通过标准（四项全过才算）：(i) 全期币均 Taker 净 > +2%，(ii) 前后两半都为正，"
          "(iii) 每笔毛利 > 25 USDT 且两半都 > 25，(iv) R1 省成本占比 ≤ 80%。")

    # ---- 数据校验（与 35 轮同口径）----
    data15 = {}
    for sym in SYMBOLS:
        bars = R35.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R35.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R35.group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    data1h = R15.build_1h_combined()
    days_all_15 = set(R35.group_days(data15["BTC_USDT"][0], 96).keys())
    front_46 = {d for d in days_all_15 if d < SPLIT_R35.date()}
    back_57 = {d for d in days_all_15 if d >= SPLIT_R35.date()}
    print(f"窗口：全 103d（前 {len(front_46)} 天 2026-08-06~09-20 / "
          f"后 {len(back_57)} 天 2026-09-21~11-16）。")

    windows = [("103d", None), ("前46d", front_46), ("后57d", back_57)]
    atr15 = {s: R35.atr_wilder(data15[s][0]) for s in SYMBOLS}
    idx_of_t = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in SYMBOLS}

    # ---- 主臂信号：与 35 轮 §5 一字相同（去 Killzone → 夜禁过滤 → 15m ATR）----
    R15.in_killzone = lambda t: True
    main_sig_raw = {}
    for fam, label, builder in TEMPLATES:
        sig = {}
        for sym in SYMBOLS:
            bars1h, a1h = data1h[sym]
            sig[sym], _fun = builder(data15[sym][0], bars1h, a1h)
        main_sig_raw[fam] = sig
        print(f"[主臂信号 {fam}] 去 Killzone 后信号数：8 币合计 {sum(len(v) for v in sig.values())}")

    first_checks = [
        ("A", "SOL_USDT", datetime(2026, 8, 6, 14, 45, tzinfo=timezone.utc), 73.48, 1),
        ("B", "ETH_USDT", datetime(2026, 8, 6, 8, 30, tzinfo=timezone.utc), 1912.78, 1),
        ("C", "XRP_USDT", datetime(2026, 8, 6, 9, 15, tzinfo=timezone.utc), 1.0488, -1),
    ]
    for fam, sym, dt, exp_price, exp_dir in first_checks:
        et = int(dt.timestamp())
        assert et in main_sig_raw[fam][sym], f"主臂信号缺失首信号：{fam} {sym} {dt}"
        assert main_sig_raw[fam][sym][et]["direction"] == exp_dir, f"首信号方向不对：{fam} {sym}"
        assert not R35._entry_in_no_new_window(et), f"首信号不应被禁单时段拦掉：{fam} {sym}"
    print("[首信号核对 ✓] 三条首信号在主臂信号里，且均不在禁单时段。")

    main_sig, night_blocked = {}, {}
    for fam, label, builder in TEMPLATES:
        ms, nb = {}, {}
        for sym in SYMBOLS:
            ms[sym], nb[sym] = {}, 0
            for et, s in main_sig_raw[fam][sym].items():
                if R35._entry_in_no_new_window(et):
                    nb[sym] += 1
                    continue
                gi = idx_of_t[sym][et]
                a15 = atr15[sym][gi - 1] if gi - 1 >= 0 else None
                assert a15 is not None, f"15m ATR 缺失：{fam} {sym} {et}"
                ms[sym][et] = {"direction": s["direction"], "atr": a15,
                               "atr_basis": "15m", "tag": s.get("tag", "")}
        main_sig[fam] = ms
        night_blocked[fam] = nb
        print(f"[主臂信号 {fam}] 夜间禁单时段拦掉 {sum(nb.values())} 个信号；"
              f"入场信号 {sum(len(v) for v in ms.values())} 个。")

    # ---- 时段信号：唯一改动——入场时刻限制在指定时段内 ----
    sess_sig = {}
    for fam, label, builder in TEMPLATES:
        sess_sig[fam] = {}
        for sname, sdesc, h0, h1 in SESSIONS:
            ss = {}
            for sym in SYMBOLS:
                ss[sym] = {et: s for et, s in main_sig[fam][sym].items()
                           if h0 <= datetime.fromtimestamp(et, timezone.utc).hour < h1}
            sess_sig[fam][sname] = ss
            print(f"[时段信号 {fam} {sname}] 入场信号 {sum(len(v) for v in ss.values())} 个"
                  f"（占全时段 {sum(len(v) for v in main_sig[fam].values())} 个的 "
                  f"{sum(len(v) for v in ss.values()) / sum(len(v) for v in main_sig[fam].values()) * 100:.1f}%）")

    # ---- 模拟：复现臂（全时段）+ 三时段臂 ----
    all_results, all_trades = [], []
    arm_trades = {}   # (arm, fam) -> trades

    def run_arm(arm, sig_by_fam):
        for fam, label, builder in TEMPLATES:
            fam_trades = []
            skip_tot = Counter()
            for sym in SYMBOLS:
                bars, funding = data15[sym]
                trades, curve, stats = R35.simulate_stream(
                    sym, bars, sig_by_fam[fam][sym], funding, MAX_PER_DAY,
                    f"R36-{arm}-{fam}")
                fam_trades.extend(trades)
                skip_tot.update(stats)
            fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
            arm_trades[(arm, fam)] = fam_trades
            print(f"[{arm} {fam}] 全期 n={len(fam_trades)}；跳过信号：持仓中 {skip_tot['skip_open']} / "
                  f"满2笔 {skip_tot['skip_cap']} / 熔断 {skip_tot['skip_breaker']}")
            for sym in SYMBOLS:
                st = [t for t in fam_trades if t["symbol"] == sym]
                for wname, _ in windows:
                    wt = [t for t in st if wname == "103d" or split_of(t["entry_t"]) == wname]
                    wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                    eq = START_EQUITY
                    wcurve = [eq]
                    for t in wt_sorted:
                        eq += t["pnl"]
                        wcurve.append(eq)
                    res = R35.summarize(sym, wt_sorted, wcurve,
                                        f"R36-{arm}-{fam}", len(sig_by_fam[fam][sym]))
                    res["arm"] = arm
                    res["family"] = fam
                    res["template"] = fam
                    res["variant"] = f"R36-{arm}"
                    res["granularity"] = "15m"
                    res["atr_basis"] = "15m"
                    res["split"] = wname
                    res["days"] = 103 if wname == "103d" else (46 if wname == "前46d" else 57)
                    res["signals_total"] = len(sig_by_fam[fam][sym])
                    res["signals_blocked_night"] = night_blocked[fam][sym]
                    res["session"] = arm
                    all_results.append(res)
            for t in fam_trades:
                t2 = dict(t)
                t2["arm"] = arm
                t2["family"] = fam
                t2["template"] = fam
                t2["variant"] = f"R36-{arm}"
                t2["granularity"] = "15m"
                t2["atr_basis"] = "15m"
                t2["split"] = split_of(t["entry_t"])
                t2["entry_hour_utc"] = R35.entry_hour_utc(t["entry_t"])
                t2["session"] = session_of(t["entry_t"])
                all_trades.append(t2)

    print("\n=== 复现臂：全时段（= 35 轮主臂）===")
    run_arm("FULL", main_sig)
    print("\n=== 时段臂 ===")
    for sname, sdesc, h0, h1 in SESSIONS:
        print(f"--- {sdesc} ---")
        run_arm(sname, {fam: sess_sig[fam][sname] for fam, _, _ in TEMPLATES})

    # ---- 复现校验：与 35 轮 summary.json 的 MAIN 103d 行逐币逐项相等 ----
    print("\n=== 复现校验：复现臂 vs 35 轮主臂（summary.json MAIN 103d 行）===")
    r35 = json.load(open(os.path.join(DATA_DIR, "gate_iter_round35_summary.json")))
    r35_main = {(r["family"], r["symbol"]): r for r in r35
                if r["arm"] == "MAIN" and r["split"] == "103d"}
    published = {"A": (-0.0020, 176), "B": (-0.0131, 404), "C": (-0.0151, 553)}
    ok = True
    for fam, (pub_pct, pub_n) in published.items():
        rs = [r for r in all_results if r["arm"] == "FULL" and r["family"] == fam and r["split"] == "103d"]
        avg_pct = sum(r["taker_net_pct"] for r in rs) / len(rs)
        tot_n = sum(r["trades"] for r in rs)
        match_pub = abs(avg_pct - pub_pct) < 0.0001 and tot_n == pub_n
        per_coin_ok = all(
            [r for r in rs if r["symbol"] == sym][0]["taker_net_pct"]
            == r35_main[(fam, sym)]["taker_net_pct"]
            and [r for r in rs if r["symbol"] == sym][0]["trades"]
            == r35_main[(fam, sym)]["trades"]
            for sym in SYMBOLS)
        print(f"  [{fam}] 复现臂全期币均 Taker {avg_pct*100:+.2f}%（35 轮公布 {pub_pct*100:+.2f}%）"
              f"笔数 {tot_n}（公布 {pub_n}）→ {'✓ 一致' if match_pub else '✗ 不一致'}；"
              f"逐币与 round35 summary.json MAIN 103d 行逐项相等：{'✓' if per_coin_ok else '✗'}")
        ok = ok and match_pub and per_coin_ok
    assert ok, "复现校验失败：复现臂与 35 轮主臂数字不一致，停止出报告！"
    print("  复现校验通过：信号与引擎与 35 轮主臂一字相同，可以继续。")

    # ---- 格子统计：9 个模板 x 时段格子 ----
    print("\n=== 格子统计（每模板 × 每时段）===")
    cells = []
    for fam, label, builder in TEMPLATES:
        ftr = arm_trades[("FULL", fam)]
        bench = {"net": sum(t["pnl"] for t in ftr),
                 "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ftr),
                 "cost": sum(t["cost_usdt"] for t in ftr)}
        print(f"  [基准 FULL {fam}] n={len(ftr)} 毛利 {bench['gross']:+.2f} "
              f"成本 {bench['cost']:.2f} 净 {bench['net']:+.2f}")
        for sname, sdesc, h0, h1 in SESSIONS:
            st = arm_trades[(sname, fam)]
            c = cell_stats(fam, sname, st, bench)
            cells.append(c)
            print(f"  [{fam} {sname}] n={c['n']}（前 {c['n_front']} / 后 {c['n_back']}）"
                  f"币均 Taker 全 {c['coin_mean_pct_full']*100:+.2f}% / 前 {c['coin_mean_pct_front']*100:+.2f}% / "
                  f"后 {c['coin_mean_pct_back']*100:+.2f}% | 每笔毛利 {c['gross_per_trade']} "
                  f"（前 {c['gross_per_trade_front']} / 后 {c['gross_per_trade_back']}）"
                  f"毛利/成本 {c['gross_cost_ratio']} | P(1x)={c['p_reach_1x']} "
                  f"P(2x|1x)={c['p_reach_2x_given_1x']} | R1 Δ净 {c['r1_d_net']:+.0f} "
                  f"Δ毛利 {c['r1_d_gross']:+.0f} 省成本 {c['r1_saved_cost']:+.0f} "
                  f"占比 {c['r1_saved_share'] if c['r1_saved_share'] is not None else '—'} | "
                  f"四项 {'✓ 全过' if c['pass_all'] else '✗ 不过'} "
                  f"(i){'✓' if c['pass_c1_net_gt_2pct'] else '✗'} "
                  f"(ii){'✓' if c['pass_c2_both_halves_pos'] else '✗'} "
                  f"(iii){'✓' if c['pass_c3_gross_per_trade_gt_25'] else '✗'} "
                  f"(iv){'✓' if c['pass_c4_r1_le_80pct'] else '✗'}")

    # ---- 诊断：出场原因、跨夜、激活 ----
    print("\n=== 诊断 ===")
    for arm in ["FULL", "ASIA", "EURO", "US"]:
        for fam in ["A", "B", "C"]:
            at = arm_trades[(arm, fam)]
            rc = Counter(t["reason"] for t in at)
            ovn = [t for t in at
                   if datetime.fromtimestamp(t["exit_t"], timezone.utc).date()
                   > datetime.fromtimestamp(t["entry_t"], timezone.utc).date()]
            act = [t for t in at if t.get("trail_active")]
            if at:
                print(f"  [{arm} {fam}] 出场：{dict(sorted(rc.items()))}（共 {len(at)} 笔）；"
                      f"激活 {len(act)}/{len(at)}（{len(act)/len(at)*100:.1f}%）；"
                      f"跨夜 {len(ovn)} 笔净 {sum(t['pnl'] for t in ovn):+.0f}；"
                      f"资金费 {sum(t['funding_cost_usdt'] for t in at):+.2f}")
            else:
                print(f"  [{arm} {fam}] 0 笔")

    # ---- 账目核对 ----
    print("\n=== 账目核对 ===")
    for arm in ["FULL", "ASIA", "EURO", "US"]:
        for fam in ["A", "B", "C"]:
            ts = arm_trades[(arm, fam)]
            cost = sum(t["cost_usdt"] for t in ts)
            gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ts)
            net = sum(t["pnl"] for t in ts)
            assert abs(cost - len(ts) * 25.0) < 0.01, f"账目不对：{arm} {fam} 成本 {cost} ≠ 笔数x25"
            assert abs(gross - cost - net) < 0.01, f"账目不对：{arm} {fam} 毛利-成本≠净"
            print(f"  [{arm} {fam}] 笔数 {len(ts)} x 25 = {len(ts)*25:.0f} = 成本合计 {cost:.2f} ✓；"
                  f"毛利 {gross:+.2f} − 成本 {cost:.2f} = 净 {net:+.2f} ✓")

    # ---- 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round36_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round36_cells.json"), "w") as f:
        json.dump(cells, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round36_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "template", "variant", "atr_basis", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "session", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min", "peak", "trail_active",
                    "max_favour_usdt", "atr"])
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["family"], x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["template"], t["variant"], t.get("atr_basis", ""),
                        t["granularity"], t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"], t["session"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"], t.get("peak"), t.get("trail_active"),
                        round(t.get("max_favour_usdt", 0.0), 2), t.get("atr")])
    print(f"\n汇总已写入：data/gate_iter_round36_summary.json ({len(all_results)} 条)")
    print(f"格子已写入：data/gate_iter_round36_cells.json ({len(cells)} 个格子)")
    print(f"明细已写入：data/gate_iter_round36_trades.csv ({len(all_trades)} 笔)")

    print("\n=== 最终判定（时段拆分测量轮，四项全过才算）===")
    n_pass = sum(1 for c in cells if c["pass_all"])
    for c in cells:
        print(f"  {c['family']}–{c['session']}：{'通过' if c['pass_all'] else '不通过'}"
              f"（币均 Taker {c['coin_mean_pct_full']*100:+.2f}%，"
              f"每笔毛利 {c['gross_per_trade']}，R1 省成本占比 "
              f"{c['r1_saved_share'] if c['r1_saved_share'] is not None else '—'}）")
    if n_pass == 0:
        print("  9 个格子没有一个四项全过 → 时段假设证伪：判断层不得给任何时段加偏好权重，"
              "三时段同等对待；美盘的“差”只作为“美盘不加分”的依据，不作为“美盘禁判”的依据。")
    else:
        print(f"  {n_pass} 个格子四项全过 → 测量轮通过 ≠ 可以上判断层：须按 R2 在全新币种宇宙上"
              "检验一次，或在 2026-11-16 之后的实盘纸面数据上看。")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
