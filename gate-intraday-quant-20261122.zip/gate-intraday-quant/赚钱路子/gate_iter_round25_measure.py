#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第二十五轮 · 第一步：OKX 数据拉取 + 领先性测量（先做再决定第二步写法）
======================================================================
只拉公开行情，不下单、不碰真钱。

实测发现（写死进脚本，不许事后改口径）：
  - OKX 公开 candles 接口（未认证）每种 bar 最多只返回最近 1440 根：
      1m  -> 2026-11-16 17:48 ~ 2026-11-17 17:47 UTC（约 24h，不是任务假设的 7 天/10000 根）
      15m -> 2026-11-02 18:00 ~ 2026-11-17 17:45 UTC（15 天）
      1H  -> 2026-09-18 18:00 ~ 2026-11-17 17:00 UTC（60 天）
    bar 参数小时用大写 1H（bar=1h 会报 51000 Parameter bar error）。
    before 参数实测无效（仍返回最新），after 分页到 1440 根后返回空。
  - Binance 在本环境返回受限（Service unavailable from a restricted
    location），不做替换——OKX 可达，用 OKX 原数。
  - Gate 1m：limit 与 from/to 不能同传；只用 from/to 可一次取 1441 根。

测量（定义跑前写死）：
  M1 1m 互相关：OKX BTC 与 Gate BTC 的 1m 对数收益，在滞后 L=-5..+5 分钟
     上 corr(r_okx[t], r_gate[t+L])。L>0 的峰值 = OKX 领先 L 分钟。
  M2 15m 互相关：同法，滞后 -4..+4 根（±60 分钟），窗口 15 天。
  M3 1H 互相关：同法，滞后 -2..+2 根（±2 小时），窗口 60 天。
  M4 OKX BTC 5m 涨幅（1m 聚合）与 Gate 各山寨随后 15m / 1h 涨幅的相关性
     （24h 窗口，Gate 15m 缓存）；对照：同一窗口 Gate BTC 5m 涨幅的同法相关。
  M5 OKX BTC 2h 涨幅与 Gate 各山寨随后 1h 涨幅的相关性（60 天 1H 窗口，
     即 F1 信号的实际视野）；对照：Gate BTC 2h 涨幅同法。

输出：data/okx_btc_1m.json / okx_btc_15m.json / okx_btc_1h.json（原始行）
      data/gate_btc_1m_24h.json（与 OKX 1m 窗口同步的 Gate 1m）
      data/gate_iter_round25_measure.json（测量结果）
"""
import csv
import json
import math
import os
import time
import urllib.request
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
UA = {"User-Agent": "Mozilla/5.0"}


def okx_fetch(bar, want=1440):
    """分页拉 OKX candles（after 往旧翻），返回按时间升序的原始行列表。"""
    rows, after = [], None
    while len(rows) < want:
        url = ("https://www.okx.com/api/v5/market/candles?instId=BTC-USDT-SWAP"
               f"&bar={bar}&limit=300")
        if after:
            url += f"&after={after}"
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=20) as r:
            payload = json.load(r)
        data = payload.get("data", [])
        if not data:
            break
        rows.extend(data)
        after = int(data[-1][0]) - 1
        time.sleep(0.2)
    rows.sort(key=lambda x: int(x[0]))
    # 去重（分页边界可能重叠）
    seen, out = set(), []
    for row in rows:
        if row[0] not in seen:
            seen.add(row[0])
            out.append(row)
    return out


def gate_fetch_1m(t_from, t_to):
    url = ("https://api.gateio.ws/api/v4/futures/usdt/candlesticks"
           f"?contract=BTC_USDT&interval=1m&from={t_from}&to={t_to}")
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)


def load_gate_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def log_returns(closes):
    return [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes))]


def xcorr(x, y, lags):
    """corr(x[t], y[t+L])，x/y 为同一时间轴上的对数收益序列（已对齐）。"""
    n = len(x)
    assert len(y) == n
    out = {}
    for L in lags:
        if L >= 0:
            xs, ys = x[:n - L] if L else x, y[L:]
        else:
            xs, ys = x[-L:], y[:n + L]
        m = len(xs)
        if m < 30:
            out[L] = None
            continue
        mx = sum(xs) / m
        my = sum(ys) / m
        cov = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
        vx = sum((a - mx) ** 2 for a in xs)
        vy = sum((b - my) ** 2 for b in ys)
        out[L] = round(cov / math.sqrt(vx * vy), 4) if vx > 0 and vy > 0 else None
    return out


def pearson(xs, ys):
    m = len(xs)
    if m < 5:
        return None, m
    mx = sum(xs) / m
    my = sum(ys) / m
    cov = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    vx = sum((a - mx) ** 2 for a in xs)
    vy = sum((b - my) ** 2 for b in ys)
    if vx == 0 or vy == 0:
        return None, m
    return round(cov / math.sqrt(vx * vy), 4), m


def main():
    print("第二十五轮第一步：拉 OKX 数据 + 领先性测量")
    # ---------- 拉数 ----------
    okx_1m = okx_fetch("1m")
    okx_15m = okx_fetch("15m")
    okx_1h = okx_fetch("1H")
    for name, rows in (("okx_btc_1m", okx_1m), ("okx_btc_15m", okx_15m),
                       ("okx_btc_1h", okx_1h)):
        with open(os.path.join(DATA_DIR, f"{name}.json"), "w") as f:
            json.dump(rows, f)
        print(f"  {name}: {len(rows)} 根 "
              f"{datetime.fromtimestamp(int(rows[0][0]) / 1000, timezone.utc)} ~ "
              f"{datetime.fromtimestamp(int(rows[-1][0]) / 1000, timezone.utc)}")

    t0 = int(okx_1m[0][0]) // 1000
    t1 = int(okx_1m[-1][0]) // 1000 + 60
    gate_1m = gate_fetch_1m(t0 - 60, t1)
    gate_1m = sorted(gate_1m, key=lambda b: int(b["t"]))
    with open(os.path.join(DATA_DIR, "gate_btc_1m_24h.json"), "w") as f:
        json.dump(gate_1m, f)
    print(f"  gate_btc_1m_24h: {len(gate_1m)} 根 "
          f"{datetime.fromtimestamp(int(gate_1m[0]['t']), timezone.utc)} ~ "
          f"{datetime.fromtimestamp(int(gate_1m[-1]['t']), timezone.utc)}")

    # ---------- M1：1m 互相关 ----------
    okx_c = {int(r[0]) // 1000: float(r[4]) for r in okx_1m}
    gate_c = {int(b["t"]): float(b["c"]) for b in gate_1m}
    common = sorted(set(okx_c) & set(gate_c))
    print(f"  M1 对齐 1m 根数：{len(common)}（OKX {len(okx_c)} / Gate {len(gate_c)}）")
    oc = [okx_c[t] for t in common]
    gc = [gate_c[t] for t in common]
    m1 = xcorr(log_returns(oc), log_returns(gc), range(-5, 6))
    print("  M1 1m 互相关 corr(r_okx[t], r_gate[t+L]):", m1)

    # ---------- M2：15m 互相关 ----------
    gate15 = load_gate_bars(os.path.join(DATA_DIR, "gate_15m_103d_BTC_USDT.csv"))
    okx15_c = {int(r[0]) // 1000: float(r[4]) for r in okx_15m}
    gate15_c = {b["t"]: b["c"] for b in gate15}
    common15 = sorted(set(okx15_c) & set(gate15_c))
    oc15 = [okx15_c[t] for t in common15]
    gc15 = [gate15_c[t] for t in common15]
    m2 = xcorr(log_returns(oc15), log_returns(gc15), range(-4, 5))
    print(f"  M2 对齐 15m 根数：{len(common15)}，互相关：", m2)

    # ---------- M3：1H 互相关 ----------
    gate1h = load_gate_bars(os.path.join(DATA_DIR, "gate_1h_365d_BTC_USDT.csv"))
    okx1h_c = {int(r[0]) // 1000: float(r[4]) for r in okx_1h}
    gate1h_c = {b["t"]: b["c"] for b in gate1h}
    common1h = sorted(set(okx1h_c) & set(gate1h_c))
    oc1h = [okx1h_c[t] for t in common1h]
    gc1h = [gate1h_c[t] for t in common1h]
    m3 = xcorr(log_returns(oc1h), log_returns(gc1h), range(-2, 3))
    print(f"  M3 对齐 1h 根数：{len(common1h)}，互相关：", m3)

    # ---------- M4：OKX BTC 5m 涨幅 -> Gate 山寨随后 15m/1h 涨幅 ----------
    alts = ["ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]
    gate15_all = {}
    for sym in alts:
        bars = load_gate_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}_USDT.csv"))
        gate15_all[sym] = {b["t"]: b["c"] for b in bars}
    gate15_btc = gate15_c
    # 5m 收益：用 OKX 1m 收盘，每 5 根一格，格点对齐到 :00/:05/:10...
    okx5, gate5 = {}, {}
    ts_sorted = sorted(okx_c)
    for t in ts_sorted:
        if (t // 60) % 5 == 0:
            okx5[t] = okx_c[t]
            if t in gate_c:
                gate5[t] = gate_c[t]
    t5 = sorted(set(okx5) & set(gate5))
    m4, m4_ctrl = {}, {}
    for sym in alts:
        ac = gate15_all[sym]
        xs_okx, ys15, ys1h, xs_gate = [], [], [], []
        for i in range(1, len(t5)):
            t_prev, t_now = t5[i - 1], t5[i]
            if t_now - t_prev != 300:
                continue
            if t_now not in ac or t_now + 900 not in ac or t_now + 3600 not in ac:
                continue
            r_okx = math.log(okx5[t_now] / okx5[t_prev])
            r_gate = math.log(gate5[t_now] / gate5[t_prev])
            f15 = math.log(ac[t_now + 900] / ac[t_now])
            f1h = math.log(ac[t_now + 3600] / ac[t_now])
            xs_okx.append(r_okx)
            xs_gate.append(r_gate)
            ys15.append(f15)
            ys1h.append(f1h)
        c15, n = pearson(xs_okx, ys15)
        c1h, _ = pearson(xs_okx, ys1h)
        cc15, _ = pearson(xs_gate, ys15)
        cc1h, _ = pearson(xs_gate, ys1h)
        m4[sym] = {"n": n, "okx5m_vs_alt_next15m": c15, "okx5m_vs_alt_next1h": c1h}
        m4_ctrl[sym] = {"n": n, "gate5m_vs_alt_next15m": cc15, "gate5m_vs_alt_next1h": cc1h}
    print("  M4 OKX 5m -> 山寨随后：", json.dumps(m4, ensure_ascii=False))
    print("  M4 对照 Gate 5m -> 山寨随后：", json.dumps(m4_ctrl, ensure_ascii=False))

    # ---------- M5：BTC 2h 涨幅 -> 山寨随后 1h 涨幅（60 天 1H 窗口） ----------
    gate1h_all = {}
    for sym in alts:
        bars = load_gate_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}_USDT.csv"))
        gate1h_all[sym] = {b["t"]: b["c"] for b in bars}
    m5, m5_ctrl = {}, {}
    for sym in alts:
        ac = gate1h_all[sym]
        xs_okx, xs_gate, ys = [], [], []
        for i in range(2, len(common1h)):
            t = common1h[i]
            t2 = common1h[i - 2]
            if t - t2 != 7200 or t + 3600 not in ac:
                continue
            xs_okx.append(math.log(oc1h[i] / oc1h[i - 2]))
            xs_gate.append(math.log(gc1h[i] / gc1h[i - 2]))
            ys.append(math.log(ac[t + 3600] / ac[t]))
        c_okx, n = pearson(xs_okx, ys)
        c_gate, _ = pearson(xs_gate, ys)
        m5[sym] = {"n": n, "okx2h_vs_alt_next1h": c_okx}
        m5_ctrl[sym] = {"n": n, "gate2h_vs_alt_next1h": c_gate}
    print("  M5 OKX 2h -> 山寨随后 1h：", json.dumps(m5, ensure_ascii=False))
    print("  M5 对照 Gate 2h -> 山寨随后 1h：", json.dumps(m5_ctrl, ensure_ascii=False))

    result = {
        "fetched_at_utc": datetime.now(timezone.utc).isoformat(),
        "okx_windows": {
            "1m": {"n": len(okx_1m), "first": okx_1m[0][0], "last": okx_1m[-1][0]},
            "15m": {"n": len(okx_15m), "first": okx_15m[0][0], "last": okx_15m[-1][0]},
            "1H": {"n": len(okx_1h), "first": okx_1h[0][0], "last": okx_1h[-1][0]},
        },
        "okx_cap_note": "OKX public candles returns at most the most recent 1440 rows per bar (unauthenticated); before param ineffective; bar=1h invalid, use 1H.",
        "binance_note": "Binance returned restricted-location in this environment; not used as substitute because OKX was reachable.",
        "gate_1m_window": {"n": len(gate_1m), "first": gate_1m[0]["t"], "last": gate_1m[-1]["t"]},
        "M1_1m_xcorr_lag_-5_to_5": {str(k): v for k, v in m1.items()},
        "M1_n": len(common) - 1,
        "M2_15m_xcorr_lag_-4_to_4": {str(k): v for k, v in m2.items()},
        "M2_n": len(common15) - 1,
        "M3_1h_xcorr_lag_-2_to_2": {str(k): v for k, v in m3.items()},
        "M3_n": len(common1h) - 1,
        "M4_okx5m_vs_alt_next": m4,
        "M4_ctrl_gate5m_vs_alt_next": m4_ctrl,
        "M5_okx2h_vs_alt_next1h": m5,
        "M5_ctrl_gate2h_vs_alt_next1h": m5_ctrl,
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round25_measure.json"), "w") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print("测量已写入：data/gate_iter_round25_measure.json")


if __name__ == "__main__":
    main()
