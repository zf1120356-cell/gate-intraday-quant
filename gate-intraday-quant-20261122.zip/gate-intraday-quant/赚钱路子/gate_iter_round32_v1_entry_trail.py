#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十二轮：主系统模板改跟踪止盈，盈利会不会扩大？
=================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（用户提问）：“如果主系统改跟踪止赢，你算下盈利会不会扩大？”
主系统 = 第十五轮的三个计划模板（A 扫荡反转做多 / B FVG 回踩做多 /
C 供给拒绝做空），第十五轮固定止盈 2xATR 的结果是 A -0.27%、
B -0.61%、C -0.55%（103 天 15m，pooled t 全部显著为负）。
本轮只改出场一处，其余全部不变，看跟踪止盈能不能把盈利扩大。

锁定的规则（跑前定死，单组参数）：
  信号、确认、Killzone、入场、每天每币上限、熔断、成本口径：
    与第十五轮一字不差。信号直接复用 gate_iter_round15.py 的
    build_A / build_B / build_C（同一批 15m 103 天数据、同一批
    1h 合成结构），不重写、不调参。信号数必须与第十五轮完全一致
    （A 60 / B 301 / C 401），否则停。
  只改出场（唯一改动）：
    删掉固定止盈 2xATR，改成跟踪止损：
      - 入场后初始止损 = 入场价 ∓ 1xATR（与原来止损同口径，ATR 定义
        不变：入场根之前最后一个已收盘 1h 根的 Wilder ATR14）。
      - 跟踪止损只往有利方向移动，距离恒为 1xATR。
        做多：跟踪止损 = 入场以来最高价 − 1xATR；
        做空：跟踪止损 = 入场以来最低价 + 1xATR。
      - 价格碰到跟踪止损即平仓；同根先判止损（没有固定止盈可冲突，
        止损优先于一切）；跟踪止损出场按市价单计成本，与止损出场
        同口径（Taker 主口径固定 0.25% 双边；Maker 口径里跟踪止损
        出场按 taker 费率，不按限价止盈计——maker_cost 按 reason
        判定，trail_stop 不是 take_profit，自动走 taker 出口）。
    实现细节（跑前写死）：
      - 跟踪极值从入场价起算，入场当根的高低不计入极值（与引擎
        “入场根不判出场”的口径一致）；从下一根起，每根先判止损
        （用上一根收盘后更新的跟踪止损），再用该根最高/最低更新
        极值与跟踪止损。同一根内先跌破旧跟踪止损再创新高，仍按
        止损出场，不救。
      - 出场原因分四档：stop_loss（初始止损，从未移动过就被打到）、
        trail_stop（跟踪止损已上移/下移后被打到）、max_hold（持满
        96 根）、eod（收盘平仓）。报告里的“初始止损 / 跟踪止损 /
        收盘平仓”即 stop_loss / trail_stop / max_hold+eod。
  强制平仓：与第十五轮同口径——当天最后一根 15m（23:45 根）收盘
    平仓，原因 eod。注意：任务书写的“23:00 UTC 强制平仓”与第十五
    轮实际规则不符（第十五轮报告 §2.1 与引擎都是 23:45 根收盘，
    即持仓到当天最后一根）。为保“只改一处”干净（跟踪止盈是唯一
    变量），主臂保留 23:45；另加一个诊断臂“跟踪止盈 + 23:00 平仓”
    （23:00 根收盘平仓、此后不开新仓），单独报告差额，不混入主结论。
  最长持有 96 根、每天每币最多 2 笔、单日 -2% 熔断、单笔最坏亏损
    (ATR+成本) > 1% 权益跳过：全部与第十五轮同口径。
  成本：Taker 0.25% 双边（每笔约 25 USDT，以 10,000 USDT 名义计，
    实际名义为权益 10% 浮动，与第十五轮同口径）；资金费按 Gate 实际
    费率序列计入；同时报 M1 / M2（第十一轮同一算法）。
  Killzone：伦敦 08:00–11:00 / 纽约 13:00–16:00 UTC，只按入场根判定。
  窗口：15m 全 103 天，前半段 2026-08-06~09-25（51 天）/
    后半段 2026-09-26~11-16（52 天），与第十五轮同切法。

达标标准（跑前定死）：
  “盈利扩大”：跟踪版全期 Taker 净收益高于固定止盈版（第十五轮的
    A -0.27% / B -0.61% / C -0.55%），按模板逐个比，也报三模板合计。
  “能上真钱”：只有跟踪版同时满足全期 1x 净 >2% 且前后两半都正
    才算通过；否则即使扩大了也写明仍不达标。

验证（跑后必做）：
  1. 固定止盈版在同一脚本里重跑一遍，必须与第十五轮已公布数字
     一字不差（A 59 笔 -0.27% / B 193 笔 -0.61% / C 226 笔 -0.55%，
     毛利 -655 / -48 / +1,232），否则停——信号复原错了。
  2. 脚本跑两遍，summary.json 与 trades.csv 的 md5 完全一致。
  3. 三模板首信号与第十五轮 §7 对过（同一天、同一入场价）。

运行：python3 gate_iter_round32.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round32_summary.json
      + data/gate_iter_round32_trades.csv（跟踪版全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import os
import sys
from collections import Counter
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round11 as R11  # 复用第十一轮已验证的通用引擎与成本口径
import gate_iter_round15 as R15  # 复用第十五轮的信号 builders（build_A/B/C）

DATA_DIR = os.path.join(SCRIPT_DIR, "data")
SYMBOLS = R11.SYMBOLS
START_EQUITY = R11.START_EQUITY
SPLIT_15M = R11.SPLIT_15M

SL_MULT = 1.0            # 跟踪距离 = 1xATR（与原来止损同）
MAX_HOLD_15M = 96        # 与第十五轮同口径
MAX_PER_DAY = 2
EOD_2300_BAR_IDX = 92    # 诊断臂：23:00 根（当天第 93 根，00:00 为第 0 根）

# 第十五轮已公布的固定止盈版数字（验证用：同一脚本重跑必须一字不差）
R15_PUBLISHED = {
    "A": {"trades": 59, "taker_pct": -0.0027, "gross": -655.35},
    "B": {"trades": 193, "taker_pct": -0.0061, "gross": -48.45},
    "C": {"trades": 226, "taker_pct": -0.0055, "gross": 1232.08},
}
R15_SIGNALS = {"A": 60, "B": 301, "C": 401}


# ----------------------------------------------------------------------
# 跟踪止盈模拟：逐字复刻 R11.simulate_generic，只改出场部分
# ----------------------------------------------------------------------
def simulate_trailing(symbol, bars, signals, funding, days_subset, max_per_day,
                      max_hold, label, bars_per_day, eod_bar_idx=None):
    """与 R11.simulate_generic 完全同口径，唯一差别：
    无固定止盈；初始止损 1xATR，此后跟踪止损 = 入场以来最高/最低价 ∓ 1xATR，
    只往有利方向移动；碰到跟踪止损即市价平仓（同根先判止损）。
    eod_bar_idx=None 时收盘平仓在当天最后一根（23:45 根，第十五轮同口径）；
    eod_bar_idx=92 时为诊断臂：23:00 根收盘平仓，此后不开新仓。"""
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = R11.group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False
        eod_idx = eod_bar_idx if eod_bar_idx is not None else len(day_bars) - 1

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = R11.funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * R11.ROUNDTRIP_COST
            tr["cost_maker_usdt"] = R11.maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            if eod_bar_idx is not None and i > eod_bar_idx:
                break  # 诊断臂：23:00 平仓后，当天不再开新仓
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                # 1. 先判止损：用上一根收盘后更新的跟踪止损（止损优先于一切）
                if pos["direction"] == 1:
                    if b["l"] <= pos["trail"]:
                        reason = "trail_stop" if pos["trail_moved"] else "stop_loss"
                        close_trade(pos, b["t"], pos["trail"], reason)
                        exited = True
                else:
                    if b["h"] >= pos["trail"]:
                        reason = "trail_stop" if pos["trail_moved"] else "stop_loss"
                        close_trade(pos, b["t"], pos["trail"], reason)
                        exited = True
                if exited:
                    pos = None
                    continue
                # 2. 再用本根最高/最低更新极值与跟踪止损（只往有利方向）
                a = pos["atr"]
                if pos["direction"] == 1:
                    if b["h"] > pos["extreme"]:
                        pos["extreme"] = b["h"]
                        new_trail = pos["extreme"] - a
                        if new_trail > pos["trail"]:
                            pos["trail"] = new_trail
                            pos["trail_moved"] = True
                else:
                    if b["l"] < pos["extreme"]:
                        pos["extreme"] = b["l"]
                        new_trail = pos["extreme"] + a
                        if new_trail < pos["trail"]:
                            pos["trail"] = new_trail
                            pos["trail_moved"] = True
                # 3. 持满（与第十五轮同口径）
                if gi - pos["entry_gi"] >= max_hold - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                # 4. 收盘平仓（主臂：当天最后一根；诊断臂：23:00 根）
                if i == eod_idx:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = R11.MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + R11.ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - SL_MULT * a if sig["direction"] == 1 else entry + SL_MULT * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": None, "atr": a,
                       "trail": stop, "extreme": entry, "trail_moved": False,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": max_hold, "tag": sig.get("tag", "")}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


# ----------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------
def main():
    print("盈利策略迭代 · 第三十二轮：主系统模板改跟踪止盈，盈利会不会扩大？")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    print("模板 A 扫荡反转做多 / B FVG 回踩做多 / C 供给拒绝做空；"
          "唯一改动：固定止盈 2xATR → 跟踪止损（距离 1xATR），其余一字不变。")

    # ---- 数据校验（只读本地缓存，不联网）----
    data1h = R15.build_1h_combined()
    data15 = {}
    for sym in SYMBOLS:
        bars = R11.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R11.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R11.group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 9,888 根 15m / 103 天；1h 合并后每币 "
          f"{len(data1h['BTC_USDT'][0])} 根；时间戳对齐、零缺口。")

    days_all_15 = set(R11.group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def _fmt(x, spec):
        return "—" if x is None else format(x, spec)

    all_results, all_trades = [], []
    fixed_results = {}   # (family, symbol, split) -> res（固定止盈版重跑）
    pooled = {}
    eod2300 = {}         # (family) -> 全期币均（诊断臂）

    def record(res, trades_full, family, variant, gran, funnel_by_sym=None):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        if funnel_by_sym is not None:
            res["setup_stats"] = {s: dict(c) for s, c in funnel_by_sym.items()}
        all_results.append(res)
        if trades_full is not None:
            pooled.setdefault(family, [])
            for t in trades_full:
                pooled[family].append(t["pnl"] / START_EQUITY)
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_15(t["entry_t"])
                all_trades.append(t2)

    def show(res, sym, wname, tag="跟踪"):
        print(f"[{tag} {res['label']} {sym} {wname}] n={res['trades']} 胜率={_fmt(res['win_rate'], '.4f')} "
              f"盈亏比={_fmt(res['profit_factor'], '.2f')} 平均赢={_fmt(res['avg_win_usdt'], '+.0f')} "
              f"平均亏={_fmt(res['avg_loss_usdt'], '.0f')} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={_fmt(res['t_taker'], '.2f')}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={_fmt(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={_fmt(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    def show_funnel(label, funnel_by_sym):
        tot = Counter()
        for c in funnel_by_sym.values():
            tot.update(c)
        print(f"[{label}] 漏斗（8 币合计）：{dict(sorted(tot.items()))}")
        per_sym = " / ".join(
            f"{s.replace('_USDT', '')}:信号{c.get('signals', 0)}"
            for s, c in funnel_by_sym.items())
        print(f"[{label}] 分币信号数：{per_sym}")

    def run_fixed(family, label, signals_by_sym):
        """固定止盈版重跑（R11.simulate_generic 原样），验证用。"""
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
                trades, curve, ndays = R11.simulate_generic(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    MAX_PER_DAY, MAX_HOLD_15M, label, 96)
                res = R11.summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                fixed_results[(family, sym, wname)] = res

    def run_trailing(family, label, signals_by_sym, funnel_by_sym, eod_bar_idx=None,
                     tag="跟踪"):
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
                trades, curve, ndays = simulate_trailing(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    MAX_PER_DAY, MAX_HOLD_15M, label, 96, eod_bar_idx=eod_bar_idx)
                res = R11.summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                if eod_bar_idx is None:
                    record(res, trades if subset is None else None, family, label, "15m",
                           funnel_by_sym={sym: funnel_by_sym[sym]} if subset is None else None)
                    show(res, sym, wname, tag=tag)
                else:
                    eod2300.setdefault((family, wname), []).append(res)
        return

    builders = [("A", "R15-A 扫荡反转做多", R15.build_A),
                ("B", "R15-B FVG 回踩做多", R15.build_B),
                ("C", "R15-C 供给拒绝做空", R15.build_C)]
    for fam, label, builder in builders:
        print(f"\n=== {label}（103d 15m，8 币）===")
        sig, fun = {}, {}
        for sym in SYMBOLS:
            bars1h, atr1h = data1h[sym]
            sig[sym], fun[sym] = builder(data15[sym][0], bars1h, atr1h)
        show_funnel(label, fun)
        n_sig = sum(c.get("signals", 0) for c in fun.values())
        assert n_sig == R15_SIGNALS[fam], \
            f"{fam} 信号数 {n_sig} 与第十五轮 {R15_SIGNALS[fam]} 不符，信号复原错了，停止！"
        print(f"[{label}] 信号数核对通过：{n_sig}（与第十五轮一致）。")
        # 1) 固定止盈版重跑（验证）
        run_fixed(fam, label, sig)
        # 2) 跟踪止盈版（主臂）
        run_trailing(fam, label, sig, fun)
        # 3) 诊断臂：跟踪止盈 + 23:00 平仓（全期）
        run_trailing(fam, label, sig, fun, eod_bar_idx=EOD_2300_BAR_IDX, tag="诊断23:00")

    # ---- 验证 1：固定止盈版重跑必须与第十五轮已公布数字一字不差 ----
    print("\n=== 验证：固定止盈版重跑 vs 第十五轮已公布数字 ===")
    for fam in ["A", "B", "C"]:
        rs = [fixed_results[(fam, s, "103d")] for s in SYMBOLS]
        n_tr = sum(r["trades"] for r in rs)
        avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
        gross = sum(r["gross_usdt"] for r in rs)
        pub = R15_PUBLISHED[fam]
        ok = (n_tr == pub["trades"] and abs(avg_t - pub["taker_pct"]) < 0.0001
              and abs(gross - pub["gross"]) < 1.0)
        print(f"[{fam}] 重跑：{n_tr} 笔、币均 {avg_t*100:+.2f}%、毛利 {gross:+.0f} | "
              f"已公布：{pub['trades']} 笔、{pub['taker_pct']*100:+.2f}%、毛利 {pub['gross']:+.0f} "
              f"→ {'一致 PASS' if ok else '不一致 FAIL'}")
        assert ok, f"{fam} 固定版重跑与第十五轮不符，信号或口径复原错了，停止！"

    # ---- 汇总：跟踪版 vs 固定版 ----
    print("\n=== 汇总：跟踪止盈版 vs 固定止盈版（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for fam in ["A", "B", "C"]:
        for wname in ["103d", "前51d", "后52d"]:
            rs = [r for r in all_results if r["family"] == fam and r["split"] == wname]
            n_tr = sum(r["trades"] for r in rs)
            avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
            avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
            avg_g = sum(r["gross_usdt"] for r in rs)
            avg_c = sum(r["taker_cost_sum"] for r in rs)
            n_pos = sum(1 for r in rs if r["taker_net_pct"] > 0)
            frs = [fixed_results[(fam, s, wname)] for s in SYMBOLS]
            f_avg_t = sum(r["taker_net_pct"] for r in frs) / len(frs)
            f_n = sum(r["trades"] for r in frs)
            f_net = sum(r["taker_net_usdt"] for r in frs)
            t_net = sum(r["taker_net_usdt"] for r in rs)
            delta = t_net - f_net
            hold_rows = [(r["avg_hold_min"], r["trades"]) for r in rs
                       if r["avg_hold_min"] is not None and r["trades"]]
            hold = (sum(h * n for h, n in hold_rows) / sum(n for _, n in hold_rows)
                    if hold_rows else None)
            hold_s = f"{hold:.1f} 分钟" if hold is not None else "—"
            print(f"[{fam} {wname}] 跟踪 Taker {avg_t*100:+.2f}%（{n_tr} 笔，为正币 {n_pos}/8，"
                  f"毛利 {avg_g:+.0f}，成本 {avg_c:+.0f}，M2 {avg_m2*100:+.2f}%）| "
                  f"固定 {f_avg_t*100:+.2f}%（{f_n} 笔）| "
                  f"差额 {delta:+.0f} USDT（跟踪净 {t_net:+.0f} − 固定净 {f_net:+.0f}）| "
                  f"平均持仓 {hold_s}")

    # ---- 三模板合计 ----
    print("\n=== 三模板合计（跟踪版 vs 固定版，全期 103d）===")
    t_tot = sum(r["taker_net_usdt"] for r in all_results if r["split"] == "103d")
    f_tot = sum(fixed_results[(fam, s, "103d")]["taker_net_usdt"]
                for fam in ["A", "B", "C"] for s in SYMBOLS)
    t_n = sum(r["trades"] for r in all_results if r["split"] == "103d")
    f_n = sum(fixed_results[(fam, s, "103d")]["trades"]
              for fam in ["A", "B", "C"] for s in SYMBOLS)
    print(f"跟踪版合计：{t_n} 笔，净 {t_tot:+.0f} USDT；固定版合计：{f_n} 笔，净 {f_tot:+.0f} USDT；"
          f"差额 {t_tot - f_tot:+.0f} USDT。")

    # ---- 前后两半都为正的币数（跟踪版） ----
    print("\n=== 前后两半都为正的币数（跟踪版）===")
    for fam in ["A", "B", "C"]:
        both = 0
        for sym in SYMBOLS:
            rf = [r for r in all_results if r["family"] == fam and r["symbol"] == sym
                  and r["split"] == "前51d"]
            rb = [r for r in all_results if r["family"] == fam and r["symbol"] == sym
                  and r["split"] == "后52d"]
            if rf and rb and rf[0]["taker_net_pct"] > 0 and rb[0]["taker_net_pct"] > 0:
                both += 1
        print(f"[{fam}] 前后两半都为正的币数：{both}/8")

    # ---- 出场原因分布（跟踪版，全期） ----
    print("\n=== 出场原因分布（跟踪版，全期 103d，8 币合计）===")
    for fam in ["A", "B", "C"]:
        rc = Counter()
        for r in all_results:
            if r["family"] == fam and r["split"] == "103d":
                rc.update(r["reason_counts"])
        tot = sum(rc.values())
        print(f"[{fam}] {dict(sorted(rc.items()))}，合计 {tot} 笔；"
              f"初始止损 {rc.get('stop_loss', 0)} / 跟踪止损 {rc.get('trail_stop', 0)} / "
              f"持满 {rc.get('max_hold', 0)} / 收盘 {rc.get('eod', 0)}")
    rc_all = Counter()
    for r in all_results:
        if r["split"] == "103d":
            rc_all.update(r["reason_counts"])
    print(f"[合计] {dict(sorted(rc_all.items()))}，合计 {sum(rc_all.values())} 笔")

    # ---- 诊断臂：跟踪止盈 + 23:00 平仓（全期） ----
    print("\n=== 诊断臂：跟踪止盈 + 23:00 平仓（全期 103d，23:00 根收盘、此后不开新仓）===")
    for fam in ["A", "B", "C"]:
        rs = eod2300[(fam, "103d")]
        avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
        n_tr = sum(r["trades"] for r in rs)
        main_rs = [r for r in all_results if r["family"] == fam and r["split"] == "103d"]
        main_avg = sum(r["taker_net_pct"] for r in main_rs) / len(main_rs)
        print(f"[{fam}] 23:00 平仓版 Taker {avg_t*100:+.2f}%（{n_tr} 笔）| "
              f"主臂（23:45 平仓）{main_avg*100:+.2f}% | 差额 {(avg_t - main_avg)*100:+.2f}pp")

    # ---- pooled t（跟踪版，全期逐笔，Taker）----
    print("\n=== Pooled t（跟踪版，全期逐笔，Taker，1x）===")
    for fam in ["A", "B", "C"]:
        pnls = pooled.get(fam, [])
        print(f"[{fam}] n={len(pnls)} pooled t={R11.t_value(pnls)}")

    # ---- 写文件（跟踪版结果 + 固定版对照字段）----
    for r in all_results:
        f = fixed_results[(r["family"], r["symbol"], r["split"])]
        r["fixed_taker_net_pct"] = f["taker_net_pct"]
        r["fixed_trades"] = f["trades"]
        r["fixed_taker_net_usdt"] = f["taker_net_usdt"]
        r["fixed_gross_usdt"] = f["gross_usdt"]
        r["delta_vs_fixed_usdt"] = round(r["taker_net_usdt"] - f["taker_net_usdt"], 2)
    out_sum = os.path.join(DATA_DIR, "gate_iter_round32_summary.json")
    out_tr = os.path.join(DATA_DIR, "gate_iter_round32_trades.csv")
    with open(out_sum, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    if all_trades:
        keys = list(all_trades[0].keys())
        with open(out_tr, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(all_trades)
    else:
        with open(out_tr, "w", newline="") as f:
            f.write("")
    print(f"\n写出：{out_sum}（{len(all_results)} 条）")
    print(f"写出：{out_tr}（{len(all_trades)} 笔）")


if __name__ == "__main__":
    main()
