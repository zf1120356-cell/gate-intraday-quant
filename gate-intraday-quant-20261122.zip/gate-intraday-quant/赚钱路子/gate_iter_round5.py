#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第五轮：Gate 资金费率套利 179 天验证（全模拟）
================================================================
只做模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。

为什么做这一轮（跑之前写死）：
  前四轮证明：Gate 日内方向在 365 天、8 币、13 个家族里没有 edge，
  分叉三条路悬而未决，用户尚未回复。本轮不发明第 13 个日内方向家族，
  也不改任何实盘约束，只做纸面验证——把唯一曾经为正的路子
  （资金费率套利，现货多 + 永续空对冲）在 Gate、更长窗口、多币种下
  重算一遍，让分叉第 3 条路（放宽“只做合约、只做日内”去验证套利）
  有一个 Gate 实测数字可判，而不是凭 OKX 98 天的老数空谈。
  若本轮为负，则三条路里只剩“停在纸面观察”还站得住；若为正，
  则是否放宽约束仍是重大决定，等用户点头。

策略（预注册，不择时、不调仓）：
  2026-05-21 00:00 UTC 开仓：现货买入 + 永续等值做空，名义 N0；
  持有整个窗口至 2026-11-15 23:00 UTC 平仓；期间每 8 小时
  （00:00/08:00/16:00 UTC）按 Gate 资金费率收/付资金费；
  不做费率择时（费率为负也不提前平），不调仓、不换币。
  窗口 179 天（2026-05-21~2026-11-15）是 Gate 资金费率接口能回溯的
  全部长度（接口限 180 天，2026-05-21 之前取不到，第三轮已实测），
  不是挑出来的窗口；365 天做不到，如实说明。
  币种：与第三/四轮相同的 8 个币。

口径（写清，不藏）：
  资金费收入：每期按当时永续名义计，即 rate_t * N0 * (P_t / P_entry)，
  P_t 为结算时刻的永续收盘价（1h K 线）；不用“名义不变”的简化口径。
  基差 PnL：(S_exit/S_entry - 1) - (P_exit/P_entry - 1)，现货与永续
  各自用 1h 收盘价，精确算两腿价格偏离，不假设对冲完美。
  成本主口径：一轮开平 = 现货 0.10% + 永续 0.075%（API 实测 taker，
  保守，不用公布的 0.05%），每边 0.175%，开平合计 0.35% 名义；
  入场按入场名义、出场按出场名义分别计。不另加滑点（报告里点名，
  真实只会更低）；不计借币/资金划转/提现费。
  1x 口径（与 OKX 98 天报告可比）：名义 = 权益，净收益占权益 %。
  全额资金口径（诚实口径）：现货腿要全款、永续空头 1x 要等值保证金，
  实际占用资金约 2 倍名义，净收益 / 2 才是可部署资金的回报；两档都报。
  2x/3x 只作算术外推（资金费与成本同比例放大），借币成本未计，
  强平距离另行汇报，不进主结论。
  达标标准（与前几轮一致的精神）：前后两半都为正且全期 1x 净收益
  （OKX 口径）年化 >2% 才算“值得拿到用户面前讨论放宽约束”；
  否则本轮结论为“Gate 179 天套利也不成立”。

数据：
  资金费率：复用本地 data/gate_funding_365d_{SYM}.json（537 条/币，
  2026-05-21 00:00 ~ 2026-11-15 16:00，第三轮已取）。
  永续 1h：复用本地 data/gate_1h_365d_{SYM}.csv，截取窗口。
  现货 1h：Gate 公开接口现取
  /spot/candlesticks?currency_pair={SYM}&interval=1h，存
  data/gate_spot_1h_179d_{SYM}.csv；现货与永续收盘价比值应 ≈1，
  脚本内校验，偏离 >0.5% 的时点会打印出来。

运行：python3 gate_iter_round5.py
输出：终端打印全部表 + data/gate_iter_round5_summary.json
      + 报告 gate 资金费率套利-第五轮.md（本脚本同目录）
"""
import csv, json, math, os, statistics, time, urllib.request
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
BASE = "https://api.gateio.ws/api/v4"
SYMBOLS = ["BTC_USDT","ETH_USDT","SOL_USDT","DOGE_USDT","LINK_USDT","XRP_USDT","BNB_USDT","ADA_USDT"]
CORE2 = ["BTC_USDT","ETH_USDT"]
START = datetime(2026,5,21,0,0,tzinfo=timezone.utc)
END = datetime(2026,11,16,0,0,tzinfo=timezone.utc)  # 取到 11-16 00:00，完整日止于 11-15
SPLIT = datetime(2026,8,19,0,0,tzinfo=timezone.utc)  # 约一半：89 天 / 90 天
SPOT_FEE = 0.0010   # Gate VIP0 现货 taker 0.10%（Gate 官方 learn 页 + 多家 2026-11 核查一致）
PERP_FEE = 0.00075  # Gate 永续 taker API 实测 0.075%（保守，不用公布 0.05%）
START_EQUITY = 100_000.0
MAINT = {"BTC_USDT":0.003,"ETH_USDT":0.003,"SOL_USDT":0.005,"DOGE_USDT":0.008333,
         "LINK_USDT":0.0065,"XRP_USDT":0.005,"BNB_USDT":0.0066,"ADA_USDT":0.0066}

def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent":"gate-r5/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries-1: raise
            time.sleep(2*(i+1))

def fetch_spot_1h(sym):
    path = os.path.join(DATA_DIR, f"gate_spot_1h_179d_{sym}.csv")
    if os.path.exists(path):
        with open(path, newline="") as f: rows=list(csv.DictReader(f))
        bars=[{"t":int(r["t"]),"o":float(r["o"]),"h":float(r["h"]),"l":float(r["l"]),
               "c":float(r["c"]),"v":float(r["v"])} for r in rows]
        if bars and bars[0]["t"]<=int(START.timestamp())+3600 and bars[-1]["t"]>=int((END-timedelta(hours=1)).timestamp()):
            print(f"[{sym}] 现货 1h 用缓存：{len(bars)} 根")
            return bars
    bars=[]; cur=START
    while cur < END:
        nxt=min(cur+timedelta(days=7), END)
        url=(f"{BASE}/spot/candlesticks?currency_pair={sym}&interval=1h"
             f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data=http_get(url)
        for d in data:
            # Gate spot: [t, volume, close, high, low, open, amount, ...]
            bars.append({"t":int(d[0]),"o":float(d[5]),"h":float(d[3]),"l":float(d[4]),
                         "c":float(d[2]),"v":float(d[1])})
        cur=nxt; time.sleep(0.3)
    bars=sorted({b["t"]:b for b in bars}.values(), key=lambda b:b["t"])
    with open(path,"w",newline="") as f:
        w=csv.DictWriter(f, fieldnames=["t","o","h","l","c","v"]); w.writeheader(); w.writerows(bars)
    print(f"[{sym}] 现货 1h 已取：{len(bars)} 根")
    return bars

def load_perp(sym):
    with open(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"), newline="") as f:
        rows=list(csv.DictReader(f))
    bars=[{"t":int(r["t"]),"o":float(r["o"]),"h":float(r["h"]),"l":float(r["l"]),
           "c":float(r["c"]),"v":float(r["v"])} for r in rows]
    return sorted(bars, key=lambda b:b["t"])

def load_funding(sym):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{sym}.json")) as f:
        raw=json.load(f)
    return {int(k):float(v) for k,v in raw.items()}

def close_at(bars, ts):
    # bar starting at ts; bars sorted
    import bisect
    times=[b["t"] for b in bars]
    i=bisect.bisect_left(times, ts)
    if i<len(bars) and bars[i]["t"]==ts: return bars[i]["c"]
    return None

def t_value(xs):
    n=len(xs)
    if n<2: return None
    m=sum(xs)/n; var=sum((x-m)**2 for x in xs)/(n-1); sd=math.sqrt(var)
    return round(m/(sd/math.sqrt(n)),2) if sd else None

def run(sym, spot, perp, funding):
    t0=int(START.timestamp()); t_end=int((END-timedelta(hours=1)).timestamp())
    s0=close_at(spot,t0); p0=close_at(perp,t0)
    s1=close_at(spot,t_end); p1=close_at(perp,t_end)
    assert s0 and p0 and s1 and p1, f"{sym} 缺 K 线"
    # basis sanity: spot vs perp close ratio over window
    smap={b["t"]:b["c"] for b in spot}; pmap={b["t"]:b["c"] for b in perp}
    common=sorted(set(smap)&set(pmap))
    ratios=[pmap[t]/smap[t]-1 for t in common]
    max_abs_basis=max(abs(r) for r in ratios)
    # funding settlements in (entry, exit]: entry at close of 00:00 bar = 01:00; settlements 00/08/16
    entry_ts=t0+3600; exit_ts=t_end+3600
    sett=sorted(t for t in funding if entry_ts < t <= exit_ts)
    # split point: settlement closest to SPLIT 00:00
    split_ts=int(SPLIT.timestamp())
    fund_income=0.0; fund_flat=0.0
    cum=[]; c=0.0; peak=0.0; maxdd=0.0
    neg_streak=0; max_neg_streak=0; neg_periods=0
    monthly={}
    half1_fund=0.0; half2_fund=0.0
    for t in sett:
        r=funding[t]; pt=close_at(perp, t-3600)  # settlement at t: use bar ending at t (starts t-1h)
        if pt is None: pt=p1
        inc=r*(pt/p0)  # % of initial notional
        fund_income+=inc; fund_flat+=r
        c+=inc; cum.append(c)
        peak=max(peak,c); maxdd=max(maxdd, peak-c)
        if r<0:
            neg_periods+=1; neg_streak+=1; max_neg_streak=max(max_neg_streak,neg_streak)
        else: neg_streak=0
        d=datetime.fromtimestamp(t, timezone.utc)
        monthly.setdefault(d.strftime("%Y-%m"), []).append(r)
        if t < split_ts: half1_fund+=inc
        else: half2_fund+=inc
    # basis PnL per half (price at split)
    s_mid=close_at(spot, split_ts); p_mid=close_at(perp, split_ts)
    basis_full=(s1/s0-1)-(p1/p0-1)
    basis_h1=(s_mid/s0-1)-(p_mid/p0-1) if s_mid and p_mid else None
    basis_h2=basis_full-basis_h1 if basis_h1 is not None else None
    # costs: entry 0.175% of N0; exit 0.175% of exit notional (perp exit/entry ratio)
    exit_ratio=p1/p0
    cost=(SPOT_FEE+PERP_FEE)*(1+exit_ratio)
    net= fund_income + basis_full - cost
    net_h1= half1_fund + (basis_h1 or 0) - cost/2  # cost split approx: entry half only; report separately
    # proper half nets: h1 bears entry cost, h2 bears exit cost
    net_h1= half1_fund + (basis_h1 or 0) - (SPOT_FEE+PERP_FEE)
    net_h2= half2_fund + (basis_h2 or 0) - (SPOT_FEE+PERP_FEE)*exit_ratio
    days=(END-START).days
    ann=lambda x: x*365/days
    # max adverse move for short perp (max rise from entry, hourly highs)
    max_rise=max(b["h"]/p0-1 for b in perp if t0<=b["t"]<int(END.timestamp()))
    rates=[funding[t] for t in sett]
    return {
        "symbol":sym,"periods":len(sett),
        "entry_spot":s0,"entry_perp":p0,"exit_spot":s1,"exit_perp":p1,
        "fund_mean_pct":round(statistics.mean(rates)*100,5),
        "fund_median_pct":round(statistics.median(rates)*100,5),
        "fund_pos_pct":round(sum(1 for r in rates if r>0)/len(rates),4),
        "fund_sum_pct":round(fund_flat*100,4),
        "fund_income_pct":round(fund_income*100,4),
        "basis_pct":round(basis_full*100,4),
        "cost_pct":round(cost*100,4),
        "net_pct_1x":round(net*100,4),
        "net_ann_1x_pct":round(ann(net)*100,2),
        "net_pct_fullyfunded":round(net*100/2,4),
        "net_ann_fullyfunded_pct":round(ann(net)*100/2,2),
        "net_h1_pct":round(net_h1*100,4),"net_h2_pct":round(net_h2*100,4),
        "fund_h1_pct":round(half1_fund*100,4),"fund_h2_pct":round(half2_fund*100,4),
        "basis_h1_pct":round(basis_h1*100,4) if basis_h1 is not None else None,
        "basis_h2_pct":round(basis_h2*100,4) if basis_h2 is not None else None,
        "fund_maxdd_pct":round(maxdd*100,4),
        "fund_max_neg_streak":max_neg_streak,"fund_neg_periods":neg_periods,
        "max_basis_abs_pct":round(max_abs_basis*100,4),
        "max_rise_from_entry_pct":round(max_rise*100,2),
        "maint_rate_pct":round(MAINT[sym]*100,3),
        "liq_rise_1x_pct":round((1-MAINT[sym])*100,2),
        "monthly":{k:{"n":len(v),"mean_pct":round(statistics.mean(v)*100,5),
                      "sum_pct":round(sum(v)*100,4),
                      "pos":sum(1 for x in v if x>0)} for k,v in sorted(monthly.items())},
        "fund_t":t_value([r for r in rates]),
    }

def main():
    print("第五轮：Gate 资金费率套利 179 天验证（全模拟）")
    print("窗口 2026-05-21~2026-11-15（Gate 资金费率接口可回溯的全部长度）；"
          "现货多+永续空、持有整段、不择时、不调仓。")
    results=[]
    for sym in SYMBOLS:
        spot=fetch_spot_1h(sym); perp=load_perp(sym); funding=load_funding(sym)
        r=run(sym, spot, perp, funding); results.append(r)
        print(f"[{sym}] 期数={r['periods']} 资金费均值={r['fund_mean_pct']:.5f}%/期 "
              f"为正={r['fund_pos_pct']*100:.1f}% 资金费收入={r['fund_income_pct']:+.3f}% "
              f"基差={r['basis_pct']:+.3f}% 成本={r['cost_pct']:.3f}% "
              f"净1x={r['net_pct_1x']:+.3f}% (年化 {r['net_ann_1x_pct']:+.2f}%) "
              f"全额资金年化={r['net_ann_fullyfunded_pct']:+.2f}% "
              f"前半={r['net_h1_pct']:+.3f}% 后半={r['net_h2_pct']:+.3f}% "
              f"最大基差偏离={r['max_basis_abs_pct']:.3f}% 最长连负={r['fund_max_neg_streak']}期")
    print("\n=== 组合（等权，各币独立 10 万 USDT 名义，1x 口径）===")
    for scope, syms in [("BTC+ETH", CORE2), ("八币", SYMBOLS)]:
        rs=[r for r in results if r["symbol"] in syms]
        for k in ["net_pct_1x","net_ann_1x_pct","net_pct_fullyfunded","net_ann_fullyfunded_pct",
                  "fund_income_pct","basis_pct","net_h1_pct","net_h2_pct"]:
            print(f"  {scope} {k} 平均 {sum(r[k] for r in rs)/len(rs):+.4f}"
                  f"（{' / '.join(f'{r['symbol'][:4]} {r[k]:+.2f}' for r in rs)}）")
    print("\n=== 达标判定（主口径：OKX 可比 1x 年化；两半都为正且全期年化>2%）===")
    for scope, syms in [("BTC+ETH", CORE2), ("八币", SYMBOLS)]:
        rs=[r for r in results if r["symbol"] in syms]
        h1=sum(r["net_h1_pct"] for r in rs)/len(rs); h2=sum(r["net_h2_pct"] for r in rs)/len(rs)
        ann=sum(r["net_ann_1x_pct"] for r in rs)/len(rs)
        print(f"  {scope}：前半 {h1:+.3f}% / 后半 {h2:+.3f}% / 全期年化 {ann:+.2f}% → "
              f"{'值得讨论放宽约束' if (h1>0 and h2>0 and ann>2) else '不达标'}")
    print("\n=== 月度资金费（BTC/ETH，各半组合对照 OKX 98 天）===")
    for sym in CORE2:
        r=[x for x in results if x["symbol"]==sym][0]
        print(f"  {sym}: " + " | ".join(f"{m} 均值 {v['mean_pct']:+.5f}% 累计 {v['sum_pct']:+.3f}% 为正 {v['pos']}/{v['n']}"
                                        for m,v in r["monthly"].items()))
    print("\n=== 强平距离检查（永续空头 1x，价格上涨多少会强平）===")
    for r in results:
        print(f"  {r['symbol']}: 窗口内最大上涨 {r['max_rise_from_entry_pct']:+.2f}% vs 1x 强平线 +{r['liq_rise_1x_pct']:.2f}%"
              f"（维持保证金 {r['maint_rate_pct']}%）；2x 强平线约 +{(1/2-r['maint_rate_pct']/100)*100:.1f}%，"
              f"3x 约 +{(1/3-r['maint_rate_pct']/100)*100:.1f}%")
    json.dump(results, open(os.path.join(DATA_DIR,"gate_iter_round5_summary.json"),"w"), ensure_ascii=False, indent=2)
    print("\n汇总已写入：data/gate_iter_round5_summary.json")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")

if __name__=="__main__":
    main()
