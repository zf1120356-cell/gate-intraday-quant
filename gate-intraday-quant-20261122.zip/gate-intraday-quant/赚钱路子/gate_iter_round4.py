#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第四轮：截面多空 + 信号诊断扫描（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。

背景（第三轮已跑完、未向用户汇报，见 data/gate_iter_round3_summary.json）：
  A+B（S3 RSI 20/80 低换手 + Maker 混合成本）在 365 天 1h、8 个币上
  全军覆没：Maker 口径 M1 八币平均 -0.70%，核心三币 -0.81%，
  没有一个币前后两半都为正（LINK/XRP/BNB 只后半段为正，前半段为负）。
  毛利合计约 -3559 USDT / 800k 虚拟权益，方向信号本身仍无定价能力。
  180 天 +0.36% 未能通过 365 天验证——规则锁定、不调参、不挑单币。

本轮不再发明又一个单币方向家族。做两件预先写死的事：
  (A) 诊断扫描（不交易）：在同一批 365 天 1h、8 币数据上，算
      ① 每小时平均收益（24 个 UTC 小时 × 8 币，前后半段对照）；
      ② 1h 收益滞后 1 期自相关、以及 08:00 前 8h 收益与当日剩余
         收益的相关性（即截面动量/反转有没有统计基础）；
      ③ 资金费率与下一期收益的关系（只看相关性，不交易）。
      扫描结果只用来判断“有没有值得做的方向”，不用来事后挑参数。
  (B) 新家族——截面日内多空（此前从未测过；之前 C2 跨币种轮动是
      每天只做多最强 1 个币、单向追涨，本轮是同时做多最强、做空
      最弱、多空对冲、净敞口为零）：
      每天 08:00 UTC，按 00:00-08:00 的 8h 收益给 8 个币排序；
      动量版：做多前 2、做空后 2；反转版（对照）：做多后 2、做空前 2。
      每条腿名义 10,000 USDT（10 万虚拟权益的 10%），4 条腿共 4 万，
      净敞口 0；当天 23:00 UTC 收盘价平仓，不过夜；每天都交易，
      不设离散度过滤（过滤只作事后诊断，不作主口径）。
      第二个预注册变体：12:00 UTC 排序（00:00-12:00 收益），23:00 平仓。
      成本主口径 Taker 一轮名义 0.25%（0.075% 费 + 0.05% 滑点，往返，
      与前几轮同一口径）；Maker 上界：入场 -0.01%、出场市价 0.125%/边。
      资金费：持仓 08:00-23:00 跨 16:00 一个结算点，按 Gate 资金费率
      接口数据计（2026-05-21 前取不到，按 0 计，与第三轮同一处理，
      并在报告里点名；跨 1 个结算点、持仓约 15h，费率影响本就很小）。
 达标标准（与第三轮一致）：前后两半都为正且全 365 天 1 倍净收益 >2%
 才算达标；只看截面组合口径（8 币合成一个组合），单个币不单独算。
 窗口：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~2026-05-19
 （185 天）；后半段 2026-05-20~2026-11-15（180 天）。
 数据：直接读本地 data/gate_1h_365d_{SYM}.csv（第三轮已取，8,761 根/币，
 含表头），不重新拉取、不看涨幅选币。
运行：python3 gate_iter_round4.py
输出：终端打印全部表 + data/gate_iter_round4_summary.json
      + data/gate_iter_round4_trades.csv
"""
import csv, json, math, os, statistics
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
SYMBOLS = ["BTC_USDT","ETH_USDT","SOL_USDT","DOGE_USDT","LINK_USDT","XRP_USDT","BNB_USDT","ADA_USDT"]
START_EQUITY = 100_000.0
LEG_NOTIONAL = 10_000.0
TAKER_RT = 0.0025
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
SPLIT = datetime(2026,5,20,tzinfo=timezone.utc)

def load(sym):
    rows=[]
    with open(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv")) as f:
        r=csv.DictReader(f)
        for row in r:
            rows.append((datetime.fromtimestamp(int(row["t"]), tz=timezone.utc), float(row["c"])))
    rows.sort()
    return rows

def load_funding(sym):
    try:
        d=json.load(open(os.path.join(DATA_DIR, f"gate_funding_365d_{sym}.json")))
        # format unknown; try common shapes
        out={}
        if isinstance(d, list):
            for e in d:
                if isinstance(e, dict):
                    t=e.get("t") or e.get("create_time") or e.get("timestamp")
                    v=e.get("r") or e.get("funding_rate") or e.get("rate")
                    if t is not None and v is not None:
                        out[int(t)]=float(v)
        elif isinstance(d, dict):
            for k,v in d.items():
                try: out[int(k)]=float(v)
                except Exception: pass
        return out
    except Exception:
        return {}

def daily_bars(data):
    """group 1h closes by UTC date -> dict date -> list of (hour, close)"""
    days={}
    for ts,c in data:
        days.setdefault(ts.date(), []).append((ts.hour, c))
    return days

def mean(xs): return sum(xs)/len(xs) if xs else float("nan")
def corr(xs, ys):
    n=len(xs)
    if n<10: return float("nan")
    mx, my = mean(xs), mean(ys)
    num=sum((x-mx)*(y-my) for x,y in zip(xs,ys))
    den=math.sqrt(sum((x-mx)**2 for x in xs)*sum((y-my)**2 for y in ys))
    return num/den if den else float("nan")
def tstat(xs):
    if len(xs)<3: return float("nan")
    m=mean(xs); sd=statistics.pstdev(xs)
    return m/(sd/math.sqrt(len(xs))) if sd else float("nan")

def main():
    data={s: load(s) for s in SYMBOLS}
    funding={s: load_funding(s) for s in SYMBOLS}
    print("funding records per coin:", {s: len(funding[s]) for s in SYMBOLS})
    # ---- (A) diagnostic ----
    print("\n=== A1: hour-of-day mean 1h return (%) ===")
    # per coin per hour, split halves
    for s in SYMBOLS:
        rows=data[s]
        rets=[(ts, math.log(rows[i+1][1]/rows[i][1])) for i, (ts,_) in enumerate(rows[:-1]) if rows[i+1][0]==rows[i][0]+__import__("datetime").timedelta(hours=1)]
        # simpler: consecutive hourly log rets indexed by starting hour
        by_hour={h: [] for h in range(24)}
        by_hour_f={h: [] for h in range(24)}
        by_hour_b={h: [] for h in range(24)}
        for ts, r in rets:
            by_hour[ts.hour].append(r)
            (by_hour_f if ts < SPLIT else by_hour_b)[ts.hour].append(r)
        best=[]
        for h in range(24):
            best.append((h, mean(by_hour[h])*100, mean(by_hour_f[h])*100, mean(by_hour_b[h])*100, len(by_hour[h])))
        # print only hours where |full| largest, plus funding-settlement hours 0,8,16
        best_sorted=sorted(best, key=lambda x: abs(x[1]), reverse=True)[:5]
        print(s, "top |hour|:", [(h, round(m,4), round(f,4), round(b,4), n) for h,m,f,b,n in best_sorted],
              "| 0h:", (round(best[0][1],4), round(best[0][2],4), round(best[0][3],4)),
              "| 8h:", (round(best[8][1],4), round(best[8][2],4), round(best[8][3],4)),
              "| 16h:", (round(best[16][1],4), round(best[16][2],4), round(best[16][3],4)))
    print("\n=== A2: 1h lag-1 autocorrelation + 08:00 8h return vs rest-of-day return ===")
    for s in SYMBOLS:
        rows=data[s]
        lr=[math.log(rows[i+1][1]/rows[i][1]) for i in range(len(rows)-1)]
        ac1=corr(lr[:-1], lr[1:])
        # 08:00 ranking return vs rest of day
        days=daily_bars(data[s])
        xs, ys = [], []
        for d, bars in sorted(days.items()):
            m={h:c for h,c in bars}
            if 0 in m and 8 in m and 23 in m:
                xs.append(math.log(m[8]/m[0])); ys.append(math.log(m[23]/m[8]))
        print(s, f"lag1_ac={ac1:.3f}  corr(00-08, 08-23)={corr(xs,ys):.3f} n={len(xs)}  mean08-23={mean(ys)*100:.3f}%")
    # cross-sectional: rank return vs rest-of-day, pooled demeaned
    print("\n=== A2b: pooled cross-sectional (demeaned by day) corr(00-08 rank ret, 08-23 ret) ===")
    xs_all, ys_all=[],[]
    for d in sorted(set().union(*[set(daily_bars(data[s]).keys()) for s in SYMBOLS])):
        rets8, rets_rest=[],[]
        for s in SYMBOLS:
            m={h:c for h,c in daily_bars(data[s]).get(d, [])}
            if 0 in m and 8 in m and 23 in m:
                rets8.append(math.log(m[8]/m[0])); rets_rest.append(math.log(m[23]/m[8]))
        if len(rets8)==8:
            m8, mr = mean(rets8), mean(rets_rest)
            xs_all += [x-m8 for x in rets8]; ys_all += [y-mr for y in rets_rest]
    print(f"pooled demeaned corr = {corr(xs_all, ys_all):.3f}  n={len(xs_all)}")
    print("\n=== A3: funding rate vs next 8h return (corr, where funding data exists) ===")
    for s in SYMBOLS:
        fr=funding[s]
        if not fr:
            print(s, "no funding parsed"); continue
        # funding dict keys are timestamps (s or ms?) - try to align by date/hour roughly: skip if unusable
        print(s, "funding entries:", len(fr), "sample:", list(fr.items())[:2])

    # ---- (B) cross-sectional long-short ----
    results=[]; trades=[]
    for rank_hour, label in [(8,"rank08"), (12,"rank12")]:
        for mode in ["momentum","reversal"]:
            # per split
            for split_name, cond in [("365d", lambda d: True),
                                     ("前185d", lambda d: datetime(d.year,d.month,d.day,tzinfo=timezone.utc) < SPLIT),
                                     ("后180d", lambda d: datetime(d.year,d.month,d.day,tzinfo=timezone.utc) >= SPLIT)]:
                eq=START_EQUITY; daily_pnls=[]; n_trades=0; gross=0.0; notional=0.0
                # build per-day closes
                day_map={}
                for s in SYMBOLS:
                    for d, bars in daily_bars(data[s]).items():
                        day_map.setdefault(d, {})[s]={h:c for h,c in bars}
                for d in sorted(day_map):
                    if not cond(d): continue
                    m=day_map[d]
                    # need rank_hour close, 00 close, 23 close for all 8
                    if any(s not in m or 0 not in m[s] or rank_hour not in m[s] or 23 not in m[s] for s in SYMBOLS):
                        continue
                    rank_ret={s: math.log(m[s][rank_hour]/m[s][0]) for s in SYMBOLS}
                    ranked=sorted(SYMBOLS, key=lambda s: rank_ret[s])
                    if mode=="momentum":
                        longs=ranked[-2:]; shorts=ranked[:2]
                    else:
                        longs=ranked[:2]; shorts=ranked[-2:]
                    pnl_day=0.0; not_day=0.0
                    for s in longs:
                        r=(m[s][23]/m[s][rank_hour])-1
                        pnl_day += LEG_NOTIONAL*r; not_day += LEG_NOTIONAL
                    for s in shorts:
                        r=(m[s][23]/m[s][rank_hour])-1
                        pnl_day -= LEG_NOTIONAL*r; not_day += LEG_NOTIONAL
                    # costs: taker roundtrip 0.25% of notional per leg
                    cost_taker = not_day*TAKER_RT
                    # maker upper bound: entry -0.01% + exit taker 0.125% per leg = 0.115% of notional
                    cost_maker = not_day*0.00115
                    pnl_taker = pnl_day - cost_taker
                    pnl_maker = pnl_day - cost_maker
                    gross += pnl_day; notional += not_day; n_trades += 4
                    daily_pnls.append(pnl_taker)  # taker is primary for t-stat
                    trades.append({"variant":f"{label}-{mode}","split":split_name,"date":str(d),
                                   "longs":"+".join(longs),"shorts":"-".join(shorts),
                                   "price_pnl_usdt":round(pnl_day,2),"taker_net_usdt":round(pnl_taker,2),
                                   "maker_net_usdt":round(pnl_maker,2),"notional":not_day})
                # aggregate: recompute from trades for this variant/split
                tr=[t for t in trades if t["variant"]==f"{label}-{mode}" and t["split"]==split_name]
                gp=sum(t["price_pnl_usdt"] for t in tr); tp=sum(t["taker_net_usdt"] for t in tr); mp=sum(t["maker_net_usdt"] for t in tr)
                # daily pnl t-stat using daily_pnls (taker)
                results.append({"label":f"{label}-{mode}","split":split_name,"days":len(tr),
                                "legs":len(tr)*4,"gross_usdt":round(gp,2),
                                "taker_net_usdt":round(tp,2),"taker_net_pct":round(tp/START_EQUITY,4),
                                "maker_net_usdt":round(mp,2),"maker_net_pct":round(mp/START_EQUITY,4),
                                "daily_taker_t":round(tstat(daily_pnls),2) if daily_pnls else None,
                                "notional_sum":round(sum(t["notional"] for t in tr),2)})
    print("\n=== B: cross-sectional intraday long-short (1x, 100k virtual equity) ===")
    for r in results:
        print(r)
    json.dump(results, open(os.path.join(DATA_DIR,"gate_iter_round4_summary.json"),"w"), ensure_ascii=False, indent=2)
    with open(os.path.join(DATA_DIR,"gate_iter_round4_trades.csv"),"w",newline="") as f:
        w=csv.DictWriter(f, fieldnames=["variant","split","date","longs","shorts","price_pnl_usdt","taker_net_usdt","maker_net_usdt","notional"])
        w.writeheader(); w.writerows(trades)
    print("\nwrote gate_iter_round4_summary.json / gate_iter_round4_trades.csv")

if __name__=="__main__":
    main()
