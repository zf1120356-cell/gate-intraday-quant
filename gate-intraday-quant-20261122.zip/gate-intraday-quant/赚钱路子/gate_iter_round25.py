#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十五轮：新发明方向——跨所领涨（OKX 领涨、Gate 跟随）
======================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因：第七轮 F1（Gate 内 BTC 领涨-山寨跟随）毛利为正但只有成本约 1/5；
第二十轮时段限制版离盈亏平衡最近但在新币种上没泛化。本轮换一个问题：
领涨信号是不是来自 Gate 之外——OKX 的 BTC 是不是领先 Gate 的 BTC/山寨？

第一步测量结论（gate_iter_round25_measure.py 已跑，见
data/gate_iter_round25_measure.json）：OKX 不领先。
  M1 1m 互相关：滞后 0 为 0.9951，其余滞后 |r|<=0.075；
  M2 15m：滞后 0 为 0.9996，其余 |r|<=0.034；
  M3 1h：滞后 0 为 0.9988，其余 |r|<=0.009；
  M5 OKX BTC 2h 涨幅 vs 山寨随后 1h 涨幅（n=1396）：0.005~0.025，
     与 Gate BTC 对照（0.006~0.026）一字不差。
按任务要求：测量显示无领先，第二步仍按写死规则跑完并如实报告。

跑前写死的规则（单组参数，不许按第一步结果改规则）：
  X-OKX-F1（与第七轮 F1 唯一区别：领涨源从 Gate BTC 换成 OKX BTC）：
    信号根 08:00~19:00 UTC 收盘：OKX BTC 2h 收益 |rOKX| >= 0.5%，且 Gate
    山寨自身 2h 收益 |rALT| < 0.5*|rOKX|；方向 = sign(rOKX)；
    下一根开盘进（Gate）；止损 1xATR、止盈 2xATR（用户要求的 1:2）；
    最多持 4h（1h 版 4 根，15m 版 16 根）；每天每币最多 2 笔；
    当天最后一根收盘强制平仓（1h 23:00，15m 23:45）；单日 -2% 熔断；
    同根同时碰止损和止盈先判止损；只做 7 个山寨，不做 BTC 本身。
    1h 版 ATR(14,1h)、lookback 2 根；15m 版 ATR(14,15m)、lookback 8 根。
  三臂（唯一变量是领涨源 / 时段过滤）：
    X    主臂：X-OKX-F1，无时段限制。
    C1S  对照 1（短窗口）：原版 F1（Gate BTC 领涨），与主臂同一短窗口，
         苹果对苹果比较跨所信号有没有增值。
    XH   对照 2：X-OKX-F1 + 只在 09:00/15:00 UTC 入场（第二层检验，
         主结论以无时段版 X 为准）。
  另跑 C1F：原版 F1 全窗口（1h 365d / 15m 103d），只为复核引擎对照
  第九轮 TP=2.0 已发表数字，误差 <0.05pp 才算复核通过。

窗口（受 OKX 历史覆盖限制，按 OKX 可覆盖的最长连续窗口跑，不外推）：
  OKX 公开 candles 未认证最多只返回最近 1440 根（实测）：
    1H  2026-09-18 18:00 ~ 2026-11-17 17:00（60 天）
    15m 2026-11-02 18:00 ~ 2026-11-17 17:45（15 天）
  与 Gate 缓存取交集、只取完整 UTC 日：
    1h：2026-09-19 ~ 2026-11-15（58 天），前 29 天 / 后 29 天
        （分界 2026-10-18）
    15m：2026-11-03 ~ 2026-11-16（14 天），前 7 天 / 后 7 天
        （分界 2026-11-10）
  资金费：窗口全在 2026-05-21 之后，资金费文件全覆盖。

成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
M1/M2 对照同第七/九/二十轮（引擎照抄 gate_iter_round20.py）。
达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主臂按粒度分别判定。

运行：python3 gate_iter_round25.py（策略部分不联网，只读本地缓存 +
OKX 已拉取的 JSON；拉数见 gate_iter_round25_measure.py）
输出：终端打印全部表 + data/gate_iter_round25_summary.json
      + data/gate_iter_round25_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import hashlib
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, date, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round20 as r20  # noqa: E402  引擎复用，保证口径零漂移

SYMBOLS = r20.SYMBOLS
ALTS = r20.ALTS
TP_MULT = 2.0
SL_MULT = 1.0
TARGET_HOURS = {9, 15}

# ---- 跑前写死的短窗口（OKX 覆盖 ∩ Gate 缓存 ∩ 完整 UTC 日）----
WIN_1H = (date(2026, 9, 19), date(2026, 11, 15))
SPLIT_1H = date(2026, 10, 18)   # 前 29 天 / 后 29 天
WIN_15M = (date(2026, 11, 3), date(2026, 11, 16))
SPLIT_15M = date(2026, 11, 10)  # 前 7 天 / 后 7 天

# 第九轮 TP=2.0 已发表数字（第二十轮 §8(a) 复核过的同一组数）
PUBLISHED_CTRL1 = {
    "1h": {"ETH_USDT": 0.0010, "SOL_USDT": -0.0129, "DOGE_USDT": -0.0372,
           "LINK_USDT": -0.0421, "XRP_USDT": -0.0366, "BNB_USDT": -0.0500,
           "ADA_USDT": -0.0093},
    "15m": {"ETH_USDT": -0.0066, "SOL_USDT": -0.0145, "DOGE_USDT": -0.0124,
            "LINK_USDT": -0.0083, "XRP_USDT": -0.0177, "BNB_USDT": -0.0171,
            "ADA_USDT": -0.0062},
}


def load_okx_closes(fname):
    with open(os.path.join(DATA_DIR, fname)) as f:
        rows = json.load(f)
    return {int(r[0]) // 1000: float(r[4]) for r in rows}


def build_x_signals(alt_bars, leader_close, alt_atr, lookback, max_hold, tp_mult):
    """X-OKX-F1 信号：与 r20.build_f1_signals 同构，唯一区别是领涨源
    r_btc 改为 OKX BTC 收盘（按时间戳查表），Gate 山寨部分一字不变。"""
    sigs = {}
    for i in range(lookback, len(alt_bars)):
        b = alt_bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour <= 19):
            continue
        if alt_atr[i] is None:
            continue
        c_now = leader_close.get(b["t"])
        c_old = leader_close.get(alt_bars[i - lookback]["t"])
        if c_now is None or c_old is None:
            continue
        r_btc = c_now / c_old - 1
        if abs(r_btc) < 0.005:
            continue
        r_alt = alt_bars[i]["c"] / alt_bars[i - lookback]["c"] - 1
        if abs(r_alt) >= 0.5 * abs(r_btc):
            continue
        if i + 1 >= len(alt_bars):
            continue
        entry_t = alt_bars[i + 1]["t"]
        sigs[entry_t] = {"direction": 1 if r_btc > 0 else -1,
                         "atr": alt_atr[i], "sl_mult": SL_MULT, "tp_mult": tp_mult,
                         "max_hold": max_hold}
    return sigs


def window_days(all_days, win, split):
    w = {d for d in all_days if win[0] <= d <= win[1]}
    front = {d for d in w if d < split}
    back = {d for d in w if d >= split}
    return w, front, back


def main():
    print("盈利策略迭代 · 第二十五轮：跨所领涨 X-OKX-F1（全模拟）")
    print("主臂 OKX BTC 领涨 → Gate 山寨跟随；对照 1 同窗口原版 F1；"
          "对照 2 X + 09:00/15:00。止损 1xATR / 止盈 2xATR；"
          "达标：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验 ----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = r20.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = r20.load_funding(sym)
        data1h[sym] = (bars, funding)
        days = r20.group_days(bars, 24)
        assert len(days) == 365 and len(bars) == 8761
    for sym in SYMBOLS:
        bars = r20.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = r20.load_funding(sym)
        data15[sym] = (bars, funding)
        days = r20.group_days(bars, 96)
        assert len(days) == 103 and len(bars) == 103 * 96
    okx_1h = load_okx_closes("okx_btc_1h.json")
    okx_15m = load_okx_closes("okx_btc_15m.json")
    print(f"OKX BTC 覆盖：1H {len(okx_1h)} 根 "
          f"{datetime.fromtimestamp(min(okx_1h), timezone.utc)} ~ "
          f"{datetime.fromtimestamp(max(okx_1h), timezone.utc)}；"
          f"15m {len(okx_15m)} 根 "
          f"{datetime.fromtimestamp(min(okx_15m), timezone.utc)} ~ "
          f"{datetime.fromtimestamp(max(okx_15m), timezone.utc)}")
    # 覆盖校验：窗口内每个 Gate 时间戳都必须有 OKX 对应根（OKX 多余的
    # 11-16/11-17 部分超出 Gate 缓存，不用，不管它）
    for t in [b["t"] for b in data1h["BTC_USDT"][0]
              if WIN_1H[0] <= datetime.fromtimestamp(b["t"], timezone.utc).date() <= WIN_1H[1]]:
        assert t in okx_1h, f"窗口内 Gate 1h 时间戳 {t} 缺 OKX 对应根"
    for t in [b["t"] for b in data15["BTC_USDT"][0]
              if WIN_15M[0] <= datetime.fromtimestamp(b["t"], timezone.utc).date() <= WIN_15M[1]]:
        assert t in okx_15m, f"窗口内 Gate 15m 时间戳 {t} 缺 OKX 对应根"
    print("覆盖校验通过：窗口内 Gate 时间戳全部有 OKX 对应根。")

    days_all_1h = set(r20.group_days(data1h["BTC_USDT"][0], 24).keys())
    days_all_15 = set(r20.group_days(data15["BTC_USDT"][0], 96).keys())
    w1h, f1h, b1h = window_days(days_all_1h, WIN_1H, SPLIT_1H)
    w15, f15, b15 = window_days(days_all_15, WIN_15M, SPLIT_15M)
    print(f"窗口：1h {WIN_1H[0]}~{WIN_1H[1]}（{len(w1h)} 天，前 {len(f1h)} / 后 {len(b1h)}）；"
          f"15m {WIN_15M[0]}~{WIN_15M[1]}（{len(w15)} 天，前 {len(f15)} / 后 {len(b15)}）。")

    atr1h = {s: r20.atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: r20.atr_wilder(data15[s][0]) for s in SYMBOLS}

    # ---- 信号：X（OKX 领涨）与 C1（Gate 领涨）各生成一次 ----
    sigx_1h, sigx_15, sigc_1h, sigc_15 = {}, {}, {}, {}
    for sym in ALTS:
        sigx_1h[sym] = build_x_signals(data1h[sym][0], okx_1h, atr1h[sym], 2, 4, TP_MULT)
        sigx_15[sym] = build_x_signals(data15[sym][0], okx_15m, atr15[sym], 8, 16, TP_MULT)
        sigc_1h[sym] = r20.build_f1_signals(data1h[sym][0], data1h["BTC_USDT"][0],
                                            atr1h[sym], 2, 4, TP_MULT)
        sigc_15[sym] = r20.build_f1_signals(data15[sym][0], data15["BTC_USDT"][0],
                                            atr15[sym], 8, 16, TP_MULT)
    print(f"[X 信号] 1h 合计 {sum(len(v) for v in sigx_1h.values())}，"
          f"15m 合计 {sum(len(v) for v in sigx_15.values())}。")
    print(f"[C1 信号全窗口] 1h 合计 {sum(len(v) for v in sigc_1h.values())}，"
          f"15m 合计 {sum(len(v) for v in sigc_15.values())}。")

    # ---- X vs C1 信号一致性诊断（短窗口内，同一 entry_t）----
    for gran, sigx, sigc, win in (("1h", sigx_1h, sigc_1h, w1h),
                                  ("15m", sigx_15, sigc_15, w15)):
        tot_x = tot_c = both = same_dir = 0
        for sym in ALTS:
            xs = {t for t in sigx[sym]
                  if datetime.fromtimestamp(t, timezone.utc).date() in win}
            cs = {t for t in sigc[sym]
                  if datetime.fromtimestamp(t, timezone.utc).date() in win}
            tot_x += len(xs)
            tot_c += len(cs)
            inter = xs & cs
            both += len(inter)
            same_dir += sum(1 for t in inter
                            if sigx[sym][t]["direction"] == sigc[sym][t]["direction"])
        print(f"[诊断 {gran}] 短窗口内 X 信号 {tot_x} / C1 信号 {tot_c} / "
              f"同一入场时刻 {both}（其中方向相同 {same_dir}）；"
              f"X 信号里与 C1 重合 {both}/{tot_x} = "
              f"{both / tot_x * 100:.1f}%（若接近 100%，跨所信号 ≈ 所内信号）。")

    def filter_hours(sigs, keep):
        return {t: v for t, v in sigs.items() if keep(r20.entry_hour_utc(t))}

    # (arm, label, gran, sigs, data, bpd, windows[(name, subset)], split_fn)
    GRANS_SHORT = [
        ("1h", data1h, sigx_1h, sigc_1h, 24,
         [("58d", w1h), ("前29d", f1h), ("后29d", b1h)],
         lambda et: "前29d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H else "后29d"),
        ("15m", data15, sigx_15, sigc_15, 96,
         [("14d", w15), ("前7d", f15), ("后7d", b15)],
         lambda et: "前7d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M else "后7d"),
    ]
    ARMS = [
        ("X", "X-OKX-F1", lambda s: s),
        ("C1S", "F1-GateBTC-short", lambda s: s),
        ("XH", "X-OKX-F1-hours-0915", lambda s: filter_hours(s, lambda h: h in TARGET_HOURS)),
    ]

    all_results, all_trades = [], []
    for arm, label, sigfn in ARMS:
        for gran, data, sigx, sigc, bpd, windows, split_fn in GRANS_SHORT:
            sigs_all = sigx if arm in ("X", "XH") else sigc
            print(f"\n=== {arm} {label} · {gran}（TP {TP_MULT}，SL {SL_MULT}）===")
            for sym in ALTS:
                sigs = sigfn(sigs_all[sym])
                for wname, subset in windows:
                    bars, funding = data[sym]
                    trades, curve, ndays = r20.simulate_f1(
                        sym, bars, sigs, funding, subset, 2, label, bpd)
                    res = r20.summarize(sym, trades, curve, label, len(sigs))
                    res.update({"arm": arm, "variant": label, "family": "X-OKX-F1",
                                "tp_mult": TP_MULT, "granularity": gran,
                                "split": wname, "days": ndays,
                                "signals_total": len(sigs_all[sym]),
                                "signals_pass": len(sigs),
                                "signal_pass_rate": round(len(sigs) / len(sigs_all[sym]), 4)
                                if sigs_all[sym] else None})
                    all_results.append(res)
                    if wname in ("58d", "14d"):
                        for t in trades:
                            t2 = dict(t)
                            t2.update({"arm": arm, "variant": label,
                                       "family": "X-OKX-F1", "tp_mult": TP_MULT,
                                       "granularity": gran, "split": split_fn(t["entry_t"]),
                                       "entry_hour_utc": r20.entry_hour_utc(t["entry_t"])})
                            all_trades.append(t2)
                    gpt = (f"{res['gross_per_trade_usdt']:+.2f}" if res['gross_per_trade_usdt'] is not None else "—")
                    wr = (f"{res['win_rate']}" if res['win_rate'] is not None else "—")
                    pf = (f"{res['profit_factor']}" if res['profit_factor'] is not None else "—")
                    tt = (f"{res['t_taker']}" if res['t_taker'] is not None else "—")
                    ahm = (f"{res['avg_hold_min']}" if res['avg_hold_min'] is not None else "—")
                    print(f"[{arm} {gran} {sym} {wname}] n={res['trades']} "
                          f"信号 {len(sigs)}/{len(sigs_all[sym])} 胜率={wr} "
                          f"盈亏比={pf} Taker {res['taker_net_pct']*100:+.2f}% "
                          f"(t={tt}, MDD {res['taker_max_dd']*100:.2f}%) | "
                          f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                          f"每笔毛利={gpt} 成本={res['taker_cost_sum']:+.0f} "
                          f"持仓={ahm}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均 + pooled t ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label, _ in ARMS:
        for gran, _, _, _, _, windows, _ in GRANS_SHORT:
            for wname, _ in windows:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                wr = (sum((r["win_rate"] or 0) * r["trades"] for r in rs) / nt) if nt else None
                print(f"  {arm} {gran} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                      f"每笔毛利 {gt/nt:+.2f} USDT 胜率 {wr:.3f}" if wr is not None else
                      f"  {arm} {gran} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} 每笔毛利 — 胜率 —")
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for arm, label, _ in ARMS:
        for gran, _, _, _, _, windows, _ in GRANS_SHORT:
            full = windows[0][0]
            trs = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
            gross = [t["price_pnl"] - t["funding_cost_usdt"] for t in trs]
            print(f"  {arm} {gran}（{full}）：n={len(trs)} "
                  f"Taker pooled t={r20.t_value([t['pnl'] / r20.START_EQUITY for t in trs])} / "
                  f"M1 pooled t={r20.t_value([t['pnl_maker_m1'] / r20.START_EQUITY for t in trs])} / "
                  f"毛利逐笔 t={r20.t_value([g / r20.START_EQUITY for g in gross])}")

    # ---- 对照 1 全窗口复核（C1F）：只为核对引擎 vs 第九轮已发表数字 ----
    print("\n=== 复核 C1F：原版 F1 全窗口 vs 第九轮 TP=2.0 已发表数字 ===")
    n_ok = n_tot = 0
    for gran, data, sigc, bpd, wname in (("1h", data1h, sigc_1h, 24, "365d"),
                                         ("15m", data15, sigc_15, 96, "103d")):
        for sym in ALTS:
            bars, funding = data[sym]
            trades, curve, _ = r20.simulate_f1(sym, bars, sigc[sym], funding,
                                               None, 2, "F1-nofilter", bpd)
            res = r20.summarize(sym, trades, curve, "F1-nofilter", len(sigc[sym]))
            pub = PUBLISHED_CTRL1[gran][sym]
            diff = res["taker_net_pct"] - pub
            ok = abs(diff) < 0.0005
            n_ok += ok
            n_tot += 1
            print(f"  C1F {gran} {sym}：本轮 {res['taker_net_pct']*100:+.2f}% vs "
                  f"已发表 {pub*100:+.2f}%  误差 {diff*100:+.3f}pp {'✓' if ok else '✗ FAIL'}")
            res.update({"arm": "C1F", "variant": "F1-nofilter", "family": "F1",
                        "tp_mult": TP_MULT, "granularity": gran, "split": wname,
                        "days": 365 if gran == "1h" else 103,
                        "signals_total": len(sigc[sym]), "signals_pass": len(sigc[sym]),
                        "signal_pass_rate": 1.0})
            all_results.append(res)
    print(f"复核：{n_ok}/{n_tot} 一致（误差 <0.05pp）。")

    # ---- 首笔 X 交易人工核对材料 ----
    xtr = [t for t in all_trades if t["arm"] == "X" and t["granularity"] == "1h"]
    xtr.sort(key=lambda t: t["entry_t"])
    if xtr:
        t0 = xtr[0]
        print("\n=== 首笔 X-1h 交易（人工核对用）===")
        print(f"  {t0['symbol']} 方向={'LONG' if t0['direction'] == 1 else 'SHORT'} "
              f"入场 {datetime.fromtimestamp(t0['entry_t'], timezone.utc)} "
              f"价格 {t0['entry']} 止损 {t0['stop']:.6f} 止盈 {t0['tp']:.6f} "
              f"ATR {t0['atr']:.6f} 出场 {t0['exit']}（{t0['reason']}） "
              f"价差 PnL {t0['price_pnl']:+.2f} Taker 净 {t0['pnl']:+.2f}")

    # ---- 写出 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round25_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round25_trades.csv"), "w", newline="") as f:
        fields = ["arm", "variant", "family", "tp_mult", "granularity", "split",
                  "symbol", "direction", "entry_t", "entry", "stop", "tp", "atr",
                  "notional", "margin", "exit_t", "exit", "reason", "hold_min",
                  "price_pnl", "funding_cost_usdt", "cost_usdt", "cost_maker_usdt",
                  "pnl", "pnl_maker_m1", "pnl_pct_equity", "entry_hour_utc"]
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["granularity"], x["entry_t"])):
            w.writerow({k: (datetime.fromtimestamp(t[k], timezone.utc).isoformat()
                            if k in ("entry_t", "exit_t") and t[k] else t.get(k))
                        for k in fields})
    print("\n已写入：data/gate_iter_round25_summary.json（"
          f"{len(all_results)} 条）/ data/gate_iter_round25_trades.csv（{len(all_trades)} 笔）")
    for fn in ("gate_iter_round25_summary.json", "gate_iter_round25_trades.csv"):
        with open(os.path.join(DATA_DIR, fn), "rb") as f:
            print(f"  md5 {fn}: {hashlib.md5(f.read()).hexdigest()}")


if __name__ == "__main__":
    main()
