#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gate 日内策略深化研究（全模拟，不下单、不开户、不碰真钱）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约。BTC/ETH/SOL。
前置结论：ORB+VWAP+ATR 组合策略 15m、90 天、1x 平均 -2.12%，
亏损几乎全是手续费，毛盈亏基本为零。

本次深化（任务要求逐项落实）：
  1. 窗口拉长到 180 天。实测发现 Gate 15m K 线接口有硬限制：
     "Candlestick too long ago. Maximum 10000 points recently are allowed"，
     15m 10000 根 ≈ 104 天，2026-08-05 可取、2026-08-01 已报错，
     所以 180 天 15m 从 Gate 取不到（不是没试，是接口不让）。
     改用 30m K 线做 180 天主验证（30m 10000 根 ≈ 208 天，
     2026-05-20 可取），窗口 2026-05-20 ~ 2026-11-15，共 180 个完整 UTC 日。
     30m 版策略是 15m 版的同逻辑平移（ORB 1h = 2 根 30m，
     ATR(14) 改为 30m，VWAP 同口径），不是同一根 K 线，不能直接
     把 30m 的数字说成 15m 的数字，报告里分开写。
     同时 15m 原口径保留 90 天对照（2026-08-18~11-15）。
     180 天分两半：前 90 天 2026-05-20~08-17（样本内 A），
     后 90 天 2026-08-18~11-15（样本内 B / 也是原 15m 窗口）。
     变体是任务下达前就定好的，不是看数据后挑的，所以两半
     都可当作未调参的验证；但基策略的设计灵感来自后 90 天，
     后 90 天对基策略不是严格样本外，报告里如实说明。
     资金费率接口另有限制：from 早于 180 天报错
     "from time exceeds 180-day limit"，2026-05-20 报错、
     2026-05-21 可取，故资金费率从 2026-05-21 起取，
     2026-05-20 当天的资金费按 0 计（影响约 0.01% 名义，可忽略，已注明）。
  2. 变体（全部 30m、180 天、1x、同一成本口径）：
     V0 基准 ORB+VWAP+ATR，止盈 2x ATR
     V1 止盈 3x ATR
     V2 去掉 VWAP 反穿出场（只用止损/止盈/收盘平仓）
     V3a ORB 窗口 30 分钟（1 根 30m）
     V3b ORB 窗口 2 小时（4 根 30m）
     V4 成交量过滤：突破那根 K 线成交量 > 前 20 根均量
  3. 新思路（全部 30m、180 天、1x、同一成本口径）：
     N1 资金费率结算点套利（日内版）：只做 08:00 / 16:00 UTC
        两个结算点（00:00 的那笔入场在前一天 23:00，会跨 UTC 日，
        为守住“日内”定义而跳过）。决策用上一结算点的费率
        （无前视）：上一期 > +0.005% 则做空收钱，< -0.005% 则做多，
        提前 1 小时入场、结算后 30 分钟出场。持仓约 1.5 小时。
        为什么前面没试：前面只把资金费当成本项扣，没把它当信号；
        日内版 1 个结算点只能收 1 次费，成本占比极高，事先就
        预期会亏，测它是为了把“行不行”算清楚，不是为找亮点。
     N2 亚洲时段突破（伦敦开盘动量）：区间 = 00:00-08:00 UTC
        亚盘 16 根 30m 的高低点，08:00 后突破 + VWAP 同向才做，
        止损 1x ATR / 止盈 2x ATR，每天每币最多 1 笔。
        为什么前面没试：前面 ORB 只用了 1 小时开盘区间，
        没用过 8 小时亚盘区间、没区分过交易时段；加密市场
        24 小时交易但波动仍有亚欧美时段结构，值得单独测。
  4. 成本分析：Maker 挂单（Gate API 实测 maker -0.01%，即返佣）
     代替 Taker（0.075% + 滑点 0.05%/边），按成交率 100%/70%/50%
     × 逆向选择折扣 0%/25%/50% 做情景表，不假设 100% 成交。
  5. 结论诚实：180 天里样本外有没有赚钱的策略，有就报，
     没有就直说没有，不硬凑。

成本口径（与前置一致）：
  Taker 一轮 = 名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
  资金费按实际费率计。仓位：每笔保证金 10% 权益，1x，
  每天每币最多 1 笔（N1 除外：每天最多 2 笔，即两个结算点），
  当天最后一根 30m（23:30）收盘强制平仓、不过夜。
  强平检查保留（1x 下远小于强平线，实测应为 0）。

运行：python3 gate_strategy_research.py
输出：终端打印全部表 + data/gate_research_summary.json
      + data/gate_research_trades.csv
缓存：data/gate_30m_180d_{SYM}.csv, data/gate_funding_180d_{SYM}.json
"""
import csv
import json
import math
import os
import statistics
import time
import urllib.request
from datetime import datetime, timezone, timedelta

BASE = "https://api.gateio.ws/api/v4"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005}
TAKER = 0.00075
SLIPPAGE = 0.0005
ROUNDTRIP_COST = (TAKER + SLIPPAGE) * 2  # 0.25% 名义
MAKER_FEE = -0.0001  # Gate API 实测 maker -0.01%（返佣）
MAKER_ROUNDTRIP = MAKER_FEE * 2  # -0.02% 名义（假设挂单成交、无滑点）
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
START_DAY = datetime(2026, 5, 20, tzinfo=timezone.utc)
END_DAY = datetime(2026, 11, 16, tzinfo=timezone.utc)  # 不含，窗口 2026-05-20~11-15
SPLIT_DAY = datetime(2026, 8, 18, tzinfo=timezone.utc)  # 前 90 天 / 后 90 天分界
ATR_PERIOD = 14


def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "gate-research/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles_30m(contract):
    path = os.path.join(DATA_DIR, f"gate_30m_180d_{contract}.csv")
    if os.path.exists(path):
        with open(path, newline="") as f:
            rows = list(csv.DictReader(f))
        bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
                 "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
                 "sum": float(r["sum"])} for r in rows]
        if bars and bars[0]["t"] <= int(START_DAY.timestamp()) + 1800 and \
                bars[-1]["t"] >= int((END_DAY - timedelta(minutes=30)).timestamp()):
            print(f"[{contract}] 30m K 线用缓存：{len(bars)} 根 "
                  f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
                  f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
            return bars
    bars = []
    cur = START_DAY
    while cur < END_DAY:
        nxt = min(cur + timedelta(days=7), END_DAY)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=30m"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] 30m K 线已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
    return bars


def fetch_funding_180d(contract):
    path = os.path.join(DATA_DIR, f"gate_funding_180d_{contract}.json")
    if os.path.exists(path):
        with open(path) as f:
            raw = json.load(f)
        out = {int(k): float(v) for k, v in raw.items()}
        if out and min(out) <= int(datetime(2026, 5, 22, tzinfo=timezone.utc).timestamp()):
            print(f"[{contract}] 资金费率用缓存：{len(out)} 条")
            return out
    out = {}
    # 资金费率 from 早于 180 天会报错，实测 2026-05-20 报错、05-21 可取，
    # 故从 05-21 起取；05-20 当天按 0 计（已在文档注明）。
    cur = datetime(2026, 5, 21, tzinfo=timezone.utc)
    while cur < END_DAY:
        nxt = min(cur + timedelta(days=30), END_DAY)
        url = (f"{BASE}/futures/usdt/funding_rate?contract={contract}&limit=100"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            t = int(d["t"])
            t = (t // 28800) * 28800
            out[t] = float(d["r"])
        cur = nxt
        time.sleep(0.3)
    with open(path, "w") as f:
        json.dump(out, f)
    print(f"[{contract}] 资金费率已取：{len(out)} 条 "
          f"{datetime.fromtimestamp(min(out), timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(max(out), timezone.utc).date()}")
    return out


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def summarize(equity, start, trades, label):
    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] <= 0]
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0.0
    avg_loss = abs(sum(t["pnl"] for t in losses) / len(losses)) if losses else 0.0
    return {
        "label": label,
        "days": None,
        "trades": len(trades),
        "win_rate": round(len(wins) / len(trades), 4) if trades else None,
        "net_return": round((equity - start) / start, 4),
        "final_equity": round(equity, 2),
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2),
        "avg_loss_usdt": round(avg_loss, 2),
        "total_pnl": round(sum(t["pnl"] for t in trades), 2),
        "liquidations": sum(1 for t in trades if t.get("liquidated")),
    }


def add_mdd(result, curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    result["max_dd"] = round(mdd, 4)
    return result


# ---------------------------------------------------------------- 通用 ORB+VWAP+ATR 回测（30m）
def run_orb_variant(bars, funding, symbol, days_subset, orb_bars=2, tp_atr=2.0,
                    use_vwap_exit=True, volume_filter=False, leverage=1,
                    entry_start_hour=None, entry_end_hour=20.0, label=""):
    """days_subset: 日期集合（None = 全部）。返回 (result, trades, curve)。
    交易记录含 price_pnl / cost_usdt / funding_cost_usdt，供 Maker 分析用。"""
    atr = atr_wilder(bars)
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 48)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / leverage - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    if entry_start_hour is None:
        entry_start_hour = orb_bars * 0.5  # ORB 结束时刻（UTC 小时）

    for day, day_bars in days.items():
        cum_pv, cum_v, vwap = 0.0, 0.0, [None] * len(day_bars)
        for i, b in enumerate(day_bars):
            tp = (b["h"] + b["l"] + b["c"]) / 3
            cum_pv += tp * b["sum"]
            cum_v += b["sum"]
            vwap[i] = cum_pv / cum_v if cum_v else b["c"]
        or_high = max(b["h"] for b in day_bars[:orb_bars])
        or_low = min(b["l"] for b in day_bars[:orb_bars])
        or_range = or_high - or_low
        pos = None
        trades_today = 0
        day_start_equity = equity
        day_pnl = 0.0
        day_stopped = False
        armed = {1: True, -1: True}

        def funding_cost(tr):
            cost = 0.0
            ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
            for h in (8, 16):
                s = int((ds + timedelta(hours=h)).timestamp())
                if tr["entry_t"] < s <= tr["exit_t"] and s in funding:
                    cost += funding[s] * tr["notional"] * (1 if tr["direction"] == 1 else -1)
            return cost

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost(tr)
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (TAKER + SLIPPAGE)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                if pos["direction"] == 1:
                    adv = (pos["entry"] - b["l"]) / pos["entry"]
                else:
                    adv = (b["h"] - pos["entry"]) / pos["entry"]
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                    elif use_vwap_exit and b["c"] < vwap[i]:
                        close_trade(pos, b["t"], b["c"], "vwap_recross"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                    elif use_vwap_exit and b["c"] > vwap[i]:
                        close_trade(pos, b["t"], b["c"], "vwap_recross"); exited = True
                if exited:
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 1 \
                    and i >= orb_bars and entry_start_hour <= hour < entry_end_hour \
                    and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if or_range < 0.4 * a:
                    continue
                if not (0.0005 <= a / b["c"] <= 0.010):
                    continue
                sig = 0
                if or_low <= b["c"] <= or_high:
                    armed[1] = armed[-1] = True
                if b["c"] > or_high and b["c"] > vwap[i] and armed[1]:
                    sig = 1
                elif b["c"] < or_low and b["c"] < vwap[i] and armed[-1]:
                    sig = -1
                if sig == 0:
                    continue
                if volume_filter:
                    # 突破那根 K 线成交量 > 前 20 根均量（全局序列）
                    if gi < 20:
                        continue
                    avg_v = sum(bars[j]["v"] for j in range(gi - 20, gi)) / 20
                    if bars[gi]["v"] <= avg_v:
                        continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * leverage
                worst = notional * (a / entry + ROUNDTRIP_COST)
                if worst / equity > 0.01:
                    continue
                stop = entry - a if sig == 1 else entry + a
                tp = entry + tp_atr * a if sig == 1 else entry - tp_atr * a
                armed[sig] = False
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "price_pnl": 0.0, "hold_min": None,
                       "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    res = summarize(equity, START_EQUITY, trades, label)
    res["symbol"] = symbol
    res["days"] = len(days)
    res["avg_hold_min"] = round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None
    add_mdd(res, curve)
    return res, trades


# ---------------------------------------------------------------- N1 资金费率结算点套利（日内版）
def run_funding_settlement(bars, funding, symbol, days_subset, leverage=1, label="N1-funding"):
    """只做 08:00 / 16:00 UTC 结算点。决策用上一结算点费率（无前视）：
    上一期 > +0.005% 做空收钱，< -0.005% 做多；提前 1 小时入场，
    结算后 30 分钟（下一根 30m 收盘）出场。每天最多 2 笔。"""
    days = group_days(bars, 48)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    # 结算点时间戳列表（排序）
    settles = sorted(funding.keys())
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        for h_settle in (8, 16):
            ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
            s_ts = int((ds + timedelta(hours=h_settle)).timestamp())
            # 上一结算点费率（决策信号，无前视）
            prev = [t for t in settles if t < s_ts]
            if not prev:
                continue
            prev_rate = funding[max(prev)]
            if prev_rate > 0.00005:
                direction = -1
            elif prev_rate < -0.00005:
                direction = 1
            else:
                continue
            # 入场：结算前 1 小时那根 30m 的开盘价（07:00 / 15:00 那根）
            entry_bar = None
            exit_bar = None
            for b in day_bars:
                dt = datetime.fromtimestamp(b["t"], timezone.utc)
                if dt.hour == h_settle - 1 and dt.minute == 0:
                    entry_bar = b
                if dt.hour == h_settle and dt.minute == 30:
                    exit_bar = b
            if entry_bar is None or exit_bar is None:
                continue
            if day_pnl / day_start_equity <= -0.02:
                continue
            margin = MARGIN_FRAC * equity
            notional = margin * leverage
            entry = entry_bar["o"]
            exit_price = exit_bar["c"]
            # 实际收到的资金费：用本次结算点的实现费率计
            realized = funding.get(s_ts, 0.0)
            funding_gain = realized * notional * (-direction)  # 做空且费率>0 收钱
            # 注意：funding_gain 的符号——做空 direction=-1，费率>0 时空头收钱为正：
            # 上式 -direction=+1，realized>0 => 正，正确；做多 direction=+1，
            # 费率<0 时多头收钱：-direction=-1，realized<0 => 正，正确。
            move = (exit_price - entry) / entry * direction
            price_pnl = notional * move
            cost = notional * ROUNDTRIP_COST
            pnl = price_pnl - cost + funding_gain
            equity += pnl
            day_pnl += pnl
            trades.append({"symbol": symbol, "variant": label, "direction": direction,
                           "entry_t": entry_bar["t"], "entry": entry,
                           "exit_t": exit_bar["t"], "exit": exit_price,
                           "stop": None, "tp": None, "atr": None,
                           "notional": notional, "margin": margin, "pnl": pnl,
                           "liquidated": False, "reason": "funding_settle",
                           "funding_cost_usdt": -funding_gain,
                           "cost_usdt": cost, "price_pnl": price_pnl,
                           "hold_min": 90.0, "pnl_pct_equity": pnl / day_start_equity,
                           "prev_rate": prev_rate, "realized_rate": realized})
            curve.append(equity)
    res = summarize(equity, START_EQUITY, trades, label)
    res["symbol"] = symbol
    res["days"] = len(days)
    res["avg_hold_min"] = 90.0 if trades else None
    add_mdd(res, curve)
    return res, trades


def run_funding_maker_variant(trades):
    """N1 的 Maker 成本版：只改成本项（taker 0.25% -> maker -0.02%），
    其余（价格盈亏、资金费）不变，算 100% 成交下的净收益。"""
    total = 0.0
    for t in trades:
        maker_cost = t["notional"] * MAKER_ROUNDTRIP  # 负数 = 返佣
        total += t["price_pnl"] - maker_cost + (-t["funding_cost_usdt"])
    return total


# ---------------------------------------------------------------- 主流程
def main():
    print("Gate 日内策略深化研究（30m、180 天、全模拟）")
    print(f"窗口：{START_DAY.date()} ~ {END_DAY.date() - timedelta(days=1)}，"
          f"前 90 天 {START_DAY.date()}~{SPLIT_DAY.date() - timedelta(days=1)}，"
          f"后 90 天 {SPLIT_DAY.date()}~{END_DAY.date() - timedelta(days=1)}")
    data = {}
    for sym in SYMBOLS:
        bars = fetch_candles_30m(sym)
        funding = fetch_funding_180d(sym)
        data[sym] = (bars, funding)
        days = group_days(bars, 48)
        print(f"[{sym}] 完整交易日：{len(days)} 天，"
              f"首日 {min(days)} 末日 {max(days)}")

    # ---- Regime 描述 ----
    print("\n=== Regime：180 天市场是什么样 ===")
    for sym in SYMBOLS:
        bars, _ = data[sym]
        days = group_days(bars, 48)
        dates = sorted(days)
        first_half = [d for d in dates if d < SPLIT_DAY.date()]
        second_half = [d for d in dates if d >= SPLIT_DAY.date()]
        def regime(ds):
            closes = [days[d][-1]["c"] for d in ds]
            hi = max(b["h"] for d in ds for b in days[d])
            lo = min(b["l"] for d in ds for b in days[d])
            import math as _m
            rets = [(closes[i] - closes[i - 1]) / closes[i - 1] for i in range(1, len(closes))]
            vol = (sum(r * r for r in rets) / len(rets)) ** 0.5 * _m.sqrt(365) if rets else 0
            return (f"{ds[0]}~{ds[-1]}：{closes[0]:.2f}->{closes[-1]:.2f} "
                    f"({(closes[-1]/closes[0]-1)*100:+.1f}%)，区间 {lo:.2f}~{hi:.2f} "
                    f"(振幅 {(hi/lo-1)*100:.1f}%)，日收益年化波动 {vol*100:.0f}%")
        print(f"[{sym}] 前 90 天 {regime(first_half)}")
        print(f"[{sym}] 后 90 天 {regime(second_half)}")

    variants = [
        ("V0-base-TP2", dict()),
        ("V1-TP3", dict(tp_atr=3.0)),
        ("V2-noVWAPexit", dict(use_vwap_exit=False)),
        ("V3a-ORB30m", dict(orb_bars=1)),
        ("V3b-ORB2h", dict(orb_bars=4)),
        ("V4-volume", dict(volume_filter=True)),
    ]
    all_results = []
    all_trades = []
    # 每个变体：全 180 天 + 前半 + 后半（各重置 10 万权益）
    for label, kwargs in variants:
        for sym in SYMBOLS:
            bars, funding = data[sym]
            days_all = set(group_days(bars, 48).keys())
            days_a = {d for d in days_all if d < SPLIT_DAY.date()}
            days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
            for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
                res, trades = run_orb_variant(bars, funding, sym, subset, label=label, **kwargs)
                res["split"] = split_name
                all_results.append(res)
                if split_name == "180d":
                    for t in trades:
                        t["variant"] = label
                        t["split"] = "180d"
                    all_trades.extend(trades)
                print(f"[{label} {sym} {split_name}] 笔数={res['trades']} 胜率={res['win_rate']} "
                      f"净收益={res['net_return']*100:.2f}% 盈亏比={res['profit_factor']} "
                      f"最大回撤={res['max_dd']*100:.2f}% 平均持仓={res['avg_hold_min']}分钟")

    # ---- 新思路 ----
    print("\n=== 新思路 ===")
    for sym in SYMBOLS:
        bars, funding = data[sym]
        days_all = set(group_days(bars, 48).keys())
        days_a = {d for d in days_all if d < SPLIT_DAY.date()}
        days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
        for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
            res, trades = run_funding_settlement(bars, funding, sym, subset, label="N1-funding")
            res["split"] = split_name
            all_results.append(res)
            if split_name == "180d":
                for t in trades:
                    t["split"] = "180d"
                all_trades.extend(trades)
            print(f"[N1-funding {sym} {split_name}] 笔数={res['trades']} 胜率={res['win_rate']} "
                  f"净收益={res['net_return']*100:.2f}% 盈亏比={res['profit_factor']} "
                  f"最大回撤={res['max_dd']*100:.2f}%")
    # N2：亚洲时段突破 = ORB 16 根 + 入场起点 08:00
    for sym in SYMBOLS:
        bars, funding = data[sym]
        days_all = set(group_days(bars, 48).keys())
        days_a = {d for d in days_all if d < SPLIT_DAY.date()}
        days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
        for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
            res, trades = run_orb_variant(bars, funding, sym, subset, orb_bars=16,
                                          tp_atr=2.0, label="N2-asian", entry_start_hour=8.0)
            res["split"] = split_name
            all_results.append(res)
            if split_name == "180d":
                for t in trades:
                    t["variant"] = "N2-asian"
                    t["split"] = "180d"
                all_trades.extend(trades)
            print(f"[N2-asian {sym} {split_name}] 笔数={res['trades']} 胜率={res['win_rate']} "
                  f"净收益={res['net_return']*100:.2f}% 盈亏比={res['profit_factor']} "
                  f"最大回撤={res['max_dd']*100:.2f}% 平均持仓={res['avg_hold_min']}分钟")

    # ---- 汇总表：三币平均（1x）----
    print("\n=== 汇总：三币平均净收益 1x（各币独立 10 万 USDT）===")
    labels = [v[0] for v in variants] + ["N1-funding", "N2-asian"]
    for label in labels:
        for split_name in ["180d", "前90d", "后90d"]:
            rs = [r for r in all_results if r["label"] == label and r["split"] == split_name]
            if not rs:
                continue
            avg = sum(r["net_return"] for r in rs) / len(rs)
            tot = sum(r["trades"] for r in rs)
            wrs = [r["win_rate"] for r in rs if r["win_rate"] is not None]
            pfs = [r["profit_factor"] for r in rs if r["profit_factor"] is not None]
            mdds = [r["max_dd"] for r in rs]
            print(f"{label} {split_name}：平均净收益 {avg*100:+.2f}%  总笔数 {tot}  "
                  f"胜率 {min(wrs)*100:.1f}%~{max(wrs)*100:.1f}%  "
                  f"盈亏比 {min(pfs):.2f}~{max(pfs):.2f}  最大回撤 {min(mdds)*100:.2f}%~{max(mdds)*100:.2f}%")

    # ---- Maker 成本分析（以 V0 180d 为例）----
    print("\n=== Maker 成本分析（V0，180d，1x）===")
    for sym in SYMBOLS:
        bars, funding = data[sym]
        res, trades = run_orb_variant(bars, funding, sym, None, label="V0-base-TP2")
        n = len(trades)
        taker_cost = sum(t["cost_usdt"] for t in trades)
        gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)  # 扣资金费后的毛利
        # Maker 100% 成交：成本 = 名义 x (-0.02%)，即返佣
        maker_pnl_100 = gross - sum(t["notional"] * MAKER_ROUNDTRIP for t in trades)
        print(f"[{sym}] 笔数={n} Taker净={res['net_return']*100:+.2f}% "
              f"成本拖累={taker_cost/1000:.2f}%权益 毛利(扣资金费后)={gross/1000:+.2f}%权益 "
              f"Maker100%成交净={maker_pnl_100/1000:+.2f}%权益（省 {maker_pnl_100/1000-res['net_return']*100:+.2f}pp）")
        # 情景：成交率 × 逆向选择折扣（对价格毛利打折）
        # 逆向选择方向：挂单成交的交易，毛利比平均更差——毛利为正时打折扣
        # （乘 1-hair），毛利为负时更负（减 hair*|毛利|），不能反向变好。
        # 公式：filled_gross = gross - hair * abs(gross)
        for fill in (1.0, 0.7, 0.5):
            row = []
            for hair in (0.0, 0.25, 0.5):
                filled_gross = gross - hair * abs(gross)
                exp = fill * (filled_gross - sum(t["notional"] * MAKER_ROUNDTRIP for t in trades))
                row.append(f"折扣{int(hair*100)}%:{exp/1000:+.2f}%")
            print(f"    成交率 {int(fill*100)}% -> " + "  ".join(row) + "  （%权益，错失的交易按 0 计）")
        # N1 的 Maker 版（100% 成交）
        res_n1, trades_n1 = run_funding_settlement(bars, funding, sym, None)
        maker_n1 = run_funding_maker_variant(trades_n1)
        print(f"    [N1-funding {sym}] Taker净={res_n1['net_return']*100:+.2f}% "
              f"Maker100%成交净={maker_n1/1000:+.2f}%权益")

    # ---- 落盘 ----
    with open(os.path.join(DATA_DIR, "gate_research_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_research_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "split", "symbol", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_usdt", "price_pnl_usdt",
                    "cost_usdt", "funding_cost_usdt", "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["symbol"], x.get("variant", ""))):
            w.writerow([t.get("variant", ""), t.get("split", ""), t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t.get("exit"), t["notional"], round(t["pnl"], 2),
                        round(t.get("price_pnl", 0), 2), round(t.get("cost_usdt", 0), 2),
                        round(t.get("funding_cost_usdt", 0), 2), t.get("reason", ""),
                        t.get("liquidated", False), t.get("hold_min")])
    print("\n汇总已写入：data/gate_research_summary.json")
    print("明细已写入：data/gate_research_trades.csv")
    print("模拟结束：本脚本不下单、不开户、不碰真钱。")


if __name__ == "__main__":
    main()
