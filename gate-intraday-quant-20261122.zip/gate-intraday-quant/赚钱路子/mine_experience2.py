#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回测经验挖掘 Part 2（方法修正版）
发现阶段：去标识化——汇成一个池，删币种、删时间戳/小时/日期；
只留结构特征（方向、入场上下文、确认强度、ATR倍数、毛利、成本、市况结构）。
ZEC 与 17:00 UTC 只作验证用，训练池排除。
验证阶段：解开币种/时间，检验模式是否跨币种、跨时间成立；单币/单时段成立=抄数据，丢弃。
不新开回测轮、不调参、不宣称 edge。
"""
import bisect, csv, glob, json, math, os, statistics, sys
from collections import defaultdict
from datetime import datetime, timezone

sys.path.insert(0, os.path.expanduser('~/workspace/赚钱路子'))
from mine_experience import load_trades, dist_stats, tstat

DATA = os.path.expanduser('~/workspace/赚钱路子/data')
COST_LINE = 25.0

# ---------------- 价格缓存：1h（20币，365d） ----------------
def load_1h_cache():
    cache = {}
    for f in sorted(glob.glob(os.path.join(DATA, 'gate_1h_365d_*_USDT.csv'))):
        sym = os.path.basename(f).replace('gate_1h_365d_', '').replace('_USDT.csv', '')
        bars = []
        with open(f, newline='', encoding='utf-8') as fh:
            for row in csv.DictReader(fh):
                bars.append((int(float(row['t'])), float(row['o']), float(row['h']),
                             float(row['l']), float(row['c'])))
        bars.sort()
        ts = [b[0] for b in bars]
        closes = [b[4] for b in bars]
        # Wilder ATR14
        atr = [float('nan')] * len(bars)
        trs = []
        for i, b in enumerate(bars):
            if i == 0:
                trs.append(b[2] - b[3])
            else:
                pc = bars[i - 1][4]
                trs.append(max(b[2] - b[3], abs(b[2] - pc), abs(b[3] - pc)))
        if len(trs) >= 14:
            atr[13] = sum(trs[:14]) / 14
            for i in range(14, len(trs)):
                atr[i] = (atr[i - 1] * 13 + trs[i]) / 14
        atr_med = statistics.median([a for a in atr if a == a]) if any(a == a for a in atr) else float('nan')
        cache[sym] = dict(ts=ts, bars=bars, closes=closes, atr=atr, atr_med=atr_med)
    return cache

def bar_before(cache_sym, epoch):
    """返回 entry 时刻之前最后一根已收盘 1h bar 的下标（bar 的 t <= epoch-1），无则 None"""
    ts = cache_sym['ts']
    i = bisect.bisect_right(ts, epoch - 1) - 1
    return i if i >= 0 else None

def close_at(cache_sym, epoch):
    i = bar_before(cache_sym, epoch)
    return cache_sym['closes'][i] if i is not None else None

def enrich(trades, cache):
    btc = cache.get('BTC')
    n_no_feat = 0
    for t in trades:
        t['feat'] = {}
        if t['entry_dt'] is None:
            n_no_feat += 1
            continue
        ep = int(t['entry_dt'].timestamp())
        sym = t['symbol']
        cs = cache.get(sym)
        if cs is None or btc is None:
            n_no_feat += 1
            continue
        i = bar_before(cs, ep)
        ib = bar_before(btc, ep)
        if i is None or ib is None or i < 3 or ib < 3:
            n_no_feat += 1
            continue
        # 前 2h 自身收益、BTC 收益（收盘价口径）
        own_2h = cs['closes'][i] / cs['closes'][i - 2] - 1
        btc_2h = btc['closes'][ib] / btc['closes'][ib - 2] - 1
        own_24h = cs['closes'][i] / cs['closes'][max(0, i - 24)] - 1 if i >= 24 else float('nan')
        # ATR 与波动比
        atr = cs['atr'][i]
        vol_ratio = (atr / cs['atr_med']) if (atr == atr and cs['atr_med'] == cs['atr_med'] and cs['atr_med'] > 0) else float('nan')
        # 确认强度：入场前最后一根已收盘 1h 的逆向影线（ATR单位）与实体
        b = cs['bars'][i]
        o, h, l, c = b[1], b[2], b[3], b[4]
        if atr == atr and atr > 0:
            wick_dir = ((h - c) / atr) if t['direction'] == -1 else ((c - l) / atr)
            wick_opp = ((c - l) / atr) if t['direction'] == -1 else ((h - c) / atr)
            body = abs(c - o) / atr
        else:
            wick_dir = wick_opp = body = float('nan')
        # 实现 R（毛利 / 1h ATR 名义）：atr*notional/entry
        try:
            entry_px = float(t['entry_price']) if t['entry_price'] not in (None, '') else float('nan')
            notional = 10000.0
            r_mult = (t['gross'] / (atr * notional / entry_px)) if (atr == atr and entry_px == entry_px and entry_px > 0) else float('nan')
        except Exception:
            r_mult = float('nan')
        t['feat'] = dict(own_2h=own_2h, btc_2h=btc_2h, own_24h=own_24h,
                         vol_ratio=vol_ratio, wick_dir=wick_dir, wick_opp=wick_opp,
                         body=body, r_mult=r_mult, atr=atr)
    return n_no_feat

def month_regime(cache):
    """BTC 月度市况：收益（首收->尾收）与波动（小时 log 收益标准差）"""
    btc = cache['BTC']
    bars = btc['bars']
    months = defaultdict(list)
    for b in bars:
        dt = datetime.fromtimestamp(b[0], tz=timezone.utc)
        months[dt.strftime('%Y-%m')].append(b)
    import math as _m
    vols = {}
    regs = {}
    for m, bs in sorted(months.items()):
        ret = bs[-1][4] / bs[0][4] - 1
        lrs = [_m.log(bs[i][4] / bs[i - 1][4]) for i in range(1, len(bs))]
        vol = statistics.pstdev(lrs) if len(lrs) > 1 else float('nan')
        vols[m] = vol
        regs[m] = ret
    med_vol = statistics.median(list(vols.values()))
    out = {}
    for m in regs:
        cls = 'up' if regs[m] > 0.05 else ('down' if regs[m] < -0.05 else 'flat')
        out[m] = dict(ret=regs[m], vol=vols[m], trend=cls,
                      volcls='high' if vols[m] > med_vol else 'low')
    return out, med_vol

def bucket_report(name, groups, min_n=30):
    print(f"\n=== {name} ===")
    print(f"{'bucket':34s} {'n':>6} {'mean':>8} {'med':>8} {'>25%':>6} {'>0%':>6} {'t':>6}")
    res = []
    for k, gs in sorted(groups.items(), key=lambda kv: -statistics.mean(kv[1]) if kv[1] else 0):
        if len(gs) < 1:
            continue
        d = dist_stats(gs)
        d['bucket'] = str(k)
        res.append(d)
        flag = '  <<<' if (len(gs) >= min_n and d['mean'] > COST_LINE and d['t'] > 2) else ''
        print(f"{str(k):34s} {d['n']:6d} {d['mean']:8.2f} {d['median']:8.2f} {d['frac_gt25']:6.2f} {d['frac_gt0']:6.2f} {d['t']:6.2f}{flag}")
    return res

def main():
    trades = load_trades()
    print(f"loaded rows: {len(trades)}")
    # ---- 去重：同一笔交易在多轮里作对照重跑，只留一份 ----
    seen = {}
    for t in trades:
        key = (t['symbol'], t['entry_dt'], t['direction'], round(t['gross'], 2))
        if key not in seen:
            seen[key] = t
    ded = list(seen.values())
    print(f"deduped distinct trades: {len(ded)} (removed {len(trades)-len(ded)} control duplicates)")
    # ---- 发现池：排除 ZEC 与 17:00 ----
    disc = [t for t in ded if t['symbol'] != 'ZEC' and t['entry_hour'] != 17]
    excl_zec = sum(1 for t in ded if t['symbol'] == 'ZEC')
    excl_h17 = sum(1 for t in ded if t['entry_hour'] == 17)
    print(f"discovery pool: {len(disc)} (excluded ZEC={excl_zec}, hour17={excl_h17})")
    cache = load_1h_cache()
    print(f"1h cache coins: {len(cache)}")
    n_nf = enrich(ded, cache)
    print(f"trades without price features: {n_nf}")
    regs, med_vol = month_regime(cache)
    print(f"BTC monthly median hourly vol: {med_vol:.5f}")
    for m, r in sorted(regs.items()):
        print(f"  {m}: ret={r['ret']*100:+6.1f}% vol={r['vol']:.5f} {r['trend']}/{r['volcls']}")
    for t in ded:
        t['regime'] = regs.get(t['month'] or '', {})
    # 只对发现池做 enrich 后的分析（特征已在 ded 上算好）
    pool = [t for t in disc if t['feat']]
    print(f"discovery pool with features: {len(pool)}")
    out = dict(n_total=len(trades), n_dedup=len(ded), n_disc=len(disc), n_pool=len(pool),
               monthly_regime={m: {k: (round(v, 5) if isinstance(v, float) else v) for k, v in r.items()} for m, r in regs.items()})
    json.dump(out, open('/tmp/mine2_meta.json', 'w', encoding='utf-8'), ensure_ascii=False, default=str)
    # 保存去重+特征池，供后续分析与报告复核
    import pickle
    with open('/tmp/mine2_pool.pkl', 'wb') as fh:
        pickle.dump(ded, fh)
    print("saved /tmp/mine2_meta.json and /tmp/mine2_pool.pkl")

if __name__ == '__main__':
    main()
