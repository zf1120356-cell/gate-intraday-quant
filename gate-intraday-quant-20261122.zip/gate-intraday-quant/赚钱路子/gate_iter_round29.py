#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十九轮：走前（walk-forward）机器学习方向预测（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（预注册检验，不是事后挑参）：
  全系列 40 个方向家族全是人工规则。第四轮诊断：1h 收益滞后自相关
  约等于 0、截面相关 0.004；BTC→山寨跟随相关只有 0.01~0.03 的量级。
  本轮换一个方法问题：非线性模型能不能从同一批特征里挖出人工规则
  没看到的东西？预期是挖不出来，但用最严格的走前检验一次性把
  “换个模型”这条线也闭上，而不是留一个“没试过机器学习”的尾巴。

跑前写死的规则（单组参数，不许用全样本挑，不许调参）：
  特征（每币、每根 1h，全部只用收盘时已知的量，严禁未来函数）：
    13 列：本币滞后 1/2/3/6/12 根收益率、BTC 滞后 1/2/3 根收益率、
    BTC 2h 涨幅、本币 ATR(14)/收盘价、RSI(14)、当前资金费率
    （最近一次结算点的值，2026-05-21 之前为 0）、小时哑变量
    （信号根 UTC 小时 ∈ {9,15} 为 1，否则 0，照搬第二十轮的发现，
    不许再筛小时）。
  目标：下一根 1h 收益率的符号（涨=1，跌=0），二分类。
  模型（两个都测，不许事后只报好的那个）：
    LR  逻辑回归（sklearn，C=1.0，lbfgs，max_iter=1000），特征用训练
        窗内均值/标准差标准化；
    RF  随机森林（sklearn，n_estimators=200，max_depth=3，
        random_state=29），特征不标准化。
  交易阈值（跑前写死，不许调）：P(涨) >= 0.55 做多，P(涨) <= 0.45
    做空，中间不开单。入场为信号根下一根 1h 开盘价。
  走前划分（跑前写死）：训练 90 天 → 测试 30 天 → 窗口滚动 30 天；
    测试窗起点为全年第 90/120/150/180/210/240/270/300/330 天，
    共 9 个测试窗；每个测试窗的模型只用该窗之前的 90 天训练数据，
    标准化参数也只在训练窗内算。测试期共 270 天
    （2026-02-14~2026-11-10），全年第 361~365 天（11-11~11-15）
    不在任何测试窗内，不用。
  交易规则（与 F1 家族同一引擎、同一口径）：
    止损 1xATR、止盈 2xATR（用户要求的 1:2）；最多持 4 根；
    每天每币最多 2 笔；当天 23:00 收盘强制平仓；单日 -2% 熔断；
    同根同时碰止损和止盈先判止损；成本 Taker 一轮名义 x 0.25%。
    引擎直接 import 第二十轮（simulate_f1 / summarize / atr_wilder），
    口径零漂移。
  四臂：
    ML-LR   主臂：逻辑回归走前预测；
    ML-RF   对照：随机森林走前预测；
    RND     对照 1：随机信号——每币每窗的信号数与 ML-LR 臂相同，
            信号根与方向随机抽（种子 20261118），其余规则一字相同，
            用来判断模型有没有比瞎猜强；
    F1      对照 2：原版 F1（第七轮规则，TP=2.0）在同一批测试日上
            的结果，用来判断 ML 相对最好人工规则有没有增值。
            F1 只做 7 个山寨（第七轮原样）；ML 三臂做全部 8 个币
            （含 BTC，模型预测的是每个币自己的下一根收益）。
  前后两半（按测试窗日期划分，不是按全年划分）：
    前半 135 天 2026-02-14~2026-06-28；后半 135 天 2026-06-29~2026-11-10。
    各窗口重置 10 万 USDT 虚拟权益（每币独立），与第二十轮口径一致。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。ML-LR 与 ML-RF 各为一个组合，
两个模型都通过才算整轮通过。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) F1 全 365 天复核：引擎 import 自第二十轮，F1 全期 Taker 逐币
      对照第九轮 TP=2.0 已发表数字（ETH +0.10% / SOL -1.29% /
      DOGE -3.72% / LINK -4.21% / XRP -3.66% / BNB -5.00% /
      ADA -0.93%），误差 <0.05pp。
  (b) 无未来函数检查：训练集最后一条样本的 bar 索引 < 测试集第一条
      样本的 bar 索引（脚本内 assert）；特征全部只用收盘时已知的量。
  (c) 首笔 ML-LR 交易人工核对触发链、入场、止损/止盈。
  (d) 脚本跑两遍，summary / trades / accuracy 三个文件的 md5 完全一致。

运行：python3 gate_iter_round29.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round29_summary.json
      + data/gate_iter_round29_trades.csv
      + data/gate_iter_round29_accuracy.json
"""
import csv
import json
import math
import os
import random
import sys
from datetime import datetime, timedelta, timezone

import numpy as np

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round20 as r20  # noqa: E402  引擎：simulate_f1 / summarize / 口径

from sklearn.ensemble import RandomForestClassifier  # noqa: E402
from sklearn.linear_model import LogisticRegression  # noqa: E402

SYMBOLS = r20.SYMBOLS
ALTS = r20.ALTS
SL_MULT = 1.0
TP_MULT = 2.0
MAX_HOLD = 4
MAX_PER_DAY = 2
PROB_LONG = 0.55   # 跑前写死，不许调
PROB_SHORT = 0.45  # 跑前写死，不许调
TRAIN_DAYS = 90
TEST_DAYS = 30
STEP_DAYS = 30
RND_SEED = 20261118
FEATURE_NAMES = ["r1", "r2", "r3", "r6", "r12",
                 "btc_r1", "btc_r2", "btc_r3", "btc_r2h",
                 "atr_rel", "rsi14", "funding", "hour_0915"]


def rsi_wilder(closes, period=14):
    n = len(closes)
    rsi = [None] * n
    if n <= period:
        return rsi
    gains = [0.0] * n
    losses = [0.0] * n
    for i in range(1, n):
        d = closes[i] - closes[i - 1]
        gains[i] = max(d, 0.0)
        losses[i] = max(-d, 0.0)
    avg_g = sum(gains[1:period + 1]) / period
    avg_l = sum(losses[1:period + 1]) / period
    rsi[period] = 100.0 - 100.0 / (1.0 + avg_g / avg_l) if avg_l > 0 else 100.0
    for i in range(period + 1, n):
        avg_g = (avg_g * (period - 1) + gains[i]) / period
        avg_l = (avg_l * (period - 1) + losses[i]) / period
        rsi[i] = 100.0 - 100.0 / (1.0 + avg_g / avg_l) if avg_l > 0 else 100.0
    return rsi


def funding_at(funding, t):
    """最近一次结算点 <= t 的资金费率；无则 0。"""
    best = None
    for k in funding:
        if k <= t and (best is None or k > best):
            best = k
    return funding[best] if best is not None else 0.0


def build_features(bars, btc_bars, atr, funding):
    """返回 X (n x 13)、y（下一根收益符号，最后一根为 None）、valid 布尔列。"""
    closes = np.array([b["c"] for b in bars], dtype=float)
    btc_closes = np.array([b["c"] for b in btc_bars], dtype=float)
    rsi = rsi_wilder(closes)
    n = len(bars)
    X = np.full((n, len(FEATURE_NAMES)), np.nan)
    y = [None] * n
    for i in range(n):
        if i < 14 or atr[i] is None or rsi[i] is None:
            continue
        dt = datetime.fromtimestamp(bars[i]["t"], timezone.utc)
        X[i] = [
            closes[i] / closes[i - 1] - 1,
            closes[i] / closes[i - 2] - 1,
            closes[i] / closes[i - 3] - 1,
            closes[i] / closes[i - 6] - 1,
            closes[i] / closes[i - 12] - 1,
            btc_closes[i] / btc_closes[i - 1] - 1,
            btc_closes[i] / btc_closes[i - 2] - 1,
            btc_closes[i] / btc_closes[i - 3] - 1,
            btc_closes[i] / btc_closes[i - 2] - 1,
            atr[i] / closes[i],
            rsi[i] / 100.0,
            funding_at(funding, bars[i]["t"]),
            1.0 if dt.hour in (9, 15) else 0.0,
        ]
        if i + 1 < n:
            y[i] = 1 if closes[i + 1] > closes[i] else 0
    valid = ~np.isnan(X).any(axis=1)
    return X, y, valid


def signals_from_probs(bars, atr, idxs, probs):
    """把测试窗内每根信号根的预测概率转成 simulate_f1 的 signals dict。"""
    sigs = {}
    for j, i in enumerate(idxs):
        p = probs[j]
        if p >= PROB_LONG:
            direction = 1
        elif p <= PROB_SHORT:
            direction = -1
        else:
            continue
        if i + 1 >= len(bars):
            continue
        sigs[bars[i + 1]["t"]] = {"direction": direction, "atr": atr[i],
                                  "sl_mult": SL_MULT, "tp_mult": TP_MULT,
                                  "max_hold": MAX_HOLD}
    return sigs


def main():
    print("盈利策略迭代 · 第二十九轮：走前机器学习方向预测（全模拟）")
    print("主臂 ML-LR 逻辑回归；对照 ML-RF 随机森林、RND 随机信号、F1 原版。")
    print("止损 1xATR / 止盈 2xATR；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data = {}
    for sym in SYMBOLS:
        bars = r20.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = r20.load_funding(sym)
        data[sym] = (bars, funding)
        days = r20.group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data[sym][0]] == base_ts, f"{sym} 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；时间戳对齐、零缺口。")

    days_all = sorted(r20.group_days(data["BTC_USDT"][0], 24).keys())
    assert len(days_all) == 365
    # ---- 走前窗口（跑前写死）：训练 90 天 → 测试 30 天，滚动 30 天 ----
    windows = []
    for start in range(TRAIN_DAYS, 365 - TEST_DAYS + 1, STEP_DAYS):
        train_days = days_all[start - TRAIN_DAYS:start]
        test_days = days_all[start:start + TEST_DAYS]
        windows.append((start, train_days, test_days))
    assert len(windows) == 9, f"测试窗应为 9 个，实际 {len(windows)}"
    test_days_all = sorted({d for _, _, td in windows for d in td})
    assert len(test_days_all) == 270, f"测试期应为 270 天，实际 {len(test_days_all)}"
    split_date = test_days_all[len(test_days_all) // 2]  # 前 135 天 / 后 135 天
    front_days = {d for d in test_days_all if d < split_date}
    back_days = {d for d in test_days_all if d >= split_date}
    print(f"走前窗口：9 个测试窗，测试期 {test_days_all[0]}~{test_days_all[-1]} "
          f"（{len(test_days_all)} 天）；前半 {len(front_days)} 天（至 {split_date - timedelta(days=1)}）"
          f" / 后半 {len(back_days)} 天；全年第 361~365 天不用。")

    atr = {s: r20.atr_wilder(data[s][0]) for s in SYMBOLS}
    # ---- 特征（全量只建一次；训练/测试划分只在窗口内做）----
    feats = {}
    for sym in SYMBOLS:
        bars, funding = data[sym]
        X, y, valid = build_features(bars, data["BTC_USDT"][0], atr[sym], funding)
        feats[sym] = (X, y, valid)
    n_valid = {s: int(feats[s][2].sum()) for s in SYMBOLS}
    print(f"特征：13 列，有效样本 {n_valid}（每币约 8,747 根，首 14 根热身）。")

    day_of_bar = {}
    for sym in SYMBOLS:
        bars = data[sym][0]
        day_of_bar[sym] = [datetime.fromtimestamp(b["t"], timezone.utc).date()
                           for b in bars]

    # ---- 走前训练 + 预测 ----
    acc_rows = []      # 每窗每币每模型的准确率
    lr_sigs = {}       # (sym) -> signals dict（全测试期）
    rf_sigs = {}
    rnd_sigs = {}
    lr_importance = []  # LR 系数（标准化后）逐窗
    rf_importance = []
    for wi, (start, train_days, test_days) in enumerate(windows):
        train_set, test_set = set(train_days), set(test_days)
        for ci, sym in enumerate(SYMBOLS):
            X, y, valid = feats[sym]
            days = day_of_bar[sym]
            tr_idx = [i for i in range(len(X))
                      if valid[i] and y[i] is not None and days[i] in train_set]
            te_idx = [i for i in range(len(X))
                      if valid[i] and y[i] is not None and days[i] in test_set]
            # 复核 (b)：无未来函数——训练集最后一条 bar 索引 < 测试集第一条
            assert max(tr_idx) < min(te_idx), f"{sym} 窗 {wi} 训练/测试重叠"
            Xtr = X[tr_idx]
            ytr = np.array([y[i] for i in tr_idx])
            Xte = X[te_idx]
            yte = np.array([y[i] for i in te_idx])
            mu = Xtr.mean(axis=0)
            sd = Xtr.std(axis=0)
            sd = np.where(sd == 0, 1.0, sd)
            Xtr_s = (Xtr - mu) / sd
            Xte_s = (Xte - mu) / sd
            lr = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000)
            lr.fit(Xtr_s, ytr)
            rf = RandomForestClassifier(n_estimators=200, max_depth=3,
                                        random_state=29, n_jobs=-1)
            rf.fit(Xtr, ytr)
            p_lr_tr = lr.predict_proba(Xtr_s)[:, 1]
            p_lr_te = lr.predict_proba(Xte_s)[:, 1]
            p_rf_tr = rf.predict_proba(Xtr)[:, 1]
            p_rf_te = rf.predict_proba(Xte)[:, 1]
            acc_rows.append({
                "window": wi, "train_start": str(train_days[0]),
                "test_start": str(test_days[0]), "test_end": str(test_days[-1]),
                "symbol": sym,
                "lr_train_acc": round(float(((p_lr_tr >= 0.5).astype(int) == ytr).mean()), 4),
                "lr_test_acc": round(float(((p_lr_te >= 0.5).astype(int) == yte).mean()), 4),
                "rf_train_acc": round(float(((p_rf_tr >= 0.5).astype(int) == ytr).mean()), 4),
                "rf_test_acc": round(float(((p_rf_te >= 0.5).astype(int) == yte).mean()), 4),
                "n_train": len(tr_idx), "n_test": len(te_idx),
                "test_up_rate": round(float(yte.mean()), 4),
            })
            lr_importance.append(lr.coef_[0].tolist())
            rf_importance.append(rf.feature_importances_.tolist())
            bars = data[sym][0]
            s_lr = signals_from_probs(bars, atr[sym], te_idx, p_lr_te)
            s_rf = signals_from_probs(bars, atr[sym], te_idx, p_rf_te)
            lr_sigs.setdefault(sym, {}).update(s_lr)
            rf_sigs.setdefault(sym, {}).update(s_rf)
            # RND：与 LR 同窗同币同信号数，信号根与方向随机抽
            rng = random.Random(RND_SEED + wi * 1000 + ci * 17)
            pool = [i for i in te_idx if i + 1 < len(bars)]
            k = len(s_lr)
            chosen = rng.sample(pool, k) if k > 0 else []
            s_rnd = {}
            for i in chosen:
                s_rnd[bars[i + 1]["t"]] = {
                    "direction": rng.choice([1, -1]), "atr": atr[sym][i],
                    "sl_mult": SL_MULT, "tp_mult": TP_MULT, "max_hold": MAX_HOLD}
            rnd_sigs.setdefault(sym, {}).update(s_rnd)
        print(f"[窗 {wi}] 测试 {test_days[0]}~{test_days[-1]}："
              f"LR 信号 {sum(len(v) for v in [lr_sigs[s] for s in SYMBOLS])} 累计 / "
              f"RF 信号 {sum(len(v) for v in [rf_sigs[s] for s in SYMBOLS])} 累计")

    # ---- F1 对照信号（第七轮原版，TP=2.0）----
    f1_sigs = {}
    for sym in ALTS:
        f1_sigs[sym] = r20.build_f1_signals(data[sym][0], data["BTC_USDT"][0],
                                            atr[sym], 2, MAX_HOLD, TP_MULT)
    print(f"[F1] 信号数（全 365 天）：合计 {sum(len(v) for v in f1_sigs.values())}。")

    # ---- 回测：每臂 × 每币 × 三窗口（前半/后半/全测试期）----
    ARMS = [
        ("ML-LR", "ml_lr", lr_sigs, SYMBOLS),
        ("ML-RF", "ml_rf", rf_sigs, SYMBOLS),
        ("RND", "rnd", rnd_sigs, SYMBOLS),
        ("F1", "f1", f1_sigs, ALTS),
    ]
    WINDOWS = [("全270d", None), ("前135d", front_days), ("后135d", back_days)]
    all_results, all_trades = [], []
    for arm, label, sigs_all, coins in ARMS:
        for sym in coins:
            bars, funding = data[sym]
            sigs = sigs_all[sym]
            for wname, subset in WINDOWS:
                use = test_days_all if subset is None else subset
                trades, curve, ndays = r20.simulate_f1(
                    sym, bars, sigs, funding, set(use), MAX_PER_DAY, label, 24)
                res = r20.summarize(sym, trades, curve, label, len(sigs))
                res["arm"] = arm
                res["variant"] = label
                res["family"] = "ML" if arm != "F1" else "F1"
                res["tp_mult"] = TP_MULT
                res["granularity"] = "1h"
                res["split"] = wname
                res["days"] = ndays
                res["signals_total"] = len(sigs)
                all_results.append(res)
                if wname == "全270d":
                    for t in trades:
                        t2 = dict(t)
                        t2["arm"] = arm
                        t2["variant"] = label
                        t2["family"] = res["family"]
                        t2["tp_mult"] = TP_MULT
                        t2["granularity"] = "1h"
                        t2["split"] = ("前135d" if datetime.fromtimestamp(
                            t["entry_t"], timezone.utc).date() < split_date else "后135d")
                        all_trades.append(t2)
                print(f"[{arm} {sym} {wname}] n={res['trades']} 信号 {len(sigs)} "
                      f"胜率={res['win_rate']} 盈亏比={res['profit_factor']} "
                      f"Taker {res['taker_net_pct']*100:+.2f}% (t={res['t_taker']}) | "
                      f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                      f"出场={res['reason_counts']}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label, _, coins in ARMS:
        for wname, _ in WINDOWS:
            rs = [r for r in all_results if r["arm"] == arm and r["split"] == wname]
            gt = sum(r["gross_usdt"] for r in rs)
            ct = sum(r["taker_cost_sum"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
            print(f"  {arm} {wname}：Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                  f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                  f"每笔毛利 {gt/nt:+.2f} USDT 胜率 {wr:.3f}" if wr is not None else
                  f"  {arm} {wname}：Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                  f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} 每笔毛利 — 胜率 —")

    # ---- 准确率汇总 ----
    print("\n=== 准确率：样本内 vs 样本外（0.5 阈值，全部测试根）===")
    for model in ("lr", "rf"):
        tr = [a[f"{model}_train_acc"] for a in acc_rows]
        te = [a[f"{model}_test_acc"] for a in acc_rows]
        print(f"  {model.upper()}：样本内 {sum(tr)/len(tr)*100:.2f}%（72 个窗币格）/ "
              f"样本外 {sum(te)/len(te)*100:.2f}%；样本外 >55% 的格子 "
              f"{sum(1 for v in te if v > 0.55)} 个，<45% 的格子 "
              f"{sum(1 for v in te if v < 0.45)} 个")
    # 特征重要性平均
    lr_imp = np.mean(np.array(lr_importance), axis=0)
    rf_imp = np.mean(np.array(rf_importance), axis=0)
    print("\n=== 特征重要性平均（72 个窗币格）===")
    print("  LR 系数（标准化特征）：")
    for name, v in sorted(zip(FEATURE_NAMES, lr_imp), key=lambda kv: -abs(kv[1])):
        print(f"    {name:>10}: {v:+.4f}")
    print("  RF 重要性：")
    for name, v in sorted(zip(FEATURE_NAMES, rf_imp), key=lambda kv: -kv[1]):
        print(f"    {name:>10}: {v:.4f}")

    # ---- pooled t ----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for arm, label, _, _ in ARMS:
        sub = [t for t in all_trades if t["arm"] == arm]
        for wname, _ in WINDOWS:
            s2 = [t for t in sub if wname == "全270d" or t["split"] == wname]
            vt = [t["pnl"] / r20.START_EQUITY for t in s2]
            vm = [t["pnl_maker_m1"] / r20.START_EQUITY for t in s2]
            print(f"  {arm} {wname}：n={len(s2)} pooled t(Taker)={r20.t_value(vt)} "
                  f"pooled t(M1)={r20.t_value(vm)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    verdict = {}
    for arm, label, _, coins in ARMS:
        row = {}
        for wname, _ in WINDOWS:
            rs = [r for r in all_results if r["arm"] == arm and r["split"] == wname]
            row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
        good = row["前135d"] > 0 and row["后135d"] > 0 and row["全270d"] > 0.02
        verdict[arm] = good
        print(f"  {arm} Taker：前 {row['前135d']*100:+.2f}% / "
              f"后 {row['后135d']*100:+.2f}% / 全 {row['全270d']*100:+.2f}% → "
              f"{'达标' if good else '不达标'}")
        for sym in coins:
            rf_ = [r for r in all_results if r["arm"] == arm and r["symbol"] == sym
                   and r["split"] == "前135d"][0]
            rb = [r for r in all_results if r["arm"] == arm and r["symbol"] == sym
                  and r["split"] == "后135d"][0]
            both = rf_["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
            print(f"    {sym}: 前 {rf_['taker_net_pct']*100:+.2f}% / "
                  f"后 {rb['taker_net_pct']*100:+.2f}% → "
                  f"{'★ 两半都为正' if both else ''}")
    print(f"\n  主臂整轮判定：ML-LR {'达标' if verdict['ML-LR'] else '不达标'}、"
          f"ML-RF {'达标' if verdict['ML-RF'] else '不达标'} → "
          f"{'通过' if verdict['ML-LR'] and verdict['ML-RF'] else '不通过'}")

    # ---- 复核 (a)：F1 全 365 天 vs 第九轮 TP=2.0 已发表数字 ----
    print("\n=== 复核 (a)：F1 全 365 天 vs 第九轮 TP=2.0 已发表数字（Taker，全期）===")
    checks = {
        "ETH_USDT": 0.0010, "SOL_USDT": -0.0129, "DOGE_USDT": -0.0372,
        "LINK_USDT": -0.0421, "XRP_USDT": -0.0366, "BNB_USDT": -0.0500,
        "ADA_USDT": -0.0093,
    }
    ok = True
    for sym, expect in checks.items():
        bars, funding = data[sym]
        trades, curve, _ = r20.simulate_f1(sym, bars, f1_sigs[sym], funding,
                                           None, MAX_PER_DAY, "f1", 24)
        res = r20.summarize(sym, trades, curve, "f1", len(f1_sigs[sym]))
        diff = abs(res["taker_net_pct"] - expect)
        flag = "✓" if diff < 0.0005 else "✗"
        if diff >= 0.0005:
            ok = False
        print(f"  {flag} {sym}: 实测 {res['taker_net_pct']*100:+.2f}% vs 发表 "
              f"{expect*100:+.2f}%（差 {diff*100:.3f}pp）")
    print(f"  复核 (a)：{'全部通过' if ok else '有差异，需先修引擎'}")

    # ---- 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round29_summary.json"), "w") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    with open(os.path.join(DATA_DIR, "gate_iter_round29_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        keys = ["arm", "variant", "family", "tp_mult", "granularity", "split",
                "symbol", "direction", "entry_t", "entry", "exit_t", "exit",
                "stop", "tp", "atr", "notional", "margin", "reason", "hold_min",
                "price_pnl", "cost_usdt", "cost_maker_usdt", "pnl_maker_m1",
                "funding_cost_usdt", "pnl", "pnl_pct_equity"]
        w.writerow(keys)
        for t in all_trades:
            w.writerow([t.get(k, "") for k in keys])
    acc_out = {
        "windows": [{"window": wi, "train_start": str(train_days[0]),
                     "train_end": str(train_days[-1]),
                     "test_start": str(test_days[0]),
                     "test_end": str(test_days[-1])}
                    for wi, (_, train_days, test_days) in enumerate(windows)],
        "per_window_coin": acc_rows,
        "feature_importance": {
            "lr_coef_mean": {n: round(float(v), 4) for n, v in zip(FEATURE_NAMES, lr_imp)},
            "rf_importance_mean": {n: round(float(v), 4) for n, v in zip(FEATURE_NAMES, rf_imp)},
        },
        "thresholds": {"long": PROB_LONG, "short": PROB_SHORT},
        "train_days": TRAIN_DAYS, "test_days": TEST_DAYS, "step_days": STEP_DAYS,
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round29_accuracy.json"), "w") as f:
        json.dump(acc_out, f, ensure_ascii=False, indent=2)
    print("\n已写入：data/gate_iter_round29_summary.json / "
          "data/gate_iter_round29_trades.csv / data/gate_iter_round29_accuracy.json")


if __name__ == "__main__":
    main()
