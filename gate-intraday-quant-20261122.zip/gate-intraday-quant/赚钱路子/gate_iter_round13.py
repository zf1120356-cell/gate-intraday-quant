#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十三轮：止损倍数对照（止盈 2xATR 固定，止损 1 / 0.75 / 0.5 xATR）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因：第九轮 §6 留下的唯一未开轮方向——止损端一直钉在 1xATR 没动过。
第九轮发现 40%~65% 的交易亏满 1xATR，止损端是净收益的最大头。
本轮补这个缺口——只改止损倍数，止盈固定 2xATR（用户要求的 1:2），
其他全部照原样。预期低：止损收窄会让止损命中更多、胜率更低，
方向上和止盈放大是同一枚硬币的另一面；测一轮闭环就够。

锁定的规则（跑前定死，写死在文件头，不用全样本挑参数）：
  SL_MULTS = [1.0, 0.75, 0.5]，TP_MULT = 2.0（固定）。
  (1) S3 RSI 20/80 低换手版（365 天 1h，8 币）：
      引擎 = 第三轮 gate_iter_round3.py run_s3_1h（即 gate_iter_A.py
      的 S3 引擎按 1h 平移），一字不变，只把 tp 从 1.5*a 改成参数：
      RSI(14,Wilder) 收盘 <20 做多、>80 做空；08:00-20:00 UTC；
      本根振幅 > 前 20 根振幅中位数；每天每币最多 2 笔；
      出场 RSI 回 50 / 止损 SL_MULT xATR / 止盈 2xATR /
      当天 23:00 那根收盘强制平仓；每笔保证金 10% 权益、1x；
      收盘触发、下一根开盘成交；止损/止盈用盘中高低价触发
      （同根同时碰到先判止损）；单日 -2% 熔断；
      单笔最坏情况 (ATR+成本) > 1% 权益跳过。
      成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
      双边）；资金费按实际费率计（08:00/16:00 结算点，前半段
      2026-05-21 之前无数据按 0 计，第三轮已验证偏差个位数 USDT）。
      M1/M2 只做对照（第三轮同款公式与 B 实测成交率/逆向惩罚，
      新币种用 SOL 保守代理），主口径是 Taker。
  (2) F1 BTC 领涨-山寨跟随（365 天 1h + 103 天 15m，7 个山寨）：
      引擎 = 第七轮 gate_iter_round7.py simulate + build_f1_signals
      （15m 版 = 第八轮 gate_iter_round8.py 的粒度换算），一字不变，
      只把 sl_mult 从 1.0 改成参数（tp_mult 固定 2.0）：
      信号根 08:00~19:00 收盘：BTC 2h 收益 |rBTC| >= 0.5%，且山寨
      自身 2h 收益 |rALT| < 0.5*|rBTC|；方向 = sign(rBTC)；
      下一根开盘进场；止损 SL_MULT xATR、止盈 2xATR；
      最多持 4h（1h 版 4 根，15m 版 16 根）；每天每币最多 2 笔；
      当天最后一根收盘强制平仓（1h 版 23:00，15m 版 23:45）；
      单日 -2% 熔断；同根同时碰到先判止损；只做 7 个山寨，不做 BTC。
      1h 版 ATR(14,1h)、lookback 2 根；15m 版 ATR(14,15m)、lookback 8 根。
      成本主口径 Taker：一轮名义 x 0.25%；M1/M2 对照同第七/八轮。
      信号与止损无关，同一粒度下三档共用同一组信号（只生成一次），
      差异只来自出场——这是对照成立的前提。
  不测 ORB：ORB 的止盈对照已经有结果；本轮只测 S3 和 F1 这两个
  最好的家族（第九轮毛利/成本最高的两个）。

窗口：
  S3 / F1-1h：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  F1-15m：全 103 天 2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

口径出入说明（以本脚本为准）：
  - S3 的 1h 版以第三轮脚本为准（EOD 为 23:00 那根收盘，1h 平移），
    不是 gate_iter_A.py 的 30m 版（EOD 23:30、48 根/天）；任务说的
    “S3 用 365 天 1h 数据”只能对应第三轮的 1h 引擎。1.5 档复核目标
    是第三轮数字（见 §复核）。
  - F1 的资金费只计 08:00/16:00 结算点（第七轮同款；00:00 点不计，
    日内持仓不过夜，跨 00:00 的仓不存在）。
  - 盈亏比 = 平均赢 / 平均亏（前几轮同款定义，不是总赢/总亏）。
  - t 值：逐笔净收益（占 10 万起始权益 %）的 t = mean/(sd/sqrt(n))；
    报告主表用 M1 口径 t（与前几轮可比），JSON 里同时给 Taker 口径 t。
  - 最大回撤：报告主表用 Taker 权益曲线（逐笔收盘后）的最大回撤，
    JSON 里同时给 M1 最大回撤。

运行：python3 gate_iter_round13.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round13_summary.json
      + data/gate_iter_round13_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
复核：SL=1.0 / TP=2.0 档必须复现第九轮 TP2.0 数字（误差 <0.05pp）——
  S3 全期平均 -1.17%（BTC -1.50% / ETH -0.68% / SOL -1.76% /
  DOGE -0.89% / LINK -0.86% / XRP -0.73% / BNB -1.00% / ADA -1.90%）；
  F1-1h 全期平均 -2.67%（ETH +0.10% / SOL -1.29% / DOGE -3.72% /
  LINK -4.21% / XRP -3.66% / BNB -5.00% / ADA -0.93%）；
  F1-15m 全期平均 -1.18%（ETH -0.66% / SOL -1.45% / DOGE -1.24% /
  LINK -0.83% / XRP -1.77% / BNB -1.71% / ADA -0.62%）。
"""
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
ALTS = [s for s in SYMBOLS if s != "BTC_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005,
              "DOGE_USDT": 0.008333, "LINK_USDT": 0.0065, "XRP_USDT": 0.005,
              "BNB_USDT": 0.0066, "ADA_USDT": 0.0066}

# ---- 锁定的对照档位：只改止损，止盈 2xATR 固定 ----
SL_MULTS = [1.0, 0.75, 0.5]
TP_MULT = 2.0
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)    # 前半段止于 05-19
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)   # 前半段止于 09-25

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
RSI_LO, RSI_HI = 20, 80
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def rsi_wilder(closes, period=14):
    rsi = [None] * len(closes)
    if len(closes) <= period:
        return rsi
    gains, losses = [], []
    for i in range(1, period + 1):
        ch = closes[i] - closes[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    avg_g = sum(gains) / period
    avg_l = sum(losses) / period
    rsi[period] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    for i in range(period + 1, len(closes)):
        ch = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(ch, 0.0)) / period
        avg_l = (avg_l * (period - 1) + max(-ch, 0.0)) / period
        rsi[i] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    return rsi


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    # 止盈出场可用限价 Maker -0.01%；其余（止损/EOD/到期/RSI 回中/爆仓）
    # 只能市价 Taker 0.125%/边；入场 Maker -0.01%（第三轮/第七轮同款）。
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


# ----------------------------------------------------------------------
# S3 引擎：第三轮 run_s3_1h 一字不变，只把止损倍数做成参数 sl_mult（止盈固定 2xATR）
# ----------------------------------------------------------------------
def run_s3_1h(bars, funding, symbol, days_subset, sl_mult, label):
    atr = atr_wilder(bars)
    rsi = rsi_wilder([b["c"] for b in bars])
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 24)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / 1 - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                       else (b["h"] - pos["entry"]) / pos["entry"])
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                r = rsi[gi]
                if r is not None:
                    if pos["direction"] == 1 and r >= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                    if pos["direction"] == -1 and r <= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if not (8.0 <= hour < 20.0):
                    continue
                r = rsi[gi]
                if r is None or gi < 20:
                    continue
                ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                    continue
                sig = 0
                if r < RSI_LO:
                    sig = 1
                elif r > RSI_HI:
                    sig = -1
                if sig == 0:
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - sl_mult * a if sig == 1 else entry + sl_mult * a
                tp = entry + TP_MULT * a if sig == 1 else entry - TP_MULT * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


# ----------------------------------------------------------------------
# F1 引擎：第七轮 simulate + build_f1_signals（第八轮粒度换算），
# 一字不变，只把止损倍数做成参数 sl_mult（止盈固定 2xATR）
# ----------------------------------------------------------------------
def build_f1_signals(alt_bars, btc_bars, alt_atr, lookback, max_hold, sl_mult):
    sigs = {}
    for i in range(lookback, len(alt_bars)):
        b = alt_bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour <= 19):
            continue
        if alt_atr[i] is None:
            continue
        r_btc = btc_bars[i]["c"] / btc_bars[i - lookback]["c"] - 1
        if abs(r_btc) < 0.005:
            continue
        r_alt = alt_bars[i]["c"] / alt_bars[i - lookback]["c"] - 1
        if abs(r_alt) >= 0.5 * abs(r_btc):
            continue
        if i + 1 >= len(alt_bars):
            continue
        entry_t = alt_bars[i + 1]["t"]
        sigs[entry_t] = {"direction": 1 if r_btc > 0 else -1,
                         "atr": alt_atr[i], "sl_mult": sl_mult, "tp_mult": TP_MULT,
                         "max_hold": max_hold}
    return sigs


def simulate_f1(symbol, bars, signals, funding, days_subset, max_per_day, label, bars_per_day):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= pos["max_hold"] - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": sig["max_hold"]}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": sum(1 for t in trades if t.get("liquidated")),
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def main():
    print("盈利策略迭代 · 第十三轮：止损倍数对照（止盈 2xATR 固定，止损 1/0.75/0.5 xATR，全模拟）")
    print("只改止损，其他照原样；不测 ORB；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- F1 信号：与止损无关，同一粒度只生成一次，三档共用 ----
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig1h, sig15 = {}, {}
    for sym in ALTS:
        sig1h[sym] = build_f1_signals(data1h[sym][0], data1h["BTC_USDT"][0],
                                      atr1h[sym], 2, 4, 1.0)
        sig15[sym] = build_f1_signals(data15[sym][0], data15["BTC_USDT"][0],
                                      atr15[sym], 8, 16, 1.0)
    print(f"[F1] 信号数（与止损无关，三档共用）：1h 合计 {sum(len(v) for v in sig1h.values())}，"
          f"15m 合计 {sum(len(v) for v in sig15.values())}。")

    all_results, all_trades = [], []

    def record(res, trades_full, family, variant, sl, gran, full_name, split_fn):
        res["family"] = family
        res["variant"] = variant
        res["sl_mult"] = sl
        res["tp_mult"] = TP_MULT
        res["granularity"] = gran
        all_results.append(res)
        if trades_full is not None:
            for t in trades_full:
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["sl_mult"] = sl
                t2["tp_mult"] = TP_MULT
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    # ================= S3：8 币 x 3 档 x 3 窗口 =================
    print("\n=== S3 RSI 20/80（365d 1h，8 币）===")
    for sl in SL_MULTS:
        label = f"R13-S3-SL{sl}"
        for sym in SYMBOLS:
            bars, funding = data1h[sym]
            for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
                trades, curve, ndays = run_s3_1h(bars, funding, sym, subset, sl, label)
                res = summarize(sym, trades, curve, label)
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if wname == "365d" else None, "S3", label, sl, "1h",
                       wname, lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d")
                print(f"[{label} {sym} {wname}] n={res['trades']} 胜率={res['win_rate']} "
                      f"盈亏比={res['profit_factor']} 平均赢={res['avg_win_usdt']:+.0f} "
                      f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
                      f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                      f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                      f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ================= F1-1h：7 山寨 x 3 档 x 3 窗口 =================
    print("\n=== F1 BTC 领涨-山寨跟随（365d 1h，7 山寨）===")
    for sl in SL_MULTS:
        label = f"R13-F1-1h-SL{sl}"
        # 信号只依赖方向/ATR/持有期，止损倍数在信号 dict 里现改（与生成时一致）
        sigs = {s: {k: dict(v, sl_mult=sl) for k, v in sig1h[s].items()} for s in ALTS}
        for sym in ALTS:
            bars, funding = data1h[sym]
            for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
                trades, curve, ndays = simulate_f1(sym, bars, sigs[sym], funding, subset, 2, label, 24)
                res = summarize(sym, trades, curve, label, len(sig1h[sym]))
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if wname == "365d" else None, "F1", label, sl, "1h",
                       wname, lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d")
                print(f"[{label} {sym} {wname}] n={res['trades']} 胜率={res['win_rate']} "
                      f"盈亏比={res['profit_factor']} 平均赢={res['avg_win_usdt']:+.0f} "
                      f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
                      f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                      f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                      f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ================= F1-15m：7 山寨 x 3 档 x 3 窗口 =================
    print("\n=== F1 BTC 领涨-山寨跟随（103d 15m，7 山寨）===")
    for sl in SL_MULTS:
        label = f"R13-F1-15m-SL{sl}"
        sigs = {s: {k: dict(v, sl_mult=sl) for k, v in sig15[s].items()} for s in ALTS}
        for sym in ALTS:
            bars, funding = data15[sym]
            for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
                trades, curve, ndays = simulate_f1(sym, bars, sigs[sym], funding, subset, 2, label, 96)
                res = summarize(sym, trades, curve, label, len(sig15[sym]))
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if wname == "103d" else None, "F1", label, sl, "15m",
                       wname, lambda et: "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d")
                print(f"[{label} {sym} {wname}] n={res['trades']} 胜率={res['win_rate']} "
                      f"盈亏比={res['profit_factor']} 平均赢={res['avg_win_usdt']:+.0f} "
                      f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
                      f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                      f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                      f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, syms, wnames) in [
            ("S3", "1h", SYMBOLS, ["365d", "前185d", "后180d"]),
            ("F1", "1h", ALTS, ["365d", "前185d", "后180d"]),
            ("F1", "15m", ALTS, ["103d", "前51d", "后52d"])]:
        for sl in SL_MULTS:
            for wname in wnames:
                rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["sl_mult"] == sl and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                print(f"  {fam}-{gran} SL{sl} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                      f"每笔毛利 {gt/nt:+.2f} USDT 胜率 "
                      f"{sum(r['win_rate']*r['trades'] for r in rs)/nt:.3f}")

    # ---- pooled t（全期明细，M1 逐笔；与前几轮同口径）----
    print("\n=== Pooled t 值（M1 逐笔净收益占权益 %，全期明细）===")
    for (fam, gran, wnames, full) in [
            ("S3", "1h", ["365d", "前185d", "后180d"], "365d"),
            ("F1", "1h", ["365d", "前185d", "后180d"], "365d"),
            ("F1", "15m", ["103d", "前51d", "后52d"], "103d")]:
        for sl in SL_MULTS:
            sub = [t for t in all_trades if t["family"] == fam and t["granularity"] == gran
                   and t["sl_mult"] == sl]
            for wname in wnames:
                s2 = [t for t in sub if wname == full or t["split"] == wname]
                vals = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
                vals_t = [t["pnl"] / START_EQUITY for t in s2]
                print(f"  {fam}-{gran} SL{sl} {wname}：n={len(vals)} "
                      f"pooled t(M1)={t_value(vals)} pooled t(Taker)={t_value(vals_t)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    for (fam, gran, syms, wnames) in [
            ("S3", "1h", SYMBOLS, ["前185d", "后180d", "365d"]),
            ("F1", "1h", ALTS, ["前185d", "后180d", "365d"]),
            ("F1", "15m", ALTS, ["前51d", "后52d", "103d"])]:
        for sl in SL_MULTS:
            row = {}
            for wname in wnames:
                rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["sl_mult"] == sl and r["split"] == wname]
                row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            good = row[wnames[0]] > 0 and row[wnames[1]] > 0 and row[wnames[2]] > 0.02
            print(f"  {fam}-{gran} SL{sl} Taker：前 {row[wnames[0]]*100:+.2f}% / "
                  f"后 {row[wnames[1]]*100:+.2f}% / 全 {row[wnames[2]]*100:+.2f}% → "
                  f"{'达标' if good else '不达标'}")
            for sym in syms:
                rf = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["sl_mult"] == sl and r["symbol"] == sym and r["split"] == wnames[0]][0]
                rb = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                      and r["sl_mult"] == sl and r["symbol"] == sym and r["split"] == wnames[1]][0]
                both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
                print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                      f"后 {rb['taker_net_pct']*100:+.2f}% → "
                      f"{'★ 两半都为正' if both else ''}")

    # ---- 复核 TP=1.5 档是否与前几轮一致 ----
    print("\n=== 复核：SL=1.0 / TP=2.0 档 vs 第九轮 TP2.0 已发表数字（Taker，全期）===")
    checks = {
        ("S3", "1h", "BTC_USDT"): -0.0150, ("S3", "1h", "ETH_USDT"): -0.0068,
        ("S3", "1h", "SOL_USDT"): -0.0176, ("S3", "1h", "DOGE_USDT"): -0.0089,
        ("S3", "1h", "LINK_USDT"): -0.0086, ("S3", "1h", "XRP_USDT"): -0.0073,
        ("S3", "1h", "BNB_USDT"): -0.0100, ("S3", "1h", "ADA_USDT"): -0.0190,
        ("F1", "1h", "ETH_USDT"): +0.0010, ("F1", "1h", "SOL_USDT"): -0.0129,
        ("F1", "1h", "DOGE_USDT"): -0.0372, ("F1", "1h", "LINK_USDT"): -0.0421,
        ("F1", "1h", "XRP_USDT"): -0.0366, ("F1", "1h", "BNB_USDT"): -0.0500,
        ("F1", "1h", "ADA_USDT"): -0.0093,
        ("F1", "15m", "ETH_USDT"): -0.0066, ("F1", "15m", "SOL_USDT"): -0.0145,
        ("F1", "15m", "DOGE_USDT"): -0.0124, ("F1", "15m", "LINK_USDT"): -0.0083,
        ("F1", "15m", "XRP_USDT"): -0.0177, ("F1", "15m", "BNB_USDT"): -0.0171,
        ("F1", "15m", "ADA_USDT"): -0.0062,
    }
    full_name = {("S3", "1h"): "365d", ("F1", "1h"): "365d", ("F1", "15m"): "103d"}
    bad = 0
    for (fam, gran, sym), expect in sorted(checks.items()):
        r = [x for x in all_results if x["family"] == fam and x["granularity"] == gran
             and x["sl_mult"] == 1.0 and x["symbol"] == sym
             and x["split"] == full_name[(fam, gran)]][0]
        ok = abs(r["taker_net_pct"] - expect) < 0.0005
        bad += 0 if ok else 1
        print(f"  {fam}-{gran} {sym}: 本轮 {r['taker_net_pct']*100:+.2f}% vs 第九轮 "
              f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核结果：{len(checks)-bad}/{len(checks)} 一致" + ("（全部通过）" if bad == 0 else "（有出入，见报告）"))

    with open(os.path.join(DATA_DIR, "gate_iter_round13_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round13_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "variant", "sl_mult", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "exit_time_utc", "entry", "exit",
                    "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt", "price_pnl_usdt",
                    "cost_taker_usdt", "cost_maker_usdt", "funding_cost_usdt",
                    "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["family"], x["granularity"], x["tp_mult"], x["symbol"])):
            w.writerow([t["family"], t["variant"], t["sl_mult"], t["tp_mult"], t["granularity"], t["split"],
                        t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t.get("liquidated", False), t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round13_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round13_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益.")


if __name__ == "__main__":
    main()
