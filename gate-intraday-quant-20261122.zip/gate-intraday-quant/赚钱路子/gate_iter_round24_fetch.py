#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第二十四轮取数：12 个新币种的 1h/15m/资金费（Gate 公开接口）。
币种名单（跑前写死，见 gate_iter_round24.py 头与报告 §0）：
  按 2026-11-17 17:12 UTC tickers volume_24h_quote 排序，原 8 币之外、
  spread<=0.07%、1h 首周有 K 线（365 天连续性初筛）通过的前 12 个：
  ZEC, EVAA, HYPE, LTC, BLESS, XLM, AKE, NEAR, PEPE, UNI, SUI, XAUT。
取数窗口与之前轮次对齐：1h 2025-11-16~2026-11-15（8,761 根）、
15m 2026-08-06~2026-11-16（9,888 根）、资金费 2026-05-21 起。
取数方法照抄第三轮（1h/资金费）与第八轮（15m）的 fetch 函数。
"""
import csv
import json
import os
import time
import urllib.request
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
BASE = "https://api.gateio.ws/api/v4"

NEW_SYMBOLS = ["ZEC_USDT", "EVAA_USDT", "HYPE_USDT", "LTC_USDT",
               "BLESS_USDT", "XLM_USDT", "AKE_USDT", "NEAR_USDT",
               "PEPE_USDT", "UNI_USDT", "SUI_USDT", "XAUT_USDT"]

START_1H = datetime(2025, 11, 16, tzinfo=timezone.utc)
END_1H = datetime(2026, 11, 16, tzinfo=timezone.utc)
START_15M = datetime(2026, 8, 6, tzinfo=timezone.utc)
END_15M = datetime(2026, 11, 17, tzinfo=timezone.utc)
FUNDING_START = datetime(2026, 5, 22, tzinfo=timezone.utc)  # 实测：接口 from<=2026-05-21 报 400（180 天保留期边界，2026-11-17 晚间）；05-22 起可取，缺失的 05-21 按 0 计（与前轮“无数据按 0 计”同一约定，影响 <1 USDT）


def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "gate-r24-fetch/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles(contract, interval, start, end, path):
    bars = []
    cur = start
    while cur < end:
        nxt = min(cur + timedelta(days=7), end)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval={interval}"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    if interval == "15m":
        bars = [b for b in bars
                if int(start.timestamp()) <= b["t"] < int(end.timestamp())]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] {interval} 已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}", flush=True)
    return bars


def fetch_funding(contract):
    path = os.path.join(DATA_DIR, f"gate_funding_365d_{contract}.json")
    out = {}
    cur = FUNDING_START
    while cur < END_1H:
        nxt = min(cur + timedelta(days=30), END_1H)
        url = (f"{BASE}/futures/usdt/funding_rate?contract={contract}&limit=100"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            t = int(d["t"])
            t = (t // 28800) * 28800
            out[t] = float(d["r"])
        cur = nxt
        time.sleep(0.3)
    with open(path, "w") as f:
        json.dump(out, f)
    print(f"[{contract}] 资金费率已取：{len(out)} 条", flush=True)
    return out


def main():
    for sym in NEW_SYMBOLS:
        p1h = os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv")
        p15 = os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv")
        pf = os.path.join(DATA_DIR, f"gate_funding_365d_{sym}.json")
        if not (os.path.exists(p1h) and sum(1 for _ in open(p1h)) == 8762):
            fetch_candles(sym, "1h", START_1H, END_1H, p1h)
        else:
            print(f"[{sym}] 1h 用缓存（8,761 根）", flush=True)
        if not (os.path.exists(p15) and sum(1 for _ in open(p15)) == 9889):
            fetch_candles(sym, "15m", START_15M, END_15M, p15)
        else:
            print(f"[{sym}] 15m 用缓存（9,888 根）", flush=True)
        if not os.path.exists(pf):
            fetch_funding(sym)
        else:
            print(f"[{sym}] 资金费率用缓存", flush=True)
    print("全部取数完成。")


if __name__ == "__main__":
    main()
