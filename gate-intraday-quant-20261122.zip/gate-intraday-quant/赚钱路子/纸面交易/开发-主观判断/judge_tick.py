#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘中主观判断——定时任务入口（judge_tick.py）
====================================================
每 15 分钟（对齐 15m 收盘）跑一次，流程：
  1. 只在交易日 00:00–23:00 UTC 内跑；之外只记一行日志退出。
  2. 轻量预检（judge_precheck）：8 个币最近 15m 是否有候选。
     无候选 → 只记一行日志，退出（省算力）。
  3. 有候选 → 对每个候选做完整主观读盘（judge_read.brief + decide）。
     结论为 write 时：
       a. 方向一致性：与早上计划偏向相反 → 不写，记日志。
       b. 调 write_trigger 写进当日计划文件“盘中补充触发”小节
          （写前校验：23:00 前、当日无已有补充触发、早上计划未成交、
          引擎 state 里该币无补充登记；引擎已支持 mtime 重读与解析，
          不改引擎、不重启引擎）。
  4. 每步都写日志（JSON 行），日志在 --log 指定的文件；无候选也只记一行。

用法（cron 每 15 分钟）：
  python3 judge_tick.py [--source gate|file] [--data-dir DIR]
      [--plan-file PATH] [--log PATH] [--now-ts SEC]
  --source file 时用缓存数据（离线调试用）；默认 gate（拉 Gate 公开接口）。
  --now-ts 用于测试（指定“现在”的 UTC 秒）；默认用真实当前时间。
  --plan-file 默认取当日计划 ~/workspace/赚钱路子/纸面交易/YYYY-MM-DD.md
    （按 UTC 日期；若文件不存在，方向一致性跳过、只按其余规则判断）。
"""
import argparse
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import judge_precheck as jp  # noqa: E402
import judge_read as jr  # noqa: E402

COINS = jp.COINS
LOG_DEFAULT = os.path.expanduser("~/workspace/赚钱路子/纸面交易/盘中主观判断.log")


def log_line(log_path, obj):
    obj["ts"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    line = json.dumps(obj, ensure_ascii=False)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line)


def today_plan_path(now_utc):
    d = now_utc.strftime("%Y-%m-%d")
    return os.path.join(jr.PLAN_DIR, f"{d}.md")


def run_tick(source="gate", data_dir=None, plan_file=None, log_path=LOG_DEFAULT,
             now_ts=None):
    now = (datetime.fromtimestamp(now_ts, tz=timezone.utc) if now_ts
           else datetime.now(timezone.utc))
    # 1. 只在 00:00–23:00 UTC 内跑
    if now.hour >= 23:
        log_line(log_path, {"event": "skip_eod", "note": "23:00 UTC 之后不判断"})
        return {"event": "skip_eod"}
    plan = plan_file or today_plan_path(now)
    plan_dirs = jr.plan_directions(plan) if os.path.exists(plan) else {}
    # 2. 预检（只用已收盘的 15m/1h；进行中那根不算）
    now_floor15 = int(now.timestamp()) // 900 * 900
    cands = []
    data = {}
    for coin in COINS:
        try:
            if source == "gate":
                bars15 = jp.fetch_gate_15m(f"{coin}_USDT")
                bars1h = jr.fetch_gate_1h(f"{coin}_USDT")
            else:
                bars15 = jp.load_file_15m(data_dir, coin)
                bars1h = jr.load_file_1h(data_dir, coin)
        except Exception as e:
            log_line(log_path, {"event": "fetch_fail", "coin": coin,
                                "error": str(e)})
            continue
        bars15 = [b for b in bars15 if b["t"] + 900 <= now_floor15]
        bars1h = [b for b in bars1h if b["t"] + 3600 <= now_floor15]
        if not bars15:
            continue
        data[coin] = (bars15, bars1h)
        cands.extend(jp.precheck_coin(bars15, coin))
    if not cands:
        log_line(log_path, {"event": "no_candidate",
                            "time_utc": now.strftime("%H:%M")})
        return {"event": "no_candidate", "candidates": 0}
    # 3. 完整读盘 + 判断 + 写
    results = []
    books = {}  # coin -> 决策时刻盘口快照（每币只抓一次；抓不到记 None，不拦判断）
    for cand in cands:
        coin = cand["coin"]
        direction = cand["direction"]
        bars15, bars1h = data[coin]
        # 确认根 = 最近已收盘根
        confirm_t = bars15[-1]["t"]
        if coin not in books:
            try:
                books[coin] = jr.fetch_gate_book(f"{coin}_USDT")
            except Exception as e:
                log_line(log_path, {"event": "book_fail", "coin": coin,
                                    "error": str(e)})
                books[coin] = None
        b = jr.brief(coin, direction, confirm_t, bars15, bars1h,
                     plan_path=plan if os.path.exists(plan) else None,
                     book=books[coin])
        dec, reason, checks = jr.decide(b)
        rec = {"event": "judge", "coin": coin, "direction": direction,
               "time_utc": now.strftime("%H:%M"), "decision": dec,
               "reason": reason,
               "vol": b.get("volume"), "book": b.get("book")}
        if dec == "write":
            # a. 方向一致性
            pd = plan_dirs.get(coin)
            if pd is not None and pd != direction:
                rec["write"] = False
                rec["write_msg"] = (f"{coin} 早上计划偏向"
                                    f"{'做多' if pd == 1 else '做空'}，方向相反，不写")
            else:
                trig = jr.build_trigger(b, reason)
                ok, msg = jr.write_trigger(plan, trig)
                rec["write"] = ok
                rec["write_msg"] = msg
                if ok:
                    rec["trigger"] = {"pending_entry_t": trig["pending_entry_t"],
                                      "ref_entry": trig["ref_entry"],
                                      "sl": trig["sl"], "tp": trig["tp"]}
        log_line(log_path, rec)
        results.append(rec)
    return {"event": "judged", "candidates": len(cands), "results": results}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", choices=["gate", "file"], default="gate")
    ap.add_argument("--data-dir", default=None)
    ap.add_argument("--plan-file", default=None)
    ap.add_argument("--log", default=LOG_DEFAULT)
    ap.add_argument("--now-ts", type=int, default=None)
    args = ap.parse_args()
    res = run_tick(source=args.source, data_dir=args.data_dir,
                   plan_file=args.plan_file, log_path=args.log,
                   now_ts=args.now_ts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
