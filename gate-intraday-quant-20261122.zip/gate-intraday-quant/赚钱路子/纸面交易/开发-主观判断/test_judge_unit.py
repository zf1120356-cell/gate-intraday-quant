#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘中主观判断——边界/单元测试（test_judge_unit.py）
====================================================
不碰 live 引擎、不碰分系统、不改真实计划文件（只写 /tmp 下的副本）。
覆盖：
  B1 无候选时不写计划（precheck 返回空 → 不调用 brief/write）。
  B2 已成交跳过：早上计划已成交的币，decide=write 也不写
     （write_trigger 读引擎 state；此处用假 state 文件验证）。
  B3 23:00 UTC 之后不写（pending_entry_t >= 23:00 UTC 拒绝）。
  B4 单币每天最多 1 条补充触发（第二条同币触发拒绝写入）。
  B5 方向一致性：plan_directions 解析（做空/做多/观望无计划）。
  B6 decide 关键分支：09:00 那处（确认无跟进）拒绝；22:00 那处通过。
  B7 level_tests：探针根不计入测试；相邻测试相隔 <4 根不另计。
"""
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import judge_read  # noqa: E402
import judge_precheck as jp  # noqa: E402
import supp_observer  # noqa: E402

PASS = []
FAIL = []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"{'PASS' if cond else 'FAIL'}  {name}" + (f"  {detail}" if detail and not cond else ""))


def _mk_trigger(coin, direction, pending_entry_t, ref=100.0):
    return {"coin": coin, "direction": direction,
            "trigger_t": pending_entry_t, "pending_entry_t": pending_entry_t,
            "confirm_bar_t": pending_entry_t - 900,
            "probe_bar_t": pending_entry_t - 1800,
            "level_type": "JUDGE", "level": ref, "level_txt": "主观 100",
            "ref_entry": ref, "sl": ref + 1, "tp": ref - 2,
            "atr_1h": 1.0, "atr_1h_source": "test",
            "basis": "测试触发", "wick_x": 1.0, "confirm_x": 1.0, "atr15": 1.0}


def test_b1_no_candidate_no_write():
    """B1：平缓单边漂移（无大波动、无影线、无重复位子），预检无候选。"""
    # 每根漂移 +0.5，高点各不相同（差 0.5 > 0.5xATR≈0.275），不成簇；
    # |开-收|=0.05、无影线，不触发 A/B 类。
    bars = [{"t": 1795132800 + i * 900, "o": 100.0 + i * 0.5,
             "h": 100.1 + i * 0.5, "l": 99.9 + i * 0.5,
             "c": 100.05 + i * 0.5} for i in range(30)]
    cands = jp.precheck_coin(bars, "ETH")
    check("B1 无候选", cands == [], f"候选={cands}")


def test_b2_traded_skip():
    """B2：早上计划已成交 → write_trigger 拒绝（读假 state）。"""
    with tempfile.TemporaryDirectory() as td:
        plan = os.path.join(td, "plan.md")
        open(plan, "w").write("# 测试计划\n")
        state = os.path.join(td, "state.json")
        # 假引擎 state：ETH 早上计划已成交（plans 结构与引擎 state 一致）
        json.dump({"plans": {"ETH": {"trades_done": 1, "status": "triggered"}}},
                  open(state, "w"))
        # monkeypatch judge_read 的 state 读取路径：write_trigger 读的是
        # 硬编码的 STATE_PATH，这里改模块级常量指向假 state
        orig = judge_read.STATE_PATH
        judge_read.STATE_PATH = state
        try:
            trig = _mk_trigger("ETH", -1, 1795132800 + 3600)
            ok, msg = judge_read.write_trigger(plan, trig, lock_path=None)
            check("B2 已成交跳过", (not ok) and "已成交" in msg, msg)
        finally:
            judge_read.STATE_PATH = orig


def test_b3_after_2300_no_write():
    """B3：待入场时间 >=23:00 UTC → 不写。"""
    with tempfile.TemporaryDirectory() as td:
        plan = os.path.join(td, "plan.md")
        open(plan, "w").write("# 测试计划\n")
        # 空 state：避免 live 引擎当日成交挡住写入（与 B2 同款处理）
        state = os.path.join(td, "state.json")
        json.dump({"plans": {}, "supp": {}}, open(state, "w"))
        orig = judge_read.STATE_PATH
        judge_read.STATE_PATH = state
        try:
            # 23:00 UTC 当天
            trig = _mk_trigger("ETH", -1, 1795132800 + 23 * 3600)
            ok, msg = judge_read.write_trigger(plan, trig, lock_path=None)
            check("B3 23:00 不写", (not ok) and "23:00" in msg, msg)
            # 22:45 可以写（待入场 22:45 < 23:00）
            trig2 = _mk_trigger("ETH", -1, 1795132800 + 22 * 3600 + 45 * 60)
            ok2, msg2 = judge_read.write_trigger(plan, trig2, lock_path=None)
            check("B3 22:45 可写", ok2, msg2)
        finally:
            judge_read.STATE_PATH = orig


def test_b4_one_per_coin_per_day():
    """B4：同一币第二条补充触发拒绝写入。"""
    with tempfile.TemporaryDirectory() as td:
        plan = os.path.join(td, "plan.md")
        open(plan, "w").write("# 测试计划\n")
        # 空 state：避免 live 引擎当日成交挡住写入（与 B2 同款处理）
        state = os.path.join(td, "state.json")
        json.dump({"plans": {}, "supp": {}}, open(state, "w"))
        orig = judge_read.STATE_PATH
        judge_read.STATE_PATH = state
        try:
            t1 = _mk_trigger("ETH", -1, 1795132800 + 3600)
            ok1, _ = judge_read.write_trigger(plan, t1, lock_path=None)
            t2 = _mk_trigger("ETH", 1, 1795132800 + 7200)
            ok2, msg2 = judge_read.write_trigger(plan, t2, lock_path=None)
            check("B4 第一条写出", ok1)
            check("B4 第二条拒绝", (not ok2) and "已有" in msg2, msg2)
        finally:
            judge_read.STATE_PATH = orig


def test_b5_plan_directions():
    """B5：plan_directions 解析。"""
    txt = ("## BTC — 偏向：观望（无计划）\n\n"
           "## ETH — 偏向：做空\n\n"
           "## SOL — 偏向：做空（原做多 setup 已走完，翻空）\n\n"
           "## DOGE — 偏向：观望（做空，区间顶部拒绝）\n\n"
           "## LINK — 偏向：做多\n")
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "plan.md")
        open(p, "w").write(txt)
        d = judge_read.plan_directions(p)
        check("B5 方向解析", d == {"BTC": None, "ETH": -1, "SOL": -1,
                                   "DOGE": -1, "LINK": 1}, str(d))


def test_b6_decide_branches():
    """B6：用真实 11-20 数据跑 decide——09:00 拒绝、22:00 通过。"""
    b15 = jp.load_file_15m("/tmp/judge_test/nov20", "ETH")
    b1h = judge_read.load_file_1h("/tmp/judge_test/nov20", "ETH")
    base = 1795132800
    plan = "/home/hatch/workspace/赚钱路子/纸面交易/2026-11-20.md"
    # 09:00：确认根 01:15 UTC
    c1 = base + 3600 + 900
    bars15 = [b for b in b15 if b["t"] + 900 <= c1 + 900]
    bars1h = [b for b in b1h if b["t"] + 3600 <= c1 + 900]
    br1 = judge_read.brief("ETH", -1, c1, bars15, bars1h, plan_path=plan)
    dec1, reason1, _ = judge_read.decide(br1)
    check("B6 09:00 拒绝", dec1 == "no" and "strength" in reason1,
          f"dec={dec1} reason={reason1[:80]}")
    # 22:00：确认根 14:30 UTC
    c2 = base + 14 * 3600 + 30 * 60
    bars15b = [b for b in b15 if b["t"] + 900 <= c2 + 900]
    bars1hb = [b for b in b1h if b["t"] + 3600 <= c2 + 900]
    br2 = judge_read.brief("ETH", -1, c2, bars15b, bars1hb, plan_path=plan)
    dec2, reason2, _ = judge_read.decide(br2)
    check("B6 22:00 通过", dec2 == "write" and "1758" in reason2
          and "1733" in reason2, f"dec={dec2} reason={reason2[:120]}")


def test_b7_level_tests():
    """B7：探针根不计入；相邻测试 <4 根不另计。"""
    # level=100，atr15=1。bars：t=0..8，极值都在 100 附近
    bars = []
    for i in range(9):
        bars.append({"t": 1000 + i * 900, "o": 99.0, "h": 100.0, "l": 98.0,
                     "c": 99.0})
    # confirm_t = 第 8 根（t=1000+8*900），probe = 第 7 根
    tests, _ = judge_read.level_tests(bars, 100.0, 1.0, -1, 1000 + 8 * 900)
    # 探针（第7根）不计；第0根计1次，第1-3根与第0根相隔<4不计，第4根计，
    # 第5-6根与第4根相隔<4不计 → 共 2 次（第0、4根）
    check("B7 探针不计+间隔去重", len(tests) == 2,
          f"tests={[(t['t'], t['extreme']) for t in tests]}")


def _mk_vol_bars(n=30, v_default=100.0, probe_v=None, confirm_v=None,
                  probe_h=100.0, probe_range=1.0):
    """造带量的 15m bars：价格在 100 附近小幅波动，量默认 100。
    probe = 倒数第 2 根（cidx-1），confirm = 最后 1 根（cidx）。"""
    bars = []
    for i in range(n):
        bars.append({"t": 1000 + i * 900, "o": 99.0, "h": 100.0, "l": 98.0,
                     "c": 99.0, "v": v_default})
    if probe_v is not None:
        bars[-2]["v"] = probe_v
        bars[-2]["h"] = probe_h
        bars[-2]["l"] = probe_h - probe_range
        bars[-2]["c"] = probe_h - 0.2
    if confirm_v is not None:
        bars[-1]["v"] = confirm_v
    return bars


def test_b8_volume():
    """B8：量分析——放量确认 / 缩量存疑 / 无量算不出 / climax / 量价背离。"""
    # B8a 放量：探针+确认均 2.0x 均量 → confirm
    bars = _mk_vol_bars(probe_v=200.0, confirm_v=200.0)
    v = judge_read.analyze_volume(bars, 29, 1.0, -1)
    check("B8a 拒绝放量确认", v["verdict"] == "confirm" and abs(v["rej_x"] - 2.0) < 0.01,
          str(v))
    # B8b 缩量：探针+确认均 0.5x → against
    bars = _mk_vol_bars(probe_v=50.0, confirm_v=50.0)
    v = judge_read.analyze_volume(bars, 29, 1.0, -1)
    check("B8b 拒绝缩量存疑", v["verdict"] == "against" and abs(v["rej_x"] - 0.5) < 0.01,
          str(v))
    # B8c 无量：bars 没有 v → 算不出，不报错
    bars = [{"t": 1000 + i * 900, "o": 99.0, "h": 100.0, "l": 98.0, "c": 99.0}
            for i in range(30)]
    v = judge_read.analyze_volume(bars, 29, 1.0, -1)
    check("B8c 无量算不出", v["verdict"] is None and "算不出" in v["txt"], str(v))
    # B8d climax：探针量 3.0x、波幅 3.0xATR15 → climax True
    bars = _mk_vol_bars(probe_v=300.0, confirm_v=100.0, probe_range=3.0)
    v = judge_read.analyze_volume(bars, 29, 1.0, -1)
    check("B8d 探针 climax", v["climax"] is True, str(v))
    # B8e 量价背离：探针创新高（101 > 之前最高 100）但量 0.5x → divergence True
    bars = _mk_vol_bars(probe_v=50.0, confirm_v=100.0, probe_h=101.0)
    v = judge_read.analyze_volume(bars, 29, 1.0, -1)
    check("B8e 量价背离", v["divergence"] is True, str(v))


def _mk_book(ask_levels, bid_levels):
    """造假盘口：ask_levels/bid_levels 为 [(价格, 量)]。"""
    return {"asks": [{"p": str(p), "s": s} for p, s in ask_levels],
            "bids": [{"p": str(p), "s": s} for p, s in bid_levels],
            "current": 1795282140.19, "update": 1795282140.175}


def test_b9_book():
    """B9：盘口分析——厚墙确认 / 无墙逆失衡存疑 / 抓不到 / 格式异常。"""
    # B9a 厚墙：参考位 100、做空，带内最大一档卖单 3000（中位 100 → 30x），
    #     且卖方占优（asks 总量远大于 bids）→ confirm
    book = _mk_book([(99.5, 100), (99.8, 100), (100.0, 100), (100.2, 3000),
                     (100.5, 100)],
                    [(99.4, 100), (99.3, 100), (99.2, 100)])
    b = judge_read.analyze_book(book, 100.0, -1, 1.0)
    check("B9a 厚墙确认", b["verdict"] == "confirm" and b["wall_x"] >= 3.0, str(b))
    # B9b 无墙+逆失衡：带内各档都是中位量（无墙），买方总量占优（做空逆向）→ against
    book = _mk_book([(99.5, 100), (99.8, 100), (100.0, 100), (100.2, 100),
                     (100.5, 100)],
                    [(99.4, 1000), (99.3, 1000), (99.2, 1000), (99.1, 1000),
                     (99.0, 1000)])
    b = judge_read.analyze_book(book, 100.0, -1, 1.0)
    check("B9b 无墙逆失衡存疑", b["verdict"] == "against", str(b))
    # B9c 多档正常挂单不成墙：带内 5 档各 100，中位 100，最大一档 1.0x → 不是墙
    book = _mk_book([(99.5, 100), (99.8, 100), (100.0, 100), (100.2, 100),
                     (100.5, 100)],
                    [(99.4, 100), (99.3, 100), (99.2, 100)])
    b = judge_read.analyze_book(book, 100.0, -1, 1.0)
    check("B9c 多档正常不成墙", b["wall_x"] == 1.0 and b["verdict"] == "neutral",
          str(b))
    # B9d 抓不到 / 格式异常 → verdict None，不报错
    check("B9d 盘口 None", judge_read.analyze_book(None, 100.0, -1, 1.0)["verdict"] is None)
    check("B9e 盘口格式异常",
          judge_read.analyze_book({"asks": "bad"}, 100.0, -1, 1.0)["verdict"] is None)
    # B9f 带内无单 + 失衡顺向 → 中性（失衡是全盘信号，不是位子证据；
    #     实测：XRP 做多，带内买单 0 张、失衡 +0.58，须判中性而非确认）
    book = _mk_book([(100.5, 100), (100.8, 100), (101.0, 100)],
                    [(98.0, 1000), (97.9, 1000), (97.8, 1000), (97.7, 1000),
                     (97.6, 1000)])
    b = judge_read.analyze_book(book, 100.0, 1, 1.0)
    check("B9f 带内无单失衡顺向只算中性",
          b["verdict"] == "neutral" and b["wall_x"] == 0.0, str(b))


def test_b10_weighting_not_gate():
    """B10：称重不当门槛——量/盘口再差也不否决真 setup，再好也不救假 setup。
    用真实 11-20 数据：ETH 22:00（write）与 09:00（no，强度不通过）。"""
    b15 = jp.load_file_15m("/tmp/judge_test/nov20", "ETH")
    b1h = judge_read.load_file_1h("/tmp/judge_test/nov20", "ETH")
    base = 1795132800
    plan = "/home/hatch/workspace/赚钱路子/纸面交易/2026-11-20.md"
    # 22:00：量与盘口都改成 against，仍须 write
    c2 = base + 14 * 3600 + 30 * 60
    bars15b = [b for b in b15 if b["t"] + 900 <= c2 + 900]
    bars1hb = [b for b in b1h if b["t"] + 3600 <= c2 + 900]
    br2 = judge_read.brief("ETH", -1, c2, bars15b, bars1hb, plan_path=plan)
    br2["volume"] = {"verdict": "against", "txt": "测试缩量 0.5×"}
    br2["book"] = {"verdict": "against", "txt": "测试无墙逆失衡"}
    dec2, _, _ = judge_read.decide(br2)
    check("B10a 量盘口差也不否决真 setup", dec2 == "write", f"dec={dec2}")
    # 09:00：量与盘口都改成 confirm，仍须 no（强度不通过）
    c1 = base + 3600 + 900
    bars15 = [b for b in b15 if b["t"] + 900 <= c1 + 900]
    bars1h = [b for b in b1h if b["t"] + 3600 <= c1 + 900]
    br1 = judge_read.brief("ETH", -1, c1, bars15, bars1h, plan_path=plan)
    br1["volume"] = {"verdict": "confirm", "txt": "测试放量 2.0×"}
    br1["book"] = {"verdict": "confirm", "txt": "测试厚墙 30×"}
    dec1, reason1, _ = judge_read.decide(br1)
    check("B10b 量盘口好也不救假 setup",
          dec1 == "no" and "strength" in reason1, f"dec={dec1} reason={reason1[:60]}")


if __name__ == "__main__":
    test_b1_no_candidate_no_write()
    test_b2_traded_skip()
    test_b3_after_2300_no_write()
    test_b4_one_per_coin_per_day()
    test_b5_plan_directions()
    test_b6_decide_branches()
    test_b7_level_tests()
    test_b8_volume()
    test_b9_book()
    test_b10_weighting_not_gate()
    print(f"\n通过 {len(PASS)}/{len(PASS) + len(FAIL)}，失败：{FAIL if FAIL else '无'}")
    raise SystemExit(0 if not FAIL else 1)
