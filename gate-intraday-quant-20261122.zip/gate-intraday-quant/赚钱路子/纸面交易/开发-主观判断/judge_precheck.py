#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘中主观判断——轻量预检（judge_precheck.py）
====================================================
归属：主系统主观层（盘中主观判断 v1，见《纸面交易/盘中主观判断-设计.md》）。
只读数据、不写计划、不交易、不碰分系统、不碰 live 引擎。

作用：每 15 分钟扫 8 个币，找出“值得看一眼”的候选。
预检只负责高召回（宁可多报不可漏报），误报由完整主观读盘过滤。
完整读盘（judge_read.py + 判断者）才决定是不是真 setup。

候选种类（做空/做多对称；下面写做空，做多把高/低、收回方向反过来）：
  A. 大动根：最近已收盘 2 根 15m 里，有一根 |开-收| >= 1.0xATR15
     （22:00 那处的确认根 14:30 跌幅 2.06x 即属此类）。
  B. 拒绝影线：最近已收盘 2 根里，有一根上影（高-收）>= 0.75xATR15
     （09:00 那处的探针 01:00 上影 0.98x 即属此类）。
  C. 测试位子：最近已收盘根的高价，落在“反复测试的位子”附近
     （位子 = 最近 24 根里两根高点相差 <=0.5xATR15、相隔 >=4 根的那对
     的均值；当前根高与位子之差 <=0.25xATR15）。
     （22:00 那处的探针 14:15 高 1758.88，距 08:00/10:30 簇均值 1760.87
     仅 1.99 <=0.25xATR15=2.79，即属此类。）
  D. 位子刚成型：最近 2 根里刚完成第二根测试（两根高点相差
     <=0.5xATR15、相隔 >=4 根），位子刚形成、值得盯（只 flag 新成型的，
     不重复 flag 已成型很久的位子）。

用法：
  python3 judge_precheck.py --source gate [--limit 200]
      从 Gate 公开接口拉最近 15m（curl，与引擎同款，避开 urllib 截断）。
  python3 judge_precheck.py --source file --data-dir /path/to/dir
      从数据文件读（离线测试用）。目录里须有 {coin}_15m.json（或
      {coin}_15m_full.json），每文件为 [{t,o,h,l,c,v,...}] 按时间升序，
      o/h/l/c 可为字符串（Gate 接口原样）。
  输出：JSON 到 stdout。{"candidates": [...]}；无候选为 {"candidates": []}。
  每项 candidate：{coin, direction, kinds: [A/B/C/D], level, level_txt,
  bars: [{t,o,h,l,c}...], reason}。level 为参考位（C/D 类）或 None（A/B 类）。
"""
import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone

COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]
API = "https://api.gateio.ws/api/v4/futures/usdt/candlesticks"
ATR_PERIOD = 14
# 预检参数（宽松，高召回）
BIG_MOVE_X = 1.0      # A 类：|开-收| >= 1.0xATR15
WICK_X = 0.75         # B 类：上影/下影 >= 0.75xATR15
CLUSTER_TOL = 0.5     # C/D 类：簇内两根极值相差上限（xATR15）
CLUSTER_GAP_MIN = 4   # 簇两根相隔下限（根数，1h）
CLUSTER_WINDOW = 24   # 只看最近 24 根（6h）
LEVEL_NEAR_X = 0.25   # C 类：当前根高与位子之差上限（xATR15）


def atr_wilder(bars, period=ATR_PERIOD):
    """Wilder ATR，与引擎/supp_observer 一字相同。bars 按时间升序。"""
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def _norm(bars):
    """Gate 接口原样（o/h/l/c 为字符串）→ float；按 t 升序。
    保留量 v（Gate K 线自带，单位张；旧数据/测试数据可能没有 v，
    缺失时记 None，下游量分析返回“量算不出”，不报错）。"""
    out = []
    for b in bars:
        v = b.get("v")
        out.append({"t": int(b["t"]), "o": float(b["o"]), "h": float(b["h"]),
                    "l": float(b["l"]), "c": float(b["c"]),
                    "v": (float(v) if v is not None else None)})
    out.sort(key=lambda x: x["t"])
    return out


def fetch_gate_15m(contract, limit=200):
    """curl 拉 Gate 15m（与引擎同款，避开 urllib 截断）。返回 _norm 后的 bars。"""
    url = f"{API}?contract={contract}&interval=15m&limit={limit}"
    cp = subprocess.run(["curl", "-sS", "-m", "25", "-w", "\n%{http_code}", url],
                        capture_output=True, text=True, timeout=40)
    lines = cp.stdout.strip().split("\n")
    code = lines[-1] if lines else ""
    body = "\n".join(lines[:-1])
    if cp.returncode != 0 or code != "200":
        raise RuntimeError(f"Gate {contract} 15m 拉取失败 curl={cp.returncode} http={code}")
    return _norm(json.loads(body))


def load_file_15m(data_dir, coin):
    """从数据文件读 15m。优先 {coin}_15m_full.json，其次 {coin}_15m.json。"""
    import os
    for name in (f"{coin}_15m_full.json", f"{coin}_15m.json",
                 f"nov20_15m_fresh_{coin}_USDT.json", f"nov17_15m_full_{coin}_USDT.json"):
        p = os.path.join(data_dir, name)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            bars = d if isinstance(d, list) else d.get("bars", d)
            return _norm(bars)
    return []


def _find_level_pair(bars, atr, direction):
    """在最近 CLUSTER_WINDOW 根里找反复测试的位子（两根极值相差 <=0.5xATR、
    相隔 >=4 根）。返回 (level, bar_a, bar_b) 或 None。做空取高点最大的那对
    （最高阻力），做多取低点最小的那对。"""
    if len(bars) < CLUSTER_GAP_MIN + 1:
        return None
    window = bars[-CLUSTER_WINDOW:]
    half = CLUSTER_TOL * atr
    best = None
    for a in range(len(window)):
        for c in range(a + CLUSTER_GAP_MIN, len(window)):
            pa, pc = window[a], window[c]
            va = pa["h"] if direction == -1 else pa["l"]
            vc = pc["h"] if direction == -1 else pc["l"]
            if abs(va - vc) > half:
                continue
            if direction == -1:
                key = (max(va, vc), pc["t"])
            else:
                key = (-min(va, vc), pc["t"])
            if best is None or key > best[0]:
                best = (key, (pa, pc))
    if best is None:
        return None
    pa, pc = best[1]
    va = pa["h"] if direction == -1 else pa["l"]
    vc = pc["h"] if direction == -1 else pc["l"]
    return (va + vc) / 2.0, pa, pc


def precheck_coin(bars15, coin):
    """对一个币做预检。bars15 为截至当前（含最近已收盘根）的历史，按时间升序。
    返回 [candidate, ...]（可能 0、1 或 2 个方向各 1 个）。"""
    if len(bars15) < 20:
        return []
    atrs = atr_wilder(bars15)
    atr = atrs[-1]
    if atr is None or atr <= 0:
        return []
    out = []
    last2 = bars15[-2:]
    for direction in (-1, 1):
        kinds = []
        level = None
        level_txt = ""
        # A 类：大动根（最近 2 根里有 |开-收| >= 1.0xATR15）
        for b in last2:
            if abs(b["o"] - b["c"]) >= BIG_MOVE_X * atr:
                kinds.append("A")
                break
        # B 类：拒绝影线（最近 2 根里有上影/下影 >= 0.75xATR15）
        for b in last2:
            wick = (b["h"] - b["c"]) if direction == -1 else (b["c"] - b["l"])
            if wick >= WICK_X * atr:
                kinds.append("B")
                break
        # C/D 类：反复测试的位子
        lv = _find_level_pair(bars15, atr, direction)
        if lv is not None:
            level, pa, pc = lv
            level_txt = (f"{level:.4g}（{fmt_ts(pa['t'])[11:]}/"
                         f"{fmt_ts(pc['t'])[11:]}簇 {pa['h'] if direction == -1 else pa['l']:.4g}/"
                         f"{pc['h'] if direction == -1 else pc['l']:.4g}）")
            # C 类：最近已收盘根的高/低落在位子附近（<=0.25xATR15）
            last = bars15[-1]
            ext = last["h"] if direction == -1 else last["l"]
            if abs(ext - level) <= LEVEL_NEAR_X * atr:
                kinds.append("C")
            # D 类：位子刚成型（簇的第二根在最近 2 根里）
            if pc["t"] >= bars15[-2]["t"]:
                kinds.append("D")
        if not kinds:
            continue
        d_txt = "做空" if direction == -1 else "做多"
        reason = (f"{d_txt}候选（{'/'.join(kinds)}）："
                  + "；".join(_kind_reason(k, bars15, atr, direction, level)
                             for k in kinds))
        out.append({
            "coin": coin, "direction": direction, "kinds": kinds,
            "level": level, "level_txt": level_txt,
            "bars": [{"t": b["t"], "o": b["o"], "h": b["h"], "l": b["l"], "c": b["c"]}
                     for b in last2],
            "reason": reason,
        })
    return out


def _kind_reason(kind, bars15, atr, direction, level):
    last2 = bars15[-2:]
    if kind == "A":
        b = max(last2, key=lambda x: abs(x["o"] - x["c"]))
        return (f"大动根 {fmt_ts(b['t'])[11:]} |开-收|={abs(b['o'] - b['c']):.4g}"
                f"={abs(b['o'] - b['c']) / atr:.2f}xATR15")
    if kind == "B":
        b = max(last2, key=lambda x: (x["h"] - x["c"]) if direction == -1 else (x["c"] - x["l"]))
        w = (b["h"] - b["c"]) if direction == -1 else (b["c"] - b["l"])
        return (f"拒绝影线 {fmt_ts(b['t'])[11:]} {'上影' if direction == -1 else '下影'}"
                f"={w:.4g}={w / atr:.2f}xATR15")
    if kind == "C":
        last = bars15[-1]
        ext = last["h"] if direction == -1 else last["l"]
        return f"测试位子 {fmt_ts(last['t'])[11:]} 极值 {ext:.4g} 距位子 {level:.4g} 仅 {abs(ext - level):.4g}"
    return "位子刚成型（第二根测试在最近 2 根内）"


def fmt_ts(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")


def run(source="gate", data_dir=None, limit=200):
    """跑一次预检，返回 {"candidates": [...]}。"""
    cands = []
    for coin in COINS:
        try:
            if source == "gate":
                bars = fetch_gate_15m(f"{coin}_USDT", limit=limit)
            else:
                bars = load_file_15m(data_dir, coin)
        except Exception as e:
            print(f"预检 {coin} 拉数失败：{e}", file=sys.stderr)
            continue
        if not bars:
            continue
        cands.extend(precheck_coin(bars, coin))
    return {"candidates": cands}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", choices=["gate", "file"], default="gate")
    ap.add_argument("--data-dir", default=None)
    ap.add_argument("--limit", type=int, default=200)
    args = ap.parse_args()
    res = run(source=args.source, data_dir=args.data_dir, limit=args.limit)
    print(json.dumps(res, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
