#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘中主观判断——离线验证（test_judge_replay.py）
====================================================
用缓存的 15m/1h 数据、按时间顺序重放，验证判断流程。
不碰 live 引擎、不碰分系统、不改真实计划文件（只写计划副本）。

用法：
  python3 test_judge_replay.py --day 2026-11-20 --data-dir /tmp/judge_test/nov20 \
      --plan-file ~/workspace/赚钱路子/纸面交易/2026-11-20.md \
      --traded-coins "" [--plan-copy /tmp/judge_test/plan_copy_2026-11-20.md]
  python3 test_judge_replay.py --day 2026-11-17 --data-dir /tmp/judge_test/nov17 \
      --plan-file "" --traded-coins "SOL,LINK,ADA,XRP"

验收（设计第十节）：
  11-20：预检须在 22:00 那处 flag 候选；判断须在 22:45 入场前写出 ETH
         触发（理由须写出“三次测试 1758–1760 + 22:30 一根砸到 1733”），
         且须明确判断 09:00 那处（写或不写都要有理由）。
  11-17：0 条补充触发（早上计划已成交 4 笔，不叠加；其余币按标准判断后也不写）。
  边界：无候选时不写计划、已成交跳过、23:00 后不写（见 test_judge_unit.py）。

输出：JSON 到 stdout（含每步的候选、简报结论、理由、写出的触发），
并在末尾给验收结论（PASS/FAIL + 原因）。
"""
import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from judge_precheck import precheck_coin, atr_wilder, load_file_15m  # noqa: E402
import judge_read  # noqa: E402

COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]


def day_bounds(day_str):
    """交易日 00:00–23:00 UTC（秒）。"""
    d = datetime.strptime(day_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return int(d.timestamp()), int((d + timedelta(hours=23)).timestamp())


def replay_day(day_str, data_dir, plan_file, traded_coins, plan_copy,
               plan_dirs=None):
    """按时间顺序重放一天。返回 report dict。
    plan_dirs: {coin: +1/-1/None} 早上计划的方向偏向；触发方向与早上
    计划相反时不写（方向一致性：判断层不与早上计划对着干）。"""
    start_t, end_t = day_bounds(day_str)
    # 载数据
    data = {}
    for coin in COINS:
        b15 = load_file_15m(data_dir, coin)
        b1h = judge_read.load_file_1h(data_dir, coin)
        data[coin] = (b15, b1h)
    # 计划副本（只写副本，不碰原文）
    if plan_file and os.path.exists(plan_file):
        shutil.copy(plan_file, plan_copy)
    else:
        with open(plan_copy, "w", encoding="utf-8") as f:
            f.write(f"# 测试计划副本 {day_str}\n\n")
    # 所有 15m 收盘时刻（取 ETH 的 bar 时间作时钟；各币 bar 对齐）
    eth15 = data["ETH"][0]
    closes = sorted({b["t"] + 900 for b in eth15 if start_t <= b["t"] + 900 <= end_t})
    events = []
    written = {}   # coin -> trigger（已写出的，当天上限 1 条）
    candidates_total = 0
    for close_t in closes:
        for coin in COINS:
            b15, b1h = data[coin]
            # 截至本根（含本根，已收盘）的历史
            bars15 = [b for b in b15 if b["t"] + 900 <= close_t]
            if len(bars15) < 20:
                continue
            bars1h = [b for b in b1h if b["t"] + 3600 <= close_t]
            # 预检
            cands = precheck_coin(bars15, coin)
            if not cands:
                continue
            candidates_total += len(cands)
            for cand in cands:
                direction = cand["direction"]
                # 完整读盘：确认根 = 最近已收盘根（close_t - 900）
                confirm_t = close_t - 900
                b = judge_read.brief(coin, direction, confirm_t, bars15, bars1h,
                                     plan_path=plan_file if plan_file else None)
                dec, reason, checks = judge_read.decide(b)
                ev = {"time_utc": datetime.fromtimestamp(close_t, tz=timezone.utc).strftime("%H:%M"),
                      "coin": coin, "direction": direction,
                      "kinds": cand["kinds"], "decision": dec, "reason": reason,
                      "brief_level": b.get("level"), "test_count": b.get("test_count"),
                      "probe_wick_x": (b.get("probe") or {}).get("wick_x"),
                      "confirm_move_x": (b.get("confirm") or {}).get("move_x")}
                if dec == "write":
                    # 方向一致性：早上计划有方向偏向且触发方向相反 → 不写
                    pd = (plan_dirs or {}).get(coin)
                    if pd is not None and pd != direction:
                        ev["write"] = False
                        ev["write_msg"] = (f"{coin} 早上计划偏向"
                                           f"{'做多' if pd == 1 else '做空'}，"
                                           f"触发方向{'做多' if direction == 1 else '做空'}相反，不写")
                    # 上限校验：该币当天已写过 → 跳过；早上计划已成交 → 跳过
                    elif coin in written:
                        ev["write"] = False
                        ev["write_msg"] = f"{coin} 当天已有补充触发，跳过（共用上限）"
                    elif coin in traded_coins:
                        ev["write"] = False
                        ev["write_msg"] = f"{coin} 早上计划已成交，跳过（不叠加）"
                    else:
                        trig = judge_read.build_trigger(b, reason)
                        ok, msg = judge_read.write_trigger(plan_copy, trig, lock_path=None)
                        ev["write"] = ok
                        ev["write_msg"] = msg
                        if ok:
                            written[coin] = trig
                            ev["trigger"] = {
                                "pending_entry_t": datetime.fromtimestamp(
                                    trig["pending_entry_t"], tz=timezone.utc).strftime("%H:%M"),
                                "ref_entry": trig["ref_entry"], "sl": trig["sl"],
                                "tp": trig["tp"], "level_txt": trig["level_txt"]}
                events.append(ev)
    return {
        "day": day_str, "closes_replayed": len(closes),
        "candidates_total": candidates_total,
        "triggers_written": {c: {"pending_entry": datetime.fromtimestamp(
            t["pending_entry_t"], tz=timezone.utc).strftime("%H:%M"),
            "ref": t["ref_entry"], "sl": t["sl"], "tp": t["tp"],
            "basis": t["basis"][:200]} for c, t in written.items()},
        "events": events,
        "plan_copy": plan_copy,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day", required=True)
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--plan-file", default="")
    ap.add_argument("--traded-coins", default="")
    ap.add_argument("--plan-copy", default=None)
    ap.add_argument("--plan-directions", default="")
    ap.add_argument("--state-path", default=None,
                    help="回放用的引擎 state 文件（默认用 live 的 STATE_PATH；"
                         "传一个空 state 可避免 live 当日成交挡住回放写入）")
    args = ap.parse_args()
    traded = {c for c in args.traded_coins.split(",") if c}
    if args.state_path:
        judge_read.STATE_PATH = args.state_path
    plan_dirs = {}
    if args.plan_directions:
        for part in args.plan_directions.split(","):
            if ":" in part:
                c, d = part.split(":", 1)
                plan_dirs[c] = int(d)
    elif args.plan_file:
        plan_dirs = judge_read.plan_directions(args.plan_file)
    plan_copy = args.plan_copy or f"/tmp/judge_test/plan_copy_{args.day}.md"
    rep = replay_day(args.day, args.data_dir, args.plan_file, traded, plan_copy,
                     plan_dirs=plan_dirs)
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
