#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
实时纸面交易引擎 · Gate 日内永续合约（全程模拟，不动真钱）
================================================================
用户纠正（2026-11-19）：“实时的纸面交易，而不是拿了今天的数据明天
去测算”——价格一到触发线就进、止损止盈一到就出、全天实时记。
本引擎每 30 秒拉一次 Gate 公开接口，用 mark price 实时跟踪持仓，
用已收盘 15m K 线判断触发，不用未收盘价触发入场。

两层并行（见《纸面交易/程序说明.md》）：
  主观层：读当日计划文件（~/workspace/赚钱路子/纸面交易/YYYY-MM-DD.md）
    的计划表，按写死的触发条件执行；止损 1 倍 ATR（1h）、止盈 2 倍 ATR；
    Killzone（08:00-11:00、13:00-16:00 UTC）内触发；入场为确认根的
    下一根 15m 开盘价；每币每天只触发一次（一次性预案）；23:00 UTC
    强制平仓。
  系统层：MAIN-15m（第二十轮原版，一字不变）：F1 信号（BTC 2h 收益
    |r|>=0.5% 且山寨 2h 收益 <0.5*|rBTC|），入场小时 ∈ {9,15}，
    15m ATR(14) 止损 1x / 止盈 2x，最多持 16 根，23:45 强制平仓，
    每币每天最多 2 笔，单日 -2% 熔断，同根先判止损。

口径（两层共用）：每笔 10,000 名义、1 倍；真实成本模型（2026-11-18 实测，
见 paper_cost_params.json / paper_cost_measure_2026-11-18.json）：
  入场市价单：taker 费 0.075%（7.50）+ 滑点（扫盘成本 + 0.5×1m 平均 |收益|）；
  止损市价单：taker 费 0.075% + 更差的滑点（扫盘成本 + 破位后 1 分钟延续 p90，
    波动分量约为入场的 4 倍，实测 3.5~4.3 倍）；
  止盈限价单：maker 费 0.02%（2.00）、无滑点，但 15m 高/低须穿过止盈价
    至少一个价差才算成交（mark 价同理），否则继续持有；
  23:00/23:45 强制平仓与持满平仓按普通市价单（taker 费 + 入场口径滑点）。
  30 秒轮询延迟记进日志（触发→执行延迟秒数）。资金费按实际费率、
  entry_t < 结算点 <= exit_t 计（08:00/16:00 UTC），与回测引擎同口径。
  旧口径（固定双边 0.25% = 25 USDT）保留为 --cost-model ideal，用于
  回放校验与第二十轮对照；每笔日志同时记理想成本口径与真实成本口径。

状态与恢复：状态存 paper_engine_state.json（原子写），事件存
paper_engine_YYYY-MM-DD.log（JSONL）；重启后先读 state.json，
损坏则从当日 JSONL 日志重建未平仓位，不重复开单、不丢单。
无当日计划文件时空转等待，不报错、不编数据。

运行：
  python3 paper_engine.py --live        常驻实时模式（systemd 跑这个）
  python3 paper_engine.py --once        只跑一轮（冒烟测试）
  python3 paper_engine.py --check       解析今日计划并打印，不交易
  python3 paper_engine.py --replay 2026-11-17 --plan-file <path> [--start 08:00]
                                        回放测试（读历史 K 线，不碰计划文件）
  python3 paper_engine.py --syscheck --from 2026-11-10 --to 2026-11-16
                                        系统层 MAIN-15m 回放校验（对第二十轮 trades.csv）
"""
import argparse
import fcntl
import json
import math
import os
import re
import subprocess
import sys
import time
import traceback
import urllib.request
import urllib.error
from datetime import datetime, timedelta, timezone, date

try:
    import supp_observer
    SUPP_OBSERVER_OK = True
except ImportError:
    supp_observer = None
    SUPP_OBSERVER_OK = False

BASE = os.path.dirname(os.path.abspath(__file__))


def _workspace_dir(sub):
    """工作区路径：systemd 下 User=root 时 HOME=/root，~/workspace 不存在，
    回退到 /home/hatch/workspace（2026-11-19 实测：服务因此找不到当日计划空转）。"""
    p = os.path.expanduser(f"~/workspace/{sub}")
    if os.path.isdir(p):
        return p
    return f"/home/hatch/workspace/{sub}"


PLAN_DIR = _workspace_dir("赚钱路子/纸面交易")
# 分系统 SUB-SMC 计划目录与开关（2026-11-20 新增，分系统计划驱动层）：
# 计划文件在 分系统计划/YYYY-MM-DD.md（UTC 交易日），与主计划同表头、
# 同解析器（parse_plan_table）；SUB_PLAN_ENABLED 只控制分系统“计划层”
# 是否生效，与动量版 SUB_ENABLED（False，已停用）无关，不要混淆。
SUB_PLAN_DIR = _workspace_dir("赚钱路子/纸面交易/分系统计划")
SUB_PLAN_ENABLED = True
PLAN_NOTE = ("本节由实时纸面引擎追加，计划原文不动。时间均为 UTC；每笔 10,000 名义、"
             "1 倍；成本按真实成本模型计（手续费 + 实测滑点，见程序说明；"
             "旧口径固定 25 USDT 仅作对照）。")
SUB_PLAN_NOTE = ("本节由实时纸面引擎追加，计划原文不动。时间均为 UTC；每笔 10,000 名义、"
                 "1 倍；成本按真实成本模型计（手续费 + 实测滑点，见分系统说明；"
                 "旧口径固定 25 USDT 仅作对照）。")
STATE_PATH = os.path.join(BASE, "paper_engine_state.json")
LOCK_PATH = os.path.join(BASE, "paper_engine.lock")

COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]
CONTRACT = {c: f"{c}_USDT" for c in COINS}
ALTS = [c for c in COINS if c != "BTC"]
NOMINAL = 10000.0
ROUNDTRIP_COST = 25.0  # 旧口径固定成本（ideal 模式）：taker 费 15 + 假设滑点 10
TAKER_FEE_RATE = 0.00075  # Gate VIP0 taker（API 实测）
MAKER_FEE_RATE = 0.0002   # Gate VIP0 maker
OLD_FEE_PART = 15.0       # 旧口径里的手续费部分（0.075% × 2 腿）
OLD_SLIP_PART = 10.0      # 旧口径里的假设滑点部分（0.05% × 2 腿）
COST_PARAMS_PATH = os.path.join(BASE, "paper_cost_params.json")
POLL_SEC = 30
KILLZONES = [(8 * 60, 11 * 60), (13 * 60, 16 * 60)]  # [start_min, end_min) UTC
API = "https://api.gateio.ws/api/v4/futures/usdt"
DATA_DIR = _workspace_dir("赚钱路子/data")

# 系统层 MAIN-15m（第二十轮原版）
# SYS_ENABLED：2026-11-20 01:32 CST 用户指示停用——“每个币按自己的走势和结构做，
# 不用 BTC 给定死了”。F1（BTC 领先）自 11 月 20 日起停止开新仓，只保留主观层；
# 代码保留（历史回放/校验用），syscheck 随同退役。
SYS_ENABLED = False
SYS_ENTRY_HOURS = {9, 15}
SYS_LOOKBACK = 8          # 2h = 8 根 15m
SYS_MAX_HOLD = 16         # 最多持 16 根
SYS_MAX_PER_DAY = 2
SYS_DAILY_HALT = -2000.0  # 单币单日系统层 -2000 USDT 熔断（2% × 10 万权益）
ATR_PERIOD = 14

# 分系统 SUB-15m 动量版（2026-11-20 新增，每币自己的 15m 动量跟随，全天，不看 BTC）
# 【已停用，2026-11-20 02:51 用户纠正：他说的分系统是“按照主系统的来，只是没有
# 猎杀时刻、不需要 23 点平仓”，即主观 SMC 那套画法，不是 2h 动量跟随。动量版是
# 我理解错了自己发明的信号，第三十一/三十三/三十四轮测的都是这个错信号，结论只对
# 动量信号有效，不能算分系统的验证。动量版已归档，待 SMC 版（SUB-SMC）回测后再上
# 线；停用期间引擎不产生分系统信号与持仓，主观层不受影响。】
SUB_ENABLED = False
SUB_LOOKBACK = 8          # 2h = 8 根 15m（与 F1 的 BTC 腿同口径，只换成本币自己）
SUB_MAX_HOLD = 16         # 最多持 16 根（已停用：2026-11-20 用户指示关掉 4 小时强制平仓，
                          # check_positions_hold 不再对分系统层执行；保留作归档）
SUB_MAX_PER_DAY = 2
SUB_DAILY_HALT = -2000.0  # 单币单日分系统层 -2000 USDT 熔断（2% × 10 万权益）
# 分系统 v1.2 跟踪止盈（2026-11-20 用户指示，自 2026-11-20 交易日起生效）：
# 取消固定止盈 2×ATR 与 23:00 强制平仓（分系统 only，主观层不变）：
# 初始止损仍为入场价 ±1×ATR。
# v1.3（2026-11-20 02:07 用户在主窗口纠正跟踪规则：“达到止盈位再跟踪止损”）：
# 跟踪激活门槛改为有利浮动 ≥2×ATR（即价格先触及原 2×ATR 止盈位才启动
# 跟踪）；激活后止损 = 极值 ∓1×ATR（只朝有利方向棘轮，ATR 用入场时数值；
# 激活时极值 ≥+2×ATR，所以止损 ≥+1×ATR，天然保住至少 1×ATR 利润）。
# v1.2 的 +1×ATR 激活写完未及载入即被 v1.3 取代（引擎自 11 月 19 日 13:34 UTC
# 起未重启，跑的仍是 v1.0 之前代码，分系统至今未实盘跑过）。
# 最多持 16 根（4h）不变，是跨夜持仓的唯一硬上限（最晚约入场后 4 小时平）。
# 22:45 最晚入场限制随 23:00 强平一并取消（入场只受北京时间 01:00–07:00
# 不开新单限制）。跨 00:00 UTC 的持仓由 live_loop/_load_state 结转。
SUB_TRAILING_ATR = 1.0      # 跟踪距离：极值回撤 1×ATR 即触发跟踪止损
SUB_TRAILING_ACTIVATE_ATR = 2.0  # v1.3 激活门槛：有利浮动 ≥2×ATR（到止盈位）才开始跟踪
# 分系统不开新单时段（2026-11-20 用户指示，SUB-15m v1.1，自 2026-11-20 交易日起生效）：
# 北京时间 01:00–07:00 不开新单（只禁开仓，已持仓照常按止损/止盈/23:00 平仓）。
# 北京时间 = UTC+8，所以对应 UTC 17:00–23:00（前一日 UTC 日的傍晚）。
# 其余规则与主系统一致：止损 1×ATR / 止盈 2×ATR、每天每币最多 2 笔、23:00 强制平仓。
SUB_NO_NEW_BEIJING_START = 1  # 北京时间 01:00（含）
SUB_NO_NEW_BEIJING_END = 7    # 北京时间 07:00（不含）

# 盘中补充触发（2026-11-21 设计 v1，主观层新层）：
#   观察模块 supp_observer.py（独立文件），每根 15m 收盘重读 8 个币；
#   确认后、入场前写进当日计划文件“盘中补充触发”小节，引擎下轮重读计划
#   文件解析并执行（层记 subj，走 23:00 强平与真实成本模型）。
#   v1 只开做空（SUPP_DIRECTIONS=(-1,)）；做多已实现但未单独验证，不启用。
SUPP_ENABLED = True
SUPP_DIRECTIONS = (-1,)


def _sub_entry_in_no_new_window(entry_t):
    """入场时刻（UTC 时间戳）是否落在北京时间 01:00–07:00 不开新单时段。"""
    dt_utc = datetime.fromtimestamp(entry_t, tz=timezone.utc)
    beijing_hour = (dt_utc.hour + 8) % 24
    return SUB_NO_NEW_BEIJING_START <= beijing_hour < SUB_NO_NEW_BEIJING_END
LAYER_NAME = {"subj": "主观", "sys": "系统", "sub": "分系统"}


# ----------------------------------------------------------------------
# 真实成本模型（2026-11-18 实测，paper_cost_params.json）
#   入场市价单滑点 = 扫盘成本（10,000 名义 VWAP 相对中间价，含半个价差与深度）
#                    + 0.5 × 1m 平均 |收益|（约 30 秒执行窗口内预期不利 drift）
#   止损市价单滑点 = 扫盘成本（反向边）+ 破位后 1 分钟延续 p90
#     （止损触发时价格正在向不利方向动，成交发生在 move 的尾部；实测
#      p90 延续 / (0.5×平均|1m 收益|) = 3.5~4.3 倍，取实测 p90，不另乘系数）
#   止盈限价单：maker 费，无滑点；成交须 15m 高/低穿过止盈价至少一个价差
#   （mark 价同理），否则继续持有。
# ideal 模式：旧口径——入场=开盘价、出场=止损/止盈位本身、止盈一碰成交、
#   固定成本 25，用于回放校验与第二十轮对照。
# ----------------------------------------------------------------------
class CostModel:
    def __init__(self, mode="real"):
        self.mode = mode
        self.params = {}
        if mode == "real":
            try:
                with open(COST_PARAMS_PATH) as f:
                    self.params = json.load(f).get("coins", {})
            except OSError:
                self.params = {}

    def _coin(self, coin):
        return self.params.get(coin, {})

    def entry_slip_bps(self, coin, direction):
        """入场市价单滑点（bp）。多=买 ask 边，空=卖 bid 边。"""
        if self.mode != "real":
            return 0.0
        p = self._coin(coin)
        key = "entry_slip_long_bps" if direction == 1 else "entry_slip_short_bps"
        return float(p.get(key, 0.0))

    def stop_slip_bps(self, coin, direction):
        """止损市价单滑点（bp）。多止损=卖 bid 边，空止损=买 ask 边。"""
        if self.mode != "real":
            return 0.0
        p = self._coin(coin)
        key = "stop_slip_long_bps" if direction == 1 else "stop_slip_short_bps"
        return float(p.get(key, 0.0))

    def market_slip_bps(self, coin, direction):
        """普通市价单出场滑点（持满/23:00 平仓）：与入场同口径，但方向反向
        （多头平仓=卖 bid 边，空头平仓=买 ask 边）。"""
        if self.mode != "real":
            return 0.0
        p = self._coin(coin)
        key = "entry_slip_short_bps" if direction == 1 else "entry_slip_long_bps"
        return float(p.get(key, 0.0))

    def spread_bps(self, coin):
        if self.mode != "real":
            return 0.0
        return float(self._coin(coin).get("spread_bps", 0.0))

    def spread_abs(self, coin, price):
        """一个完整价差对应的价格单位。"""
        return price * self.spread_bps(coin) / 10000.0

    @staticmethod
    def slip_usdt(bps):
        return bps / 10000.0 * NOMINAL

    @staticmethod
    def taker_fee():
        return TAKER_FEE_RATE * NOMINAL

    @staticmethod
    def maker_fee():
        return MAKER_FEE_RATE * NOMINAL


def utcnow():
    return datetime.now(timezone.utc)


def ts_to_dt(t):
    return datetime.fromtimestamp(t, timezone.utc)


def fmt_ts(t):
    return ts_to_dt(t).strftime("%Y-%m-%dT%H:%M:%SZ")


def fmt_price(x):
    if x is None:
        return "-"
    s = f"{x:.8f}".rstrip("0").rstrip(".")
    return s if s not in ("-0", "") else "0"


def parse_num(s):
    """解析 '63,900' / '72.52' / '0.05990' 这类数字串。"""
    if s is None:
        return None
    s = str(s).replace(",", "").replace("，", "").strip()
    m = re.search(r"-?\d+\.?\d*", s)
    return float(m.group(0)) if m else None


def in_killzone(dt):
    """确认根收盘时刻是否在 Killzone 内；区间左闭右开（16:00 整点不算）。"""
    mins = dt.hour * 60 + dt.minute
    return any(a <= mins < b for a, b in KILLZONES)


# ----------------------------------------------------------------------
# Gate 公开接口（无鉴权），失败重试 3 次，429 退避，失败记日志
# ----------------------------------------------------------------------
class GateClient:
    def __init__(self, log_fn=None):
        self.log_fn = log_fn or (lambda *a, **k: None)

    def _get(self, url, retries=3):
        # 2026-11-19 实测：urllib 经 egress 代理拉 Gate 大响应必截断
        #（tickers 486KB：urllib 0/10，curl 10/10；K 线也在固定字节数截断），
        # 改用 curl 子进程（代理环境变量由 systemd EnvironmentFile / shell 继承）。
        last_err = None
        for attempt in range(retries):
            try:
                cp = subprocess.run(
                    ["curl", "-sS", "-m", "25", "-w", "\n%{http_code}", url],
                    capture_output=True, text=True, timeout=30)
                body, _, code = cp.stdout.rpartition("\n")
                http_code = int(code.strip()) if code.strip().isdigit() else 0
                if http_code == 429:
                    wait = 10 * (attempt + 1)
                    self.log_fn("fetch_429", {"url": url, "wait": wait})
                    time.sleep(wait)
                    continue
                if cp.returncode != 0 or http_code != 200:
                    last_err = (f"curl exit {cp.returncode} http {http_code}: "
                                f"{cp.stderr.strip()[:150]} {url}")
                    time.sleep(1 * (attempt + 1))
                    continue
                return json.loads(body)
            except Exception as e:  # noqa: BLE001 - 网络失败一律重试后记日志
                last_err = f"{type(e).__name__}: {e} {url}"
                time.sleep(1 * (attempt + 1))
        self.log_fn("fetch_failed", {"url": url, "error": str(last_err)})
        raise RuntimeError(last_err)

    def tickers(self):
        data = self._get(f"{API}/tickers")
        return {d["contract"]: d for d in data if isinstance(d, dict)}

    def candles(self, contract, interval, limit=None, frm=None, to=None):
        url = f"{API}/candlesticks?contract={contract}&interval={interval}"
        if limit is not None:
            url += f"&limit={limit}"
        if frm is not None:
            url += f"&from={int(frm)}"
        if to is not None:
            url += f"&to={int(to)}"
        data = self._get(url)
        if isinstance(data, dict):  # 错误对象
            raise RuntimeError(f"Gate candles error: {data}")
        bars = [{"t": int(b["t"]), "o": float(b["o"]), "h": float(b["h"]),
                 "l": float(b["l"]), "c": float(b["c"])} for b in data]
        bars.sort(key=lambda b: b["t"])
        return bars

    def funding_rates(self, contract, limit=10):
        data = self._get(f"{API}/funding_rate?contract={contract}&limit={limit}")
        if isinstance(data, dict):
            raise RuntimeError(f"Gate funding error: {data}")
        return {int(d["t"]): float(d["r"]) for d in data}


def funding_cost_between(funding, entry_t, exit_t, notional, direction):
    """与回测引擎同口径：entry_t < 结算点 <= exit_t 的 08:00/16:00 结算点计费。
    cost 为正 = 多头付费（资金费为正时）；空头反向。"""
    if not funding:
        return 0.0
    cost = 0.0
    day = ts_to_dt(entry_t).date()
    for d_offset in (0, 1):
        ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc) + timedelta(days=d_offset)
        for h in (8, 16):
            s = int((ds + timedelta(hours=h)).timestamp())
            if entry_t < s <= exit_t and s in funding:
                cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def atr_wilder(bars, period=ATR_PERIOD):
    """与回测引擎一字相同的 Wilder ATR。"""
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


# ----------------------------------------------------------------------
# 计划解析（主观层）：读当日计划文件的计划表
# ----------------------------------------------------------------------
COIN_ZH = {"BTC": "BTC", "ETH": "ETH", "SOL": "SOL", "DOGE": "DOGE",
           "LINK": "LINK", "XRP": "XRP", "BNB": "BNB", "ADA": "ADA"}


def _split_row(line):
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    return cells


def parse_plan_table(text):
    """解析计划表，返回 {coin: plan_dict}。plan 包含触发解析结果。
    触发条件解析规则（与 11 月 17 日结算口径一致）：
      触及：'刺破 X' -> 长：bar low < X；空：bar high > X。
            '摸进/回踩进 X–Y' -> 长：bar low <= Y；空：bar high >= X。
      确认：按顺序提取 '回到 X 上方/下方'、'上破 X'、'下破 X'，
            每一步必须在比上一步更晚的一根已收盘 15m 上成立，
            最后一步收盘时刻必须在 Killzone 内（'随后' = 事后一根，同根不算）。
      失效：'触发前 1h 收盘下破/上破 X' -> 1h 收盘越过该价即作废。"""
    plans = {}
    lines = text.splitlines()
    # 定位计划表表头
    hdr_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("|") and "币" in ln and "触发条件" in ln:
            hdr_idx = i
            break
    if hdr_idx is None:
        return plans
    header = _split_row(lines[hdr_idx])
    col = {}
    for j, h in enumerate(header):
        for key in ("币", "方向", "入场区", "参考入场价", "止损", "止盈", "触发条件", "失效条件"):
            if key in h and key not in col:
                col[key] = j
    if "币" not in col or "触发条件" not in col:
        return plans
    for ln in lines[hdr_idx + 2:]:
        if not ln.strip().startswith("|"):
            if plans:
                break
            continue
        cells = _split_row(ln)
        if len(cells) <= max(col.values()):
            continue
        coin_cell = cells[col["币"]].strip()
        coin = None
        for c in COINS:
            if c in coin_cell:
                coin = c
                break
        if coin is None or coin in plans:
            continue
        direction = 1 if "做多" in cells[col["方向"]] else (-1 if "做空" in cells[col["方向"]] else 0)
        if direction == 0:
            continue
        zone_m = re.search(r"([\d,\.]+)\s*[–—\-]\s*([\d,\.]+)", cells[col["入场区"]])
        zone = (parse_num(zone_m.group(1)), parse_num(zone_m.group(2))) if zone_m else (None, None)
        trig = cells[col["触发条件"]]
        invalid = cells[col["失效条件"]]
        plan = {
            "coin": coin, "direction": direction,
            "zone": zone,
            "ref_entry": parse_num(cells[col["参考入场价"]]),
            "sl": parse_num(cells[col["止损"]]),
            "tp": parse_num(cells[col["止盈"]]),
            "trigger_text": trig, "invalid_text": invalid,
        }
        # --- 触及条件 ---
        m = re.search(r"刺破\s*([\d,\.]+)", trig)
        if m:
            lvl = parse_num(m.group(1))
            plan["touch"] = {"kind": "level", "level": lvl}
        else:
            m2 = re.search(r"(?:摸进|回踩进|进入)\s*([\d,\.]+)\s*[–—\-]\s*([\d,\.]+)", trig)
            if m2:
                lo, hi = parse_num(m2.group(1)), parse_num(m2.group(2))
            else:
                lo, hi = zone
            plan["touch"] = {"kind": "zone", "lo": lo, "hi": hi}
        # --- 确认步骤（按文中顺序）---
        steps = []
        for mm in re.finditer(r"(回到|上破|下破)\s*([\d,\.]+)\s*(上方|下方)?", trig):
            verb, num, side = mm.group(1), parse_num(mm.group(2)), mm.group(3)
            if verb == "上破":
                steps.append(("above", num))
            elif verb == "下破":
                steps.append(("below", num))
            elif verb == "回到" and side == "上方":
                steps.append(("above", num))
            elif verb == "回到" and side == "下方":
                steps.append(("below", num))
        plan["confirm_steps"] = steps
        # --- 失效价（只取'触发前 1h 收盘'那一段）---
        first_clause = invalid.split("；")[0]
        mi = re.search(r"(下破|上破)\s*([\d,\.]+)", first_clause)
        if mi:
            plan["invalid"] = {"kind": "below" if mi.group(1) == "下破" else "above",
                               "level": parse_num(mi.group(2))}
        else:
            plan["invalid"] = None
        plans[coin] = plan
    return plans


def parse_cutoff(text):
    """解析计划文件里的'数据截止：YYYY-MM-DD HH:MM UTC'，没有则返回 None。"""
    m = re.search(r"数据截止[：:]\s*(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})\s*UTC", text)
    if not m:
        return None
    return datetime.strptime(f"{m.group(1)} {m.group(2)}", "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)


def touch_hit(plan, bar):
    """bar（已收盘 15m）是否满足触及条件。"""
    t = plan["touch"]
    if t["kind"] == "level":
        if plan["direction"] == 1:
            return bar["l"] < t["level"]
        return bar["h"] > t["level"]
    lo, hi = t["lo"], t["hi"]
    if plan["direction"] == 1:
        return hi is not None and bar["l"] <= hi
    return lo is not None and bar["h"] >= lo


def confirm_hit(step, bar):
    """bar 收盘价是否满足某一步确认条件。"""
    kind, lvl = step
    if kind == "above":
        return bar["c"] > lvl
    return bar["c"] < lvl


# ----------------------------------------------------------------------
# 引擎：状态、事件日志、持仓管理
# ----------------------------------------------------------------------
def atomic_write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


class Engine:
    def __init__(self, client=None, dry_log=False, cost_mode="real"):
        self.client = client or GateClient(log_fn=self._client_log_event)
        # 无论客户端从哪来，拉取失败一律记进引擎日志（任务要求：记每次拉取失败）
        self._last_fetch_error_log = 0.0
        self.client.log_fn = self._client_log_event
        self.dry_log = dry_log  # 回放模式：不写计划文件、不写 state、不碰真实日志
        self.cost = CostModel(cost_mode)
        self._last_tick_t = None  # 上一轮 live tick 的时间戳（mark 出场检测延迟用）
        self.today = utcnow().date()
        self.state = self._new_state()
        self.funding_override = None  # {contract: {settlement_t: rate}}，回放/校验用历史资金费
        if not dry_log:
            self._load_state()
        self._log_fh = None
        self._last_idle_log = 0.0

    # ---- 状态 ----
    def _new_state(self):
        return {
            "date": self.today.isoformat(),
            "plan_mtime": None,
            "plans": {},        # coin -> {status, touch_bar_t, confirm_idx, confirm_bar_t, trades_done, invalidated}
            "sub_plan_mtime": None,
            "sub_plans": {},    # coin -> 与 plans 同形，分系统计划层状态
            "supp": {},         # coin -> {status, trigger, pending_entry_t, trades_done} 盘中补充触发
            "positions": [],    # open positions
            "trades": [],       # closed trades today (both layers)
            "sys_trades_today": {},   # coin -> n
            "sys_day_pnl": {},        # coin -> realized pnl today (system layer)
            "trades_today": {},       # coin -> n (both layers, cap 2)
            "funding_applied": [],    # [contract|settlement_t] 已记过的资金费
            "last_15m": {},     # coin -> last processed closed bar t
            "last_1h": {},      # coin -> last processed closed bar t
            "sys_last_sig_bar": {},   # coin -> last signal bar t evaluated
            "sys_pending": {},        # coin -> pending system entry {entry_t, direction, atr, sl, tp}
            "sys_bars": {},     # coin -> recent 15m bars (list, for ATR/lookback)
            "sub_trades_today": {},   # coin -> n（分系统层）
            "sub_day_pnl": {},        # coin -> realized pnl today（分系统层）
            "sub_pending": {},        # coin -> pending sub entry {entry_t, direction, atr}
            "funding_done_day": None,
            "summary_done": False,
        }

    def _load_state(self):
        # v1.2：分系统持仓可跨 00:00 UTC（取消 23:00 强平），换天时必须结转
        # 未平的分系统持仓，否则持仓会在新一天的状态里凭空消失（漏记盈亏）。
        carried_sub = []
        if os.path.exists(STATE_PATH):
            try:
                with open(STATE_PATH) as f:
                    st = json.load(f)
                if st.get("date") == self.today.isoformat():
                    # 状态迁移：旧版 state 文件可能缺新层键（如分系统上线前写的
                    # 文件没有 sub_* 键），缺失的一律用新版默认值补齐，否则
                    # sub_try_entry 等处直接 KeyError（2026-11-20 实测）。
                    fresh = self._new_state()
                    for k, v in fresh.items():
                        st.setdefault(k, v)
                    self.state = st
                    return
                # 隔天：归档旧状态前，先捞出未平的分系统持仓（主观/系统层仍按
                # 23:00/23:45 强平，不结转；只有分系统可以跨夜）。
                carried_sub = [p for p in st.get("positions", [])
                               if p.get("layer") == "sub"]
                arch = STATE_PATH + "." + st.get("date", "unknown")
                try:
                    os.replace(STATE_PATH, arch)
                except OSError:
                    pass
            except Exception:
                pass  # 损坏则从日志重建
        rebuilt = self._rebuild_from_log()
        if rebuilt is not None:
            self.state = rebuilt
        if carried_sub:
            # 持仓身份 = (币, 层, 入场时刻)：主观层与分系统层同币同根入场时
            # entry_t 相同，只用 (币, 入场时刻) 去重/删除会误删另一层的持仓
            # （2026-11-20 回放实测：主观层平仓误删分系统同币持仓，持仓凭空消失）。
            have = {(p["coin"], p.get("layer"), p["entry_t"]) for p in self.state["positions"]}
            for p in carried_sub:
                if (p["coin"], p.get("layer"), p["entry_t"]) not in have:
                    self.state["positions"].append(p)
            self.log_event("sub_carryover", {"day": self.today.isoformat(),
                                             "positions": len(carried_sub),
                                             "coins": [p["coin"] for p in carried_sub]})
            self._save_state()

    def _rebuild_from_log(self):
        """state.json 丢失/损坏时，从当日 JSONL 日志重建未平仓位与计数。"""
        logp = self._log_path(self.today)
        if not os.path.exists(logp):
            return None
        st = self._new_state()
        try:
            with open(logp) as f:
                for line in f:
                    try:
                        ev = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    t = ev.get("type")
                    if t == "entry":
                        st["positions"].append(ev["position"])
                        st["trades_today"][ev["coin"]] = st["trades_today"].get(ev["coin"], 0) + 1
                        if ev["position"]["layer"] == "sys":
                            st["sys_trades_today"][ev["coin"]] = st["sys_trades_today"].get(ev["coin"], 0) + 1
                        elif ev["position"]["layer"] == "sub":
                            st["sub_trades_today"][ev["coin"]] = st["sub_trades_today"].get(ev["coin"], 0) + 1
                    elif t == "exit":
                        # 出场只删同层同币同入场时刻的持仓（同上：两层同根入场时
                        # entry_t 相同，不带 layer 会误删另一层持仓）。
                        st["positions"] = [p for p in st["positions"]
                                           if not (p["coin"] == ev["coin"]
                                                   and p.get("layer") == ev["trade"].get("layer")
                                                   and p["entry_t"] == ev["entry_t"])]
                        st["trades"].append(ev["trade"])
                        if ev["trade"]["layer"] == "sys":
                            st["sys_day_pnl"][ev["coin"]] = st["sys_day_pnl"].get(ev["coin"], 0.0) + ev["trade"]["net"]
                        elif ev["trade"]["layer"] == "sub":
                            st["sub_day_pnl"][ev["coin"]] = st["sub_day_pnl"].get(ev["coin"], 0.0) + ev["trade"]["net"]
                    elif t == "plan_triggered":
                        st["plans"].setdefault(ev["coin"], {})["status"] = "triggered"
                    elif t == "entry_missed":
                        st["plans"].setdefault(ev["coin"], {})["status"] = "done"
                        st["plans"][ev["coin"]]["missed"] = True
                    elif t == "plan_invalidated":
                        st["plans"].setdefault(ev["coin"], {})["status"] = "invalidated"
                    elif t == "sub_plan_triggered":
                        st["sub_plans"].setdefault(ev["coin"], {})["status"] = "triggered"
                    elif t == "sub_plan_entry_missed":
                        st["sub_plans"].setdefault(ev["coin"], {})["status"] = "done"
                        st["sub_plans"][ev["coin"]]["missed"] = True
                    elif t == "sub_plan_invalidated":
                        st["sub_plans"].setdefault(ev["coin"], {})["status"] = "invalidated"
                    elif t == "sub_trail_update":
                        # 跟踪止损移动后重建：把最新的 sl/peak/trail_active 贴回持仓
                        # （只贴分系统层持仓；主观层同币同根持仓的 sl 不能被误改）。
                        for p in st["positions"]:
                            if (p["coin"] == ev["coin"] and p.get("layer") == "sub"
                                    and p["entry_t"] == ev["entry_t"]):
                                p["sl"] = ev["sl"]
                                p["peak"] = ev["peak"]
                                p["trail_active"] = ev["trail_active"]
        except OSError:
            return None
        # v1.2：state 文件丢失/损坏时，从昨日日志里找回未平的分系统持仓
        # （跨夜持仓的 entry 在昨日日志、exit 还没发生；只补持仓，不补计数）。
        try:
            yday = self.today - timedelta(days=1)
            ylog = self._log_path(yday)
            if os.path.exists(ylog):
                y_entries, y_exits = {}, set()
                with open(ylog) as f:
                    for line in f:
                        try:
                            ev = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        if ev.get("type") == "entry" and ev.get("position", {}).get("layer") == "sub":
                            y_entries[(ev["coin"], ev["position"].get("layer"), ev["entry_t"])] = ev["position"]
                        elif ev.get("type") == "exit":
                            y_exits.add((ev["coin"], ev["trade"].get("layer"), ev["entry_t"]))
                have = {(p["coin"], p.get("layer"), p["entry_t"]) for p in st["positions"]}
                for k, p in y_entries.items():
                    if k not in y_exits and k not in have:
                        st["positions"].append(p)
        except OSError:
            pass
        return st

    def _save_state(self):
        if self.dry_log:
            return
        try:
            atomic_write_json(STATE_PATH, self.state)
        except OSError:
            pass

    # ---- 日志 ----
    def _log_path(self, day):
        if self.dry_log:
            return os.path.join(BASE, f"paper_engine_replay_{day.isoformat()}.log")
        return os.path.join(BASE, f"paper_engine_{day.isoformat()}.log")

    def log_event(self, etype, fields=None, **kw):
        ev = {"ts": utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"), "type": etype}
        if fields:
            ev.update(fields)
        ev.update(kw)
        line = json.dumps(ev, ensure_ascii=False)
        try:
            with open(self._log_path(self.today), "a") as f:
                f.write(line + "\n")
        except OSError:
            pass
        return ev

    def _client_log_event(self, etype, fields):
        # Gate 拉取失败：节流记日志（同一错误 5 分钟内只记一次，避免刷屏）
        now = time.time()
        if now - self._last_fetch_error_log < 300 and etype == "fetch_failed":
            return
        self._last_fetch_error_log = now
        self.log_event(etype, **fields)

    # ---- 计划文件：只追加“实时执行记录”，不动原文 ----
    # plan_dir/note：默认写主计划文件（主观/系统层行为不变）；分系统层调用时
    # 传 plan_dir=SUB_PLAN_DIR、note=SUB_PLAN_NOTE，记录只进分系统计划文件。
    def append_plan_record(self, day, line, plan_dir=None, note=None):
        if self.dry_log:
            return
        path = os.path.join(plan_dir if plan_dir is not None else PLAN_DIR,
                            f"{day.isoformat()}.md")
        if not os.path.exists(path):
            return
        try:
            with open(LOCK_PATH, "w") as lockf:
                fcntl.flock(lockf, fcntl.LOCK_EX)
                try:
                    with open(path) as f:
                        content = f.read()
                    header = "## 实时执行记录（引擎实时结算）"
                    ts = utcnow().strftime("%H:%M:%S")
                    rec = f"- {ts} UTC {line}"
                    note_text = note if note is not None else PLAN_NOTE
                    if header not in content:
                        content = content.rstrip("\n") + f"\n\n{header}\n\n> {note_text}\n\n{rec}\n"
                    else:
                        content = content.rstrip("\n") + f"\n{rec}\n"
                    tmp = path + ".tmp"
                    with open(tmp, "w") as f:
                        f.write(content)
                    os.replace(tmp, path)
                finally:
                    fcntl.flock(lockf, fcntl.LOCK_UN)
        except OSError:
            self.log_event("plan_append_failed", {"day": day.isoformat(), "line": line})

    # ---- 盈亏 ----
    @staticmethod
    def gross_pnl(entry, exit_price, direction):
        return (exit_price - entry) / entry * NOMINAL * direction

    def close_position(self, pos, exit_t, exit_price, reason, exit_via="mark",
                       exit_latency_sec=0.0):
        """平仓：算资金费（entry_t < 结算点 <= exit_t）、按真实成本模型算
        成交价与成本明细、记日志。
        exit_price 是参考价（止损/止盈位、K 线收盘价、mark 价）；真实成交价
        按出场种类调整：止损市价单 = 参考价 ∓ 止损滑点；止盈限价单 = 止盈价
        本身（maker）；持满/强制平仓 = 参考价 ∓ 普通市价滑点。
        ideal 模式：沿用旧口径（成交价=参考价，固定成本 25），一字不变。"""
        funding_cost = 0.0
        try:
            if self.funding_override is not None:
                fr = self.funding_override.get(CONTRACT[pos["coin"]], {})
            else:
                fr = self.client.funding_rates(CONTRACT[pos["coin"]], limit=10)
            funding_cost = funding_cost_between(fr, pos["entry_t"], exit_t, NOMINAL, pos["direction"])
        except Exception as e:  # noqa: BLE001 - 资金费拉不到就记 0 并留日志
            self.log_event("funding_fetch_failed", {"coin": pos["coin"], "error": str(e)[:200]})
        coin, d = pos["coin"], pos["direction"]
        entry_ref = pos.get("entry_ref", pos["entry"])
        fee_entry = pos.get("fee_entry", self.cost.taker_fee())
        slip_entry = pos.get("slip_entry_usdt", 0.0)
        if reason == "take_profit":
            kind = "tp"
        elif reason in ("stop_loss", "trailing_stop"):
            # 跟踪止损也是止损市价单：触发时价格正朝不利方向走，执行滑点与止损同口径
            kind = "stop"
        else:
            kind = "market"
        if self.cost.mode == "ideal":
            fill = exit_price
            fee_exit = self.cost.taker_fee()
            slip_exit = 0.0
            gross = self.gross_pnl(pos["entry"], fill, d)
            net = gross - ROUNDTRIP_COST - funding_cost
            gross_ideal, net_ideal, cost_real = gross, net, ROUNDTRIP_COST
        else:
            if kind == "tp":
                fill = exit_price
                fee_exit = self.cost.maker_fee()
                slip_exit = 0.0
            elif kind == "stop":
                sb = self.cost.stop_slip_bps(coin, d)
                fill = exit_price * (1 - d * sb / 10000.0)
                fee_exit = self.cost.taker_fee()
                slip_exit = abs(fill - exit_price) / exit_price * NOMINAL
            else:  # market（持满 / 23:00 / 23:45 强制平仓）
                mb = self.cost.market_slip_bps(coin, d)
                fill = exit_price * (1 - d * mb / 10000.0)
                fee_exit = self.cost.taker_fee()
                slip_exit = abs(fill - exit_price) / exit_price * NOMINAL
            gross = self.gross_pnl(pos["entry"], fill, d)
            gross_ideal = self.gross_pnl(entry_ref, exit_price, d)
            cost_real = fee_entry + fee_exit
            net = gross - cost_real - funding_cost
            net_ideal = gross_ideal - ROUNDTRIP_COST - funding_cost
        trade = {"coin": coin, "layer": pos["layer"], "direction": d,
                 "entry_t": pos["entry_t"], "entry": pos["entry"],
                 "entry_ref": entry_ref,
                 "exit_t": exit_t, "exit": fill, "exit_ref": exit_price,
                 "reason": reason, "exit_kind": kind,
                 "gross": round(gross, 2), "gross_ideal": round(gross_ideal, 2),
                 "cost": round(cost_real, 2), "cost_ideal": ROUNDTRIP_COST,
                 "fee_entry": round(fee_entry, 2), "fee_exit": round(fee_exit, 2),
                 "slip_entry_usdt": round(slip_entry, 2),
                 "slip_exit_usdt": round(slip_exit, 2),
                 "slip_usdt": round(slip_entry + slip_exit, 2),
                 "spread_bps": self.cost.spread_bps(coin),
                 "entry_latency_sec": pos.get("entry_latency_sec", 0.0),
                 "exit_latency_sec": round(exit_latency_sec, 1),
                 "funding_cost": round(funding_cost, 2), "net": round(net, 2),
                 "net_ideal": round(net_ideal, 2),
                 "sl": pos["sl"], "tp": pos["tp"],
                 "supp": bool(pos.get("supp", False)),
                 "supp_level": pos.get("supp_level", ""),
                 "supp_basis": pos.get("supp_basis", "")}
        self.state["positions"] = [p for p in self.state["positions"]
                                   if not (p["coin"] == pos["coin"]
                                           and p.get("layer") == pos.get("layer")
                                           and p["entry_t"] == pos["entry_t"])]
        self.state["trades"].append(trade)
        if pos["layer"] == "sys":
            c = pos["coin"]
            self.state["sys_day_pnl"][c] = self.state["sys_day_pnl"].get(c, 0.0) + net
        elif pos["layer"] == "sub":
            c = pos["coin"]
            self.state["sub_day_pnl"][c] = self.state["sub_day_pnl"].get(c, 0.0) + net
        self.log_event("exit", coin=pos["coin"], entry_t=pos["entry_t"], trade=trade)
        dd = "多" if pos["direction"] == 1 else "空"
        line = (f"{pos['coin']} {LAYER_NAME.get(pos['layer'], pos['layer'])}做{dd}平仓："
                f"入场 {fmt_price(pos['entry'])} → 出场 {fmt_price(fill)}（{reason}，{exit_via}），"
                f"毛利 {gross:+.2f}，手续费 {fee_entry + fee_exit:.2f}（入 {fee_entry:.2f}/出 {fee_exit:.2f}），"
                f"滑点 {slip_entry + slip_exit:.2f}，资金费 {funding_cost:+.2f}，"
                f"净盈亏 {net:+.2f} USDT（理想口径 {net_ideal:+.2f}）")
        if pos["layer"] == "sub":
            self.append_plan_record(self.today, line, plan_dir=SUB_PLAN_DIR, note=SUB_PLAN_NOTE)
        else:
            self.append_plan_record(self.today, line)
        self._save_state()
        return trade

    def open_position(self, coin, layer, direction, entry_t, entry, sl, tp, extra=None,
                      latency_sec=0.0):
        """开仓：entry 是参考价（下一根 15m 开盘价）；真实成交价 = 参考价 ± 入场滑点
        （市价单扫盘成本 + 波动分量；ideal 模式成交价 = 参考价）。"""
        slip_bps = self.cost.entry_slip_bps(coin, direction)
        if self.cost.mode == "real":
            fill = entry * (1 + direction * slip_bps / 10000.0)
        else:
            fill = entry
        fee_entry = self.cost.taker_fee()
        slip_usdt = abs(fill - entry) / entry * NOMINAL
        pos = {"coin": coin, "layer": layer, "direction": direction,
               "entry_t": entry_t, "entry": fill, "entry_ref": entry,
               "sl": sl, "tp": tp,
               "fee_entry": round(fee_entry, 2),
               "slip_entry_usdt": round(slip_usdt, 2),
               "slip_entry_bps": round(slip_bps, 3),
               "spread_bps": self.cost.spread_bps(coin),
               "entry_latency_sec": round(latency_sec, 1)}
        if extra:
            pos.update(extra)
        self.state["positions"].append(pos)
        self.state["trades_today"][coin] = self.state["trades_today"].get(coin, 0) + 1
        if layer == "sys":
            self.state["sys_trades_today"][coin] = self.state["sys_trades_today"].get(coin, 0) + 1
        elif layer == "sub":
            self.state["sub_trades_today"][coin] = self.state["sub_trades_today"].get(coin, 0) + 1
        self.log_event("entry", coin=coin, position=pos)
        d = "多" if direction == 1 else "空"
        note = ""
        if extra and "plan_sl" in extra:
            note = (f"（计划止损 {fmt_price(extra['plan_sl'])}、止盈 "
                    f"{fmt_price(extra['plan_tp'])}，按入场开盘价重算 1×/2×ATR）")
        line = (f"{coin} {LAYER_NAME.get(layer, layer)}做{d}入场：{fmt_price(fill)}，"
                f"止损 {fmt_price(sl)}，止盈 {fmt_price(tp)}{note}"
                f"（参考开盘 {fmt_price(entry)}，入场滑点 {slip_bps:.2f}bp/{slip_usdt:.2f} USDT，"
                f"触发→执行延迟 {latency_sec:.0f} 秒）")
        if layer == "sub":
            self.append_plan_record(self.today, line, plan_dir=SUB_PLAN_DIR, note=SUB_PLAN_NOTE)
        else:
            self.append_plan_record(self.today, line)
        self._save_state()
        return pos


    # ---- 主观层：对一根已收盘 15m 做触发判定 ----
    def subj_on_closed_bar(self, coin, bar, plan, plan_mtime):
        """处理一根已收盘 15m。bar: {t,o,h,l,c}，t 为开盘时间戳。"""
        st = self.state["plans"].setdefault(coin, {"status": "waiting", "confirm_idx": 0,
                                                   "touch_bar_t": None, "confirm_bar_t": None,
                                                   "trades_done": 0})
        if st["status"] in ("triggered", "invalidated", "done"):
            return
        if st.get("trades_done", 0) >= 1:
            st["status"] = "done"
            return
        close_t = bar["t"] + 900
        # 只评估计划写成之后收盘的 K 线（回放时用 --start 控制）
        if plan_mtime is not None and close_t <= plan_mtime:
            return
        # 触及
        if st["status"] == "waiting":
            if touch_hit(plan, bar):
                st["status"] = "touched"
                st["touch_bar_t"] = bar["t"]
                st["confirm_idx"] = 0
                self.log_event("plan_touched", coin=coin, bar_t=bar["t"],
                               bar_close=fmt_ts(close_t))
                self._save_state()
            return
        # 确认步骤（每步必须在比上一步更晚的一根上成立）
        if st["status"] == "touched":
            idx = st.get("confirm_idx", 0)
            steps = plan["confirm_steps"]
            if idx < len(steps) and bar["t"] > st["touch_bar_t"] and confirm_hit(steps[idx], bar):
                # 本步成立：若不是最后一步，下一根继续；若是最后一步，判 Killzone
                if idx + 1 < len(steps):
                    st["confirm_idx"] = idx + 1
                    st["touch_bar_t"] = bar["t"]  # 下一步必须更晚
                    self.log_event("plan_confirm_step", coin=coin, step=idx + 1,
                                   bar_t=bar["t"])
                    self._save_state()
                    return
                # 最后一步：收盘时刻必须在 Killzone 内
                if not in_killzone(ts_to_dt(close_t)):
                    self.log_event("plan_confirm_outside_killzone", coin=coin, bar_t=bar["t"],
                                   bar_close=fmt_ts(close_t))
                    st["status"] = "waiting"  # 确认失败，回到等待（触及状态不保留）
                    st["confirm_idx"] = 0
                    st["touch_bar_t"] = None
                    self._save_state()
                    return
                st["status"] = "confirmed"
                st["confirm_bar_t"] = bar["t"]
                st["pending_entry_t"] = bar["t"] + 900
                self.log_event("plan_triggered", coin=coin, bar_t=bar["t"],
                               bar_close=fmt_ts(close_t),
                               pending_entry_t=bar["t"] + 900)
                d = "多" if plan["direction"] == 1 else "空"
                self.append_plan_record(
                    self.today,
                    f"{coin} 主观做{d}触发：确认根 {fmt_ts(close_t)} 收盘，"
                    f"下一根 15m 开盘入场（参考 {fmt_price(plan['ref_entry'])}）")
                self._save_state()

    def subj_on_closed_1h(self, coin, bar, plan):
        """1h 收盘失效检查（只在触发前有效）。"""
        st = self.state["plans"].setdefault(coin, {"status": "waiting"})
        if st["status"] in ("triggered", "invalidated", "done"):
            return
        inv = plan.get("invalid")
        if not inv:
            return
        hit = (bar["c"] < inv["level"]) if inv["kind"] == "below" else (bar["c"] > inv["level"])
        if hit:
            st["status"] = "invalidated"
            self.log_event("plan_invalidated", coin=coin, bar_t=bar["t"],
                           close=bar["c"], level=inv["level"])
            self.append_plan_record(
                self.today,
                f"{coin} 主观计划作废：1h 收盘 {fmt_price(bar['c'])} 越过失效价 "
                f"{fmt_price(inv['level'])}")
            self._save_state()

    def subj_try_entry(self, coin, bar_open_t, bar_open, plan, latency_sec=0.0):
        """新一根 15m 开盘时，若有待入场计划则执行入场。
        latency_sec：触发确认根收盘 → 本轮检测到开盘的秒数（live 实测，
        回放为 0）。"""
        st = self.state["plans"].get(coin)
        if not st or st["status"] != "confirmed":
            return
        pend = st.get("pending_entry_t")
        if pend is None:
            return
        if pend < bar_open_t:
            # 入场窗口已过（引擎停摆期间错过）：记一条 entry_missed，
            # 释放计划，不再尝试。否则计划永远卡在 confirmed，无日志无释放。
            eod_t = int(datetime(self.today.year, self.today.month, self.today.day,
                                 23, 0, tzinfo=timezone.utc).timestamp())
            if pend >= eod_t:
                self.log_event("entry_skipped_eod", coin=coin, bar_open_t=pend)
            else:
                self.log_event("entry_missed", coin=coin, pending_entry_t=pend,
                               bar_open_t=bar_open_t, reason="stale_expired")
                self.append_plan_record(
                    self.today,
                    f"{coin} 主观计划未入场：待入场时间 {fmt_ts(pend)} 已过"
                    f"（引擎停摆错过），不再尝试")
            st["status"] = "done"
            st["missed"] = True
            st["missed_reason"] = "stale_expired" if pend < eod_t else "eod"
            self._save_state()
            return
        if pend != bar_open_t:
            return
        if bar_open_t >= int(datetime(self.today.year, self.today.month, self.today.day,
                                      23, 0, tzinfo=timezone.utc).timestamp()):
            self.log_event("entry_skipped_eod", coin=coin, bar_open_t=bar_open_t)
            st["status"] = "done"
            self._save_state()
            return
        # 入场价若已穿计划止损：跳过（setup 已失效）；若已穿计划止盈：跳过（目标已到，无利可图）。
        plan_sl, plan_tp = plan["sl"], plan["tp"]
        if plan["direction"] == 1 and bar_open <= plan_sl:
            self.log_event("entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if plan["direction"] == -1 and bar_open >= plan_sl:
            self.log_event("entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if (plan["direction"] == 1 and bar_open >= plan_tp) or (plan["direction"] == -1 and bar_open <= plan_tp):
            self.log_event("entry_skipped_tp_reached", coin=coin, open=bar_open, tp=plan_tp)
            self.append_plan_record(
                self.today,
                f"{coin} 主观计划未入场：开盘价 {fmt_price(bar_open)} 已到计划止盈 "
                f"{fmt_price(plan_tp)}，目标已走完，不追")
            st["status"] = "done"
            self._save_state()
            return
        # 止损/止盈按实际入场开盘价重算（1×/2×ATR），不沿用计划参考价的固定价位。
        # 原因（2026-11-19 实测）：计划价位按参考价算，确认根收盘到入场开盘之间价格
        # 已走 0.5–0.8 个 ATR；沿用固定价位会让实际盈亏比倒挂——BNB 1:0.67、LINK 1:0.67、
        # DOGE 1:0.89（止损距离大于止盈距离），违反“止损 1、盈利 1:1.5–3”的要求。
        # ATR 从计划自身取：止损与参考价之差即 1×ATR（计划写法：止损 = 参考价 ∓ 1×ATR）。
        atr = abs(plan_sl - plan["ref_entry"])
        if plan["direction"] == 1:
            sl, tp = bar_open - atr, bar_open + 2 * atr
        else:
            sl, tp = bar_open + atr, bar_open - 2 * atr
        pos = self.open_position(coin, "subj", plan["direction"], bar_open_t, bar_open, sl, tp,
                                 extra={"plan_sl": plan_sl, "plan_tp": plan_tp, "atr_1h": atr},
                                 latency_sec=latency_sec)
        st["status"] = "triggered"
        st["trades_done"] = st.get("trades_done", 0) + 1
        self._save_state()

    # ---- 盘中补充触发（主观层新层，2026-11-21 设计 v1） ----
    def supp_register(self, trigger, source="file"):
        """登记一条补充触发（来自计划文件重读或观察模块直写）。
        单币每天最多 1 条；该币早上计划已成交则跳过（不叠加）。"""
        coin = trigger["coin"]
        st = self.state["supp"].setdefault(coin, {"status": "waiting", "trigger": None,
                                                   "pending_entry_t": None, "trades_done": 0})
        if st.get("trades_done", 0) >= 1 or st.get("status") in ("triggered", "done"):
            return False
        if st.get("trigger") is not None:
            return False
        plan_st = self.state["plans"].get(coin, {})
        if plan_st.get("trades_done", 0) >= 1 or plan_st.get("status") == "triggered":
            self.log_event("supp_skipped_plan_traded", coin=coin, source=source)
            st["status"] = "done"
            self._save_state()
            return False
        st["trigger"] = trigger
        st["pending_entry_t"] = trigger["pending_entry_t"]
        st["status"] = "confirmed"
        st["source"] = source
        self.log_event("supp_registered", coin=coin, trigger=trigger, source=source)
        self._save_state()
        return True

    def supp_merge(self, supp_triggers, now_t):
        """把计划文件里解析出的补充触发并进 state（mtime 重读的恢复路径）。
        pending_entry_t 已过 15 分钟以上的记 supp_stale 并作废（不追单）。"""
        if not supp_triggers:
            return
        for tr in supp_triggers:
            coin = tr["coin"]
            st = self.state["supp"].get(coin, {})
            if st.get("trigger") is not None or st.get("trades_done", 0) >= 1:
                continue
            if tr["pending_entry_t"] < now_t - 900:
                self.log_event("supp_stale", coin=coin, pending_entry_t=tr["pending_entry_t"],
                               now_t=now_t)
                self.state["supp"].setdefault(coin, {"status": "done", "trigger": tr,
                                                      "pending_entry_t": tr["pending_entry_t"],
                                                      "trades_done": 0})
                self._save_state()
                continue
            self.supp_register(tr, source="file")

    def supp_try_entry(self, coin, bar_open_t, bar_open, latency_sec=0.0):
        """新一根 15m 开盘时，若有待入场的补充触发则执行入场。
        与 subj_try_entry 同口径：SL/TP 按实际入场开盘价重算（1×/2×ATR，
        ATR 从触发自身的 |sl - ref_entry| 取）；层记 subj，走 23:00 强平。"""
        if not SUPP_ENABLED:
            return
        st = self.state["supp"].get(coin)
        if not st or st.get("status") != "confirmed":
            return
        trig = st.get("trigger")
        if not trig:
            return
        pend = st.get("pending_entry_t")
        if pend is None:
            return
        if pend < bar_open_t:
            eod_t = int(datetime(self.today.year, self.today.month, self.today.day,
                                 23, 0, tzinfo=timezone.utc).timestamp())
            if pend >= eod_t:
                self.log_event("supp_entry_skipped_eod", coin=coin, bar_open_t=pend)
            else:
                self.log_event("supp_entry_missed", coin=coin, pending_entry_t=pend,
                               bar_open_t=bar_open_t, reason="stale_expired")
                self.append_plan_record(
                    self.today,
                    f"{coin} 盘中补充触发未入场：待入场时间 {fmt_ts(pend)} 已过"
                    f"（引擎停摆错过），不再尝试")
            st["status"] = "done"
            st["missed"] = True
            self._save_state()
            return
        if pend != bar_open_t:
            return
        if bar_open_t >= int(datetime(self.today.year, self.today.month, self.today.day,
                                      23, 0, tzinfo=timezone.utc).timestamp()):
            self.log_event("supp_entry_skipped_eod", coin=coin, bar_open_t=bar_open_t)
            st["status"] = "done"
            self._save_state()
            return
        direction = trig["direction"]
        plan_sl, plan_tp = trig["sl"], trig["tp"]
        if direction == 1 and bar_open <= plan_sl:
            self.log_event("supp_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if direction == -1 and bar_open >= plan_sl:
            self.log_event("supp_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if (direction == 1 and bar_open >= plan_tp) or (direction == -1 and bar_open <= plan_tp):
            self.log_event("supp_entry_skipped_tp_reached", coin=coin, open=bar_open, tp=plan_tp)
            self.append_plan_record(
                self.today,
                f"{coin} 盘中补充触发未入场：开盘价 {fmt_price(bar_open)} 已到参考止盈 "
                f"{fmt_price(plan_tp)}，目标已走完，不追")
            st["status"] = "done"
            self._save_state()
            return
        atr = abs(plan_sl - trig["ref_entry"])
        if direction == 1:
            sl, tp = bar_open - atr, bar_open + 2 * atr
        else:
            sl, tp = bar_open + atr, bar_open - 2 * atr
        pos = self.open_position(coin, "subj", direction, bar_open_t, bar_open, sl, tp,
                                 extra={"plan_sl": plan_sl, "plan_tp": plan_tp, "atr_1h": atr,
                                        "supp": True,
                                        "supp_level": trig.get("level_txt", ""),
                                        "supp_basis": trig.get("basis", "")},
                                 latency_sec=latency_sec)
        st["status"] = "triggered"
        st["trades_done"] = st.get("trades_done", 0) + 1
        self.append_plan_record(
            self.today,
            f"{coin} 盘中补充触发（{trig.get('level_txt', '')}；{trig.get('basis', '')}）")
        self._save_state()

    # ---- 分系统 SUB-SMC 计划层：与主观层同口径的触发/失效/入场 ----
    # 与 subj_* 的差异（SUB-SMC v1.0，2026-11-20）：
    #   状态走 state["sub_plans"]，日志事件名加 sub_plan_ 前缀，记录写分系统计划文件；
    #   确认最后一步不判 Killzone（全天有效）；无 23:00 强平/跳过；
    #   入场加北京时间 01:00–07:00 不开新单检查；无固定止盈（tp=None），
    #   跟踪止盈复用 sub_update_trail（2×ATR 激活）。
    def sub_plan_on_closed_bar(self, coin, bar, plan, plan_mtime):
        """处理一根已收盘 15m（分系统计划层）。bar: {t,o,h,l,c}，t 为开盘时间戳。"""
        st = self.state["sub_plans"].setdefault(coin, {"status": "waiting", "confirm_idx": 0,
                                                       "touch_bar_t": None, "confirm_bar_t": None,
                                                       "trades_done": 0})
        if st["status"] in ("triggered", "invalidated", "done"):
            return
        if st.get("trades_done", 0) >= 1:
            st["status"] = "done"
            return
        if any(p["coin"] == coin and p["layer"] == "sub" for p in self.state["positions"]):
            return  # 该币已有未平分系统持仓：不推进触发状态
        close_t = bar["t"] + 900
        # 只评估计划写成之后收盘的 K 线（回放时用 --start 控制）
        if plan_mtime is not None and close_t <= plan_mtime:
            return
        # 触及
        if st["status"] == "waiting":
            if touch_hit(plan, bar):
                st["status"] = "touched"
                st["touch_bar_t"] = bar["t"]
                st["confirm_idx"] = 0
                self.log_event("sub_plan_touched", coin=coin, bar_t=bar["t"],
                               bar_close=fmt_ts(close_t))
                self._save_state()
            return
        # 确认步骤（每步必须在比上一步更晚的一根上成立）
        if st["status"] == "touched":
            idx = st.get("confirm_idx", 0)
            steps = plan["confirm_steps"]
            if idx < len(steps) and bar["t"] > st["touch_bar_t"] and confirm_hit(steps[idx], bar):
                # 本步成立：若不是最后一步，下一根继续；若是最后一步，直接确认
                # （分系统全天有效，不判 Killzone——与主观层唯一的区别在此）。
                if idx + 1 < len(steps):
                    st["confirm_idx"] = idx + 1
                    st["touch_bar_t"] = bar["t"]  # 下一步必须更晚
                    self.log_event("sub_plan_confirm_step", coin=coin, step=idx + 1,
                                   bar_t=bar["t"])
                    self._save_state()
                    return
                st["status"] = "confirmed"
                st["confirm_bar_t"] = bar["t"]
                st["pending_entry_t"] = bar["t"] + 900
                self.log_event("sub_plan_triggered", coin=coin, bar_t=bar["t"],
                               bar_close=fmt_ts(close_t),
                               pending_entry_t=bar["t"] + 900)
                d = "多" if plan["direction"] == 1 else "空"
                self.append_plan_record(
                    self.today,
                    f"{coin} 分系统做{d}触发：确认根 {fmt_ts(close_t)} 收盘，"
                    f"下一根 15m 开盘入场（参考 {fmt_price(plan['ref_entry'])}）",
                    plan_dir=SUB_PLAN_DIR, note=SUB_PLAN_NOTE)
                self._save_state()

    def sub_plan_on_closed_1h(self, coin, bar, plan):
        """1h 收盘失效检查（分系统计划层，只在触发前有效）。"""
        st = self.state["sub_plans"].setdefault(coin, {"status": "waiting"})
        if st["status"] in ("triggered", "invalidated", "done"):
            return
        inv = plan.get("invalid")
        if not inv:
            return
        hit = (bar["c"] < inv["level"]) if inv["kind"] == "below" else (bar["c"] > inv["level"])
        if hit:
            st["status"] = "invalidated"
            self.log_event("sub_plan_invalidated", coin=coin, bar_t=bar["t"],
                           close=bar["c"], level=inv["level"])
            self.append_plan_record(
                self.today,
                f"{coin} 分系统计划作废：1h 收盘 {fmt_price(bar['c'])} 越过失效价 "
                f"{fmt_price(inv['level'])}",
                plan_dir=SUB_PLAN_DIR, note=SUB_PLAN_NOTE)
            self._save_state()

    def sub_plan_try_entry(self, coin, bar_open_t, bar_open, plan, latency_sec=0.0):
        """新一根 15m 开盘时，若有待入场分系统计划则执行入场。
        与 subj_try_entry 的差异：无 23:00 跳过检查；pending 过期不分 eod；
        增加北京时间 01:00–07:00 不开新单检查；无固定止盈（tp=None），
        跟踪止盈初始状态 peak/entry、trail_active=False（供 sub_update_trail 用）。"""
        st = self.state["sub_plans"].get(coin)
        if not st or st["status"] != "confirmed":
            return
        pend = st.get("pending_entry_t")
        if pend is None:
            return
        if pend < bar_open_t:
            # 入场窗口已过（引擎停摆期间错过）：记一条 sub_plan_entry_missed，
            # 释放计划，不再尝试（分系统无 23:00 强平，不分 eod）。
            self.log_event("sub_plan_entry_missed", coin=coin, pending_entry_t=pend,
                           bar_open_t=bar_open_t, reason="stale_expired")
            self.append_plan_record(
                self.today,
                f"{coin} 分系统计划未入场：待入场时间 {fmt_ts(pend)} 已过"
                f"（引擎停摆错过），不再尝试",
                plan_dir=SUB_PLAN_DIR, note=SUB_PLAN_NOTE)
            st["status"] = "done"
            st["missed"] = True
            st["missed_reason"] = "stale_expired"
            self._save_state()
            return
        if pend != bar_open_t:
            return
        if _sub_entry_in_no_new_window(pend):
            # 北京时间 01:00–07:00 不开新单：跳过，释放计划，不再尝试。
            self.log_event("sub_plan_entry_skipped_night", coin=coin,
                           pending_entry_t=pend, bar_open_t=bar_open_t)
            st["status"] = "done"
            self._save_state()
            return
        # 入场价若已穿计划止损：跳过（setup 已失效）；若已穿计划止盈：跳过（目标已到，无利可图）。
        plan_sl, plan_tp = plan["sl"], plan["tp"]
        if plan["direction"] == 1 and bar_open <= plan_sl:
            self.log_event("sub_plan_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if plan["direction"] == -1 and bar_open >= plan_sl:
            self.log_event("sub_plan_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if (plan["direction"] == 1 and bar_open >= plan_tp) or (plan["direction"] == -1 and bar_open <= plan_tp):
            self.log_event("sub_plan_entry_skipped_tp_reached", coin=coin, open=bar_open, tp=plan_tp)
            self.append_plan_record(
                self.today,
                f"{coin} 分系统计划未入场：开盘价 {fmt_price(bar_open)} 已到计划止盈 "
                f"{fmt_price(plan_tp)}，目标已走完，不追",
                plan_dir=SUB_PLAN_DIR, note=SUB_PLAN_NOTE)
            st["status"] = "done"
            self._save_state()
            return
        # 入场前检查：该币已有未平分系统持仓则不入；单币单日 -2000 熔断则不入。
        if any(p["coin"] == coin and p["layer"] == "sub" for p in self.state["positions"]):
            return
        if self.state["sub_day_pnl"].get(coin, 0) <= SUB_DAILY_HALT:
            return
        # 止损按实际入场开盘价重算（1×ATR）；无固定止盈，止盈靠跟踪止损。
        # ATR 从计划自身取：止损与参考价之差即 1×ATR。
        atr = abs(plan_sl - plan["ref_entry"])
        if plan["direction"] == 1:
            sl = bar_open - atr
        else:
            sl = bar_open + atr
        pos = self.open_position(coin, "sub", plan["direction"], bar_open_t, bar_open, sl, None,
                                 extra={"plan_sl": plan_sl, "plan_tp": plan_tp, "atr": atr,
                                        "entry_bar_t": bar_open_t},
                                 latency_sec=latency_sec)
        pos["peak"] = pos["entry"]
        pos["trail_active"] = False
        st["status"] = "triggered"
        st["trades_done"] = st.get("trades_done", 0) + 1
        self._save_state()

    # ---- 系统层 MAIN-15m：对一根已收盘 15m 做 F1 信号判定 ----
    def sys_on_closed_bar(self, coin, bar, hist, btc_hist, atr_value):
        """bar 为本根已收盘 15m；hist/btc_hist 为截至本根（含本根）的历史，
        用于 2h 回看（hist[-1] 与 hist[-1-8]）与 ATR（调用方传入本根 ATR）。
        与第二十轮 build_f1_signals 同口径：信号根小时 8–19，|rBTC|>=0.5%，
        |rALT|<0.5*|rBTC|，方向=sign(rBTC)，入场为下一根开盘且小时∈{9,15}。"""
        if not SYS_ENABLED:
            return
        if coin == "BTC":
            return
        if self.state["sys_trades_today"].get(coin, 0) >= SYS_MAX_PER_DAY:
            return
        if self.state["sys_day_pnl"].get(coin, 0.0) <= SYS_DAILY_HALT:
            return
        if any(p["coin"] == coin and p["layer"] == "sys" for p in self.state["positions"]):
            return
        if self.state["trades_today"].get(coin, 0) >= 2:
            return
        dt = ts_to_dt(bar["t"])
        if not (8 <= dt.hour <= 19):
            return
        if len(hist) < SYS_LOOKBACK + 1 or len(btc_hist) < SYS_LOOKBACK + 1:
            return
        if atr_value is None:
            return
        r_btc = btc_hist[-1]["c"] / btc_hist[-1 - SYS_LOOKBACK]["c"] - 1
        if abs(r_btc) < 0.005:
            return
        r_alt = hist[-1]["c"] / hist[-1 - SYS_LOOKBACK]["c"] - 1
        if abs(r_alt) >= 0.5 * abs(r_btc):
            return
        entry_t = bar["t"] + 900
        if ts_to_dt(entry_t).hour not in SYS_ENTRY_HOURS:
            return
        direction = 1 if r_btc > 0 else -1
        self.state["sys_pending"][coin] = {
            "entry_t": entry_t, "direction": direction, "atr": atr_value}
        self.log_event("sys_signal", coin=coin, bar_t=bar["t"], r_btc=round(r_btc, 5),
                       r_alt=round(r_alt, 5), direction=direction, entry_t=entry_t)

    def sys_try_entry(self, coin, bar_open_t, bar_open, latency_sec=0.0):
        if not SYS_ENABLED:
            return
        pend = self.state["sys_pending"].get(coin)
        if not pend:
            return
        if pend["entry_t"] < bar_open_t:
            # 系统信号入场窗口已过（引擎停摆期间错过）：记一条，释放待入场，
            # 不再尝试。否则 sys_pending 永远占着位置，无日志无释放。
            eod_t = int(datetime(self.today.year, self.today.month, self.today.day,
                                 23, 45, tzinfo=timezone.utc).timestamp())
            if pend["entry_t"] >= eod_t:
                self.log_event("sys_entry_skipped_eod", coin=coin,
                               bar_open_t=pend["entry_t"])
            else:
                self.log_event("sys_entry_missed", coin=coin,
                               pending_entry_t=pend["entry_t"],
                               bar_open_t=bar_open_t, reason="stale_expired")
            del self.state["sys_pending"][coin]
            self._save_state()
            return
        if pend["entry_t"] != bar_open_t:
            return
        del self.state["sys_pending"][coin]
        if bar_open_t >= int(datetime(self.today.year, self.today.month, self.today.day,
                                      23, 45, tzinfo=timezone.utc).timestamp()):
            self.log_event("sys_entry_skipped_eod", coin=coin, bar_open_t=bar_open_t)
            self._save_state()
            return
        a = pend["atr"]
        direction = pend["direction"]
        sl = bar_open - a if direction == 1 else bar_open + a
        tp = bar_open + 2 * a if direction == 1 else bar_open - 2 * a
        if (direction == 1 and bar_open <= sl) or (direction == -1 and bar_open >= sl):
            self.log_event("sys_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=sl)
            self._save_state()
            return
        pos = self.open_position(coin, "sys", direction, bar_open_t, bar_open, sl, tp,
                                 extra={"atr": a, "entry_bar_t": bar_open_t},
                                 latency_sec=latency_sec)
        if (direction == 1 and bar_open >= tp) or (direction == -1 and bar_open <= tp):
            self.close_position(pos, bar_open_t, tp, "take_profit", exit_via="开盘跳空穿止盈")
        self._save_state()

    # ---- 分系统 SUB-15m：每币自己的 2h 动量跟随，全天，不看 BTC ----
    def sub_on_closed_bar(self, coin, bar, hist, atr_value):
        """bar 为本根已收盘 15m；hist 为截至本根（含本根）的本币历史。
        信号：本币自己 2h 收益 |r|>=0.5%，方向=sign(r)；不看 BTC、不看其他币、
        不设 Killzone；v1.2 起取消最晚入场 22:45 限制（23:00 强平已取消，
        入场只受北京时间 01:00–07:00 不开新单限制）。
        与第三十一轮回测同口径（v1.0）；v1.2 跟踪止盈见 sub_update_trail。"""
        if not SUB_ENABLED:
            return
        if self.state["sub_trades_today"].get(coin, 0) >= SUB_MAX_PER_DAY:
            return
        if self.state["sub_day_pnl"].get(coin, 0.0) <= SUB_DAILY_HALT:
            return
        if any(p["coin"] == coin and p["layer"] == "sub" for p in self.state["positions"]):
            return
        if len(hist) < SUB_LOOKBACK + 1:
            return
        if atr_value is None:
            return
        # 只评估当天的信号（重启后重算旧 K 线时，昨天已过期的信号不再挂 pending）
        day_start = int(datetime(self.today.year, self.today.month, self.today.day,
                                 tzinfo=timezone.utc).timestamp())
        if bar["t"] + 900 < day_start:
            return
        r = hist[-1]["c"] / hist[-1 - SUB_LOOKBACK]["c"] - 1
        if abs(r) < 0.005:
            return
        entry_t = bar["t"] + 900
        if _sub_entry_in_no_new_window(entry_t):
            # 北京时间 01:00–07:00 不开新单：信号作废，不挂 pending。
            self.log_event("sub_entry_skipped_night", coin=coin, bar_t=bar["t"],
                           r=round(r, 5), entry_t=entry_t)
            return
        direction = 1 if r > 0 else -1
        self.state["sub_pending"][coin] = {
            "entry_t": entry_t, "direction": direction, "atr": atr_value}
        self.log_event("sub_signal", coin=coin, bar_t=bar["t"], r=round(r, 5),
                       direction=direction, entry_t=entry_t)

    def sub_try_entry(self, coin, bar_open_t, bar_open, latency_sec=0.0):
        if not SUB_ENABLED:
            return
        pend = self.state["sub_pending"].get(coin)
        if not pend:
            return
        if pend["entry_t"] < bar_open_t:
            # 分系统信号入场窗口已过（引擎停摆期间错过）：记一条，释放待入场，
            # 不再尝试（与 sys_entry_missed 同口径）。v1.2 起无 23:00 强平，
            # 不再分 skipped_eod，一律记 missed。
            self.log_event("sub_entry_missed", coin=coin,
                           pending_entry_t=pend["entry_t"],
                           bar_open_t=bar_open_t, reason="stale_expired")
            del self.state["sub_pending"][coin]
            self._save_state()
            return
        if pend["entry_t"] != bar_open_t:
            return
        if _sub_entry_in_no_new_window(pend["entry_t"]):
            # 防守：待入场落在北京时间 01:00–07:00，跳过不开单（已持仓不受影响）。
            self.log_event("sub_entry_skipped_night", coin=coin,
                           pending_entry_t=pend["entry_t"], bar_open_t=bar_open_t)
            del self.state["sub_pending"][coin]
            self._save_state()
            return
        del self.state["sub_pending"][coin]
        # v1.2：取消 23:00 强平与固定止盈，入场不再受 23:00 限制。
        a = pend["atr"]
        direction = pend["direction"]
        sl = bar_open - a if direction == 1 else bar_open + a
        tp = None  # v1.2：无固定止盈，止盈靠跟踪止损（sub_update_trail）
        if (direction == 1 and bar_open <= sl) or (direction == -1 and bar_open >= sl):
            self.log_event("sub_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=sl)
            self._save_state()
            return
        pos = self.open_position(coin, "sub", direction, bar_open_t, bar_open, sl, tp,
                                 extra={"atr": a, "entry_bar_t": bar_open_t},
                                 latency_sec=latency_sec)
        # 跟踪止盈初始状态：极值 = 入场成交价，未激活（_rebuild_from_log 缺字段时
        # 同样按此默认值处理；止损移动后靠 sub_trail_update 日志重建）。
        pos["peak"] = pos["entry"]
        pos["trail_active"] = False
        self._save_state()

    def sub_update_trail(self, coin, bar):
        """分系统 v1.2/v1.3 跟踪止盈：每根已收盘 15m 调用一次（出场判定之后）。
        只用已收盘 K 线的高低更新极值，与回测同口径；mark 价不移动止损。
        做多 peak=入场以来最高价，做空 peak=最低价；v1.3 起有利浮动 ≥2×ATR
        （到原止盈位）才激活，激活后止损 = peak ∓1×ATR，只朝有利方向棘轮；
        未激活前止损保持初始 1×ATR。"""
        for pos in [p for p in self.state["positions"]
                    if p["coin"] == coin and p["layer"] == "sub"]:
            d = pos["direction"]
            a = pos.get("atr")
            if a is None:
                continue
            peak = pos.get("peak", pos["entry"])
            new_peak = max(peak, bar["h"]) if d == 1 else min(peak, bar["l"])
            trail_active = pos.get("trail_active", False)
            if not trail_active:
                favour = (new_peak - pos["entry"]) * d
                if favour >= SUB_TRAILING_ACTIVATE_ATR * a:
                    trail_active = True
            new_sl = pos["sl"]
            if trail_active:
                cand = (new_peak - SUB_TRAILING_ATR * a) if d == 1 else (new_peak + SUB_TRAILING_ATR * a)
                # 棘轮：做多止损只上移，做空只下移；且不低于初始止损
                new_sl = max(pos["sl"], cand) if d == 1 else min(pos["sl"], cand)
            if new_peak != peak or trail_active != pos.get("trail_active", False) or new_sl != pos["sl"]:
                pos["peak"] = new_peak
                pos["trail_active"] = trail_active
                pos["sl"] = new_sl
                self.log_event("sub_trail_update", coin=coin, entry_t=pos["entry_t"],
                               bar_t=bar["t"], peak=round(new_peak, 8),
                               sl=round(new_sl, 8), trail_active=trail_active)
                self._save_state()

    # ---- 持仓实时跟踪：mark price + 最新 K 线高低 ----
    def check_positions_mark(self, marks):
        """每 30 秒轮询：mark price 碰止损/止盈即平（止损优先）。
        止盈是提前挂好的限价单：真实口径下 mark 价须穿过止盈价至少一个价差
        才算成交（限价单要等买方/卖方打到价位），否则继续持有；
        ideal 口径一碰即成交。mark 出场的检测延迟 = 距上一轮 tick 的秒数
        （≤30 秒），记进日志。"""
        now_t = int(time.time())
        det_delay = 0.0
        if self._last_tick_t is not None:
            det_delay = max(0.0, now_t - self._last_tick_t)
        for pos in list(self.state["positions"]):
            m = marks.get(CONTRACT[pos["coin"]])
            if m is None:
                continue
            d = pos["direction"]
            hit_sl = (m <= pos["sl"]) if d == 1 else (m >= pos["sl"])
            # v1.2：分系统无固定止盈（tp=None），只判止损；止损已激活跟踪的记 trailing_stop
            hit_tp = False
            if pos.get("tp") is not None:
                if self.cost.mode == "real":
                    spr = self.cost.spread_abs(pos["coin"], pos["tp"])
                    hit_tp = (m >= pos["tp"] + spr) if d == 1 else (m <= pos["tp"] - spr)
                else:
                    hit_tp = (m >= pos["tp"]) if d == 1 else (m <= pos["tp"])
            if hit_sl:
                sl_reason = ("trailing_stop" if pos.get("layer") == "sub"
                             and pos.get("trail_active") else "stop_loss")
                self.close_position(pos, now_t, pos["sl"], sl_reason, exit_via="mark 价",
                                    exit_latency_sec=det_delay)
            elif hit_tp:
                self.close_position(pos, now_t, pos["tp"], "take_profit", exit_via="mark 价",
                                    exit_latency_sec=det_delay)

    def check_positions_bar(self, coin, bar, exit_t=None):
        """K 线高低二次检查：补 mark 轮询 30 秒间隙里碰到的止损/止盈。
        exit_t 默认取本根开盘时刻（与第二十轮同口径：出场发生在该根之内，
        早于本根收盘时刻，故收盘时刻的资金费结算点不计入）；形成中 K 线传入当前时间。
        止盈限价单：真实口径下本根高/低须穿过止盈价至少一个价差才算成交，
        否则继续持有等下一轮检查；ideal 口径一碰即成交。"""
        exit_t = bar["t"] if exit_t is None else exit_t
        for pos in [p for p in self.state["positions"] if p["coin"] == coin]:
            d = pos["direction"]
            # v1.2：分系统无固定止盈（tp=None），只判止损；已激活跟踪的止损记 trailing_stop
            sl_reason = ("trailing_stop" if pos.get("layer") == "sub"
                         and pos.get("trail_active") else "stop_loss")
            spr = 0.0
            if pos.get("tp") is not None and self.cost.mode == "real":
                spr = self.cost.spread_abs(coin, pos["tp"])
            if d == 1:
                if bar["l"] <= pos["sl"]:
                    self.close_position(pos, exit_t, pos["sl"], sl_reason, exit_via="15m 最低价")
                elif pos.get("tp") is not None and bar["h"] >= pos["tp"] + spr:
                    self.close_position(pos, exit_t, pos["tp"], "take_profit", exit_via="15m 最高价")
            else:
                if bar["h"] >= pos["sl"]:
                    self.close_position(pos, exit_t, pos["sl"], sl_reason, exit_via="15m 最高价")
                elif pos.get("tp") is not None and bar["l"] <= pos["tp"] - spr:
                    self.close_position(pos, exit_t, pos["tp"], "take_profit", exit_via="15m 最低价")

    def check_positions_hold(self, coin, bar):
        """系统层最多持 16 根：与回测同口径，入场后第 15 根（gi-entry_gi>=15）
        收盘即平（先判止损/止盈，后判持满，调用方保证顺序）。
        分系统层已取消持满上限（2026-11-20 用户指示：把 4 小时强制平仓也关了）：
        分系统持仓只按止损/跟踪止盈出场，不设时间上限。SUB_MAX_HOLD 保留作归档，
        不再执行。"""
        for pos in [p for p in self.state["positions"] if p["coin"] == coin and p["layer"] == "sys"]:
            bars_held = (bar["t"] - pos["entry_bar_t"]) // 900
            if bars_held >= SYS_MAX_HOLD - 1:
                self.close_position(pos, bar["t"], bar["c"], "max_hold", exit_via="15m 收盘价")

    def force_close(self, when_label, layer=None, exit_t=None, marks=None):
        """强制平仓：实时用当前 mark 价；回放时调用方传入 exit_t 与 marks
        （23:00 平仓价取 22:45 根收盘价近似当时 mark）。"""
        now_t = int(time.time()) if exit_t is None else exit_t
        if marks is None:
            marks = {}
            try:
                tk = self.client.tickers()
                marks = {c: float(d["mark_price"]) for c, d in tk.items() if d.get("mark_price")}
            except Exception:
                pass
        for pos in list(self.state["positions"]):
            if layer and pos["layer"] != layer:
                continue
            m = marks.get(CONTRACT[pos["coin"]])
            if m is None:
                continue
            self.close_position(pos, now_t, m, when_label, exit_via="mark 价")

    @staticmethod
    def _summary_line(trades):
        """按给定交易子集拼一条结算汇总行（主计划/分系统计划同格式）。"""
        total = sum(t["net"] for t in trades)
        total_ideal = sum(t.get("net_ideal", t["net"]) for t in trades)
        fee_delta = sum(OLD_FEE_PART - t.get("fee_entry", 7.5) - t.get("fee_exit", 7.5)
                        for t in trades)
        slip_delta = sum(OLD_SLIP_PART - t.get("slip_usdt", 0.0) for t in trades)
        friction = total - total_ideal
        resid = friction - fee_delta - slip_delta  # 交叉项（应≈0）
        tp = sum(1 for t in trades if t["reason"] == "take_profit")
        sl = sum(1 for t in trades if t["reason"] == "stop_loss")
        tr = sum(1 for t in trades if t["reason"] == "trailing_stop")
        eod = sum(1 for t in trades if t["reason"] in ("eod_2300", "eod_2345", "max_hold"))
        trig = len(trades)
        return (f"当日结算汇总：成交 {trig} 笔，止盈 {tp}、止损 {sl}、跟踪止盈 {tr}、持满/平仓 {eod}，"
                f"合计净盈亏（真实成本口径）{total:+.2f} USDT；"
                f"理想成本口径（旧固定 25/笔）{total_ideal:+.2f} USDT；"
                f"真实摩擦 {friction:+.2f} USDT（其中手续费差 {fee_delta:+.2f}、"
                f"滑点差 {slip_delta:+.2f}、交叉项 {resid:+.2f}）")

    def daily_summary(self):
        if self.state.get("summary_done"):
            return
        trades = self.state["trades"]
        total = sum(t["net"] for t in trades)
        total_ideal = sum(t.get("net_ideal", t["net"]) for t in trades)
        # 分解：真实摩擦 vs 旧口径（固定 25 = 手续费 15 + 假设滑点 10）
        fee_delta = sum(OLD_FEE_PART - t.get("fee_entry", 7.5) - t.get("fee_exit", 7.5)
                        for t in trades)
        slip_delta = sum(OLD_SLIP_PART - t.get("slip_usdt", 0.0) for t in trades)
        friction = total - total_ideal
        resid = friction - fee_delta - slip_delta  # 交叉项（应≈0）
        tp = sum(1 for t in trades if t["reason"] == "take_profit")
        sl = sum(1 for t in trades if t["reason"] == "stop_loss")
        tr = sum(1 for t in trades if t["reason"] == "trailing_stop")
        eod = sum(1 for t in trades if t["reason"] in ("eod_2300", "eod_2345", "max_hold"))
        trig = len(trades)
        # 按层拆分写计划文件：主计划文件只写主观+系统层（无分系统交易时与旧行一字相同）；
        # 分系统计划文件只在有分系统交易时追加一行分系统汇总（同格式，数字只含 sub 层）。
        main_trades = [t for t in trades if t["layer"] in ("subj", "sys")]
        self.append_plan_record(self.today, self._summary_line(main_trades))
        sub_trades = [t for t in trades if t["layer"] == "sub"]
        if sub_trades:
            self.append_plan_record(self.today, self._summary_line(sub_trades),
                                    plan_dir=SUB_PLAN_DIR, note=SUB_PLAN_NOTE)
        self.log_event("daily_summary", trades=trig, tp=tp, sl=sl, trailing=tr, eod=eod,
                       total=round(total, 2), total_ideal=round(total_ideal, 2),
                       friction=round(friction, 2), fee_delta=round(fee_delta, 2),
                       slip_delta=round(slip_delta, 2), residual=round(resid, 2))
        self.state["summary_done"] = True
        self._save_state()


    # ---- 计划加载 ----
    def load_today_plan(self):
        path = os.path.join(PLAN_DIR, f"{self.today.isoformat()}.md")
        if not os.path.exists(path):
            return None, None, []
        mtime = os.path.getmtime(path)
        try:
            with open(path) as f:
                text = f.read()
        except OSError:
            return None, None, []
        plans = parse_plan_table(text)
        cutoff = parse_cutoff(text)
        plan_mtime = int(mtime)
        if cutoff is not None:
            plan_mtime = max(plan_mtime, int(cutoff.timestamp()))
        supp_triggers = []
        if SUPP_ENABLED and SUPP_OBSERVER_OK:
            supp_triggers = supp_observer.parse_supp_triggers(text)
        return plans, plan_mtime, supp_triggers

    def load_today_sub_plan(self):
        """分系统计划加载：与 load_today_plan 同口径，只换目录（SUB_PLAN_DIR）。
        无分系统计划文件时返回 (None, None)，引擎继续只跑主计划。"""
        if not SUB_PLAN_ENABLED:
            return None, None
        path = os.path.join(SUB_PLAN_DIR, f"{self.today.isoformat()}.md")
        if not os.path.exists(path):
            return None, None
        mtime = os.path.getmtime(path)
        try:
            with open(path) as f:
                text = f.read()
        except OSError:
            return None, None
        plans = parse_plan_table(text)
        cutoff = parse_cutoff(text)
        plan_mtime = int(mtime)
        if cutoff is not None:
            plan_mtime = max(plan_mtime, int(cutoff.timestamp()))
        return plans, plan_mtime

    # ---- 实时主循环 ----
    def live_loop(self, once=False):
        print(f"[{utcnow().strftime('%H:%M:%S')}Z] paper engine live start, day={self.today}", flush=True)
        last_candle_fetch = 0.0
        marks = {}
        while True:
            try:
                self._live_tick()
            except Exception:
                traceback.print_exc()
                self.log_event("loop_error", {"trace": traceback.format_exc()[-500:]})
            if once:
                break
            # 日期翻转：00:00 UTC 换天
            # v1.2：分系统持仓可跨夜，换天时结转未平的分系统持仓（主观/系统层
            # 已在 23:00/23:45 强平，不结转）；计数与盈亏按新的一天重计。
            if utcnow().date() != self.today:
                carried = [p for p in self.state["positions"] if p.get("layer") == "sub"]
                self.today = utcnow().date()
                self.state = self._new_state()
                self.state["positions"] = carried
                self._save_state()
                self.log_event("day_rollover", {"day": self.today.isoformat(),
                                                "sub_carried": len(carried),
                                                "coins": [p["coin"] for p in carried]})
            time.sleep(POLL_SEC)

    def _live_tick(self):
        now = utcnow()
        now_t = int(now.timestamp())
        # --- 拉 mark price（每轮） ---
        try:
            tk = self.client.tickers()
            marks = {c: float(d["mark_price"]) for c, d in tk.items() if d.get("mark_price")}
        except Exception as e:
            marks = {}
            self.log_event("tickers_failed", {"error": str(e)[:200]})
        if marks:
            self.check_positions_mark(marks)
        self._last_tick_t = now_t  # 供下一轮 mark 出场算检测延迟（距上一轮 tick 的秒数）
        # --- 23:00 / 23:45 强制平仓 ---
        # v1.2：分系统取消 23:00 强平（跟踪止损/初始止损/持满出场，可跨夜），
        # 这里只平主观层；系统层 23:45 强平保留（SYS_ENABLED=False 已停用）。
        hm = now.hour * 60 + now.minute
        if hm >= 23 * 60 and any(p["layer"] == "subj" for p in self.state["positions"]):
            self.force_close("eod_2300", layer="subj")
        if hm >= 23 * 60 + 45 and any(p["layer"] == "sys" for p in self.state["positions"]):
            self.force_close("eod_2345", layer="sys")
        if hm >= 23 * 60 + 50:
            self.daily_summary()
        # --- 计划文件（主计划 + 分系统计划；两者都缺才空转） ---
        plans, plan_mtime, supp_triggers = self.load_today_plan()
        sub_plans, sub_plan_mtime = self.load_today_sub_plan()
        if plans is None and sub_plans is None:
            if time.time() - self._last_idle_log > 1800:
                self._last_idle_log = time.time()
                self.log_event("idle_no_plan", {"day": self.today.isoformat()})
            return
        if plans is not None and self.state.get("plan_mtime") != plan_mtime:
            self.state["plan_mtime"] = plan_mtime
            self._save_state()
        # 补充触发：计划文件 mtime 变化重读的恢复路径（观察模块写进文件后，
        # 下轮 tick 在这里并进 state；重启后也一样能吃到未执行的触发）
        if SUPP_ENABLED and supp_triggers:
            self.supp_merge(supp_triggers, now_t)
        if sub_plans is not None and self.state.get("sub_plan_mtime") != sub_plan_mtime:
            self.state["sub_plan_mtime"] = sub_plan_mtime
            self._save_state()
        # --- 拉 K 线（每轮；15m 取 40 根够 ATR+回看，1h 取 6 根） ---
        try:
            bars15 = {}
            bars1h = {}
            for c in COINS:
                bars15[c] = self.client.candles(CONTRACT[c], "15m", limit=40)
                bars1h[c] = self.client.candles(CONTRACT[c], "1h", limit=10)
        except Exception as e:
            self.log_event("candles_failed", {"error": str(e)[:200]})
            return
        # --- 处理新收盘的 15m/1h ---
        for c in COINS:
            plan = plans.get(c) if plans is not None else None
            sub_plan = sub_plans.get(c) if sub_plans is not None else None
            closed15 = [b for b in bars15[c] if b["t"] + 900 <= now_t]
            if not closed15:
                continue
            latest_closed = closed15[-1]
            last_t = self.state["last_15m"].get(c, 0)
            if last_t and closed15[0]["t"] > last_t + 900:
                self.log_event("bars_gap", {"coin": c, "last_t": last_t,
                                            "first_fetched": closed15[0]["t"]})
            # 系统层历史缓存（用于 ATR 与 2h 回看）：只追加，不预填未来
            hist = self.state["sys_bars"].setdefault(c, [])
            for b in closed15:
                if b["t"] not in [h["t"] for h in hist]:
                    hist.append(b)
            hist.sort(key=lambda b: b["t"])
            self.state["sys_bars"][c] = hist[-80:]
            # 入场：新一根 15m 开盘（forming bar 的 open）
            forming = bars15[c][-1] if bars15[c] and bars15[c][-1]["t"] + 900 > now_t else None
            if forming is not None:
                # 触发→执行延迟：本轮检测到开盘的时刻减去开盘时刻（0~30 秒轮询延迟）
                latency = max(0, now_t - forming["t"])
                if plan is not None:
                    self.subj_try_entry(c, forming["t"], forming["o"], plan,
                                        latency_sec=latency)
                if SUPP_ENABLED:
                    self.supp_try_entry(c, forming["t"], forming["o"],
                                        latency_sec=latency)
                self.sys_try_entry(c, forming["t"], forming["o"], latency_sec=latency)
                self.sub_try_entry(c, forming["t"], forming["o"], latency_sec=latency)
                if sub_plan is not None:
                    self.sub_plan_try_entry(c, forming["t"], forming["o"], sub_plan,
                                            latency_sec=latency)
            # 新收盘的 1h：失效检查（与 15m 确认同根时失效优先）
            closed1h = [b for b in bars1h[c] if b["t"] + 3600 <= now_t]
            if closed1h:
                last1 = self.state["last_1h"].get(c, 0)
                for b in closed1h:
                    if b["t"] > last1 and plan is not None:
                        self.subj_on_closed_1h(c, b, plan)
                    if b["t"] > last1 and sub_plan is not None:
                        self.sub_plan_on_closed_1h(c, b, sub_plan)
                self.state["last_1h"][c] = closed1h[-1]["t"]
            # 新收盘的 15m：逐根处理（一般只有一根是新的）
            for b in closed15:
                if b["t"] <= last_t:
                    continue
                # 先判持仓的 K 线止损/止盈（补 mark 轮询间隙），再判持满，
                # 最后用本根收盘更新分系统跟踪止损（出场判定在前，移动在后）
                self.check_positions_bar(c, b)
                self.check_positions_hold(c, b)
                self.sub_update_trail(c, b)
                # 主观触发判定
                if plan is not None:
                    self.subj_on_closed_bar(c, b, plan, plan_mtime)
                # 盘中补充触发观察（主观层新层）：本根为确认根，上一根为探针根；
                # 确认后写进计划文件（审计），并立即登记（执行路径，下轮重读为恢复路径）
                if SUPP_ENABLED and SUPP_OBSERVER_OK:
                    supp_st = self.state["supp"].get(c, {})
                    plan_st = self.state["plans"].get(c, {})
                    if (supp_st.get("trigger") is None and supp_st.get("trades_done", 0) < 1
                            and plan_st.get("trades_done", 0) < 1
                            and plan_st.get("status") != "triggered"):
                        hist15 = self.state["sys_bars"].get(c, [])
                        if hist15 and hist15[-1]["t"] == b["t"]:
                            atr1h_plan = None
                            atr1h_src = "plan"
                            if plan is not None:
                                atr1h_plan = abs(plan["sl"] - plan["ref_entry"])
                            if atr1h_plan is None or atr1h_plan <= 0:
                                h1c = [x for x in bars1h[c] if x["t"] + 3600 <= b["t"]]
                                a1 = atr_wilder(h1c)
                                atr1h_plan = a1[-1] if a1 and a1[-1] else None
                                atr1h_src = "live_1h"
                            day_start_t = int(datetime(self.today.year, self.today.month,
                                                       self.today.day,
                                                       tzinfo=timezone.utc).timestamp())
                            trig = supp_observer.detect_on_closed_bar(
                                hist15, bars1h[c], c, atr1h_plan, day_start_t,
                                atr1h_source=atr1h_src, directions=SUPP_DIRECTIONS)
                            if trig is not None:
                                plan_path = os.path.join(
                                    PLAN_DIR, f"{self.today.isoformat()}.md")
                                try:
                                    supp_observer.append_supp_trigger(
                                        plan_path, trig, lock_path=LOCK_PATH)
                                except OSError:
                                    self.log_event("supp_write_failed", coin=c)
                                self.supp_register(trig, source="observer")
                # 分系统计划触发判定（全天有效，不判 Killzone）
                if sub_plan is not None:
                    self.sub_plan_on_closed_bar(c, b, sub_plan, sub_plan_mtime)
                # 系统层 F1 信号判定：历史截断到本根（与回测同口径；SYS_ENABLED=False 已停用）
                hist_t = [h for h in self.state["sys_bars"][c] if h["t"] <= b["t"]]
                atrs = atr_wilder(hist_t)
                atr_v = atrs[-1] if atrs else None
                if c != "BTC":
                    btc_t = [h for h in self.state["sys_bars"].get("BTC", []) if h["t"] <= b["t"]]
                    self.sys_on_closed_bar(c, b, hist_t, btc_t, atr_v)
                # 分系统 SUB-15m：每币自己的 2h 动量，全天，不看 BTC
                self.sub_on_closed_bar(c, b, hist_t, atr_v)
            self.state["last_15m"][c] = latest_closed["t"]
            # 形成中 K 线的高低二次检查（mark 轮询的补充；出场时间记当前）
            if forming is not None:
                self.check_positions_bar(c, forming, exit_t=now_t)
        self._save_state()


# ----------------------------------------------------------------------
# 回放模式：读历史 K 线，用同一套状态机复算某一天
# ----------------------------------------------------------------------
def replay_day(plan_path, day_str, start_hhmm, client, cost_mode="real", sub_plan_path=None):
    day = datetime.strptime(day_str, "%Y-%m-%d").date()
    with open(plan_path) as f:
        text = f.read()
    plans = parse_plan_table(text)
    if not plans:
        print("回放失败：计划表解析为空")
        return None
    sub_plans = {}
    if sub_plan_path is not None:
        with open(sub_plan_path) as f:
            sub_plans = parse_plan_table(f.read())
        if not sub_plans:
            print("回放失败：分系统计划表解析为空")
            return None
    start_dt = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    sh, sm = map(int, start_hhmm.split(":"))
    start_t = int((start_dt + timedelta(hours=sh, minutes=sm)).timestamp())
    end_t = int((start_dt + timedelta(hours=23)).timestamp())
    eng = Engine(client=client, dry_log=True, cost_mode=cost_mode)
    eng.today = day
    eng.state = eng._new_state()
    eng.state["date"] = day.isoformat()
    plan_mtime = start_t  # 回放只评估 start 之后的收盘 K 线
    bars15, bars1h = {}, {}
    for c in COINS:
        bars15[c] = client.candles(CONTRACT[c], "15m", frm=start_t - 3600 * 4, to=end_t + 900)
        bars1h[c] = client.candles(CONTRACT[c], "1h", frm=start_t - 3600 * 4, to=end_t + 3600)
    day_start_t = int(start_dt.timestamp())
    supp_done = set()
    # 15m 逐根模拟（按开盘时间顺序；顺序与回测 simulate_f1 一致：
    # 先判已持仓的止损/止盈/持满，再入场（上一根确认的待入场），最后评估本根触发）
    all_t = sorted({b["t"] for c in COINS for b in bars15[c] if b["t"] >= start_t})
    for t in all_t:
        if t >= end_t:  # 23:00 根不开新仓
            break
        for c in COINS:
            bar = next((b for b in bars15[c] if b["t"] == t), None)
            if bar is None:
                continue
            plan = plans.get(c)
            sub_plan = sub_plans.get(c) if sub_plans else None
            # 1. 已持仓：本根高低判止损/止盈（先止损），再判持满，
            #    最后用本根收盘更新分系统跟踪止损
            eng.check_positions_bar(c, bar)
            eng.check_positions_hold(c, bar)
            eng.sub_update_trail(c, bar)
            # 2. 入场：本根开盘（上一根收盘后已确认的计划）
            if plan is not None:
                eng.subj_try_entry(c, t, bar["o"], plan)
            if SUPP_ENABLED:
                eng.supp_try_entry(c, t, bar["o"])
            eng.sys_try_entry(c, t, bar["o"])
            eng.sub_try_entry(c, t, bar["o"])
            if sub_plan is not None:
                eng.sub_plan_try_entry(c, t, bar["o"], sub_plan)
            # 3. 1h 失效（整点收盘的根；与触发同根时失效优先）
            if (t + 900) % 3600 == 0 and plan is not None:
                h1 = next((b for b in bars1h[c] if b["t"] == t - 2700), None)
                if h1 is not None:
                    eng.subj_on_closed_1h(c, h1, plan)
            if (t + 900) % 3600 == 0 and sub_plan is not None:
                h1 = next((b for b in bars1h[c] if b["t"] == t - 2700), None)
                if h1 is not None:
                    eng.sub_plan_on_closed_1h(c, h1, sub_plan)
            # 4. 触发判定：本根收盘
            if plan is not None:
                eng.subj_on_closed_bar(c, bar, plan, plan_mtime)
            # 4b. 盘中补充触发观察（主观层新层）：本根为确认根，上一根为探针根
            if SUPP_ENABLED and SUPP_OBSERVER_OK and c not in supp_done:
                hist15 = [x for x in bars15[c] if x["t"] <= t]
                atr1h = None
                atr1h_src = "plan"
                if plan is not None:
                    atr1h = abs(plan["sl"] - plan["ref_entry"])
                if atr1h is None or atr1h <= 0:
                    h1c = [x for x in bars1h[c] if x["t"] + 3600 <= t]
                    a1 = atr_wilder(h1c)
                    atr1h = a1[-1] if a1 and a1[-1] else None
                    atr1h_src = "live_1h"
                trig = supp_observer.detect_on_closed_bar(
                    hist15, bars1h[c], c, atr1h, day_start_t,
                    atr1h_source=atr1h_src, directions=SUPP_DIRECTIONS)
                if trig is not None:
                    try:
                        supp_observer.append_supp_trigger(plan_path, trig)
                    except OSError:
                        eng.log_event("supp_write_failed", coin=c)
                    if eng.supp_register(trig, source="observer"):
                        supp_done.add(c)
            if sub_plan is not None:
                eng.sub_plan_on_closed_bar(c, bar, sub_plan, plan_mtime)
            # 5. 分系统 SUB-15m：每币自己的 2h 动量（回放也评估，与实盘同口径）
            hist_t = [b for b in bars15[c] if b["t"] <= t]
            atrs = atr_wilder(hist_t)
            eng.sub_on_closed_bar(c, bar, hist_t, atrs[-1] if atrs else None)
        # 23:00 强制平仓在循环外处理（见下）
    # 23:00 UTC：按 23:00 根收盘价强制平仓主观层持仓。
    # v1.2：分系统取消 23:00 强平，回放里 23:00 未平的分系统持仓记为跨夜结转
    # （不结算、不算盈亏；实盘由跟踪止损/初始止损/持满在之后出场）。
    for pos in list(eng.state["positions"]):
        if pos["layer"] not in ("subj",):
            continue
        bar23 = next((b for b in bars15[pos["coin"]] if b["t"] == end_t - 900), None)
        px = bar23["c"] if bar23 else pos["entry"]
        eng.close_position(pos, end_t, px, "eod_2300", exit_via="23:00 收盘价")
    carried = [p for p in eng.state["positions"] if p["layer"] == "sub"]
    if carried:
        eng.log_event("sub_carried_overnight", {
            "coins": [p["coin"] for p in carried],
            "positions": [(p["coin"], p["entry"], p["sl"], p.get("trail_active")) for p in carried]})
    return eng


# ----------------------------------------------------------------------
# 系统层校验：本地 15m 缓存回放，对第二十轮 trades.csv
# ----------------------------------------------------------------------
def syscheck(from_date, to_date, client):
    """系统层 MAIN-15m 回放校验：本地 15m 缓存逐根模拟，对第二十轮 trades.csv。
    历史与回测一致：ATR 从缓存开头（2026-08-06）算起；资金费按历史实际费率。"""
    import csv
    d0 = datetime.strptime(from_date, "%Y-%m-%d").date()
    d1 = datetime.strptime(to_date, "%Y-%m-%d").date()
    data = {}
    for c in COINS:
        path = os.path.join(DATA_DIR, f"gate_15m_103d_{CONTRACT[c]}.csv")
        with open(path, newline="") as f:
            rows = list(csv.DictReader(f))
        bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
                 "l": float(r["l"]), "c": float(r["c"])} for r in rows]
        bars.sort(key=lambda b: b["t"])
        data[c] = bars
    # 历史资金费（窗口前后各放宽一天，覆盖 entry<结算点<=exit 的边界）
    funding = {}
    frm = int(datetime(d0.year, d0.month, d0.day, tzinfo=timezone.utc).timestamp()) - 86400
    to = int(datetime(d1.year, d1.month, d1.day, tzinfo=timezone.utc).timestamp()) + 2 * 86400
    for c in ALTS:
        try:
            rows = client._get(
                f"{API}/funding_rate?contract={CONTRACT[c]}&from={frm}&to={to}&limit=100")
            funding[CONTRACT[c]] = {int(d["t"]): float(d["r"]) for d in rows}
        except Exception as e:
            print(f"  资金费拉取失败 {c}：{e}（该币资金费按 0 计）")
            funding[CONTRACT[c]] = {}
    # 全量 ATR 预计算（与回测一致：ATR 从缓存开头 2026-08-06 算起；
    # 引擎 live 时只用最近 80 根，差值约 1e-6 量级，可忽略）
    atr_full = {c: atr_wilder(data[c]) for c in COINS}
    idx_of_t = {c: {b["t"]: i for i, b in enumerate(data[c])} for c in COINS}
    eng = Engine(client=client, dry_log=True, cost_mode="ideal")  # 系统层校验跑旧口径，与第二十轮逐笔对照
    eng.funding_override = funding
    trades_got = []
    days = sorted({ts_to_dt(b["t"]).date() for b in data["BTC"] if d0 <= ts_to_dt(b["t"]).date() <= d1})
    for day in days:
        eng.today = day
        eng.state = eng._new_state()
        eng.state["date"] = day.isoformat()
        # 历史预热：窗口开始前的最近 80 根（2h 回看与回测一致）
        for c in COINS:
            prior = [b for b in data[c] if ts_to_dt(b["t"]).date() < day]
            eng.state["sys_bars"][c] = prior[-80:]
        day_bars = {c: [b for b in data[c] if ts_to_dt(b["t"]).date() == day] for c in COINS}
        all_t = sorted({b["t"] for b in day_bars["BTC"]})
        for t in all_t:
            # BTC 本根先追加历史（山寨信号的 r_btc 必须用本根，不能滞后一根）
            btc_bar = next((b for b in day_bars["BTC"] if b["t"] == t), None)
            if btc_bar is not None:
                eng.state["sys_bars"]["BTC"].append(btc_bar)
                eng.state["sys_bars"]["BTC"] = eng.state["sys_bars"]["BTC"][-80:]
            for c in ALTS:
                bar = next((b for b in day_bars[c] if b["t"] == t), None)
                if bar is None:
                    continue
                # 1. 已持仓：本根高低判止损/止盈（先止损），再判持满
                eng.check_positions_bar(c, bar)
                eng.check_positions_hold(c, bar)
                # 2. 入场：本根开盘（上一根信号的待入场）
                eng.sys_try_entry(c, t, bar["o"])
                # 3. 本根收盘后追加历史，再判信号（ATR 用全量预计算值）
                eng.state["sys_bars"][c].append(bar)
                eng.state["sys_bars"][c] = eng.state["sys_bars"][c][-80:]
                hist_t = eng.state["sys_bars"][c]
                btc_t = [h for h in eng.state["sys_bars"].get("BTC", []) if h["t"] <= t]
                eng.sys_on_closed_bar(c, bar, hist_t, btc_t, atr_full[c][idx_of_t[c][t]])
        # 日终：23:45 强制平仓（按当日最后一根收盘价，出场时刻记该根开盘，与回测同口径）
        for pos in list(eng.state["positions"]):
            if pos["layer"] != "sys":
                continue
            last = day_bars[pos["coin"]][-1]
            eng.close_position(pos, last["t"], last["c"], "eod_2345", exit_via="日终收盘价")
        trades_got.extend(eng.state["trades"])
    # 对照第二十轮 trades.csv（MAIN-15m），按（币/方向/入场分钟）匹配
    exp = []
    with open(os.path.join(DATA_DIR, "gate_iter_round20_trades.csv"), newline="") as f:
        for r in csv.DictReader(f):
            if r["arm"] != "MAIN" or r["granularity"] != "15m":
                continue
            d = datetime.strptime(r["entry_time_utc"][:10], "%Y-%m-%d").date()
            if d0 <= d <= d1:
                exp.append(r)

    def key_got(t):
        return (t["coin"], t["direction"], t["entry_t"] // 60)

    def key_exp(r):
        et = int(datetime.strptime(r["entry_time_utc"], "%Y-%m-%dT%H:%M:%S+00:00").timestamp())
        return (r["symbol"].replace("_USDT", ""), 1 if r["direction"] == "LONG" else -1, et // 60)

    got_keys = {key_got(t) for t in trades_got}
    exp_keys = {key_exp(r) for r in exp}
    print(f"系统层校验 {from_date}~{to_date}：引擎 {len(trades_got)} 笔，"
          f"第二十轮 {len(exp)} 笔")
    print(f"  匹配（币/方向/入场分钟）：{len(got_keys & exp_keys)} / {len(exp_keys)}")
    for m in sorted(exp_keys - got_keys)[:10]:
        print(f"  缺失：{m}")
    for m in sorted(got_keys - exp_keys)[:10]:
        print(f"  多余：{m}")
    # 逐笔核对出场：匹配上的笔核对出场价/原因/净盈亏。
    # 注意口径差：第二十轮名义本金 = 10% × 复利权益（9,942~10,065），
    # 引擎按纸面交易口径固定 10,000；三项（价差/成本/资金费）都随本金线性缩放，
    # 故期望净盈亏 = r20 净盈亏 × 10000/notional。
    exp_by_key = {key_exp(r): r for r in exp}
    bad = 0
    for t in trades_got:
        r = exp_by_key.get(key_got(t))
        if r is None:
            continue
        ok_exit = abs(float(r["exit"]) - t["exit"]) < 1e-9
        ok_reason = (r["reason"] == t["reason"])
        et = int(datetime.strptime(r["exit_time_utc"], "%Y-%m-%dT%H:%M:%S+00:00").timestamp())
        ok_time = (et == t["exit_t"])
        exp_net = float(r["pnl_taker_usdt"]) * 10000.0 / float(r["notional"])
        ok_pnl = abs(exp_net - t["net"]) < 0.05
        exp_fund = float(r["funding_cost_usdt"]) * 10000.0 / float(r["notional"])
        ok_fund = abs(exp_fund - t["funding_cost"]) < 0.05
        if not (ok_exit and ok_reason and ok_pnl and ok_fund and ok_time):
            bad += 1
            print(f"  出场不符 {t['coin']} {fmt_ts(t['entry_t'])}：引擎 "
                  f"exit={fmt_price(t['exit'])} {t['reason']} exit_t={fmt_ts(t['exit_t'])} "
                  f"net={t['net']:.2f} fund={t['funding_cost']:.2f}；第二十轮 "
                  f"exit={r['exit']} {r['reason']} exit_t={r['exit_time_utc'][:16]} "
                  f"net={exp_net:.2f} fund={exp_fund:.2f}（按 10,000 本金换算）")
    print(f"  出场核对：{len(exp_keys & got_keys) - bad}/{len(exp_keys & got_keys)} 笔一致")
    return trades_got, exp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--replay", default=None)
    ap.add_argument("--plan-file", default=None)
    ap.add_argument("--sub-plan-file", default=None)
    ap.add_argument("--start", default="08:00")
    ap.add_argument("--cost-model", default="real", choices=["real", "ideal"],
                    help="成本口径：real=真实成本模型（默认），ideal=旧固定 25/笔")
    ap.add_argument("--syscheck", action="store_true")
    ap.add_argument("--from", dest="from_date", default=None)
    ap.add_argument("--to", dest="to_date", default=None)
    args = ap.parse_args()
    client = GateClient()

    if args.check:
        eng = Engine(client=client, dry_log=True)
        plans, mtime, supp_triggers = eng.load_today_plan()
        if plans is None:
            print(f"今日（{eng.today}）无计划文件，引擎空转等待。")
            return 0
        for tr in supp_triggers:
            print(f"补充触发 {tr['coin']} {'多' if tr['direction'] == 1 else '空'} "
                  f"入场 {fmt_ts(tr['pending_entry_t'])} 参考 {fmt_price(tr['ref_entry'])} "
                  f"SL {fmt_price(tr['sl'])} TP {fmt_price(tr['tp'])}（{tr.get('level_txt', '')}）")
        for c, p in plans.items():
            print(f"{c} {'多' if p['direction'] == 1 else '空'} "
                  f"区 {fmt_price(p['zone'][0])}–{fmt_price(p['zone'][1])} "
                  f"SL {fmt_price(p['sl'])} TP {fmt_price(p['tp'])} "
                  f"触及 {p['touch']} 确认 {p['confirm_steps']} 失效 {p['invalid']}")
        print(f"共 {len(plans)} 条计划，plan_mtime={mtime}")
        return 0

    if args.replay:
        if not args.plan_file:
            print("--replay 需要 --plan-file")
            return 2
        eng = replay_day(args.plan_file, args.replay, args.start, client,
                         cost_mode=args.cost_model, sub_plan_path=args.sub_plan_file)
        if eng is None:
            return 2
        trades = eng.state["trades"]
        total = sum(t["net"] for t in trades)
        total_ideal = sum(t.get("net_ideal", t["net"]) for t in trades)
        print(f"回放 {args.replay}（{args.cost_model} 口径）：成交 {len(trades)} 笔，"
              f"合计净盈亏 {total:+.2f} USDT，理想口径 {total_ideal:+.2f} USDT")
        for t in trades:
            print(f"  {t['coin']} {'多' if t['direction'] == 1 else '空'} "
                  f"入场 {fmt_ts(t['entry_t'])} {fmt_price(t['entry'])} → "
                  f"出场 {fmt_ts(t['exit_t'])} {fmt_price(t['exit'])}（{t['reason']}）"
                  f" 净 {t['net']:+.2f}（理想 {t.get('net_ideal', t['net']):+.2f}；"
                  f"手续费 {t.get('fee_entry', 0) + t.get('fee_exit', 0):.2f}，"
                  f"滑点 {t.get('slip_usdt', 0):.2f}）")
        report = os.path.join(BASE, f"paper_engine_replay_{args.replay}.md")
        if args.cost_model == "ideal":
            # 旧口径：与已结算结果逐笔核对，报告重写（内容与原来一致）
            exp = {"SOL": 87.82, "LINK": 30.90, "XRP": 71.80, "ADA": 117.21}
            ok = True
            if abs(total - 307.73) > 0.01:
                ok = False
            for t in trades:
                if abs(t["net"] - exp.get(t["coin"], 0)) > 0.01:
                    ok = False
            got_coins = {t["coin"] for t in trades}
            if got_coins != set(exp):
                ok = False
            if not all(t["reason"] == "take_profit" for t in trades):
                ok = False
            print("回放校验：" + ("PASS（4 笔全止盈，合计 +307.73）" if ok else "FAIL（与已结算结果不符）"))
            with open(report, "w") as f:
                f.write(f"# 实时引擎回放测试 · {args.replay}\n\n")
                f.write(f"计划文件：{args.plan_file}\n\n回放窗口：{args.replay} {args.start}–23:00 UTC；"
                        f"触发只看已收盘 15m，入场为确认根下一根开盘价，止损/止盈看 15m 高低。\n\n")
                f.write(f"结果：成交 {len(trades)} 笔，合计净盈亏 {total:+.2f} USDT；"
                        f"期望：4 笔全止盈，合计 +307.73 USDT。\n\n")
                for t in trades:
                    f.write(f"- {t['coin']} {'多' if t['direction'] == 1 else '空'}："
                            f"入场 {fmt_ts(t['entry_t'])} {fmt_price(t['entry'])} → "
                            f"出场 {fmt_ts(t['exit_t'])} {fmt_price(t['exit'])}（{t['reason']}）"
                            f" 净 {t['net']:+.2f} USDT\n")
                f.write(f"\n校验：{'PASS' if ok else 'FAIL'}\n")
            print(f"回放报告已写：{report}")
            return 0 if ok else 1
        # 真实口径：不重写旧报告，追加一节；旧数字保留不动
        fee_delta = sum(OLD_FEE_PART - t.get("fee_entry", 7.5) - t.get("fee_exit", 7.5)
                        for t in trades)
        slip_delta = sum(OLD_SLIP_PART - t.get("slip_usdt", 0.0) for t in trades)
        resid = (total - total_ideal) - fee_delta - slip_delta
        path_effect = (total - 307.73) - fee_delta - slip_delta - resid
        lines = []
        lines.append("\n## 真实成本口径重算（2026-11-19 新模型，旧数字保留）\n")
        lines.append("模型：入场市价单 taker 0.075% + 滑点（扫盘成本 + 0.5×1m 平均 |收益|）；"
                     "止损市价单 taker 0.075% + 更差滑点（扫盘 + 破位延续 p90，波动分量约入场 4 倍）；"
                     "止盈限价单 maker 0.02%、无滑点，15m 高/低须穿过止盈价至少一个价差才算成交。"
                     "参数实测于 2026-11-18（`paper_cost_params.json`，3 次订单簿快照中位数 + 24h 1m K 线）。"
                     "回放用 11 月 18 日实测参数代理 11 月 17 日盘口条件（价差日内稳定，属近似，见注）。\n")
        lines.append(f"结果：成交 {len(trades)} 笔，合计净盈亏（真实口径）{total:+.2f} USDT；"
                     f"旧口径（固定 25/笔）+307.73 USDT。\n")
        lines.append("| 币 | 方向 | 入场参考→成交 | 出场参考→成交 | 原因 | 毛利 | 手续费 | 滑点 | 资金费 | 净（真实） | 净（理想） |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|---|")
        for t in trades:
            lines.append(f"| {t['coin']} | {'多' if t['direction'] == 1 else '空'} | "
                         f"{fmt_price(t.get('entry_ref', t['entry']))}→{fmt_price(t['entry'])} | "
                         f"{fmt_price(t.get('exit_ref', t['exit']))}→{fmt_price(t['exit'])} | "
                         f"{t['reason']} | {t['gross']:+.2f} | "
                         f"{t.get('fee_entry', 0) + t.get('fee_exit', 0):.2f} | "
                         f"{t.get('slip_usdt', 0):.2f} | {t['funding_cost']:+.2f} | "
                         f"{t['net']:+.2f} | {t.get('net_ideal', t['net']):+.2f} |")
        lines.append("")
        lines.append(f"差额分解（真实 − 旧 +307.73 = {total - 307.73:+.2f} USDT）：")
        lines.append(f"- 手续费差 {fee_delta:+.2f} USDT（旧口径手续费部分 15/笔 vs 真实：止盈腿 maker 2.00 而非 taker 7.50）；")
        lines.append(f"- 滑点差 {slip_delta:+.2f} USDT（旧口径假设滑点 10/笔 vs 真实滑点）；")
        lines.append(f"- 路径差 {path_effect:+.2f} USDT（止盈须穿价差一个价差才成交，出场时机/原因变化所致；"
                     f"含交叉项 {resid:+.2f}）；")
        lines.append(f"- 合计 {fee_delta + slip_delta + resid + path_effect:+.2f} USDT，与总差额一致。")
        lines.append("")
        lines.append("注：11 月 17 日 4 笔在旧口径下全为止盈；真实口径下若某笔止盈因未穿够一个价差"
                     "而延迟或改走止损/23:00 平仓，差额主要体现在“路径差”里，不代表模型算错。"
                     "本节只重算、不改已结算的旧口径结论（一天纸面盈利不构成 edge，第十五轮已定论）。")
        with open(report, "a") as f:
            f.write("\n".join(lines) + "\n")
        print(f"差额分解：手续费差 {fee_delta:+.2f}，滑点差 {slip_delta:+.2f}，"
              f"路径差 {path_effect:+.2f}（交叉项 {resid:+.2f}），合计 {total - 307.73:+.2f}")
        print(f"回放报告已追加：{report}")
        return 0

    if args.syscheck:
        if not args.from_date or not args.to_date:
            print("--syscheck 需要 --from/--to")
            return 2
        syscheck(args.from_date, args.to_date, client)
        return 0

    eng = Engine(client=client)
    if args.once:
        eng.live_loop(once=True)
        return 0
    eng.live_loop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
