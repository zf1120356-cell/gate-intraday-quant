#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""盘中补充触发回放验证（只用引擎副本 + 本地缓存 K 线，不碰 live 引擎/真实计划文件）。
用法：
  python3 test_replay_supp.py 2026-11-17 [--start 08:00] [--cost-model real]
  python3 test_replay_supp.py 2026-11-20 [--start 00:00] [--cost-model real]
期望：
  2026-11-17：真实口径 +309.69，4 笔（SOL/LINK/ADA/XRP），主观层一字不变，补充触发 0 条。
  2026-11-20：早上计划 0 笔 + 补充触发 ETH 做空 1 笔（14:45 入场、15:15 止盈），
               且不产生其他计划外单子。数据覆盖至 11-20 16:30 UTC（当日未完）。
"""
import argparse
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import paper_engine as pe
import supp_observer as so


class LocalClient:
    """用本地缓存文件扮 GateClient.candles（同接口，按 from/to 过滤）。"""

    def __init__(self, day):
        self.day = day
        self.cache = {}
        for tag in ("15m", "1h"):
            for c in pe.COINS:
                if day == "2026-11-17":
                    path = "/tmp/supp/nov17_%s_full_%s_USDT.json" % (tag, c)
                else:
                    path = "/tmp/supp/nov20_%s_fresh_%s_USDT.json" % (tag, c)
                with open(path) as f:
                    data = json.load(f)
                bars = [{"t": int(b["t"]), "o": float(b["o"]), "h": float(b["h"]),
                         "l": float(b["l"]), "c": float(b["c"])} for b in data]
                bars.sort(key=lambda b: b["t"])
                self.cache[(c, tag)] = bars

    def candles(self, contract, interval, limit=None, frm=None, to=None):
        coin = contract.replace("_USDT", "")
        bars = list(self.cache[(coin, interval)])
        if frm is not None:
            bars = [b for b in bars if b["t"] >= int(frm)]
        if to is not None:
            bars = [b for b in bars if b["t"] <= int(to)]
        if limit is not None:
            bars = bars[-limit:]
        return bars

    def tickers(self):
        return {}

    def funding_rates(self, contract, limit=10):
        return {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("day")
    ap.add_argument("--start", default="08:00")
    ap.add_argument("--cost-model", default="real", choices=["real", "ideal"])
    args = ap.parse_args()

    plan_copy = os.path.join(HERE, "plan-%s-copy.md" % args.day)
    if args.day == "2026-11-17":
        orig = "/home/hatch/workspace/赚钱路子/SMC主观分析-2026-11-17.md"
    else:
        orig = "/home/hatch/workspace/赚钱路子/纸面交易/2026-11-20.md"
    with open(orig, encoding="utf-8") as f:
        orig_text = f.read()
    with open(plan_copy, "w", encoding="utf-8") as f:
        f.write(orig_text)

    client = LocalClient(args.day)
    b15 = client.candles("ETH_USDT", "15m")
    print("数据覆盖 ETH 15m：%d 根，%s ~ %s" % (
        len(b15),
        datetime.fromtimestamp(b15[0]["t"], timezone.utc),
        datetime.fromtimestamp(b15[-1]["t"], timezone.utc)))
    eng = pe.replay_day(plan_copy, args.day, args.start, client,
                        cost_mode=args.cost_model)
    if eng is None:
        print("回放失败")
        return 2
    trades = eng.state["trades"]
    total = sum(t["net"] for t in trades)
    total_ideal = sum(t.get("net_ideal", t["net"]) for t in trades)
    supp_trades = [t for t in trades if t.get("supp")]
    morning_trades = [t for t in trades if not t.get("supp")]
    print("\n回放 %s（%s 口径，--start %s）：成交 %d 笔，合计净 %+.2f USDT（理想 %+.2f）" % (
        args.day, args.cost_model, args.start, len(trades), total, total_ideal))
    print("  其中早上计划 %d 笔，补充触发 %d 笔" % (len(morning_trades), len(supp_trades)))
    for t in trades:
        tag = "补充触发" if t.get("supp") else "早上计划"
        print("  [%s] %s %s 入场 %s %s -> 出场 %s %s（%s）毛利 %+.2f 净 %+.2f（理想 %+.2f）" % (
            tag, t["coin"], "多" if t["direction"] == 1 else "空",
            pe.fmt_ts(t["entry_t"]), pe.fmt_price(t["entry"]),
            pe.fmt_ts(t["exit_t"]), pe.fmt_price(t["exit"]), t["reason"],
            t["gross"], t["net"], t.get("net_ideal", t["net"])))
    with open(plan_copy, encoding="utf-8") as f:
        txt = f.read()
    supp_rows = so.parse_supp_triggers(txt)
    print("计划副本里补充触发小节：%d 条" % len(supp_rows))
    for r in supp_rows:
        print("  %s %s 入场 %s 参考 %s SL %s TP %s（%s）" % (
            r["coin"], "空" if r["direction"] == -1 else "多",
            pe.fmt_ts(r["pending_entry_t"]), r["ref_entry"], r["sl"], r["tp"],
            r["level_txt"]))
    print("引擎 state[supp]：%s" % {k: v.get("status") for k, v in eng.state["supp"].items()})
    return 0


if __name__ == "__main__":
    sys.exit(main())
