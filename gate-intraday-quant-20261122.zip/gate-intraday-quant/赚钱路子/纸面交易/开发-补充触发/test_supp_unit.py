#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""盘中补充触发 · 单元测试（引擎副本 + 观察模块，不碰 live 引擎/真实计划文件）。
跑：python3 test_supp_unit.py
"""
import datetime
import json
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import supp_observer as so
import paper_engine as pe

PASSED = []
FAILED = []


def check(name, cond, extra=""):
    if cond:
        PASSED.append(name)
        print("PASS %s" % name)
    else:
        FAILED.append(name)
        print("FAIL %s %s" % (name, extra))


def load(p):
    d = json.load(open(p))
    b = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
          "l": float(r["l"]), "c": float(r["c"])} for r in d]
    b.sort(key=lambda x: x["t"])
    return b


def T(hhmm, day=20):
    h, m = map(int, hhmm.split(":"))
    return int(datetime.datetime(2026, 11, day, h, m, tzinfo=datetime.timezone.utc).timestamp())


ATR1H = {"BTC": 572.66, "ETH": 19.28, "SOL": 0.859, "DOGE": 0.000641,
         "LINK": 0.1009, "XRP": 0.01085, "BNB": 4.32, "ADA": 0.001755}
DAY0_20 = T("00:00", 20)
DAY0_17 = T("00:00", 17)


def hist_upto(b15, b1h, upto_t):
    bars = [b for b in b15 if b["t"] <= upto_t]
    pre = [b for b in b15 if b["t"] < DAY0_20 or b["t"] < DAY0_17]
    return bars, b1h


# ---------- 1. 观察者判定 ----------
b15e = load("/tmp/supp/nov20_15m_fresh_ETH_USDT.json")
b1he = load("/tmp/supp/nov20_1h_fresh_ETH_USDT.json")
pre20 = [b for b in b15e if b["t"] < DAY0_20][-40:]


def detect_at(close_t):
    bars = [b for b in b15e if DAY0_20 <= b["t"] <= close_t]
    hist = pre20 + bars
    h1 = [b for b in b1he if b["t"] + 3600 <= close_t]
    return so.detect_on_closed_bar(hist, h1, "ETH", ATR1H["ETH"], DAY0_20)


# 1a. ETH 14:15 探针 + 14:30 确认 -> 触发，数值与设计一致
tr = detect_at(T("14:30"))
check("1a ETH 14:15 触发", tr is not None and tr["direction"] == -1
      and tr["level_type"] == "L2" and abs(tr["level"] - 1759.11) < 1e-9
      and abs(tr["ref_entry"] - 1733.45) < 1e-9
      and abs(tr["sl"] - 1752.73) < 1e-9 and abs(tr["tp"] - 1694.89) < 1e-9
      and tr["pending_entry_t"] == T("14:45")
      and abs(tr["confirm_x"] - 2.06) < 0.05, str(tr))
# 1b. ETH 13:45 近失样本 -> 不触发（探针上影 3.31、确认跌幅 1.43，均 <1.5xATR）
tr13 = detect_at(T("14:00"))
check("1b ETH 13:45 近失不触发", tr13 is None, str(tr13))
# 1c. ETH 01:00 -> 不触发（上影 0.98x < 1.5x；已知漏报，设计第四节）
tr01 = detect_at(T("01:15"))
check("1c ETH 01:00 不触发（上影不足）", tr01 is None, str(tr01))

# 1d. Nov 17 BTC/DOGE 15:15 -> 不触发（探针新鲜度规则挡掉）
for coin in ("BTC", "DOGE"):
    b15 = load("/tmp/supp/nov17_15m_full_%s_USDT.json" % coin)
    b1h = load("/tmp/supp/nov17_1h_full_%s_USDT.json" % coin)
    bars = [b for b in b15 if DAY0_17 <= b["t"] <= T("15:30", 17)]
    pre = [b for b in b15 if b["t"] < DAY0_17][-40:]
    h1 = [b for b in b1h if b["t"] + 3600 <= T("15:30", 17)]
    trx = so.detect_on_closed_bar(pre + bars, h1, coin, ATR1H[coin], DAY0_17)
    check("1d Nov17 %s 15:15 不触发（新鲜度）" % coin, trx is None, str(trx))

# ---------- 2. 计划文件写入 / 解析 ----------
d = tempfile.mkdtemp()
p = os.path.join(d, "plan.md")
open(p, "w").write("# 计划\n\n| 币 | 方向 | 入场区 | 参考入场价 | 止损 | 止盈 | 触发条件 | 失效条件 |\n|---|---|---|---|---|---|---|---|\n| ETH | 做空 | 1800.3–1819.3 | 1809.8 | 1829.1 | 1771.2 | 摸进 1800.3–1819.3 | 触发前 1h 收盘上破 1822 |\n")
trig = detect_at(T("14:30"))
check("2a 写入返回 True", so.append_supp_trigger(p, trig) is True)
check("2b 幂等：第二次返回 False", so.append_supp_trigger(p, trig) is False)
txt = open(p).read()
check("2c 计划原文不动", "1800.3" in txt and "1829.1" in txt and "1771.2" in txt)
parsed = so.parse_supp_triggers(txt)
check("2d 解析回 1 条且数值全精度", len(parsed) == 1
      and abs(parsed[0]["ref_entry"] - 1733.45) < 1e-9
      and abs(parsed[0]["sl"] - 1752.73) < 1e-9
      and abs(parsed[0]["tp"] - 1694.89) < 1e-9
      and parsed[0]["pending_entry_t"] == T("14:45"), str(parsed))
open(p, "a").write("| ETH | 做空 | 2026-11-20 15:00 | 2026-11-20 15:15 | L2 | 坏数 | 1 | 2 | 3 | x |\n")
check("2e 缺字段行丢弃", len(so.parse_supp_triggers(open(p).read())) == 1)


class StubClient:
    def tickers(self):
        return {}

    def funding_rates(self, contract, limit=10):
        return {}

    def candles(self, contract, interval, limit=None, frm=None, to=None):
        return []


def fresh_engine(day=20):
    eng = pe.Engine(client=StubClient(), dry_log=True, cost_mode="real")
    eng.today = datetime.date(2026, 11, day)
    eng.state = eng._new_state()
    eng.state["date"] = eng.today.isoformat()
    return eng


# ---------- 3. supp_register / supp_merge ----------
eng = fresh_engine(20)
tr = detect_at(T("14:30"))
check("3a 登记成功", eng.supp_register(dict(tr), source="observer") is True)
check("3b 同币第二条拒绝", eng.supp_register(dict(tr), source="observer") is False)
check("3c 状态为 confirmed", eng.state["supp"]["ETH"]["status"] == "confirmed"
      and eng.state["supp"]["ETH"]["pending_entry_t"] == T("14:45"))

eng2 = fresh_engine(20)
eng2.state["plans"]["ETH"] = {"status": "triggered", "trades_done": 1}
check("3d 早上计划已成交则跳过", eng2.supp_register(dict(tr), source="file") is False
      and eng2.state["supp"]["ETH"]["status"] == "done")

eng3 = fresh_engine(20)
stale = dict(tr, pending_entry_t=T("14:45") - 3600)
eng3.supp_merge([stale], now_t=T("16:00"))
check("3e 过期触发记 stale 作废", eng3.state["supp"]["ETH"]["status"] == "done"
      and eng3.state["supp"]["ETH"].get("trigger") is not None)
eng4 = fresh_engine(20)
eng4.supp_merge([dict(tr)], now_t=T("14:40"))
check("3f 未过期触发并进 state", eng4.state["supp"]["ETH"]["status"] == "confirmed")

# ---------- 4. load_today_plan mtime 重读（PLAN_DIR 指向临时目录） ----------
tmpdir = tempfile.mkdtemp()
plan_path = os.path.join(tmpdir, "2026-11-20.md")
open(plan_path, "w").write("# 计划\n\n| 币 | 方向 | 入场区 | 参考入场价 | 止损 | 止盈 | 触发条件 | 失效条件 |\n|---|---|---|---|---|---|---|---|\n| ETH | 做空 | 1800.3–1819.3 | 1809.8 | 1829.1 | 1771.2 | 摸进 1800.3–1819.3 | 触发前 1h 收盘上破 1822 |\n")
old_plan_dir = pe.PLAN_DIR
pe.PLAN_DIR = tmpdir
try:
    eng5 = fresh_engine(20)
    plans, mtime, supp0 = eng5.load_today_plan()
    check("4a 无补充触发时解析为空", supp0 == [] and "ETH" in plans)
    so.append_supp_trigger(plan_path, dict(tr))
    plans, mtime2, supp1 = eng5.load_today_plan()
    check("4b 文件改动后重读到新触发", len(supp1) == 1
          and supp1[0]["coin"] == "ETH" and supp1[0]["pending_entry_t"] == T("14:45"))
    check("4c mtime 变化", mtime2 >= mtime)
    eng5.supp_merge(supp1, now_t=T("14:40"))
    check("4d 重读的触发可登记", eng5.state["supp"]["ETH"]["status"] == "confirmed")
finally:
    pe.PLAN_DIR = old_plan_dir

# ---------- 5. supp_try_entry 守卫 ----------
# 5a 正常入场：SL/TP 按实际开盘价重算（ATR 取 |sl-ref|=19.28）
eng6 = fresh_engine(20)
eng6.supp_register(dict(tr), source="observer")
eng6.supp_try_entry("ETH", T("14:45"), 1733.38)
check("5a 正常入场开仓", len(eng6.state["positions"]) == 1
      and eng6.state["supp"]["ETH"]["status"] == "triggered")
pos = eng6.state["positions"][0]
check("5a SL/TP 按开盘价重算", abs(pos["sl"] - (1733.38 + 19.28)) < 0.01
      and abs(pos["tp"] - (1733.38 - 2 * 19.28)) < 0.01
      and pos.get("supp") is True, str(pos))
# 5b gap-stop：开盘已穿止损
eng7 = fresh_engine(20)
eng7.supp_register(dict(tr), source="observer")
eng7.supp_try_entry("ETH", T("14:45"), 1753.00)
check("5b 开盘穿止损跳过", len(eng7.state["positions"]) == 0
      and eng7.state["supp"]["ETH"]["status"] == "done")
# 5c TP-reached：开盘已到止盈
eng8 = fresh_engine(20)
eng8.supp_register(dict(tr), source="observer")
eng8.supp_try_entry("ETH", T("14:45"), 1694.00)
check("5c 开盘到止盈跳过", len(eng8.state["positions"]) == 0
      and eng8.state["supp"]["ETH"]["status"] == "done")
# 5d 过期：待入场时间已过
eng9 = fresh_engine(20)
eng9.supp_register(dict(tr), source="observer")
eng9.supp_try_entry("ETH", T("15:00"), 1730.00)
check("5d 过期待入场记 missed", len(eng9.state["positions"]) == 0
      and eng9.state["supp"]["ETH"]["status"] == "done"
      and eng9.state["supp"]["ETH"].get("missed") is True)
# 5e 23:00 之后不开新仓
eng10 = fresh_engine(20)
tr_eod = dict(tr, pending_entry_t=T("23:00"))
eng10.supp_register(tr_eod, source="observer")
eng10.supp_try_entry("ETH", T("23:00"), 1730.00)
check("5e 23:00 不开新仓", len(eng10.state["positions"]) == 0
      and eng10.state["supp"]["ETH"]["status"] == "done")

print("\n通过 %d 项，失败 %d 项" % (len(PASSED), len(FAILED)))
if FAILED:
    print("失败：", FAILED)
    sys.exit(1)
print("全部单元测试通过")
