"""给引擎副本加盘中补充触发（只改副本，live 引擎不动）。
每处替换断言恰好命中一次，否则报错退出。"""
import sys

P = "paper_engine.py"
src = open(P, encoding="utf-8").read()

def rep(old, new, name):
    global src
    n = src.count(old)
    assert n == 1, f"{name}: 命中 {n} 次（期望 1）"
    src = src.replace(old, new)
    print(f"OK {name}")

# 1. 导入观察模块（缺失则 supp 自动关闭，不影响引擎其余功能）
rep("""from datetime import datetime, timedelta, timezone, date""",
    """from datetime import datetime, timedelta, timezone, date

try:
    import supp_observer
    SUPP_OBSERVER_OK = True
except ImportError:
    supp_observer = None
    SUPP_OBSERVER_OK = False""", "import supp_observer")

# 2. 补充触发开关（v1 只开做空）
rep("""SUB_NO_NEW_BEIJING_START = 1  # 北京时间 01:00（含）
SUB_NO_NEW_BEIJING_END = 7    # 北京时间 07:00（不含）""",
    """SUB_NO_NEW_BEIJING_START = 1  # 北京时间 01:00（含）
SUB_NO_NEW_BEIJING_END = 7    # 北京时间 07:00（不含）

# 盘中补充触发（2026-11-21 设计 v1，主观层新层）：
#   观察模块 supp_observer.py（独立文件），每根 15m 收盘重读 8 个币；
#   确认后、入场前写进当日计划文件“盘中补充触发”小节，引擎下轮重读计划
#   文件解析并执行（层记 subj，走 23:00 强平与真实成本模型）。
#   v1 只开做空（SUPP_DIRECTIONS=(-1,)）；做多已实现但未单独验证，不启用。
SUPP_ENABLED = True
SUPP_DIRECTIONS = (-1,)""", "SUPP config")

# 3. state 加 supp
rep("""            "sub_plans": {},    # coin -> 与 plans 同形，分系统计划层状态""",
    """            "sub_plans": {},    # coin -> 与 plans 同形，分系统计划层状态
            "supp": {},         # coin -> {status, trigger, pending_entry_t, trades_done} 盘中补充触发""",
    "state supp")

# 4. supp 方法（插在 subj_try_entry 之后、分系统段之前）
rep("""        st["status"] = "triggered"
        st["trades_done"] = st.get("trades_done", 0) + 1
        self._save_state()

    # ---- 分系统 SUB-SMC 计划层：与主观层同口径的触发/失效/入场 ----""",
    """        st["status"] = "triggered"
        st["trades_done"] = st.get("trades_done", 0) + 1
        self._save_state()

    # ---- 盘中补充触发（主观层新层，2026-11-21 设计 v1） ----
    def supp_register(self, trigger, source="file"):
        \"\"\"登记一条补充触发（来自计划文件重读或观察模块直写）。
        单币每天最多 1 条；该币早上计划已成交则跳过（不叠加）。\"\"\"
        coin = trigger["coin"]
        st = self.state["supp"].setdefault(coin, {"status": "waiting", "trigger": None,
                                                   "pending_entry_t": None, "trades_done": 0})
        if st.get("trades_done", 0) >= 1 or st.get("status") in ("triggered", "done"):
            return False
        if st.get("trigger") is not None:
            return False
        plan_st = self.state["plans"].get(coin, {})
        if plan_st.get("trades_done", 0) >= 1 or plan_st.get("status") == "triggered":
            self.log_event("supp_skipped_plan_traded", coin=coin, source=source)
            st["status"] = "done"
            self._save_state()
            return False
        st["trigger"] = trigger
        st["pending_entry_t"] = trigger["pending_entry_t"]
        st["status"] = "confirmed"
        st["source"] = source
        self.log_event("supp_registered", coin=coin, trigger=trigger, source=source)
        self._save_state()
        return True

    def supp_merge(self, supp_triggers, now_t):
        \"\"\"把计划文件里解析出的补充触发并进 state（mtime 重读的恢复路径）。
        pending_entry_t 已过 15 分钟以上的记 supp_stale 并作废（不追单）。\"\"\"
        if not supp_triggers:
            return
        for tr in supp_triggers:
            coin = tr["coin"]
            st = self.state["supp"].get(coin, {})
            if st.get("trigger") is not None or st.get("trades_done", 0) >= 1:
                continue
            if tr["pending_entry_t"] < now_t - 900:
                self.log_event("supp_stale", coin=coin, pending_entry_t=tr["pending_entry_t"],
                               now_t=now_t)
                self.state["supp"].setdefault(coin, {"status": "done", "trigger": tr,
                                                      "pending_entry_t": tr["pending_entry_t"],
                                                      "trades_done": 0})
                self._save_state()
                continue
            self.supp_register(tr, source="file")

    def supp_try_entry(self, coin, bar_open_t, bar_open, latency_sec=0.0):
        \"\"\"新一根 15m 开盘时，若有待入场的补充触发则执行入场。
        与 subj_try_entry 同口径：SL/TP 按实际入场开盘价重算（1×/2×ATR，
        ATR 从触发自身的 |sl - ref_entry| 取）；层记 subj，走 23:00 强平。\"\"\"
        if not SUPP_ENABLED:
            return
        st = self.state["supp"].get(coin)
        if not st or st.get("status") != "confirmed":
            return
        trig = st.get("trigger")
        if not trig:
            return
        pend = st.get("pending_entry_t")
        if pend is None:
            return
        if pend < bar_open_t:
            eod_t = int(datetime(self.today.year, self.today.month, self.today.day,
                                 23, 0, tzinfo=timezone.utc).timestamp())
            if pend >= eod_t:
                self.log_event("supp_entry_skipped_eod", coin=coin, bar_open_t=pend)
            else:
                self.log_event("supp_entry_missed", coin=coin, pending_entry_t=pend,
                               bar_open_t=bar_open_t, reason="stale_expired")
                self.append_plan_record(
                    self.today,
                    f"{coin} 盘中补充触发未入场：待入场时间 {fmt_ts(pend)} 已过"
                    f"（引擎停摆错过），不再尝试")
            st["status"] = "done"
            st["missed"] = True
            self._save_state()
            return
        if pend != bar_open_t:
            return
        if bar_open_t >= int(datetime(self.today.year, self.today.month, self.today.day,
                                      23, 0, tzinfo=timezone.utc).timestamp()):
            self.log_event("supp_entry_skipped_eod", coin=coin, bar_open_t=bar_open_t)
            st["status"] = "done"
            self._save_state()
            return
        direction = trig["direction"]
        plan_sl, plan_tp = trig["sl"], trig["tp"]
        if direction == 1 and bar_open <= plan_sl:
            self.log_event("supp_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if direction == -1 and bar_open >= plan_sl:
            self.log_event("supp_entry_skipped_gap_stop", coin=coin, open=bar_open, sl=plan_sl)
            st["status"] = "done"
            self._save_state()
            return
        if (direction == 1 and bar_open >= plan_tp) or (direction == -1 and bar_open <= plan_tp):
            self.log_event("supp_entry_skipped_tp_reached", coin=coin, open=bar_open, tp=plan_tp)
            self.append_plan_record(
                self.today,
                f"{coin} 盘中补充触发未入场：开盘价 {fmt_price(bar_open)} 已到参考止盈 "
                f"{fmt_price(plan_tp)}，目标已走完，不追")
            st["status"] = "done"
            self._save_state()
            return
        atr = abs(plan_sl - trig["ref_entry"])
        if direction == 1:
            sl, tp = bar_open - atr, bar_open + 2 * atr
        else:
            sl, tp = bar_open + atr, bar_open - 2 * atr
        pos = self.open_position(coin, "subj", direction, bar_open_t, bar_open, sl, tp,
                                 extra={"plan_sl": plan_sl, "plan_tp": plan_tp, "atr_1h": atr,
                                        "supp": True,
                                        "supp_level": trig.get("level_txt", ""),
                                        "supp_basis": trig.get("basis", "")},
                                 latency_sec=latency_sec)
        st["status"] = "triggered"
        st["trades_done"] = st.get("trades_done", 0) + 1
        self.append_plan_record(
            self.today,
            f"{coin} 盘中补充触发（{trig.get('level_txt', '')}；{trig.get('basis', '')}）")
        self._save_state()

    # ---- 分系统 SUB-SMC 计划层：与主观层同口径的触发/失效/入场 ----""",
    "supp methods")

# 5. load_today_plan 也解析补充触发小节
rep("""    def load_today_plan(self):
        path = os.path.join(PLAN_DIR, f"{self.today.isoformat()}.md")
        if not os.path.exists(path):
            return None, None
        mtime = os.path.getmtime(path)
        try:
            with open(path) as f:
                text = f.read()
        except OSError:
            return None, None
        plans = parse_plan_table(text)
        cutoff = parse_cutoff(text)
        plan_mtime = int(mtime)
        if cutoff is not None:
            plan_mtime = max(plan_mtime, int(cutoff.timestamp()))
        return plans, plan_mtime""",
    """    def load_today_plan(self):
        path = os.path.join(PLAN_DIR, f"{self.today.isoformat()}.md")
        if not os.path.exists(path):
            return None, None, []
        mtime = os.path.getmtime(path)
        try:
            with open(path) as f:
                text = f.read()
        except OSError:
            return None, None, []
        plans = parse_plan_table(text)
        cutoff = parse_cutoff(text)
        plan_mtime = int(mtime)
        if cutoff is not None:
            plan_mtime = max(plan_mtime, int(cutoff.timestamp()))
        supp_triggers = []
        if SUPP_ENABLED and SUPP_OBSERVER_OK:
            supp_triggers = supp_observer.parse_supp_triggers(text)
        return plans, plan_mtime, supp_triggers""",
    "load_today_plan supp")

# 6a. _live_tick：解包三元组 + supp_merge
rep("""        plans, plan_mtime = self.load_today_plan()
        sub_plans, sub_plan_mtime = self.load_today_sub_plan()
        if plans is None and sub_plans is None:
            if time.time() - self._last_idle_log > 1800:
                self._last_idle_log = time.time()
                self.log_event("idle_no_plan", {"day": self.today.isoformat()})
            return
        if plans is not None and self.state.get("plan_mtime") != plan_mtime:
            self.state["plan_mtime"] = plan_mtime
            self._save_state()""",
    """        plans, plan_mtime, supp_triggers = self.load_today_plan()
        sub_plans, sub_plan_mtime = self.load_today_sub_plan()
        if plans is None and sub_plans is None:
            if time.time() - self._last_idle_log > 1800:
                self._last_idle_log = time.time()
                self.log_event("idle_no_plan", {"day": self.today.isoformat()})
            return
        if plans is not None and self.state.get("plan_mtime") != plan_mtime:
            self.state["plan_mtime"] = plan_mtime
            self._save_state()
        # 补充触发：计划文件 mtime 变化重读的恢复路径（观察模块写进文件后，
        # 下轮 tick 在这里并进 state；重启后也一样能吃到未执行的触发）
        if SUPP_ENABLED and supp_triggers:
            self.supp_merge(supp_triggers, now_t)""",
    "live_tick load+merge")

# 6b. _live_tick：1h 拉 10 根（L1 要最近 4 根有效已收盘 1h，留余量防扁平占位根）
rep("""                bars1h[c] = self.client.candles(CONTRACT[c], "1h", limit=6)""",
    """                bars1h[c] = self.client.candles(CONTRACT[c], "1h", limit=10)""",
    "1h limit 10")

# 6c. _live_tick：形成中 K 线处也试补充触发入场
rep("""                if plan is not None:
                    self.subj_try_entry(c, forming["t"], forming["o"], plan,
                                        latency_sec=latency)
                self.sys_try_entry(c, forming["t"], forming["o"], latency_sec=latency)""",
    """                if plan is not None:
                    self.subj_try_entry(c, forming["t"], forming["o"], plan,
                                        latency_sec=latency)
                if SUPP_ENABLED:
                    self.supp_try_entry(c, forming["t"], forming["o"],
                                        latency_sec=latency)
                self.sys_try_entry(c, forming["t"], forming["o"], latency_sec=latency)""",
    "live_tick supp_try_entry")

# 6d. _live_tick：已收盘 15m 循环里跑观察者（主观触发判定之后）
rep("""                # 主观触发判定
                if plan is not None:
                    self.subj_on_closed_bar(c, b, plan, plan_mtime)
                # 分系统计划触发判定（全天有效，不判 Killzone）""",
    """                # 主观触发判定
                if plan is not None:
                    self.subj_on_closed_bar(c, b, plan, plan_mtime)
                # 盘中补充触发观察（主观层新层）：本根为确认根，上一根为探针根；
                # 确认后写进计划文件（审计），并立即登记（执行路径，下轮重读为恢复路径）
                if SUPP_ENABLED and SUPP_OBSERVER_OK:
                    supp_st = self.state["supp"].get(c, {})
                    plan_st = self.state["plans"].get(c, {})
                    if (supp_st.get("trigger") is None and supp_st.get("trades_done", 0) < 1
                            and plan_st.get("trades_done", 0) < 1
                            and plan_st.get("status") != "triggered"):
                        hist15 = self.state["sys_bars"].get(c, [])
                        if hist15 and hist15[-1]["t"] == b["t"]:
                            atr1h_plan = None
                            atr1h_src = "plan"
                            if plan is not None:
                                atr1h_plan = abs(plan["sl"] - plan["ref_entry"])
                            if atr1h_plan is None or atr1h_plan <= 0:
                                h1c = [x for x in bars1h[c] if x["t"] + 3600 <= b["t"]]
                                a1 = atr_wilder(h1c)
                                atr1h_plan = a1[-1] if a1 and a1[-1] else None
                                atr1h_src = "live_1h"
                            day_start_t = int(datetime(self.today.year, self.today.month,
                                                       self.today.day,
                                                       tzinfo=timezone.utc).timestamp())
                            trig = supp_observer.detect_on_closed_bar(
                                hist15, bars1h[c], c, atr1h_plan, day_start_t,
                                atr1h_source=atr1h_src, directions=SUPP_DIRECTIONS)
                            if trig is not None:
                                plan_path = os.path.join(
                                    PLAN_DIR, f"{self.today.isoformat()}.md")
                                try:
                                    supp_observer.append_supp_trigger(
                                        plan_path, trig, lock_path=LOCK_PATH)
                                except OSError:
                                    self.log_event("supp_write_failed", coin=c)
                                self.supp_register(trig, source="observer")
                # 分系统计划触发判定（全天有效，不判 Killzone）""",
    "live_tick observer")

# 7a. replay_day：入场步也试补充触发
rep("""            # 2. 入场：本根开盘（上一根收盘后已确认的计划）
            if plan is not None:
                eng.subj_try_entry(c, t, bar["o"], plan)
            eng.sys_try_entry(c, t, bar["o"])""",
    """            # 2. 入场：本根开盘（上一根收盘后已确认的计划）
            if plan is not None:
                eng.subj_try_entry(c, t, bar["o"], plan)
            if SUPP_ENABLED:
                eng.supp_try_entry(c, t, bar["o"])
            eng.sys_try_entry(c, t, bar["o"])""",
    "replay supp_try_entry")

# 7b. replay_day：触发判定步跑观察者（写进计划文件副本 + 登记）
rep("""            # 4. 触发判定：本根收盘
            if plan is not None:
                eng.subj_on_closed_bar(c, bar, plan, plan_mtime)""",
    """            # 4. 触发判定：本根收盘
            if plan is not None:
                eng.subj_on_closed_bar(c, bar, plan, plan_mtime)
            # 4b. 盘中补充触发观察（主观层新层）：本根为确认根，上一根为探针根
            if SUPP_ENABLED and SUPP_OBSERVER_OK and c not in supp_done:
                hist15 = [x for x in bars15[c] if x["t"] <= t]
                atr1h = None
                atr1h_src = "plan"
                if plan is not None:
                    atr1h = abs(plan["sl"] - plan["ref_entry"])
                if atr1h is None or atr1h <= 0:
                    h1c = [x for x in bars1h[c] if x["t"] + 3600 <= t]
                    a1 = atr_wilder(h1c)
                    atr1h = a1[-1] if a1 and a1[-1] else None
                    atr1h_src = "live_1h"
                trig = supp_observer.detect_on_closed_bar(
                    hist15, bars1h[c], c, atr1h, day_start_t,
                    atr1h_source=atr1h_src, directions=SUPP_DIRECTIONS)
                if trig is not None:
                    try:
                        supp_observer.append_supp_trigger(plan_path, trig)
                    except OSError:
                        eng.log_event("supp_write_failed", coin=c)
                    if eng.supp_register(trig, source="observer"):
                        supp_done.add(c)""",
    "replay observer")

# 7c. replay_day：初始化 supp_done 与 day_start_t（在 bars 拉取之后、循环之前）
rep("""    bars15, bars1h = {}, {}
    for c in COINS:
        bars15[c] = client.candles(CONTRACT[c], "15m", frm=start_t - 3600 * 4, to=end_t + 900)
        bars1h[c] = client.candles(CONTRACT[c], "1h", frm=start_t - 3600 * 4, to=end_t + 3600)""",
    """    bars15, bars1h = {}, {}
    for c in COINS:
        bars15[c] = client.candles(CONTRACT[c], "15m", frm=start_t - 3600 * 4, to=end_t + 900)
        bars1h[c] = client.candles(CONTRACT[c], "1h", frm=start_t - 3600 * 4, to=end_t + 3600)
    day_start_t = int(start_dt.timestamp())
    supp_done = set()""",
    "replay init supp")

# 8. main --check：解包三元组并打印补充触发
rep("""        eng = Engine(client=client, dry_log=True)
        plans, mtime = eng.load_today_plan()
        if plans is None:
            print(f"今日（{eng.today}）无计划文件，引擎空转等待。")
            return 0""",
    """        eng = Engine(client=client, dry_log=True)
        plans, mtime, supp_triggers = eng.load_today_plan()
        if plans is None:
            print(f"今日（{eng.today}）无计划文件，引擎空转等待。")
            return 0
        for tr in supp_triggers:
            print(f"补充触发 {tr['coin']} {'多' if tr['direction'] == 1 else '空'} "
                  f"入场 {fmt_ts(tr['pending_entry_t'])} 参考 {fmt_price(tr['ref_entry'])} "
                  f"SL {fmt_price(tr['sl'])} TP {fmt_price(tr['tp'])}（{tr.get('level_txt', '')}）")""",
    "main check supp")

open(P, "w", encoding="utf-8").write(src)
print("全部补丁已写入")
