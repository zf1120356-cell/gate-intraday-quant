#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第三期——取数：8 个新币的 1h/15m 历史（Gate 公开接口，curl）。
币种名单（跑前写死，见 第三期-20题.md §0）：
  从 2026-11-22 tickers 快照（gate_tickers_train3.json）按 24h 成交额排序，
  排除第 1–42 轮已用 32 币、第一期 8 币（ANT、IRYS、DRAM、BZ、BCH、PUMP、
  APT、ICP）、第二期 8 币（BTW、ONDO、AAVE、JCT、TRX、GRAM、INIT、LIT）、
  稳定币、杠杆代币、价差 >0.07%、代币化股票/ETF/商品后，
  取成交额前 8 个通过 1h 连续性校验的虚拟币。
  KORU 经核实为 Direxion 韩国 Bull 3x ETF（代币化 ETF），已排除；
  VVV 是第二期替补（取过数、未进题），为保“全新”严格起见也跳过；
  ENSO（Enso Network 原生代币）、CAP（Cap 协议治理代币）经核实为虚拟币。
  最终 8 币：ENSO、OP、WLFI、SHIB、TIA、FARTCOIN、ORDI、PENGU；
  替补：CAP、VIRTUAL、ETC、ASTER。
窗口：1h/15m 均为最近 60 天（2026-09-22~2026-11-22 UTC），7 天分片 from/to，
不带 limit（limit 不能与 from/to 同用；15m 60 天 = 5,760 根 < 10,000 上限）。
每根的量 "v" 也存下来（Gate K 线自带 v 字段，供题干相对量用）。
只取数，不出题、不做判断。
"""
import json
import os
import subprocess
import time
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = "https://api.gateio.ws/api/v4"

# 按成交额排序的候选（前 12 个虚拟币，含 4 个替补；最终取前 8 个通过连续性校验的）
CANDIDATES = ["ENSO", "OP", "WLFI", "SHIB", "TIA", "FARTCOIN",
              "ORDI", "PENGU", "CAP", "VIRTUAL", "ETC", "ASTER"]
START = datetime(2026, 9, 22, tzinfo=timezone.utc)
END = datetime(2026, 11, 22, 12, 0, tzinfo=timezone.utc)


def http_get_json(url, retries=3):
    for i in range(retries):
        try:
            out = subprocess.run(["curl", "-s", "--max-time", "60", url],
                                 capture_output=True, text=True, timeout=70)
            data = json.loads(out.stdout)
            if isinstance(data, dict) and "label" in data:
                raise ValueError(f"API error: {data}")
            return data
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles(contract, interval, start, end, path):
    bars = []
    cur = start
    while cur < end:
        nxt = min(cur + timedelta(days=7), end)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval={interval}"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get_json(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"])})
        cur = nxt
        time.sleep(0.2)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    bars = [b for b in bars if int(start.timestamp()) <= b["t"] < int(end.timestamp())]
    with open(path, "w") as f:
        json.dump(bars, f)
    print(f"[{contract}] {interval} 已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}", flush=True)
    return bars


def check_continuity(bars, interval_sec, label):
    """连续性：最大间隔、缺根数。返回 (ok, msg)。"""
    if len(bars) < 2:
        return False, f"{label} 只有 {len(bars)} 根"
    gaps = [bars[i + 1]["t"] - bars[i]["t"] for i in range(len(bars) - 1)]
    mx = max(gaps)
    missing = sum(g - interval_sec for g in gaps if g > interval_sec) // interval_sec
    ok = mx <= interval_sec * 2 and missing <= 5
    return ok, (f"{label} {len(bars)} 根，最大间隔 {mx // 60} 分钟，"
                f"缺约 {missing} 根，{'通过' if ok else '不通过'}")


def main():
    results = {}
    for sym in CANDIDATES:
        p1h = os.path.join(HERE, f"train3_{sym}_1h.json")
        if os.path.exists(p1h):
            bars = json.load(open(p1h))
            print(f"[{sym}] 1h 用缓存（{len(bars)} 根）", flush=True)
        else:
            bars = fetch_candles(f"{sym}_USDT", "1h", START, END, p1h)
        ok, msg = check_continuity(bars, 3600, f"{sym} 1h")
        print("  " + msg, flush=True)
        results[sym] = ok
    print("连续性结果：", results, flush=True)
    passed = [s for s in CANDIDATES if results[s]]
    print("通过 1h 连续性的币（按成交额排序）：", passed, flush=True)
    print("最终 8 币：", passed[:8], flush=True)
    # 只给最终 8 币取 15m
    for sym in passed[:8]:
        p15 = os.path.join(HERE, f"train3_{sym}_15m.json")
        if os.path.exists(p15):
            bars = json.load(open(p15))
            print(f"[{sym}] 15m 用缓存（{len(bars)} 根）", flush=True)
        else:
            fetch_candles(f"{sym}_USDT", "15m", START, END, p15)
    print("取数完成。")


if __name__ == "__main__":
    main()
