#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第一期——替换 Q19（校验发现其 SL 与探针高点在 4 位小数显示下相等，
缓冲不可见，参考答案自相矛盾）。从 YES 池另取一道方向一致性题（NO6），
要求：币种计数 <3、同一币同一天不重复、SL 与探针极值在指数单位下差距 >=0.001。
其余 19 道不动；替换后按（币种，时间）重排并重编 Q01–Q20。
"""
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGE_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/开发-主观判断")
sys.path.insert(0, JUDGE_DIR)
sys.path.insert(0, HERE)
import judge_read  # noqa: E402
from select_questions import build_anchors, load_bars, swing_points, outcome_bars, idx_scale  # noqa: E402


def main():
    data = json.load(open(os.path.join(HERE, "第一期-20题.json")))
    qs = data["questions"]
    scan = json.load(open(os.path.join(HERE, "scan_results.json")))
    bars_cache = {}
    for coin in ["ANT", "IRYS", "DRAM", "BZ", "BCH", "PUMP", "APT", "ICP"]:
        bars_cache[coin] = (load_bars(coin, "15m"), load_bars(coin, "1h"))

    keep = [q for q in qs if q["id"] != "Q19"]
    used_T = {(q["coin"], q["T"]) for q in keep}
    coin_count = defaultdict(int)
    used_day = set()
    for q in keep:
        coin_count[q["coin"]] += 1
        used_day.add((q["coin"], datetime.fromtimestamp(q["T"], timezone.utc).date()))

    # NO6 候选：清单全通过（decision=write）的 YES 池
    cands = [r for r in scan if r["decision"] == "write"
             and (r["coin"], r["T"]) not in used_T
             and coin_count[r["coin"]] < 3]
    cands.sort(key=lambda r: (r["coin"], r["T"]))
    chosen = None
    for r in cands:
        coin, T, d = r["coin"], r["T"], r["direction"]
        day = datetime.fromtimestamp(T, timezone.utc).date()
        if (coin, day) in used_day:
            continue
        bars15, bars1h = bars_cache[coin]
        b15 = [b for b in bars15 if b["t"] <= T]
        b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
        a = build_anchors(coin, d, T, b15, b1h, r)
        if a is None:
            continue
        # 可见性：SL 与探针极值在指数单位下差距 >=0.001
        stem1h = b1h[-24:]
        base = stem1h[0]["c"]
        probe_ext = r["probe"]["h"] if d == -1 else r["probe"]["l"]
        gap = abs(a["sl"] - probe_ext) / base * 100.0
        if gap < 0.001:
            continue
        chosen = (r, a, b15, b1h)
        break
    if chosen is None:
        print("没有可用的 NO6 替补候选，算不出")
        return 1
    r, a, b15, b1h = chosen
    coin, T, d = r["coin"], r["T"], r["direction"]
    bias = 1 if d == -1 else -1
    stem1h = b1h[-24:]
    stem15 = b15[-16:]
    ans15 = [b for b in bars_cache[coin][0] if T < b["t"] <= T + 8 * 900]
    assert len(stem1h) == 24 and len(stem15) == 16 and len(ans15) == 8
    to_idx = idx_scale(stem1h)
    ref = r["confirm"]["c"]
    tests_list, _sp = judge_read.level_tests(b15, r["level"],
                                             __import__("judge_precheck").atr_wilder(b15)[-1],
                                             d, T)
    tests_idx = []
    for t in tests_list:
        mins = (T - t["t"]) // 60
        tests_idx.append({"rel": f"T-{mins // 60}h{mins % 60:02d}m",
                          "extreme": to_idx(t["extreme"])})
    struct_ok, struct_txt = judge_read.structure_1h(b1h, d, r["atr1h"])
    pd_pct, pd_txt = judge_read.premium_discount(b1h)
    fvgs = judge_read.fvg_edges(b1h)
    hi, lo = swing_points(b1h)
    # 参考锚位文本（指数单位，与题干一致）
    sl_txt = (f"探针{'高' if d == -1 else '低'}点 {to_idx(a['sl_extreme'])} 之外 "
              f"{'+' if d == -1 else '−'}0.1xATR15")
    if a["capped"]:
        tp_txt = f"按 3 倍封顶（最近结构目标 {to_idx(a['tp_target'])} 在 3 倍之外）"
    else:
        tp_txt = f"{a['tp_kind']} {to_idx(a['tp_target'])}"
    oc = outcome_bars(ans15, d, ref, a["sl"], a["tp"])
    q = {
        "id": "Q19",
        "coin": coin, "T": T, "direction": d,
        "kind": "NO6", "morning_bias": bias,
        "stem_1h": [{"label": f"H-{24 - i}", "o": to_idx(b["o"]), "h": to_idx(b["h"]),
                     "l": to_idx(b["l"]), "c": to_idx(b["c"])} for i, b in enumerate(stem1h)],
        "stem_15m": [{"label": f"M-{16 - i}", "o": to_idx(b["o"]), "h": to_idx(b["h"]),
                      "l": to_idx(b["l"]), "c": to_idx(b["c"])} for i, b in enumerate(stem15)],
        "atr1h_idx": round(r["atr1h"] / stem1h[0]["c"] * 100.0, 4),
        "atr15_idx": round(__import__("judge_precheck").atr_wilder(b15)[-1] / stem1h[0]["c"] * 100.0, 4),
        "level_idx": to_idx(r["level"]),
        "test_count": len(tests_idx),
        "tests_idx": tests_idx,
        "probe_idx": {"o": to_idx(r["probe"]["o"]), "h": to_idx(r["probe"]["h"]),
                      "l": to_idx(r["probe"]["l"]), "c": to_idx(r["probe"]["c"]),
                      "wick_x": r["probe"]["wick_x"]},
        "confirm_idx": {"o": to_idx(r["confirm"]["o"]), "h": to_idx(r["confirm"]["h"]),
                        "l": to_idx(r["confirm"]["l"]), "c": to_idx(r["confirm"]["c"]),
                        "move_x": r["confirm"]["move_x"]},
        "structure_txt": struct_txt,
        "pd_pct": None if pd_pct is None else round(pd_pct, 1),
        "pd_txt": pd_txt,
        "fvg_idx": [{"kind": f["kind"], "lo": to_idx(f["lo"]), "hi": to_idx(f["hi"])}
                    for f in fvgs[-6:]],
        "swing_high_idx": [to_idx(x) for x in hi[-4:]],
        "swing_low_idx": [to_idx(x) for x in lo[-4:]],
        "ref_idx": to_idx(ref),
        "setup": False, "ref_direction": d,
        "fail_items": [6],
        "fail_reason": ("第 6 项方向一致性不通过：题干早上计划偏向为"
                        f"{'做多' if bias == 1 else '做空'}，与判断方向"
                        f"{'做空' if d == -1 else '做多'}相反；其余 5 项全部通过。"),
        "anchors": {"sl": to_idx(a["sl"]), "tp": to_idx(a["tp"]),
                    "rr": round(a["rr"], 2), "capped": a["capped"],
                    "sl_anchor_txt": sl_txt, "tp_txt": tp_txt,
                    "sl_levels": [to_idx(x) for x in a["sl_levels"]],
                    "tp_levels": [to_idx(x) for x in a["tp_levels"]]},
        "answer_15m": [{"label": f"M+{i + 1}", "o": to_idx(b["o"]), "h": to_idx(b["h"]),
                        "l": to_idx(b["l"]), "c": to_idx(b["c"])} for i, b in enumerate(ans15)],
        "outcome": oc,
        "checks_txt": {k: v["txt"] for k, v in r["checks"].items()},
    }
    all_q = keep + [q]
    all_q.sort(key=lambda x: (x["coin"], x["T"]))
    for i, qq in enumerate(all_q, start=1):
        qq["id"] = f"Q{i:02d}"
    with open(os.path.join(HERE, "第一期-20题.json"), "w") as f:
        json.dump({"coins": data["coins"], "questions": all_q}, f, ensure_ascii=False, indent=1)
    print(f"已替换 Q19：新题 {coin} 方向={'空' if d == -1 else '多'} "
          f"SL-探针差距 {gap:.4f} 指数单位，outcome={oc['hit']}")
    for qq in all_q:
        print(f"  {qq['id']} {qq['kind']:4s} 方向={'空' if qq['direction'] == -1 else '多'} "
              f"setup={'有' if qq['setup'] else '无'} fail={qq['fail_items']}")


if __name__ == "__main__":
    raise SystemExit(main())
