#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第一期——给题库 JSON 补一个无原始价的参考事实块 ref_facts
（供跑题脚本与题库 md 渲染用，跑题时不再碰原始价数据）：
  probe_ok / confirm_ok（拒绝成立的两半）、played_out / failed_break（事前检查）、
  played_dist_x_atr1h（位子到确认收盘，xATR1h）、test_span_bars（首末测试跨度，根）、
  test_recent_bars（最近测试距探针，根）、struct_dmax_x / struct_dmin_x
  （1h 结构最近 6h 与之前 6h 的最高收/最低收之差，xATR1h）。
全部用 brief() 重算（只喂 T 及之前的数据），不引入未来数据。
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGE_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/开发-主观判断")
sys.path.insert(0, JUDGE_DIR)
import judge_read  # noqa: E402


def load_bars(sym, interval):
    with open(os.path.join(HERE, f"train1_{sym}_{interval}.json")) as f:
        return json.load(f)


def main():
    path = os.path.join(HERE, "第一期-20题.json")
    data = json.load(open(path))
    bars_cache = {}
    for q in data["questions"]:
        coin, T, d = q["coin"], q["T"], q["direction"]
        if coin not in bars_cache:
            bars_cache[coin] = (load_bars(coin, "15m"), load_bars(coin, "1h"))
        bars15, bars1h = bars_cache[coin]
        b15 = [b for b in bars15 if b["t"] <= T]
        b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
        b = judge_read.brief(coin, d, T, b15, b1h, plan_path=None)
        assert "error" not in b, (q["id"], b)
        # 测试跨度与新鲜度（根数）
        ts = [t["t"] for t in b["tests"]]
        span = (max(ts) - min(ts)) // 900 if len(ts) >= 2 else 0
        recent = (b["probe"]["t"] - max(ts)) // 900 if ts else None
        # 结构差值（xATR1h）
        closes = [x["c"] for x in b1h[-12:]] if len(b1h) >= 12 else []
        # brief 内部用的 bars1h_closed：与 b1h 一致（已截断）
        b1h_closed = [x for x in bars1h if x["t"] + 3600 <= T + 900]
        cl = [x["c"] for x in b1h_closed]
        atr1h = b["atr1h"]
        if len(cl) >= 12 and atr1h:
            dmax = (max(cl[-6:]) - max(cl[-12:-6])) / atr1h
            dmin = (min(cl[-6:]) - min(cl[-12:-6])) / atr1h
        else:
            dmax = dmin = None
        played_dist = ((b["level"] - b["confirm"]["c"]) / atr1h if d == -1
                       else (b["confirm"]["c"] - b["level"]) / atr1h)
        q["ref_facts"] = {
            "probe_ok": b["probe_ok"],
            "confirm_ok": b["confirm_ok"],
            "played_out": b["played_out"],
            "played_dist_x_atr1h": round(played_dist, 2),
            "failed_break": b["failed_break"],
            "test_span_bars": span,
            "test_recent_bars": recent,
            "struct_dmax_x": None if dmax is None else round(dmax, 2),
            "struct_dmin_x": None if dmin is None else round(dmin, 2),
        }
        print(f"{q['id']} ref_facts 已补", flush=True)
    with open(path, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    print("已写回 第一期-20题.json")


if __name__ == "__main__":
    main()
