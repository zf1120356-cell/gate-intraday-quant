#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只打印题干（不含答案、币种名、时间戳），做题时用。
用法：python3 print_stem2.py 1 2 3   # 打印 Q01 Q02 Q03 的题干"""
import sys
sys.path.insert(0, "/home/hatch/workspace/赚钱路子/纸面交易/读盘训练")
from train_common3 import load_questions, render_stem

qs = load_questions()
for arg in sys.argv[1:]:
    i = int(arg) - 1
    print(render_stem(qs[i]))
    print()
