#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第一期——公共 helper（跑题脚本与题库 md 共用）。
只读 第一期-20题.json，不碰原始价数据、不碰币种名与时间戳。
价格一律是指数单位（题干首根 1h 收盘 = 100）。
打分只判判断本身（setup 有无、方向、锚位是否合理），按 6 项清单记错在哪；
不汇总收益率、不做任何规则验证。
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(HERE, "第一期-20题.json")

ITEM_NAME = {1: "结构对齐", 2: "位子合格", 3: "拒绝成立",
             4: "事前检查", 5: "强度足够", 6: "方向一致性"}
ITEM_ORDER = [1, 2, 3, 4, 5, 6]


def load_questions():
    with open(DATA_PATH) as f:
        return json.load(f)["questions"]


def fmt(x, nd=4):
    return f"{x:.{nd}f}"


# ---------------------------------------------------------------- 题干渲染
def render_stem(q):
    L = []
    L.append(f"=== {q['id']} / 20 ===")
    bias = q["morning_bias"]
    bias_txt = "无偏向" if bias is None else ("做空" if bias == -1 else "做多")
    L.append(f"早上计划偏向：{bias_txt}")
    L.append("")
    L.append("--- 1h（24 根，H-24 … H-1；指数：首根收盘 = 100）---")
    L.append("  根     开        高        低        收")
    for b in q["stem_1h"]:
        L.append(f"  {b['label']:>5}  {fmt(b['o']):>9}  {fmt(b['h']):>9}  "
                 f"{fmt(b['l']):>9}  {fmt(b['c']):>9}")
    L.append("")
    L.append("--- 15m（16 根，M-16 … M-1；M-1 为确认根，M-2 为探针根）---")
    L.append("  根     开        高        低        收")
    for b in q["stem_15m"]:
        L.append(f"  {b['label']:>5}  {fmt(b['o']):>9}  {fmt(b['h']):>9}  "
                 f"{fmt(b['l']):>9}  {fmt(b['c']):>9}")
    L.append("")
    L.append("--- 结构事实（只给事实，不给结论）---")
    L.append(f"ATR1h：{fmt(q['atr1h_idx'])}；ATR15：{fmt(q['atr15_idx'])}（指数单位）")
    # 1h 结构：最近 6 根与之前 6 根的最高收/最低收（指数单位，只给数）
    closes = [b["c"] for b in q["stem_1h"]]
    dmax = max(closes[-6:]) - max(closes[-12:-6])
    dmin = min(closes[-6:]) - min(closes[-12:-6])
    thr = 0.5 * q["atr1h_idx"]
    L.append(f"1h 结构：最近 6 根最高收 {fmt(max(closes[-6:]))}（之前 6 根 "
             f"{fmt(max(closes[-12:-6]))}，{dmax:+.4f}），最低收 "
             f"{fmt(min(closes[-6:]))}（之前 6 根 {fmt(min(closes[-12:-6]))}，"
             f"{dmin:+.4f}）；0.5×ATR1h = {fmt(thr)}。"
             f"做空只在两者都上移超 {fmt(thr)} 时不对齐，做多只在两者都下移超 {fmt(thr)} 时不对齐。")
    # P/D
    w20 = q["stem_1h"][-20:]
    hi20 = max(b["h"] for b in w20)
    lo20 = min(b["l"] for b in w20)
    cur = q["stem_1h"][-1]["c"]
    pd = q["pd_pct"]
    L.append(f"P/D：最近 20 根 1h 区间 [{fmt(lo20)}, {fmt(hi20)}]，现价 "
             f"{fmt(cur)}，P/D {pd}%。做空顺立场 >50%，做多顺立场 <50%（称重项，不是硬门槛）。")
    # 双向位子簇
    for name, label in (("top", "高点簇（做空参考位）"), ("bottom", "低点簇（做多参考位）")):
        cl = q["clusters"][name]
        if cl is None:
            L.append(f"{label}：最近 24 根内无成对测试的位子。")
        else:
            tests = "、".join(f"{t['rel']}极值 {fmt(t['extreme'])}" for t in cl["tests"])
            L.append(f"{label}：{fmt(cl['level'])}，测试 {len(cl['tests'])} 次"
                     f"（{tests}）；成对测试在 {cl['pair'][0]} 与 {cl['pair'][1]}。")
    # FVG 边
    if q["fvg_idx"]:
        fvg_txt = "、".join(
            f"{'看涨' if f['kind'] == 'bull' else '看跌'} [{fmt(f['lo'])}, {fmt(f['hi'])}]"
            for f in q["fvg_idx"])
        L.append(f"未填补 FVG 边（最近 6 条）：{fvg_txt}")
    else:
        L.append("未填补 FVG 边：无。")
    L.append(f"最近摆动高点：{', '.join(fmt(x) for x in q['swing_high_idx'])}；"
             f"最近摆动低点：{', '.join(fmt(x) for x in q['swing_low_idx'])}。")
    # 最后两根 15m 的影线与涨跌幅（方向中立，只给数）
    atr15 = q["atr15_idx"]
    p = q["probe_idx"]
    c = q["confirm_idx"]
    L.append(f"M-2（探针根）：上影 {fmt((p['h'] - p['c']) / atr15, 2)}×ATR15，"
             f"下影 {fmt((p['c'] - p['l']) / atr15, 2)}×ATR15。")
    L.append(f"M-1（确认根）：涨/跌幅 {fmt((c['c'] - c['o']) / atr15, 2)}×ATR15"
             f"（收盘相对开盘），上影 {fmt((c['h'] - c['c']) / atr15, 2)}×，"
             f"下影 {fmt((c['c'] - c['l']) / atr15, 2)}×。")
    L.append("")
    L.append("三问：")
    L.append("(1) 现在有没有 setup？（按 6 项清单：结构对齐、位子合格、拒绝成立、"
             "事前检查、强度足够、方向一致性）")
    L.append("(2) 方向？做空 / 做多")
    L.append("(3) 止损锚哪、止盈锚哪？（止损锚结构位之外、止盈锚下一个结构目标，"
             "盈亏比须在 1:1.5–3；给指数价位）")
    return "\n".join(L)


# ---------------------------------------------------------------- 答案渲染
def render_answer(q):
    L = []
    L.append(f"--- {q['id']} 答案 ---")
    d = q["direction"]
    d_txt = "做空" if d == -1 else "做多"
    rf = q["ref_facts"]
    if q["setup"]:
        L.append(f"参考结论：有 setup，方向 {d_txt}。")
    else:
        L.append(f"参考结论：无 setup（考虑方向 {d_txt}；反方向也验证过，同样无 setup）。")
        if q["fail_items"]:
            L.append("不通过项：" + "、".join(
                f"{i} {ITEM_NAME[i]}" for i in q["fail_items"]) + "。")
    # 逐项事实（指数单位）
    L.append(f"[1 结构] 最近 6h 与之前 6h：最高收差 {rf['struct_dmax_x']}×ATR1h，"
             f"最低收差 {rf['struct_dmin_x']}×ATR1h。"
             f"{'明确反向趋势，不对齐' if (d == -1 and rf['struct_dmax_x'] is not None and rf['struct_dmax_x'] > 0.5 and rf['struct_dmin_x'] > 0.5) or (d == 1 and rf['struct_dmax_x'] is not None and rf['struct_dmax_x'] < -0.5 and rf['struct_dmin_x'] < -0.5) else '非明确反向趋势，对齐'}。")
    fvg_near = [f for f in q["fvg_idx"]
                if abs(f["lo"] - q["level_idx"]) <= 0.5 * q["atr1h_idx"]
                or abs(f["hi"] - q["level_idx"]) <= 0.5 * q["atr1h_idx"]]
    L.append(f"[2 位子] 参考位 {fmt(q['level_idx'])}，测试 {q['test_count']} 次"
             f"（首末跨度 {rf['test_span_bars']} 根，最近测试距探针 "
             f"{rf['test_recent_bars']} 根）；附近 FVG 边 {len(fvg_near)} 条。")
    L.append(f"[3 拒绝] 探针探出后收回：{'是' if rf['probe_ok'] else '否'}；"
             f"确认收盘在探针收盘顺势一侧：{'是' if rf['confirm_ok'] else '否'}；"
             f"探针影 {q['probe_idx']['wick_x']}×ATR15，确认涨/跌幅 "
             f"{q['confirm_idx']['move_x']}×ATR15。")
    L.append(f"[4 事前] setup 已走完：{'是' if rf['played_out'] else '否'}"
             f"（位子到确认收盘 {rf['played_dist_x_atr1h']}×ATR1h，≥2×为走完）；"
             f"破位失败：{'是' if rf['failed_break'] else '否'}。")
    L.append(f"[5 强度] 确认涨/跌幅 {q['confirm_idx']['move_x']}×ATR15"
             f"（先决 ≥0.5×）；探针影 {q['probe_idx']['wick_x']}×；"
             f"位子测试 {q['test_count']} 次。")
    bias = q["morning_bias"]
    bias_txt = "无偏向" if bias is None else ("做空" if bias == -1 else "做多")
    L.append(f"[6 方向] 早上计划偏向：{bias_txt}；判断方向 {d_txt}。"
             f"{'一致，通过' if bias is None or bias == d else '相反，不通过'}。")
    pd = q["pd_pct"]
    pd_side = "顺立场" if ((d == -1 and pd is not None and pd > 50)
                           or (d == 1 and pd is not None and pd < 50)) else "逆立场"
    L.append(f"[P/D 称重] P/D {pd}%（{pd_side}，不是硬门槛）。")
    # 参考锚位
    if q["anchors"] is not None and q["setup"]:
        a = q["anchors"]
        L.append(f"参考锚位：入场参考价 {fmt(q['ref_idx'])}（确认根收盘）；"
                 f"止损 {fmt(a['sl'])}（{a['sl_anchor_txt']}）；"
                 f"止盈 {fmt(a['tp'])}（{a['tp_txt']}）；盈亏比 {a['rr']:.2f}。")
    elif q["anchors"] is not None and not q["setup"]:
        # NO6：1–5 项全过、只因偏向相反而不做；锚位本身成立，但不是参考锚位
        a = q["anchors"]
        oc = q["outcome"]
        L.append(f"注：第 6 项之外的 1–5 项全部通过；若偏向不冲突，这会是一道 YES 题，"
                 f"锚位本会是：止损 {fmt(a['sl'])}（{a['sl_anchor_txt']}），"
                 f"止盈 {fmt(a['tp'])}（{a['tp_txt']}），盈亏比 {a['rr']:.2f}。"
                 f"但第 6 项不通过，参考结论仍是无 setup，不做。")
        L.append(f"若按此锚位跑答案窗口：先到{oc['hit']}；最大有利 {oc['max_fav_R']}R，"
                 f"最大不利 {oc['max_adv_R']}R（仅供复盘参考，不计分）。")
    else:
        L.append("参考锚位：无（无 setup，不锚）。")
    # 答案 8 根
    L.append("")
    L.append("--- 随后 8 根 15m（M+1 … M+8）---")
    L.append("  根     开        高        低        收")
    for b in q["answer_15m"]:
        L.append(f"  {b['label']:>5}  {fmt(b['o']):>9}  {fmt(b['h']):>9}  "
                 f"{fmt(b['l']):>9}  {fmt(b['c']):>9}")
    if q["setup"] and q["anchors"] is not None:
        oc = q["outcome"]
        L.append(f"参考锚位结果：先到{oc['hit']}；最大有利 {oc['max_fav_R']}R，"
                 f"最大不利 {oc['max_adv_R']}R（以止损距离为 1R；触发根只计触发侧，"
                 f"根内先后顺序未知）。")
    else:
        # 无锚位：只给随后 8 根的顺势/逆势最大幅度（复盘参考，不计分）
        atr15 = q["atr15_idx"]
        ref = q["ref_idx"]
        fav = adv = 0.0
        for b in q["answer_15m"]:
            if d == -1:
                fav = max(fav, (ref - b["l"]) / atr15)
                adv = max(adv, (b["h"] - ref) / atr15)
            else:
                fav = max(fav, (b["h"] - ref) / atr15)
                adv = max(adv, (ref - b["l"]) / atr15)
        L.append(f"随后 8 根：顺势最大 {fav:.2f}×ATR15，逆势最大 {adv:.2f}×ATR15"
                 f"（仅供复盘参考，不计分）。")
    return "\n".join(L)


# ---------------------------------------------------------------- 结果模拟
def outcome_with_anchors(ans_bars, d, ref, sl, tp):
    """用给定锚位跑答案窗口：先到 SL 还是 TP；最大有利/不利（以止损距离为 1R）。
    口径与题库一致：触发根只计触发侧。"""
    sld = abs(sl - ref)
    if sld <= 0:
        return {"hit": "算不出", "max_fav_R": 0.0, "max_adv_R": 0.0}
    max_fav = 0.0
    max_adv = 0.0
    hit = None
    for b in ans_bars:
        if d == -1:
            fav = (ref - b["l"]) / sld
            adv = (b["h"] - ref) / sld
            if b["h"] >= sl:
                hit = "SL"; max_adv = max(max_adv, adv); break
            if b["l"] <= tp:
                hit = "TP"; max_fav = max(max_fav, fav); break
        else:
            fav = (b["h"] - ref) / sld
            adv = (ref - b["l"]) / sld
            if b["l"] <= sl:
                hit = "SL"; max_adv = max(max_adv, adv); break
            if b["h"] >= tp:
                hit = "TP"; max_fav = max(max_fav, fav); break
        max_fav = max(max_fav, fav)
        max_adv = max(max_adv, adv)
    return {"hit": hit or "均未触及", "max_fav_R": round(max_fav, 2),
            "max_adv_R": round(max_adv, 2)}


# ---------------------------------------------------------------- 打分
def score(q, ans):
    """ans = {"setup": bool, "direction": -1/1/None,
              "sl": float|None, "tp": float|None, "fail_items": [int]}。
    返回打分 dict。error_items 里是 1–6 的项号，或 "方向"/"锚位"/"未指明"。"""
    notes = []
    error_items = []
    ref_setup = q["setup"]
    ref_dir = q["ref_direction"]
    considered = q["direction"]
    out = {"setup_ok": None, "direction_ok": None, "attribution_ok": None,
           "sl_ok": None, "tp_ok": None, "rr_ok": None,
           "error_items": error_items, "notes": notes}
    out["setup_ok"] = bool(ans["setup"] == ref_setup)
    if ans["setup"] and ref_setup:
        if ans["direction"] == ref_dir:
            out["direction_ok"] = True
            ref = q["ref_idx"]
            atr15 = q["atr15_idx"]
            sl_t, tp_t = ans.get("sl"), ans.get("tp")
            if sl_t is None or tp_t is None:
                out["sl_ok"] = out["tp_ok"] = out["rr_ok"] = False
                error_items.append("锚位")
                notes.append("未给出止损/止盈锚位")
            else:
                d = ref_dir
                sld_t = abs(sl_t - ref)
                sl_side_ok = (sl_t > ref) if d == -1 else (sl_t < ref)
                sl_levels = q["anchors"]["sl_levels"]
                sl_struct_ok = (sl_t >= min(sl_levels)) if d == -1 else (sl_t <= max(sl_levels))
                out["sl_ok"] = bool(sl_side_ok and sl_struct_ok)
                if not sl_side_ok:
                    notes.append("止损放在了错误一侧")
                elif not sl_struct_ok:
                    notes.append("止损未放在结构位之外（未越过最近结构位）")
                tp_levels = q["anchors"]["tp_levels"]
                tol = 0.25 * atr15
                tp_near = any(abs(tp_t - t) <= tol for t in tp_levels)
                cap = ref - 3.0 * sld_t if d == -1 else ref + 3.0 * sld_t
                tp_cap = abs(tp_t - cap) <= tol
                out["tp_ok"] = bool(tp_near or tp_cap)
                if not out["tp_ok"]:
                    notes.append("止盈未锚在结构目标（不在任一结构目标 ±0.25×ATR15 内，也不在 3 倍封顶处）")
                if sld_t <= 0:
                    out["rr_ok"] = False
                    notes.append("止损距离为 0，盈亏比算不出")
                else:
                    rr_t = abs(tp_t - ref) / sld_t
                    out["rr_ok"] = bool(1.45 <= rr_t <= 3.05)
                    if not out["rr_ok"]:
                        notes.append(f"盈亏比 {rr_t:.2f} 不在 1.5–3")
                if not (out["sl_ok"] and out["tp_ok"] and out["rr_ok"]):
                    error_items.append("锚位")
        else:
            out["direction_ok"] = False
            error_items.append("方向")
            notes.append("方向判反了")
    elif ans["setup"] and not ref_setup:
        # 误判为 setup
        if ans["direction"] == considered:
            error_items.extend(q["fail_items"])
            notes.append("误判为 setup，漏掉了不通过项："
                         + "、".join(f"{i} {ITEM_NAME[i]}" for i in q["fail_items"]))
        else:
            error_items.append("方向")
            notes.append("反方向也没有 setup（已验证），方向与 setup 都错了")
    elif (not ans["setup"]) and ref_setup:
        # 误判为无 setup
        named = ans.get("fail_items") or []
        if named:
            error_items.extend(named)
            notes.append("误判为无 setup：错在把以下项当成了不通过："
                         + "、".join(f"{i} {ITEM_NAME[i]}" for i in named))
        else:
            error_items.append("未指明")
            notes.append("误判为无 setup，且未指明哪项不通过")
    else:
        # 双方都判无 setup：比对归因
        ref_fails = set(q["fail_items"])
        named = set(ans.get("fail_items") or [])
        if named == ref_fails:
            out["attribution_ok"] = True
        else:
            out["attribution_ok"] = False
            wrong_named = sorted(named - ref_fails)
            if wrong_named:
                error_items.extend(wrong_named)
                notes.append("归因错误：以下项实际通过，却被当成不通过："
                             + "、".join(f"{i} {ITEM_NAME[i]}" for i in wrong_named))
            missed = sorted(ref_fails - named)
            if missed:
                notes.append("漏掉的不通过项："
                             + "、".join(f"{i} {ITEM_NAME[i]}" for i in missed))
    return out
