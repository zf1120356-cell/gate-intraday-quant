#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘中主观判断——完整主观读盘（judge_read.py）
====================================================
归属：主系统主观层（盘中主观判断 v1，见《纸面交易/盘中主观判断-设计.md》）。
只读数据；写触发时只调 supp_observer.append_supp_trigger（与机械层同一
函数、同一小节格式），不改引擎、不碰分系统、不改计划原文。

用法（定时任务里的判断者按此流程）：
  1. 预检（judge_precheck.py）给出候选后，对每个候选调 brief()：
     python3 judge_read.py brief --coin ETH --direction -1 \
         --confirm-t <确认根UTC秒> --data-dir <数据目录> [--plan-file <当日计划>]
     输出 JSON 简报（结构、P/D、FVG/OB、位子测试史、拒绝、事前检查）。
  2. decide(brief) 按设计第六节清单给结论（write / no）与理由。
     判断者可凭盘面整体推翻结论，但必须在日志里写明推翻的理由。
  3. 结论为 write 时，调 write_trigger() 写进当日计划文件
     “盘中补充触发”小节（幂等、带锁、写前校验该币当日无已有触发、
     早上计划未成交）。触发字段与机械层同形，引擎已支持解析。

设计第六节清单（必须全部通过才算真 setup）：
  1 结构对齐：1h 结构与方向一致。
  2 位子合格：反复测试的位子（>=2 次、相隔 >=4 根即 1h、最近测试距探针
     <=24 根即 6h）或清晰的 FVG/OB 边。
  3 拒绝成立：探针根探出参考位后收回区内，且确认根收盘在探针根收盘的
     顺势一侧。
  4 事前检查通过：setup 没走完（参考位到确认收盘 <2xATR1h）、止盈没到、
     不是破位失败。
  5 强度足够：确认涨/跌幅 >=1.0xATR15，或探针影 >=1.0xATR15，或
     （位子测试 >=3 次且（探针影 >=0.5x 或确认涨/跌幅 >=0.5x））。
P/D 立场是称重项，不是硬门槛（顺立场信心更高；逆立场只要上面 5 项全
通过、拒绝够决定性，仍可写，并在理由里写明“逆立场”）。
"""
import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from judge_precheck import atr_wilder, _norm, load_file_15m  # noqa: E402

# 复用机械层同一写入函数与小节格式（引擎已支持解析，不改引擎）
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "开发-补充触发"))
try:
    import supp_observer
    SUPP_OK = True
except ImportError:
    supp_observer = None
    SUPP_OK = False

COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]
ENGINE_DIR = os.path.expanduser(
    "~/workspace/goals/gate-intraday-perpetual-quant-strategy/hidden_files")
LOCK_PATH = os.path.join(ENGINE_DIR, "paper_engine.lock")
STATE_PATH = os.path.join(ENGINE_DIR, "paper_engine_state.json")
PLAN_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易")

ATR_PERIOD = 14
CLUSTER_TOL = 0.5       # 位子簇内极值相差上限（xATR15）
CLUSTER_GAP_MIN = 4     # 位子测试相隔下限（根数，1h）
CLUSTER_RECENCY = 24    # 最近测试距探针上限（根数，6h）
LEVEL_WINDOW = 24       # 位子测试史只看最近 24 根（6h）
STRUCT_WINDOW_1H = 24   # 结构只看最近 24 根 1h
PD_WINDOW_1H = 20       # P/D 用最近 20 根已收盘 1h
STRENGTH_MAIN = 1.0     # 强度主线：确认涨/跌幅或探针影 >=1.0xATR15
STRENGTH_WEAK = 0.5     # 位子 >=3 次时的放宽线


def fmt_ts(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")


def fmt_bj(t):
    """UTC 秒 → 北京时间 HH:MM。"""
    return datetime.fromtimestamp(t, tz=timezone.utc).astimezone(
        timezone(__import__("datetime").timedelta(hours=8))).strftime("%H:%M")


def fetch_gate_1h(contract, limit=200):
    """curl 拉 Gate 1h（与引擎同款，避开 urllib 截断）。返回 _norm 后的 bars。"""
    url = (f"https://api.gateio.ws/api/v4/futures/usdt/candlesticks"
           f"?contract={contract}&interval=1h&limit={limit}")
    cp = subprocess.run(["curl", "-sS", "-m", "25", "-w", "\n%{http_code}", url],
                        capture_output=True, text=True)
    out, code = cp.stdout.rsplit("\n", 1)
    if cp.returncode != 0 or code != "200":
        raise RuntimeError(f"Gate {contract} 1h 拉取失败 curl={cp.returncode} http={code}")
    return _norm(json.loads(out))


def load_file_1h(data_dir, coin):
    """从数据文件读 1h。优先 {coin}_1h_full.json，其次 {coin}_1h.json。"""
    for name in (f"{coin}_1h_full.json", f"{coin}_1h.json",
                 f"nov20_1h_fresh_{coin}_USDT.json", f"nov17_1h_{coin}_USDT.json"):
        p = os.path.join(data_dir, name)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            bars = d if isinstance(d, list) else d.get("bars", d)
            return _norm(bars)
    return []


def plan_directions(plan_path):
    """从当日计划文件读每个币早上计划的方向偏向。
    解析 `## COIN — 偏向：做空/做多`（含“观望（做空…）/观望（做多…）”
    这种带方向的观望）；纯观望（无计划）返回 None（无方向约束）。
    返回 {coin: +1/-1/None}。读不到文件或无该币小节时该币为 None。"""
    out = {}
    try:
        text = open(plan_path, encoding="utf-8").read()
    except Exception:
        return out
    import re
    for m in re.finditer(r"^##\s*(BTC|ETH|SOL|DOGE|LINK|XRP|BNB|ADA)\s*—\s*偏向：([^\n]*)",
                         text, flags=re.M):
        coin, bias = m.group(1), m.group(2)
        if "做空" in bias:
            out[coin] = -1
        elif "做多" in bias:
            out[coin] = +1
        else:
            out[coin] = None
    return out


def get_atr1h(plan_path, coin, bars1h):
    """ATR1h：优先解析当天早上计划的 1h ATR 表；解析不到则用最近 14 根
    已收盘 1h 的 Wilder ATR。返回 (atr, source)。"""
    if plan_path and os.path.exists(plan_path):
        try:
            with open(plan_path, encoding="utf-8") as f:
                text = f.read()
            m = re.search(r"ATR（1h，14 周期[^：]*：([^。\n]*)", text)
            if m:
                for part in m.group(1).split("、"):
                    mm = re.match(r"\s*([A-Z]+)\s+([\d.]+)", part.strip())
                    if mm and mm.group(1) == coin:
                        return float(mm.group(2)), "plan"
        except (OSError, ValueError):
            pass
    atrs = atr_wilder(bars1h)
    a = atrs[-1] if atrs else None
    return (a, "live1h") if a else (None, "none")


def fvg_edges(bars1h):
    """三根 K 线法找 FVG（未填补的才算）。返回 [{kind, lo, hi, t}]。
    看涨 FVG：前根低 > 后根高，缺口 [后根高, 前根低]；
    看跌 FVG：前根高 < 后根低，缺口 [前根高, 后根低]。
    只保留最近 48 根 1h 里的、且之后没有一根 1h 收盘穿过缺口的。"""
    out = []
    n = len(bars1h)
    for i in range(1, n - 1):
        a, b, c = bars1h[i - 1], bars1h[i], bars1h[i + 1]
        if a["l"] > c["h"]:
            lo, hi, kind = c["h"], a["l"], "bull"
        elif a["h"] < c["l"]:
            lo, hi, kind = a["h"], c["l"], "bear"
        else:
            continue
        # 之后有没有一根 1h 收盘穿过缺口（填补了）
        filled = False
        for d in bars1h[i + 2:]:
            if kind == "bull" and d["c"] < lo:
                filled = True
                break
            if kind == "bear" and d["c"] > hi:
                filled = True
                break
        if not filled:
            out.append({"kind": kind, "lo": lo, "hi": hi, "t": b["t"]})
    return out


def structure_1h(bars1h, direction, atr1h=None):
    """1h 结构是否与方向一致。只拦“明确的反向趋势”，不要求一路顺势：
    做空只在 1h 明确上行时才不对齐——最近 6h 的最高收盘与最低收盘
    都比之前 6h 高出 >0.5xATR1h；区间震荡、弱上行、下行都算对齐。
    做多对称。返回 (aligned: bool, detail: str)。"""
    closes = [b["c"] for b in bars1h]
    if len(closes) < 12:
        return False, "1h 数据不足 12 根，算不出结构"
    recent, prev = closes[-6:], closes[-12:-6]
    d_max = max(recent) - max(prev)
    d_min = min(recent) - min(prev)
    thr = 0.5 * atr1h if atr1h else 0.0
    if direction == -1:
        # 明确上行才拦：最高收与最低收都上移超过阈值
        blocked = d_max > thr and d_min > thr
        ok = not blocked
        return ok, (f"最近6h最高收 {max(recent):.4g} vs 之前6h {max(prev):.4g}"
                    f"（{d_max:+.4g}），最低收 {min(recent):.4g} vs 之前6h"
                    f" {min(prev):.4g}（{d_min:+.4g}），"
                    f"{'明确上行，不对齐' if blocked else '非明确上行，对齐'}")
    blocked = d_max < -thr and d_min < -thr
    ok = not blocked
    return ok, (f"最近6h最高收 {max(recent):.4g} vs 之前6h {max(prev):.4g}"
                f"（{d_max:+.4g}），最低收 {min(recent):.4g} vs 之前6h"
                f" {min(prev):.4g}（{d_min:+.4g}），"
                f"{'明确下行，不对齐' if blocked else '非明确下行，对齐'}")


def premium_discount(bars1h):
    """现价在最近 20 根已收盘 1h 区间里的位置（%）。返回 (pct, detail)。"""
    if len(bars1h) < PD_WINDOW_1H:
        return None, "1h 数据不足 20 根，算不出 P/D"
    w = bars1h[-PD_WINDOW_1H:]
    hi = max(b["h"] for b in w)
    lo = min(b["l"] for b in w)
    cur = bars1h[-1]["c"]
    if hi <= lo:
        return None, "区间高低相等，算不出 P/D"
    pct = (cur - lo) / (hi - lo) * 100.0
    return pct, f"20根1h区间 [{lo:.4g}, {hi:.4g}]，现价 {cur:.4g}，P/D {pct:.0f}%"


def level_tests(bars15, level, atr15, direction, confirm_t):
    """位子测试史：确认根之前、最近 24 根里，极值落在位子 ±0.5xATR15 内的
    根。相邻测试须相隔 >=4 根（1h）才各计一次——连续几根都顶在同一位子
    上只算一次测试，不虚增次数。探针根本身不计入测试（它是正在测试位子
    的那根，不是之前确立位子的测试）。返回 (tests, max_spread)。"""
    tests = []
    half = CLUSTER_TOL * atr15
    last_idx = None
    probe_t = confirm_t - 900
    for i, b in enumerate(bars15):
        if b["t"] >= probe_t:
            break  # 探针根及之后不计入测试
        if b["t"] < confirm_t - LEVEL_WINDOW * 900:
            continue
        ext = b["h"] if direction == -1 else b["l"]
        if abs(ext - level) <= half:
            if last_idx is not None and i - last_idx < CLUSTER_GAP_MIN:
                continue  # 与上一次测试相隔不足 4 根，不另计
            tests.append({"t": b["t"], "extreme": ext})
            last_idx = i
    if not tests:
        return [], None
    vals = [t["extreme"] for t in tests]
    return tests, max(vals) - min(vals)


def find_level(bars15, atr15, direction, confirm_idx):
    """给候选找参考位：最近 24 根里反复测试的位子（两根极值相差 <=0.5xATR、
    相隔 >=4 根），取极值最大的那对（做空）/最小的那对（做多）的均值；
    找不到则取最近 24 根的极值（单次测试的弱位子）。返回
    (level, tests, spread, pair)。"""
    window = bars15[max(0, confirm_idx - LEVEL_WINDOW):confirm_idx]
    if len(window) < CLUSTER_GAP_MIN + 1:
        return None, [], None, None
    half = CLUSTER_TOL * atr15
    best = None
    for a in range(len(window)):
        for c in range(a + CLUSTER_GAP_MIN, len(window)):
            pa, pc = window[a], window[c]
            va = pa["h"] if direction == -1 else pa["l"]
            vc = pc["h"] if direction == -1 else pc["l"]
            if abs(va - vc) > half:
                continue
            key = (max(va, vc), pc["t"]) if direction == -1 else (-min(va, vc), pc["t"])
            if best is None or key > best[0]:
                best = (key, (pa, pc))
    if best is not None:
        pa, pc = best[1]
        va = pa["h"] if direction == -1 else pa["l"]
        vc = pc["h"] if direction == -1 else pc["l"]
        level = (va + vc) / 2.0
        tests, spread = level_tests(bars15, level, atr15, direction,
                                    bars15[confirm_idx]["t"])
        return level, tests, spread, (pa, pc)
    # 无成对测试：取最近 24 根的极值（弱位子，单次测试）
    ext = max(b["h"] for b in window) if direction == -1 else min(b["l"] for b in window)
    tests, spread = level_tests(bars15, ext, atr15, direction,
                                bars15[confirm_idx]["t"])
    return ext, tests, spread, None


def brief(coin, direction, confirm_t, bars15, bars1h, plan_path=None):
    """对一个候选做完整主观读盘，返回简报 dict。
    confirm_t = 确认根的 UTC 时间戳（秒）。bars15/bars1h 须包含确认根
    （含）及之前的历史，按时间升序。"""
    # 定位确认根与探针根
    cidx = None
    for i, b in enumerate(bars15):
        if b["t"] == confirm_t:
            cidx = i
            break
    if cidx is None or cidx < 1:
        return {"error": f"确认根 {confirm_t} 不在 15m 数据里，算不出"}
    confirm = bars15[cidx]
    probe = bars15[cidx - 1]
    atrs = atr_wilder(bars15)
    atr15 = atrs[cidx]
    if atr15 is None or atr15 <= 0:
        return {"error": "ATR15 算不出"}
    atr1h, atr_src = get_atr1h(plan_path, coin, bars1h)
    if atr1h is None or atr1h <= 0:
        return {"error": "ATR1h 算不出"}
    # 参考位
    level, tests, spread, pair = find_level(bars15, atr15, direction, cidx)
    if level is None:
        return {"error": "参考位找不到"}
    # 1h 结构与 P/D（只用确认根时刻之前已收盘的 1h）
    bars1h_closed = [b for b in bars1h if b["t"] + 3600 <= confirm_t + 900]
    struct_ok, struct_txt = structure_1h(bars1h_closed, direction, atr1h)
    pd_pct, pd_txt = premium_discount(bars1h_closed)
    # FVG/OB 边（附近 ±0.5xATR1h）
    fvgs = fvg_edges(bars1h_closed)
    near_fvg = [f for f in fvgs
                if abs(f["lo"] - level) <= 0.5 * atr1h or abs(f["hi"] - level) <= 0.5 * atr1h]
    # 拒绝
    if direction == -1:
        wick = probe["h"] - probe["c"]
        move = confirm["o"] - confirm["c"]
        probe_ok = probe["h"] >= level - 0.25 * atr15 and probe["c"] < level
        confirm_ok = confirm["c"] < probe["c"]
    else:
        wick = probe["c"] - probe["l"]
        move = confirm["c"] - confirm["o"]
        probe_ok = probe["l"] <= level + 0.25 * atr15 and probe["c"] > level
        confirm_ok = confirm["c"] > probe["c"]
    wick_x = wick / atr15
    move_x = move / atr15
    # 事前检查
    if direction == -1:
        played = (level - confirm["c"]) >= 2 * atr1h
        played_txt = (f"位子到确认收盘 {level - confirm['c']:.4g}"
                      f"={((level - confirm['c']) / atr1h):.2f}xATR1h"
                      f"{'，已走完' if played else '，未走完'}")
    else:
        played = (confirm["c"] - level) >= 2 * atr1h
        played_txt = (f"确认收盘到位子 {confirm['c'] - level:.4g}"
                      f"={((confirm['c'] - level) / atr1h):.2f}xATR1h"
                      f"{'，已走完' if played else '，未走完'}")
    # 破位失败：探针刺穿看涨 FVG 下沿/需求 OB 下沿（做空）后 1h 收盘收回。
    # 简化：若参考位附近有看涨 FVG 且探针最低刺穿其下沿、而最近已收盘 1h
    # 收盘在其下沿之上，则为破位失败。
    failed_break = False
    failed_txt = "非 FVG/OB 边破位，不适用"
    if direction == -1:
        for f in near_fvg:
            if f["kind"] == "bull" and probe["l"] < f["lo"]:
                last1h = bars1h_closed[-1] if bars1h_closed else None
                if last1h is not None and last1h["c"] > f["lo"]:
                    failed_break = True
                    failed_txt = (f"探针最低 {probe['l']:.4g} 刺穿看涨 FVG 下沿 "
                                  f"{f['lo']:.4g}，但 1h 收盘 {last1h['c']:.4g} 收回边内，破位失败")
                    break
    else:
        for f in near_fvg:
            if f["kind"] == "bear" and probe["h"] > f["hi"]:
                last1h = bars1h_closed[-1] if bars1h_closed else None
                if last1h is not None and last1h["c"] < f["hi"]:
                    failed_break = True
                    failed_txt = (f"探针最高 {probe['h']:.4g} 刺穿看跌 FVG 上沿 "
                                  f"{f['hi']:.4g}，但 1h 收盘 {last1h['c']:.4g} 收回边内，破位失败")
                    break
    # 测试间隔（位子是否成型：>=2 次、相隔 >=4 根、首末跨度 >=8 根即 2h）
    test_times = [t["t"] for t in tests]
    gaps_ok = False
    span_ok = False
    if len(test_times) >= 2:
        for i in range(len(test_times)):
            for j in range(i + 1, len(test_times)):
                if (test_times[j] - test_times[i]) // 900 >= CLUSTER_GAP_MIN:
                    gaps_ok = True
                    break
            if gaps_ok:
                break
        span_ok = (max(test_times) - min(test_times)) // 900 >= 8
    # 最近测试距探针 <=24 根
    recent_ok = False
    if test_times:
        last_test = max(test_times)
        if (probe["t"] - last_test) // 900 <= CLUSTER_RECENCY:
            recent_ok = True
    return {
        "coin": coin, "direction": direction,
        "confirm_t": confirm_t, "probe_t": probe["t"],
        "level": level, "level_txt": (f"{level:.4g}"),
        "tests": [{"t": t["t"], "extreme": t["extreme"]} for t in tests],
        "test_count": len(tests),
        "test_spread": spread,
        "test_gaps_ok": gaps_ok, "test_span_ok": span_ok,
        "test_recent_ok": recent_ok,
        "pair": ([fmt_ts(pair[0]["t"]), fmt_ts(pair[1]["t"])] if pair else None),
        "probe": {"t": probe["t"], "o": probe["o"], "h": probe["h"],
                  "l": probe["l"], "c": probe["c"], "wick_x": round(wick_x, 2)},
        "confirm": {"t": confirm["t"], "o": confirm["o"], "h": confirm["h"],
                    "l": confirm["l"], "c": confirm["c"], "move_x": round(move_x, 2)},
        "probe_ok": probe_ok, "confirm_ok": confirm_ok,
        "atr15": round(atr15, 4), "atr1h": atr1h, "atr1h_source": atr_src,
        "structure_ok": struct_ok, "structure_txt": struct_txt,
        "pd_pct": pd_pct, "pd_txt": pd_txt,
        "near_fvg": [{"kind": f["kind"], "lo": f["lo"], "hi": f["hi"],
                      "t": fmt_ts(f["t"])} for f in near_fvg],
        "played_out": played, "played_txt": played_txt,
        "failed_break": failed_break, "failed_txt": failed_txt,
    }


def decide(b):
    """按设计第六节清单给结论。返回 (decision, reason, checks)。
    decision: 'write'（真 setup，可写触发）或 'no'（不是，只记日志）。
    判断者可凭盘面整体推翻，但必须在日志里写明推翻的理由。"""
    if "error" in b:
        return "no", f"简报算不出：{b['error']}", {}
    d = b["direction"]
    checks = {}
    # 1 结构对齐
    checks["structure"] = (b["structure_ok"], b["structure_txt"])
    # 2 位子合格：(a) 反复测试（>=2 次、相隔 >=4 根、首末跨度 >=2h、
    #    最近测试距探针 <=24 根）或 (b) 清晰的 FVG/OB 边（附近有未填补 FVG 边）
    level_ok = (b["test_count"] >= 2 and b["test_gaps_ok"]
                and b.get("test_span_ok", True) and b["test_recent_ok"]) \
        or len(b["near_fvg"]) > 0
    checks["level"] = (level_ok,
                       f"测试 {b['test_count']} 次、间隔合格 {b['test_gaps_ok']}、"
                       f"跨度>=2h {b.get('test_span_ok')}、"
                       f"最近测试新鲜 {b['test_recent_ok']}、附近 FVG 边 {len(b['near_fvg'])} 条")
    # 3 拒绝成立
    rej_ok = b["probe_ok"] and b["confirm_ok"]
    checks["rejection"] = (rej_ok,
                           f"探针探出后收回 {b['probe_ok']}、确认收盘顺势 {b['confirm_ok']}")
    # 4 事前检查通过
    pre_ok = (not b["played_out"]) and (not b["failed_break"])
    checks["precheck"] = (pre_ok, f"{b['played_txt']}；{b['failed_txt']}")
    # 5 强度足够：确认涨/跌幅必须先有跟进（>=0.5xATR15），否则光有影线
    #    没有跟进不算拒绝；再满足以下任一：确认 >=1.0x，或探针影 >=1.0x，
    #    或（位子测试 >=3 次且（探针影 >=0.5x 或确认 >=0.5x））。
    wick_x = b["probe"]["wick_x"]
    move_x = b["confirm"]["move_x"]
    str_ok = (move_x >= STRENGTH_WEAK
              and (move_x >= STRENGTH_MAIN or wick_x >= STRENGTH_MAIN
                   or (b["test_count"] >= 3
                       and (wick_x >= STRENGTH_WEAK or move_x >= STRENGTH_WEAK))))
    checks["strength"] = (str_ok,
                          f"探针影 {wick_x}x、确认涨/跌幅 {move_x}x、"
                          f"位子测试 {b['test_count']} 次"
                          f"{'' if move_x >= STRENGTH_WEAK else '（确认无跟进 <0.5x）'}")
    # P/D 称重（不是硬门槛）
    pd = b["pd_pct"]
    if pd is None:
        pd_txt = "P/D 算不出"
        pd_aligned = None
    else:
        aligned = (pd > 50) if d == -1 else (pd < 50)
        pd_txt = f"P/D {pd:.0f}%（{'顺立场' if aligned else '逆立场'}）"
        pd_aligned = aligned
    checks["pd"] = (pd_aligned, pd_txt)
    fails = [k for k, (ok, _) in checks.items() if k != "pd" and not ok]
    if fails:
        reason = "不是真 setup：" + "；".join(
            f"{k}不通过（{checks[k][1]}）" for k in fails)
        return "no", reason, checks
    # 全部通过：写。理由里写明 P/D 立场（顺/逆）。
    coin = b["coin"]
    d_txt = "做空" if d == -1 else "做多"
    bj = fmt_bj(b["confirm_t"])
    tests_txt = "、".join(
        f"{fmt_ts(t['t'])[11:]}极值 {t['extreme']:.4g}" for t in b["tests"][:4])
    reason = (f"主观判断 北京时间{bj}确认：{b['level_txt']}位子"
              f"{b['test_count']}次测试（{tests_txt}），"
              f"{fmt_ts(b['probe_t'])[11:]}探针"
              f"{'高' if d == -1 else '低'}{b['probe']['h'] if d == -1 else b['probe']['l']:.4g}"
              f"收{b['probe']['c']:.4g}收回位内，"
              f"{fmt_ts(b['confirm_t'])[11:]}确认收{b['confirm']['c']:.4g}"
              f"{'跌幅' if d == -1 else '涨幅'}{move_x}xATR15；"
              f"1h结构{'对齐' if b['structure_ok'] else '不对齐'}；{pd_txt}；"
              f"{b['played_txt']}。")
    return "write", reason, checks


def build_trigger(b, reason):
    """按简报与理由拼补充触发 dict（与机械层同形）。ref_entry=确认收盘，
    sl/tp=确认收盘 ±1x/∓2xATR1h，pending_entry_t=确认根收盘时刻。"""
    d = b["direction"]
    ref = b["confirm"]["c"]
    atr1h = b["atr1h"]
    if d == -1:
        sl, tp = ref + atr1h, ref - 2 * atr1h
    else:
        sl, tp = ref - atr1h, ref + 2 * atr1h
    tests_txt = "、".join(
        f"{fmt_ts(t['t'])[11:]}/{t['extreme']:.4g}" for t in b["tests"][:4])
    return {
        "coin": b["coin"], "direction": d,
        "trigger_t": b["confirm_t"] + 900,
        "pending_entry_t": b["confirm_t"] + 900,
        "confirm_bar_t": b["confirm_t"],
        "probe_bar_t": b["probe_t"],
        "level_type": "JUDGE",
        "level": b["level"],
        "level_txt": f"主观 {b['level']:.4g}（{tests_txt}）",
        "ref_entry": ref, "sl": sl, "tp": tp,
        "atr_1h": atr1h, "atr_1h_source": b["atr1h_source"],
        "basis": reason,
        "wick_x": b["probe"]["wick_x"], "confirm_x": b["confirm"]["move_x"],
        "atr15": b["atr15"],
    }


def write_trigger(plan_path, trigger, lock_path=LOCK_PATH):
    """写进当日计划文件“盘中补充触发”小节。先校验：待入场时间在 23:00 UTC
    之前（23:00 强平，之后写了也没用）；该币当日无已有补充触发行
    （任一方向，共用上限）、早上计划未成交（读引擎 state，若可读）。
    返回 (ok, msg)。"""
    if not SUPP_OK:
        return False, "supp_observer 导入失败，写不了触发"
    # 0. 23:00 UTC 之后不写（待入场时间 >= 23:00 UTC 即作废）
    import datetime as _dt
    eod = int(_dt.datetime.fromtimestamp(trigger["pending_entry_t"],
                                         tz=timezone.utc)
              .replace(hour=23, minute=0, second=0, microsecond=0).timestamp())
    if trigger["pending_entry_t"] >= eod:
        return False, "待入场时间已到 23:00 UTC 强平点，不写"
    # 1. 该币当日已有补充触发行 → 跳过（共用上限）
    try:
        with open(plan_path, encoding="utf-8") as f:
            text = f.read()
    except OSError as e:
        return False, f"计划文件读不到：{e}"
    existing = supp_observer.parse_supp_triggers(text)
    for t in existing:
        if t["coin"] == trigger["coin"]:
            return False, f"{trigger['coin']} 当日已有补充触发行，跳过（共用上限）"
    # 2. 早上计划已成交 → 跳过（读引擎 state）
    try:
        with open(STATE_PATH, encoding="utf-8") as f:
            st = json.load(f)
        plan_st = st.get("plans", {}).get(trigger["coin"], {})
        if plan_st.get("trades_done", 0) >= 1 or plan_st.get("status") == "triggered":
            return False, f"{trigger['coin']} 早上计划已成交，跳过（不叠加）"
        supp_st = st.get("supp", {}).get(trigger["coin"], {})
        if supp_st.get("trades_done", 0) >= 1 or supp_st.get("status") in ("triggered", "done"):
            return False, f"{trigger['coin']} 补充触发已有登记/成交，跳过"
    except (OSError, ValueError):
        pass  # state 读不到不拦（引擎登记时还会再拦一次）
    # 3. 写（幂等、带锁）
    ok = supp_observer.append_supp_trigger(plan_path, trigger, lock_path=lock_path)
    if not ok:
        return False, f"{trigger['coin']} 写入时发现已有同方向触发，跳过"
    return True, "已写入"


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    pb = sub.add_parser("brief")
    pb.add_argument("--coin", required=True)
    pb.add_argument("--direction", type=int, required=True, choices=[-1, 1])
    pb.add_argument("--confirm-t", type=int, required=True)
    pb.add_argument("--data-dir", required=True)
    pb.add_argument("--plan-file", default=None)
    args = ap.parse_args()
    if args.cmd == "brief":
        bars15 = load_file_15m(args.data_dir, args.coin)
        bars1h = load_file_1h(args.data_dir, args.coin)
        b = brief(args.coin, args.direction, args.confirm_t, bars15, bars1h,
                  plan_path=args.plan_file)
        dec, reason, checks = decide(b)
        print(json.dumps({"brief": b, "decision": dec, "reason": reason,
                          "checks": {k: {"ok": v[0], "txt": v[1]}
                                     for k, v in checks.items()}},
                         ensure_ascii=False, indent=1))
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
