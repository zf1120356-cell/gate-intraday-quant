#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第二期——独立自查（只查，不改题库）：
1. 题数 20；YES 10（5 空 5 多）/ NO 10；NO 不通过项分布 = 拒绝 4、结构 2、位子 1、事前 1、强度 1、方向一致性 1。
2. 每题窗口：24 根 1h + 16 根 15m + 8 根答案 15m；首根 1h 收盘 = 100。
3. 时间隔离：题干最后 1 根 15m = T（确认根）；答案第 1 根 t = T+900；
   全部题干 1h 均已收盘（t+3600 <= T+900）；答案窗口 8 根与题干无重叠。
4. 无未来数据：对每题用仅含 T 及之前数据的 brief 重跑，结论与题库参考一致。
5. ATR15 全精度：题库 atr15_idx 与 bars 全精度重算的 ATR15（指数换算后）一致（误差 <0.0002）。
6. 匿名化：题册 md 的题目区（## Q01 之后）不含任何币种符号与绝对日期。
7. 跑题脚本冒烟：run_train2.py 能读题库、打分逻辑可调用。
只输出计数与通过/不通过，不输出任何一题的答案、币名或时间。
"""
import json
import os
import re
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGE_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/开发-主观判断")
sys.path.insert(0, JUDGE_DIR)
sys.path.insert(0, HERE)
import judge_read  # noqa: E402
from judge_precheck import atr_wilder  # noqa: E402

problems = []
notes = []

data = json.load(open(os.path.join(HERE, "第二期-20题.json")))
qs = data["questions"]
coins = data["coins"]

# 1. 题数与分布
n_yes = sum(1 for q in qs if q["setup"])
n_no = len(qs) - n_yes
yes_dir = Counter(q["direction"] for q in qs if q["setup"])
fail_dist = Counter(tuple(q["fail_items"]) for q in qs if not q["setup"])
notes.append(f"题数 {len(qs)}；YES {n_yes}（空 {yes_dir[-1]}、多 {yes_dir[1]}）/ NO {n_no}；"
             f"NO 不通过项分布 {dict(sorted(fail_dist.items()))}")
if len(qs) != 20 or n_yes != 10 or n_no != 10:
    problems.append("题数/YES/NO 分布不对")
if yes_dir[-1] != 5 or yes_dir[1] != 5:
    problems.append("YES 方向分布不是 5 空 5 多")
want_fail = {(3,): 4, (1,): 2, (2,): 1, (4,): 1, (5,): 1, (6,): 1}
if dict(fail_dist) != want_fail:
    problems.append(f"NO 不通过项分布与目标不符：{dict(fail_dist)} vs {want_fail}")
if len(set(coins)) != 8:
    problems.append("币种数不是 8")
per_coin = Counter(q["coin"] for q in qs)
notes.append(f"每币题数：{dict(sorted(per_coin.items()))}（最大值 {max(per_coin.values())}，上限 3）")
if max(per_coin.values()) > 3:
    problems.append("有币超过 3 道题")

bars_cache = {}


def load(sym, iv):
    if (sym, iv) not in bars_cache:
        bars_cache[(sym, iv)] = json.load(open(os.path.join(HERE, f"train2_{sym}_{iv}.json")))
    return bars_cache[(sym, iv)]


# 2/3/4/5. 逐题核查
for q in qs:
    coin, T, d = q["coin"], q["T"], q["direction"]
    b15_all, b1h_all = load(coin, "15m"), load(coin, "1h")
    b15 = [b for b in b15_all if b["t"] <= T]
    b1h = [b for b in b1h_all if b["t"] + 3600 <= T + 900]
    if len(q["stem_1h"]) != 24 or len(q["stem_15m"]) != 16 or len(q["answer_15m"]) != 8:
        problems.append(f"{q['id']} 窗口不完整")
    if abs(q["stem_1h"][0]["c"] - 100.0) > 1e-9:
        problems.append(f"{q['id']} 首根 1h 收盘不是 100")
    # 时间隔离（原始数据）
    if b15[-1]["t"] != T:
        problems.append(f"{q['id']} 题干最后 15m 不是确认根 T")
    ans = [b for b in b15_all if T < b["t"] <= T + 8 * 900]
    if len(ans) != 8 or ans[0]["t"] != T + 900:
        problems.append(f"{q['id']} 答案窗口不对（{len(ans)} 根，首根 {ans[0]['t'] if ans else None}）")
    if any(b["t"] + 3600 > T + 900 for b in b1h):
        problems.append(f"{q['id']} 题干 1h 含未收盘根")
    # ATR15 全精度
    atr15_full = atr_wilder(b15)[-1]
    base = b1h[-24:][0]["c"]
    atr15_idx = round(atr15_full / base * 100.0, 4)
    if abs(atr15_idx - q["atr15_idx"]) > 0.0002:
        problems.append(f"{q['id']} atr15_idx 与全精度重算不一致（{q['atr15_idx']} vs {atr15_idx}）")
    # 无未来数据：仅用 T 及之前数据重跑 brief，结论一致
    b = judge_read.brief(coin, d, T, b15, b1h, plan_path=None)
    if "error" in b:
        problems.append(f"{q['id']} brief 重跑出错：{b['error']}")
        continue
    dec, _reason, _checks = judge_read.decide(b)
    want = "write" if (q["setup"] or q["kind"] == "NO6") else "no"
    if dec != want:
        problems.append(f"{q['id']} 仅用 T 及之前数据重跑结论不一致（{dec} vs {want}）")
    # 反方向也不通过（与 verify 同口径，独立再算一次）
    b2 = judge_read.brief(coin, -d, T, b15, b1h, plan_path=None)
    if "error" not in b2:
        dec2, _, _ = judge_read.decide(b2)
        if dec2 == "write":
            problems.append(f"{q['id']} 反方向也通过")
notes.append("逐题核查：窗口、指数换算、时间隔离、ATR15 全精度、无未来数据重跑、反方向校验均已跑")

# 6. 匿名化：题册题目区不含币种符号与绝对日期
md = open(os.path.join(HERE, "第二期-20题.md")).read()
body = md.split("## Q01", 1)[1] if "## Q01" in md else ""
leaks = [c for c in coins if re.search(rf"\b{c}\b", body)]
dates = re.findall(r"20\d\d-\d\d-\d\d", body)
if leaks:
    problems.append(f"题册题目区泄露币种符号：{leaks}")
if dates:
    problems.append(f"题册题目区含绝对日期：{dates[:5]}")
notes.append(f"匿名化：题目区币种符号泄露 {len(leaks)} 个、绝对日期 {len(dates)} 个")

# 7. 跑题脚本冒烟
sys.path.insert(0, HERE)
from train_common2 import load_questions, score  # noqa: E402
qs2 = load_questions()
if len(qs2) != 20:
    problems.append("run_train2 读到的题数不是 20")
sc = score(qs2[0], {"setup": qs2[0]["setup"],
                    "direction": qs2[0]["ref_direction"],
                    "sl": qs2[0]["anchors"]["sl"] if qs2[0]["anchors"] else None,
                    "tp": qs2[0]["anchors"]["tp"] if qs2[0]["anchors"] else None,
                    "fail_items": list(qs2[0]["fail_items"])})
notes.append(f"跑题脚本冒烟：读题 20 道；用参考答案自答第 1 题，setup_ok={sc['setup_ok']}")

print("=== 第二期自查 ===")
for n in notes:
    print(" -", n)
print()
if problems:
    print("发现问题（须处理）：")
    for p in problems:
        print("  -", p)
    raise SystemExit(1)
print("自查全部通过。")
