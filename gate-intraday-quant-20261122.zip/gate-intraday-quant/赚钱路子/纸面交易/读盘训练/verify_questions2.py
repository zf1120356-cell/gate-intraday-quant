#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第二期——校验 20 道题（只校验，不出新题）：
1. 每个题点的反方向在同一 T 也跑 brief+decide：YES 题反方向必须不通过，
   NO 题反方向也必须不通过（否则题干里其实藏着另一个方向的真 setup，题是错的）。
2. YES 题参考锚位复核：SL 在探针极值之外、TP 在结构目标附近、盈亏比 1.5–3。
3. 题干/答案窗口完整性：24 根 1h + 16 根 15m + 8 根答案 15m；指数换算首根 1h 收盘 = 100。
4. 答案窗口与题干无重叠（答案第一根 t > T）。
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGE_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/开发-主观判断")
sys.path.insert(0, JUDGE_DIR)
import judge_read  # noqa: E402


def load_bars(sym, interval):
    with open(os.path.join(HERE, f"train2_{sym}_{interval}.json")) as f:
        return json.load(f)


def main():
    data = json.load(open(os.path.join(HERE, "第二期-20题.json")))
    bars_cache = {}
    problems = []
    for q in data["questions"]:
        coin, T, d = q["coin"], q["T"], q["direction"]
        if coin not in bars_cache:
            bars_cache[coin] = (load_bars(coin, "15m"), load_bars(coin, "1h"))
        bars15, bars1h = bars_cache[coin]
        b15 = [b for b in bars15 if b["t"] <= T]
        b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
        # 1. 反方向校验
        od = -d
        b = judge_read.brief(coin, od, T, b15, b1h, plan_path=None)
        if "error" in b:
            opp = ("error", b["error"])
        else:
            dec, reason, checks = judge_read.decide(b)
            opp = (dec, reason)
        if opp[0] == "write":
            problems.append(f"{q['id']} 反方向也通过（{opp[0]}）：题干藏着另一个方向的真 setup，题无效")
        # 2. YES 题锚位复核
        if q["setup"] or q["kind"] == "NO6":
            a = q["anchors"]
            ref, sl, tp = q["ref_idx"], a["sl"], a["tp"]
            probe = q["probe_idx"]
            if d == -1:
                if not (sl > probe["h"]):
                    problems.append(f"{q['id']} SL 未在探针高点之外（SL {sl} <= 探针高 {probe['h']}）")
                if not (1.5 - 1e-9 <= a["rr"] <= 3.0 + 1e-9):
                    problems.append(f"{q['id']} 盈亏比 {a['rr']} 不在 1.5–3")
                if not (tp < ref):
                    problems.append(f"{q['id']} 做空 TP 未在入场参考价之下")
            else:
                if not (sl < probe["l"]):
                    problems.append(f"{q['id']} SL 未在探针低点之外（SL {sl} >= 探针低 {probe['l']}）")
                if not (1.5 - 1e-9 <= a["rr"] <= 3.0 + 1e-9):
                    problems.append(f"{q['id']} 盈亏比 {a['rr']} 不在 1.5–3")
                if not (tp > ref):
                    problems.append(f"{q['id']} 做多 TP 未在入场参考价之上")
        # 3. 窗口完整性
        if len(q["stem_1h"]) != 24 or len(q["stem_15m"]) != 16 or len(q["answer_15m"]) != 8:
            problems.append(f"{q['id']} 窗口不完整：1h {len(q['stem_1h'])}、15m {len(q['stem_15m'])}、答案 {len(q['answer_15m'])}")
        if abs(q["stem_1h"][0]["c"] - 100.0) > 1e-9:
            problems.append(f"{q['id']} 指数换算错误：首根 1h 收盘不是 100（{q['stem_1h'][0]['c']}）")
        # 4. 答案与题干分开：答案第一根 t 必须 > T（用原始数据核对）
        ans = [b for b in bars15 if T < b["t"] <= T + 8 * 900]
        if len(ans) != 8:
            problems.append(f"{q['id']} 答案窗口原始数据不足 8 根（{len(ans)}）")
        print(f"{q['id']} 反方向={opp[0]}（{'通过' if opp[0]=='write' else '不通过'}）"
              f"{' 锚位OK' if (q['setup'] or q['kind']=='NO6') else ''}", flush=True)
    print()
    if problems:
        print("发现问题（须处理）：")
        for p in problems:
            print("  -", p)
    else:
        print("校验全部通过：20 道题反方向均不通过、锚位与窗口均合规。")


if __name__ == "__main__":
    main()
