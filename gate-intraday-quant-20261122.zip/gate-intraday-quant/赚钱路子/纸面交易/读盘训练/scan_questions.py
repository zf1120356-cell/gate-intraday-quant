#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第一期——扫描候选题点（只分析、不出题）。
对 8 个新币的每个 15m 收盘点 T，先跑 judge_precheck 的候选过滤，
再对每个方向跑 judge_read.brief + decide，得到参考结论（6 项清单前 5 项）。
输出 scan_results.json：每个候选 {coin, T, direction, decision, checks, brief摘要}。
题干窗口（24 根 1h + 16 根 15m，全部在 T 及之前收盘）与答案窗口（T 之后 8 根 15m）
严格分开；brief 只喂 T 及之前的数据，杜绝前视。
"""
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGE_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/开发-主观判断")
sys.path.insert(0, JUDGE_DIR)
from judge_precheck import precheck_coin, atr_wilder  # noqa: E402
import judge_read  # noqa: E402

COINS = ["ANT", "IRYS", "DRAM", "BZ", "BCH", "PUMP", "APT", "ICP"]
SCAN_START = int(datetime(2026, 10, 1, tzinfo=timezone.utc).timestamp())
SCAN_END = int(datetime(2026, 11, 20, 12, 0, tzinfo=timezone.utc).timestamp())


def load_bars(sym, interval):
    with open(os.path.join(HERE, f"train1_{sym}_{interval}.json")) as f:
        return json.load(f)


def main():
    out = []
    for coin in COINS:
        bars15 = load_bars(coin, "15m")
        bars1h = load_bars(coin, "1h")
        # 只扫有完整 24h 1h 历史的 T
        t_idx = [i for i, b in enumerate(bars15)
                 if SCAN_START <= b["t"] <= SCAN_END]
        n_flag = 0
        for i in t_idx:
            T = bars15[i]["t"]
            # 每 4 根扫一次（1 小时间隔），减少重叠窗口
            if (T // 900) % 4 != 0:
                continue
            b15 = bars15[:i + 1]
            if len(b15) < 40:
                continue
            cands = precheck_coin(b15, coin)
            if not cands:
                continue
            b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
            if len(b1h) < 24:
                continue
            for c in cands:
                d = c["direction"]
                b = judge_read.brief(coin, d, T, b15, b1h, plan_path=None)
                if "error" in b:
                    continue
                dec, reason, checks = judge_read.decide(b)
                n_flag += 1
                out.append({
                    "coin": coin, "T": T, "direction": d,
                    "decision": dec, "reason": reason,
                    "checks": {k: {"ok": v[0], "txt": v[1]} for k, v in checks.items()},
                    "level": b["level"], "test_count": b["test_count"],
                    "probe": b["probe"], "confirm": b["confirm"],
                    "atr15": b["atr15"], "atr1h": b["atr1h"],
                    "structure_ok": b["structure_ok"],
                    "pd_pct": b["pd_pct"],
                    "near_fvg": b["near_fvg"],
                    "played_out": b["played_out"],
                    "failed_break": b["failed_break"],
                    "kinds": c["kinds"],
                })
        print(f"[{coin}] 候选 {n_flag} 个", flush=True)
    with open(os.path.join(HERE, "scan_results.json"), "w") as f:
        json.dump(out, f, ensure_ascii=False)
    # 分桶统计
    from collections import Counter
    cnt = Counter()
    for r in out:
        if r["decision"] == "write":
            cnt[f"YES d={r['direction']}"] += 1
        else:
            fails = [k for k, v in r["checks"].items() if k != "pd" and not v["ok"]]
            cnt["NO " + "/".join(fails)] += 1
    print("分桶：", dict(cnt))
    print(f"共 {len(out)} 个候选，已写 scan_results.json")


if __name__ == "__main__":
    main()
