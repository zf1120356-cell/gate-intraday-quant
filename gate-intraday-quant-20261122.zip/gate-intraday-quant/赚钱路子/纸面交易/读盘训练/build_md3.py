#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""由 第三期-20题.json 生成题库册子 第三期-20题.md（避免转录错）。
只写题干与答案，不写币种名与时间戳。
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from train_common3 import ITEM_NAME, load_questions, render_answer, render_stem

MD_PATH = os.path.join(HERE, "第三期-20题.md")


def main():
    with open(os.path.join(HERE, "第三期-20题.json")) as f:
        data = json.load(f)
    questions = data["questions"]
    coins = data["coins"]

    n_yes = sum(1 for q in questions if q["setup"])
    n_no = len(questions) - n_yes
    fail_split = {}
    for q in questions:
        if not q["setup"]:
            key = tuple(q["fail_items"])
            fail_split[key] = fail_split.get(key, 0) + 1
    per_coin = {}
    for q in questions:
        per_coin[q["coin"]] = per_coin.get(q["coin"], 0) + 1
    bias_split = {}
    for q in questions:
        bias_split[q["morning_bias"]] = bias_split.get(q["morning_bias"], 0) + 1

    L = []
    L.append("# 读盘训练第三期：20 道题")
    L.append("")
    L.append("> ⚠️ 做题前请注意：不要打开 `第三期-20题.json`——里面含币种名、时间戳与参考答案。"
             "做题用 `run_train3.py`（一次一道，做完再解开），或按下面题干自行做题、"
             "再对答案。")
    L.append("")
    L.append("这是训练，不是回测：不跑统计、不验证任何规则、不调参、不汇总收益率，"
             "只练判断本身。每道题只判判断对不对（setup 有无、方向、锚位是否合理），"
             "并记到判断清单 6 项里是哪一项错了。")
    L.append("")
    L.append("## 用币清单（8 个，全部从未进入第 1–42 轮、第一期、第二期也没用过）")
    L.append("")
    L.append("名单先定死：按 Gate tickers 2026-11-22 快照的 24h 成交额排序，"
             "排除已用 32 个币（BTC、ETH、SOL、DOGE、LINK、XRP、BNB、ADA、ZEC、EVAA、"
             "HYPE、LTC、BLESS、XLM、AKE、NEAR、PEPE、UNI、SUI、XAUT、MMT、WLD、"
             "PIEVERSE、AVAX、KERNEL、PAXG、ARB、FIL、CYBER、TAO、ENA、INJ）、"
             "第一期 8 币（ANT、IRYS、DRAM、BZ、BCH、PUMP、APT、ICP）、"
             "第二期 8 币（BTW、ONDO、AAVE、JCT、TRX、GRAM、INIT、LIT）、"
             "稳定币、杠杆代币、价差 >0.07%、代币化股票/ETF/商品后取前 8 名。"
             "KORU 经核实为 Direxion 韩国 Bull 3x ETF（代币化 ETF），已排除；"
             "VVV 是第二期替补（取过数、未进题），为保“全新”严格起见也跳过。")
    L.append("")
    for c in coins:
        L.append(f"- {c}")
    L.append("")
    L.append("本期只练第一期弱项：第 3 项拒绝成立（带内触及 + 探针自收回）"
             "与考虑方向的选取。YES 题优先探针触及带未越线且自己收回的真 setup；"
             "NO 题拒绝项优先探针越线但自己没收回的假 setup，以及反方向也有位子簇、"
             "容易按离得近的簇反推方向的题。")
    L.append("")
    L.append("## 选币与出题方法")
    L.append("")
    L.append("- 数据：Gate 永续 1h/15m（2026-09-22～2026-11-22），"
             "7 天分段拉取，curl 实测接口；每根量取自 Gate K 线 v 字段。")
    L.append("- 每道题：24 根 1h + 随后 16 根 15m 做题干，随后 8 根 15m 做答案窗口。")
    n_scan = len(json.load(open(os.path.join(HERE, "scan_results3.json"))))
    L.append("- 候选扫描：用判断层自己的预检（`judge_precheck.precheck_coin`）"
             "加完整主观读盘（`judge_read.brief` + `decide`），只看截止 T 的已收盘 K 线，"
             f"无未来数据；每 4 根 15m 收盘扫一次，2026-10-01～2026-11-21，共 {n_scan:,} 个候选。"
             "扫描用的是出题前冻结的判断层快照（`train3_judge_snapshot/`），"
             "与 live 判断层后续改动隔离。")
    L.append("- 选出 20 道：YES 10 道（5 多 5 空，参考锚位盈亏比 1.5–3，优先 Q01 型）"
             "+ NO 10 道（单项不通过：拒绝 4、结构 2、位子 1、事前 1、强度 1，"
             "另 1 道方向一致性不通过取自 YES 池、把题干偏向反着设）。")
    L.append("- 约束：每币最多 3 道；每个币每天（UTC）最多 1 道；"
             "反方向在同一 T 也验证过不通过。")
    L.append("- 匿名化：币种名与全部时间戳隐藏，只标相对时间（H-24…H-1、M-16…M-1、"
             "M+1…M+8、T-XhYYm）；价格是指数（题干首根 1h 收盘 = 100.0000）；"
             "题干同时给出高点簇与低点簇（方向中立），参考位子只在答案里。")
    L.append("- 量（本期新增）：题干每根 1h/15m 与答案 8 根 15m 都带相对量"
             "（该根量 / 题干内同周期均量，1h 用 24 根均量，15m 用 16 根均量，"
             "答案 15m 沿用题干 15m 均量；无量纲，不泄露币种）；探针根、确认根的"
             "相对量在题干与答案里都能直接看到。量是称重项，不是否决项，"
             "不改变参考答案；答案库每题另存探针/确认根相对量（`vol` 字段）"
             "供事后分析量有没有帮忙。")
    oc_count = {}
    for q in questions:
        if q["setup"] and q.get("outcome"):
            oc_count[q["outcome"]["hit"]] = oc_count.get(q["outcome"]["hit"], 0) + 1
    L.append("- YES 题目是结果盲选的（选时不看答案窗口）："
             + "、".join(f"{k} {v} 道" for k, v in sorted(oc_count.items()))
             + "。这不是结果，是选时不知道。")
    L.append("")
    L.append("## 构成")
    L.append("")
    L.append(f"- YES {n_yes} 道 / NO {n_no} 道；"
             f"每币：{', '.join(f'{c} {v}' for c, v in sorted(per_coin.items()))}；"
             f"早上偏向：无偏向 {bias_split.get(None, 0)}、做多 "
             f"{bias_split.get(1, 0)}、做空 {bias_split.get(-1, 0)}。")
    L.append(f"- NO 的不通过项分布：{'; '.join('、'.join(str(i) for i in k) + f' ×{v}' for k, v in sorted(fail_split.items()))}。")
    L.append("")
    L.append("## 判断清单（6 项，全部通过才是有 setup）")
    L.append("")
    for i in range(1, 7):
        L.append(f"{i}. {ITEM_NAME[i]}")
    L.append("")
    L.append("细则见 `~/workspace/赚钱路子/纸面交易/盘中主观判断-设计.md`。"
             "主观止损止盈锚法见 `~/workspace/赚钱路子/SMC量化系统-v3.md` §3.4："
             "止损锚结构位之外（拒绝探针极值/OB/FVG 边/摆动点之外，加小缓冲），"
             "止盈锚下一个结构目标（流动性池/摆动高低点/下一个 FVG/OB），"
             "入场前写死，盈亏比 1:1.5–3（不到 1.5 不做，超 3 按 3 封顶）。")
    L.append("P/D 是称重项，不是硬门槛。")
    L.append("")
    L.append("## 打分口径（跑题脚本 `run_train3.py` 同款）")
    L.append("")
    L.append("- 每道题答三问：(1) 有没有 setup；(2) 方向；(3) 止损锚哪、止盈锚哪"
             "（无 setup 时答哪几项不通过）。")
    L.append("- setup 判断：与参考一致算对，否则算错。")
    L.append("- 方向：只在双方都判有 setup 时计；判反了记「方向」错。")
    L.append("- 锚位（只在方向判对时计）：止损须在正确一侧且越过最近结构位；"
             "止盈须在任一结构目标 ±0.25×ATR15 内或在 3 倍封顶处；"
             "盈亏比须在 1.5–3（容差 1.45–3.05）。三项都对才算锚位对，"
             "任一不对记「锚位」错。")
    L.append("- 归因（双方都判无 setup 时计）：指出的不通过项与参考一致算对；"
             "把实际通过的项当成不通过，记该项错；漏掉的不通过项只备注、不重复计。")
    L.append("- 误判为 setup：漏掉的不通过项全记错；误判为无 setup："
             "错当成不通过的项记错，未指明记「未指明」。")
    L.append("- 汇总：setup 正确率、方向正确率、锚位全对率、错题按类型汇总"
             "（1–6 项 + 方向 / 锚位 / 未指明）、建议复盘的题号。")
    L.append("- 答案窗口的走势（先到止损还是止盈）只作复盘参考："
             "它验证的是这道题的结果，不是判断的对错；20 道题的对错率"
             "不是任何规则的胜率或收益率，不要汇总成收益率。")
    L.append("")

    for q in questions:
        L.append(f"## {q['id']}")
        L.append("")
        L.append("```")
        L.append(render_stem(q))
        L.append("```")
        L.append("")
        L.append("<details><summary>答案（做完再展开）</summary>")
        L.append("")
        L.append("```")
        L.append(render_answer(q))
        L.append("```")
        L.append("")
        L.append("</details>")
        L.append("")

    with open(MD_PATH, "w") as f:
        f.write("\n".join(L))
    print(f"已生成 {MD_PATH}（{len(L)} 行）")


if __name__ == "__main__":
    main()
