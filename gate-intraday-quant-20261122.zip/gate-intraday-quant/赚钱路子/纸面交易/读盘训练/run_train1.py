#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第一期——跑题脚本。
用法：
    python3 run_train1.py                 # 交互做题（一次一道，做完再解开）
    python3 run_train1.py --answers 答案.json   # 非交互（答案文件，一题一行）
题目与答案存在 第一期-20题.json 里（本脚本只读它）。
做题时不要打开那个 JSON——里面含币种名、时间戳与参考答案。
打分只判判断本身（setup 有无、方向、锚位是否合理），按 6 项清单记错在哪；
不汇总收益率、不做任何规则验证。成绩存在 成绩-YYYYMMDD-HHMMSS.json。
"""
import argparse
import datetime
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from train_common import (ITEM_NAME, load_questions, outcome_with_anchors,
                          render_answer, render_stem, score)

EOF = object()


def ask(prompt):
    try:
        return input(prompt)
    except EOFError:
        return EOF
    except KeyboardInterrupt:
        print()
        print("已中断，退出。")
        sys.exit(1)


def parse_yes_no(s):
    if s is None:
        return None
    s = s.strip().lower()
    if s in ("y", "yes", "是", "有", "1", "有setup"):
        return True
    if s in ("n", "no", "否", "无", "0", "无setup", "没有"):
        return False
    return None


def parse_direction(s):
    if s is None:
        return None
    s = s.strip().lower()
    if s in ("空", "做空", "short", "s", "-1"):
        return -1
    if s in ("多", "做多", "long", "l", "1"):
        return 1
    return None


def parse_float(s):
    if s is None:
        return None
    s = s.strip().lower()
    if s in ("", "不做", "跳过", "-", "none", "na"):
        return None
    try:
        return float(s)
    except ValueError:
        return "BAD"


def parse_items(s):
    if s is None:
        return []
    s = s.strip()
    if s in ("", "-", "无", "none"):
        return []
    out = []
    for part in s.replace("，", ",").replace("、", ",").replace(" ", ",").split(","):
        part = part.strip()
        if part.isdigit() and 1 <= int(part) <= 6:
            out.append(int(part))
    return sorted(set(out))


def ask_question_interactive(q):
    print()
    print(render_stem(q))
    ans = {"setup": None, "direction": None, "sl": None, "tp": None,
           "fail_items": []}
    while True:
        s = ask("\n(1) 有没有 setup？[有/无] ")
        if s is EOF:
            return None
        v = parse_yes_no(s)
        if v is not None:
            ans["setup"] = v
            break
        print("  请答 有 或 无。")
    if ans["setup"]:
        while True:
            s = ask("(2) 方向？[做空/做多] ")
            if s is EOF:
                return None
            v = parse_direction(s)
            if v is not None:
                ans["direction"] = v
                break
            print("  请答 做空 或 做多。")
        while True:
            s = ask("(3) 止损锚哪？（指数价位；不做填 -） ")
            if s is EOF:
                return None
            v = parse_float(s)
            if v != "BAD":
                ans["sl"] = v
                break
            print("  请输入数字（如 101.2345）或 -。")
        while True:
            s = ask("(3) 止盈锚哪？（指数价位；不做填 -） ")
            if s is EOF:
                return None
            v = parse_float(s)
            if v != "BAD":
                ans["tp"] = v
                break
            print("  请输入数字（如 101.2345）或 -。")
    else:
        s = ask("(1) 哪几项不通过？（1–6，多个用逗号隔开；都通过填 -） ")
        if s is EOF:
            return None
        ans["fail_items"] = parse_items(s)
    return ans


def main():
    ap = argparse.ArgumentParser(description="读盘训练第一期跑题脚本")
    ap.add_argument("--answers", help="答案 JSON 文件（非交互模式）")
    args = ap.parse_args()

    questions = load_questions()
    preset = None
    if args.answers:
        with open(args.answers) as f:
            preset = json.load(f)
        if len(preset) != len(questions):
            print(f"答案文件有 {len(preset)} 条，与题数 {len(questions)} 不符，退出。")
            return 1

    print("读盘训练第一期（20 道）")
    print("规则：价格是指数（题干首根 1h 收盘 = 100），只给相对时间；")
    print("做完一道再解开答案。打分只判判断本身，不汇总收益率。")
    print("做题时不要打开 第一期-20题.json（里面含币种名、时间戳与参考答案）。")

    results = []
    for i, q in enumerate(questions):
        if preset is not None:
            ans = preset[i]
        else:
            ans = ask_question_interactive(q)
            if ans is None:
                print("未做完，退出。")
                break
        sc = score(q, ans)
        print()
        print(render_answer(q))
        print()
        # 本题小结
        if sc["setup_ok"]:
            print("  本题：setup 判断 ✓")
        else:
            print(f"  本题：setup 判断 ✗（你：{'有' if ans['setup'] else '无'}，"
                  f"参考：{'有' if q['setup'] else '无'}）")
        if sc["direction_ok"] is True:
            print("  方向 ✓")
        elif sc["direction_ok"] is False:
            print("  方向 ✗")
        if sc["attribution_ok"] is True:
            print("  归因 ✓（不通过项判对了）")
        elif sc["attribution_ok"] is False:
            print("  归因 ✗")
        if sc["sl_ok"] is not None:
            print(f"  锚位：止损 {'✓' if sc['sl_ok'] else '✗'}、"
                  f"止盈 {'✓' if sc['tp_ok'] else '✗'}、"
                  f"盈亏比 {'✓' if sc['rr_ok'] else '✗'}")
        if sc["notes"]:
            for n in sc["notes"]:
                print(f"  备注：{n}")
        # 学员锚位自己的结果（仅供参考，不计分）
        if (ans["setup"] and q["setup"] and ans["direction"] == q["ref_direction"]
                and ans.get("sl") is not None and ans.get("tp") is not None):
            oc = outcome_with_anchors(q["answer_15m"], q["direction"],
                                       q["ref_idx"], ans["sl"], ans["tp"])
            print(f"  用你的锚位跑答案窗口：先到{oc['hit']}；最大有利 "
                  f"{oc['max_fav_R']}R，最大不利 {oc['max_adv_R']}R（仅供参考，不计分）。")
        results.append({"id": q["id"], "ans": ans, "score": sc})
        if preset is None and i < len(questions) - 1:
            s = ask("\n按回车继续下一道（输入 q 退出）")
            if s is EOF or (isinstance(s, str) and s.strip().lower() == "q"):
                break

    # ---------------------------------------------------------------- 汇总
    n = len(results)
    n_setup_ok = sum(1 for r in results if r["score"]["setup_ok"])
    dir_scored = [r for r in results if r["score"]["direction_ok"] is not None]
    n_dir_ok = sum(1 for r in dir_scored if r["score"]["direction_ok"])
    anc_scored = [r for r in results if r["score"]["sl_ok"] is not None]
    n_anc_ok = sum(1 for r in anc_scored
                   if r["score"]["sl_ok"] and r["score"]["tp_ok"] and r["score"]["rr_ok"])
    err_count = {}
    for r in results:
        for e in r["score"]["error_items"]:
            err_count[e] = err_count.get(e, 0) + 1
    review = [r["id"] for r in results if not r["score"]["setup_ok"]
              or r["score"]["direction_ok"] is False
              or r["score"]["attribution_ok"] is False
              or (r["score"]["sl_ok"] is not None
                  and not (r["score"]["sl_ok"] and r["score"]["tp_ok"]
                           and r["score"]["rr_ok"]))]
    print()
    print("=" * 40)
    print(f"本次做题 {n} 道")
    print(f"setup 判断对：{n_setup_ok}/{n}")
    if dir_scored:
        print(f"方向对：{n_dir_ok}/{len(dir_scored)}"
              f"（只计双方都判有 setup 的题）")
    if anc_scored:
        print(f"锚位全对：{n_anc_ok}/{len(anc_scored)}"
              f"（只计方向判对的题；止损、止盈、盈亏比三项都对才算）")
    print("错题按类型汇总：")
    if err_count:
        for k in sorted(err_count, key=lambda x: (isinstance(x, str), x)):
            label = ITEM_NAME[k] if isinstance(k, int) else k
            print(f"  {label}：{err_count[k]} 次")
    else:
        print("  （无错题）")
    if review:
        print("建议复盘的题：" + "、".join(review))
    print()
    print("提醒：20 道题是练判断的练习量，不是样本量；")
    print("不要把这次的对错率当成任何规则的胜率或收益率。")

    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_path = os.path.join(HERE, f"成绩-{ts}.json")
    with open(out_path, "w") as f:
        json.dump({"finished_at": ts, "n": n, "setup_ok": n_setup_ok,
                   "direction_ok": n_dir_ok, "direction_scored": len(dir_scored),
                   "anchor_ok": n_anc_ok, "anchor_scored": len(anc_scored),
                   "error_count": {str(k): v for k, v in err_count.items()},
                   "review": review, "results": results},
                  f, ensure_ascii=False, indent=2)
    print(f"成绩已存：{out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
