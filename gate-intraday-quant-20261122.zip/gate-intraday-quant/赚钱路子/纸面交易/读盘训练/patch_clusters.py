#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第一期——给题库 JSON 补方向中立的双向位子簇（题干用）。
对每个题点，用 judge_read.find_level 对做空/做多两个方向各找一个反复测试的位子
（24 根 15m 窗口，与判断层同一口径），测试史用 level_tests 重算。
题干只展示这两个簇（高点簇/低点簇），不透露参考答案的方向。
只有成对测试（pair 不为空）的簇才列出；否则记为无反复测试的位子。
全部换算为指数单位，币种与时间戳不进题干。
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGE_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/开发-主观判断")
sys.path.insert(0, JUDGE_DIR)
import judge_read  # noqa: E402


def load_bars(sym, interval):
    with open(os.path.join(HERE, f"train1_{sym}_{interval}.json")) as f:
        return json.load(f)


def rel_label(T, t):
    mins = (T - t) // 60
    return f"T-{mins // 60}h{mins % 60:02d}m"


def main():
    path = os.path.join(HERE, "第一期-20题.json")
    data = json.load(open(path))
    bars_cache = {}
    for q in data["questions"]:
        coin, T = q["coin"], q["T"]
        if coin not in bars_cache:
            bars_cache[coin] = (load_bars(coin, "15m"), load_bars(coin, "1h"))
        bars15, bars1h = bars_cache[coin]
        b15 = [b for b in bars15 if b["t"] <= T]
        b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
        stem1h = b1h[-24:]
        base = stem1h[0]["c"]
        to_idx = lambda x: round(x / base * 100.0, 4)
        # 确认根在 b15 里的下标
        cidx = next(i for i, b in enumerate(b15) if b["t"] == T)
        atrs = judge_read.atr_wilder(b15) if hasattr(judge_read, "atr_wilder") else None
        from judge_precheck import atr_wilder
        atr15 = atr_wilder(b15)[cidx]
        clusters = {}
        for name, d in (("top", -1), ("bottom", 1)):
            level, tests, spread, pair = judge_read.find_level(b15, atr15, d, cidx)
            if pair is None:
                clusters[name] = None
                continue
            clusters[name] = {
                "level": to_idx(level),
                "tests": [{"rel": rel_label(T, t["t"]), "extreme": to_idx(t["extreme"])}
                          for t in tests],
                "pair": [rel_label(T, pair[0]["t"]), rel_label(T, pair[1]["t"])],
            }
        q["clusters"] = clusters
        print(f"{q['id']} 簇：高点={'有' if clusters['top'] else '无'}"
              f"（{0 if not clusters['top'] else len(clusters['top']['tests'])}次） "
              f"低点={'有' if clusters['bottom'] else '无'}"
              f"（{0 if not clusters['bottom'] else len(clusters['bottom']['tests'])}次）",
              flush=True)
    with open(path, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    print("已写回 第一期-20题.json")


if __name__ == "__main__":
    main()
