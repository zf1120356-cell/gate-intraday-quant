#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
读盘训练第二期——选 20 道题并生成题库（只选、不验证规则、不汇总收益）。
只练第一期弱项（第 3 项拒绝成立、考虑方向选取），其余与第一期同法。
选法（跑前写死）：
  YES 10 道（做多 5、做空 5）：6 项清单前 5 项全通过，且主观锚位盈亏比落在 1.5–3；
    优先 Q01 型——探针触及参考位 ±0.25xATR15 的带、未越线、自己收回（第一期
    Q01/Q06/Q09 错题型：我曾要求探针必须越线）。
  NO 10 道：单项不通过为主——拒绝 4、结构 2、位子 1、事前检查 1、强度 1、
    方向一致性 1。
    拒绝 4 道优先 Q13 型（探针越线但自己没收回区内）与 Q16 型（反方向也有位子簇，
    容易按离得近的簇反推方向）；结构 2 道优先反方向有位子簇的。
  方向一致性 1 道：取清单全通过的候选，题干早上偏向设为与方向相反，参考答案为 NO（第 6 项）。
  其余题干早上偏向：17 道无偏向、2 道与方向一致（参考 YES）。
  每币最多 3 道；优先不同日期；答案窗口 8 根 15m（T 之后），与题干严格分开。
  止损可见性：YES/NO6 候选的 SL 与探针极值在指数单位下差距 <0.001 的跳过
    （第一期 Q19 教训：4 位小数显示下缓冲不可见，参考答案自相矛盾）。
价格一律换算为指数（题干首根 1h 收盘 = 100.0000），币种名与时间戳不进题干与答案。
输出：第一期-20题.json（跑题脚本用，含币种/时间戳档案备查）与 第一期-20题.md（ workbook，答案在内）。
"""
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGE_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/开发-主观判断")
sys.path.insert(0, JUDGE_DIR)
import judge_read  # noqa: E402

ITEM_NAME = {1: "结构对齐", 2: "位子合格", 3: "拒绝成立",
             4: "事前检查", 5: "强度足够", 6: "方向一致性"}
CHECK_KEY = {"structure": 1, "level": 2, "rejection": 3, "precheck": 4, "strength": 5}


COINS2 = ["BTW", "ONDO", "AAVE", "JCT", "TRX", "GRAM", "INIT", "LIT"]  # 取数连续性校验后的最终 8 币（待 fetch_train2.py 确认）


def load_bars(sym, interval):
    with open(os.path.join(HERE, f"train2_{sym}_{interval}.json")) as f:
        return json.load(f)


def swing_points(bars1h):
    """1h 摆动高低点（分形：高于/低于相邻两根）。返回 ([highs], [lows])。"""
    hi, lo = [], []
    for i in range(1, len(bars1h) - 1):
        if bars1h[i]["h"] > bars1h[i - 1]["h"] and bars1h[i]["h"] > bars1h[i + 1]["h"]:
            hi.append(bars1h[i]["h"])
        if bars1h[i]["l"] < bars1h[i - 1]["l"] and bars1h[i]["l"] < bars1h[i + 1]["l"]:
            lo.append(bars1h[i]["l"])
    return hi, lo


def build_anchors(coin, d, T, bars15, bars1h, brief):
    """主观锚位（v3 §3.4）：SL 锚探针极值之外（+0.1xATR15 缓冲），TP 锚最近结构目标。
    ATR15 用 bars15 全精度重算（scan 记录里的 atr15 是 round(...,4)，小价币误差可达 40%+，
    不可直接用）。返回 None（无可用锚位，盈亏比到不了 1.5）或 dict。"""
    from judge_precheck import atr_wilder
    atrs = atr_wilder(bars15)
    atr15 = atrs[-1]
    if atr15 is None or atr15 <= 0:
        return None
    ref = brief["confirm"]["c"]
    probe = brief["probe"]
    if d == -1:
        sl = probe["h"] + 0.1 * atr15
    else:
        sl = probe["l"] - 0.1 * atr15
    sld = abs(sl - ref)
    if sld <= 0:
        return None
    # 结构目标：1h 摆动点 + 未填补 FVG 边（只用 T 及之前的数据）
    b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
    hi, lo = swing_points(b1h)
    fvgs = judge_read.fvg_edges(b1h)
    if d == -1:
        targets = sorted([x for x in lo if x < ref] +
                         [f["lo"] for f in fvgs if f["kind"] == "bull" and f["lo"] < ref],
                         reverse=True)  # 离 ref 最近的在前
        tgt_txt = {x: "摆动低点" for x in lo if x < ref}
        for f in fvgs:
            if f["kind"] == "bull" and f["lo"] < ref:
                tgt_txt[f["lo"]] = "看涨 FVG 下沿"
    else:
        targets = sorted([x for x in hi if x > ref] +
                         [f["hi"] for f in fvgs if f["kind"] == "bear" and f["hi"] > ref])
        tgt_txt = {x: "摆动高点" for x in hi if x > ref}
        for f in fvgs:
            if f["kind"] == "bear" and f["hi"] > ref:
                tgt_txt[f["hi"]] = "看跌 FVG 上沿"
    # 去重（相差 <0.05xATR15 视为同一目标）
    uniq = []
    for x in targets:
        if not uniq or abs(x - uniq[-1]) > 0.05 * atr15:
            uniq.append(x)
    tp = None
    tp_target = None
    tp_kind = None
    capped = False
    for x in uniq:
        rr = abs(x - ref) / sld
        if rr >= 1.5:
            if rr > 3.0:
                tp = ref - 3.0 * sld if d == -1 else ref + 3.0 * sld
                tp_target = x
                tp_kind = tgt_txt.get(x, "结构目标")
                capped = True
            else:
                tp = x
                tp_target = x
                tp_kind = tgt_txt.get(x, "结构目标")
            break
    if tp is None:
        return None
    rr = abs(tp - ref) / sld
    # 跑题脚本用的锚位检查清单
    if d == -1:
        sl_levels = sorted(set([probe["h"], brief["level"]] +
                               [x for x in hi if x > ref] +
                               [f["hi"] for f in fvgs if f["hi"] > ref]))
        tp_levels = sorted(set(uniq), reverse=True)
    else:
        sl_levels = sorted(set([probe["l"], brief["level"]] +
                               [x for x in lo if x < ref] +
                               [f["lo"] for f in fvgs if f["lo"] < ref]))
        tp_levels = sorted(set(uniq))
    return {"ref": ref, "sl": sl, "tp": tp, "rr": rr, "capped": capped,
            "sl_extreme": probe["h"] if d == -1 else probe["l"],
            "tp_target": tp_target, "tp_kind": tp_kind,
            "sl_levels": sl_levels, "tp_levels": tp_levels,
            "sld": sld}


def outcome_bars(ans_bars, d, ref, sl, tp):
    """答案窗口 8 根 15m：先到 SL 还是 TP；最大有利/不利（以 SL 距离为 1R）。
    口径：触发根只计触发那一侧的极值（根内先后顺序未知，另一侧不计）；
    未触发的根两侧都计；8 根走完未触发则全程都计。"""
    sld = abs(sl - ref)
    max_fav = 0.0
    max_adv = 0.0
    hit = None
    for b in ans_bars:
        if d == -1:
            fav = (ref - b["l"]) / sld
            adv = (b["h"] - ref) / sld
            if b["h"] >= sl:
                hit = "SL"
                max_adv = max(max_adv, adv)
                break
            if b["l"] <= tp:
                hit = "TP"
                max_fav = max(max_fav, fav)
                break
        else:
            fav = (b["h"] - ref) / sld
            adv = (ref - b["l"]) / sld
            if b["l"] <= sl:
                hit = "SL"
                max_adv = max(max_adv, adv)
                break
            if b["h"] >= tp:
                hit = "TP"
                max_fav = max(max_fav, fav)
                break
        max_fav = max(max_fav, fav)
        max_adv = max(max_adv, adv)
    return {"hit": hit or "均未触及", "max_fav_R": round(max_fav, 2),
            "max_adv_R": round(max_adv, 2)}


def idx_scale(bars1h_stem):
    """指数换算：题干首根 1h 收盘 = 100。返回换算函数。"""
    base = bars1h_stem[0]["c"]
    return lambda x: round(x / base * 100.0, 4)


def main():
    scan = json.load(open(os.path.join(HERE, "scan_results2.json")))
    bars_cache = {}
    for coin in COINS2:
        bars_cache[coin] = (load_bars(coin, "15m"), load_bars(coin, "1h"))

    # ---- 1. YES 候选：算锚位，过滤盈亏比 ----
    yes_pool = {"short": [], "long": []}
    no_single = defaultdict(list)   # item -> 候选（仅该项不通过）
    no_multi = []
    for r in scan:
        fails = [CHECK_KEY[k] for k, v in r["checks"].items()
                 if k != "pd" and not v["ok"]]
        if r["decision"] == "write":
            yes_pool["short" if r["direction"] == -1 else "long"].append(r)
        elif len(fails) == 1:
            no_single[fails[0]].append(r)
        else:
            no_multi.append(r)
    print("YES 池：做空", len(yes_pool["short"]), "做多", len(yes_pool["long"]))
    print("单项不通过池：", {k: len(v) for k, v in sorted(no_single.items())})

    # YES 锚位过滤 + Q01 型标志（探针触及带、未越线、自己收回）+ 止损可见性
    from judge_precheck import atr_wilder as _aw2
    yes_ok = {"short": [], "long": []}
    for key in ("short", "long"):
        for r in yes_pool[key]:
            coin, T, d = r["coin"], r["T"], r["direction"]
            bars15, bars1h = bars_cache[coin]
            b15 = [b for b in bars15 if b["t"] <= T]
            b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
            a = build_anchors(coin, d, T, b15, b1h, r)
            if a is None:
                continue
            # 止损可见性：SL 与探针极值在指数单位下差距 >= 0.001（第一期 Q19 教训）
            stem_base = b1h[-24:][0]["c"]
            probe_ext = r["probe"]["h"] if d == -1 else r["probe"]["l"]
            if abs(a["sl"] - probe_ext) / stem_base * 100.0 < 0.001:
                continue
            r = dict(r)
            r["anchors"] = a
            # Q01 型：探针触及带但未越线（全精度 ATR15 判定）
            atr15_full = _aw2(b15)[-1]
            lv = r["level"]
            pr = r["probe"]
            if d == -1:
                r["is_q01"] = bool(pr["h"] < lv and pr["h"] >= lv - 0.25 * atr15_full)
            else:
                r["is_q01"] = bool(pr["l"] > lv and pr["l"] <= lv + 0.25 * atr15_full)
            yes_ok[key].append(r)
    print("YES 锚位通过（盈亏比 1.5–3）：做空", len(yes_ok["short"]),
          "做多", len(yes_ok["long"]))
    print("其中 Q01 型（触及带未越线）：做空",
          sum(1 for r in yes_ok["short"] if r.get("is_q01")),
          "做多", sum(1 for r in yes_ok["long"] if r.get("is_q01")))
    # NO 池弱项分类：Q13 型（越线未收回）与反方向簇（Q16 型诱因）
    from judge_precheck import atr_wilder as _aw3
    for item, pool in list(no_single.items()):
        for r in pool:
            coin, T, d = r["coin"], r["T"], r["direction"]
            bars15, bars1h = bars_cache[coin]
            b15 = [b for b in bars15 if b["t"] <= T]
            pr, lv = r["probe"], r["level"]
            if d == -1:
                r["is_q13"] = bool(pr["h"] >= lv and pr["c"] >= lv)
            else:
                r["is_q13"] = bool(pr["l"] <= lv and pr["c"] <= lv)
            # 反方向位子簇是否存在（find_level 对反方向）
            cidx = next(i for i, b in enumerate(b15) if b["t"] == T)
            atr15_f = _aw3(b15)[cidx]
            _lv2, _t2, _s2, pair2 = judge_read.find_level(b15, atr15_f, -d, cidx)
            r["has_opp_cluster"] = pair2 is not None
    print("NO 拒绝池 Q13 型：",
          sum(1 for r in no_single[3] if r.get("is_q13")),
          "；有反方向簇：",
          sum(1 for r in no_single[3] if r.get("has_opp_cluster")))
    print("NO 结构池有反方向簇：",
          sum(1 for r in no_single[1] if r.get("has_opp_cluster")))

    # ---- 2. 按配额选 ----
    # 配额（第二期，只练弱项）：YES 做空 5、做多 5（优先 Q01 型）；
    #   NO 拒绝 4（优先 Q13/Q16 型）、结构 2、位子 1、事前 1、强度 1、方向一致性 1
    # 方向一致性 1 道从 YES 池另取（早上偏向设为相反，参考答案 NO）
    # 其余题干早上偏向：17 道无偏向、2 道与方向一致（参考 YES）
    chosen = []          # (record, kind, morning_bias)
    coin_count = defaultdict(int)
    used_coin_day = set()  # (coin, UTC date)：同一币同一天最多 1 道，避免题干重叠

    def pick(pool, n, kind, bias_fn, rank_fn=None):
        """按币轮流、日期分散取 n 个。rank_fn(r) 越小越优先（同币内先取弱项型）。"""
        pool = sorted(pool, key=lambda r: (r["coin"], r["T"]))
        # 按币分组轮流取，保证币种分散
        by_coin = defaultdict(list)
        for r in pool:
            by_coin[r["coin"]].append(r)
        for c in by_coin:
            if rank_fn is None:
                by_coin[c].sort(key=lambda r: r["T"])
            else:
                by_coin[c].sort(key=lambda r: (rank_fn(r), r["T"]))
        taken = []
        idx = {c: 0 for c in by_coin}
        order = sorted(by_coin)
        guard = 0
        while len(taken) < n and guard < 500:
            guard += 1
            progressed = False
            for c in order:
                if len(taken) >= n:
                    break
                if coin_count[c] >= 3:
                    continue
                lst = by_coin[c]
                if idx[c] >= len(lst):
                    continue
                # 日期分散：同一币同一 UTC 日最多 1 道（全局）
                r = lst[idx[c]]
                idx[c] += 1
                day = datetime.fromtimestamp(r["T"], timezone.utc).date()
                if (c, day) in used_coin_day:
                    continue
                taken.append(r)
                coin_count[c] += 1
                used_coin_day.add((c, day))
                progressed = True
            if not progressed:
                break
        for r in taken:
            chosen.append((r, kind, bias_fn(r)))
        return taken

    pick(yes_ok["short"], 5, "YES", lambda r: None,
         rank_fn=lambda r: 0 if r.get("is_q01") else 1)
    pick(yes_ok["long"], 5, "YES", lambda r: None,
         rank_fn=lambda r: 0 if r.get("is_q01") else 1)
    pick(no_single[1], 2, "NO", lambda r: None,
         rank_fn=lambda r: 0 if r.get("has_opp_cluster") else 1)
    pick(no_single[2], 1, "NO", lambda r: None)
    pick(no_single[3], 4, "NO", lambda r: None,
         rank_fn=lambda r: 0 if (r.get("is_q13") or r.get("has_opp_cluster")) else 1)
    pick(no_single[4], 1, "NO", lambda r: None)
    pick(no_single[5], 1, "NO", lambda r: None)
    # 方向一致性：从 YES 池取 1 个（与已选的不重 T），早上偏向设为相反
    used_T = {(r["coin"], r["T"]) for r, _, _ in chosen}
    item6_pool = [r for k in ("short", "long") for r in yes_ok[k]
                  if (r["coin"], r["T"]) not in used_T]
    pick(item6_pool, 1, "NO6", lambda r: 1 if r["direction"] == -1 else -1)
    # 早上偏向对齐的 2 道：把已选 YES 里的 2 道（1 空 1 多）设为对齐偏向
    aligned = 0
    for i, (r, kind, bias) in enumerate(chosen):
        if kind == "YES" and aligned < 2:
            # 挑一空一多
            if aligned == 0 and r["direction"] == -1:
                chosen[i] = (r, kind, r["direction"]); aligned += 1
            elif aligned == 1 and r["direction"] == 1:
                chosen[i] = (r, kind, r["direction"]); aligned += 1
    print("已选：", len(chosen), "道；每币计数：", dict(coin_count))

    # ---- 3. 生成题库 ----
    questions = []
    for qi, (r, kind, bias) in enumerate(sorted(chosen, key=lambda x: (x[0]["coin"], x[0]["T"])), start=1):
        coin, T, d = r["coin"], r["T"], r["direction"]
        bars15, bars1h = bars_cache[coin]
        b15 = [b for b in bars15 if b["t"] <= T]
        b1h = [b for b in bars1h if b["t"] + 3600 <= T + 900]
        stem1h = b1h[-24:]
        stem15 = b15[-16:]
        ans15 = [b for b in bars15 if T < b["t"] <= T + 8 * 900]
        assert len(stem1h) == 24 and len(stem15) == 16 and len(ans15) == 8, \
            (coin, T, len(stem1h), len(stem15), len(ans15))
        to_idx = idx_scale(stem1h)
        ref = r["confirm"]["c"]
        # 位子测试史（重算，相对时间标签；题干只给相对时间）
        # ATR15 用全精度（scan 记录里的值是 round(...,4)，不可直接用）
        from judge_precheck import atr_wilder as _aw
        _atr15_full = _aw(b15)[-1]
        tests_list, _sp = judge_read.level_tests(b15, r["level"], _atr15_full, d, T)
        tests_idx = []
        for t in tests_list:
            mins = (T - t["t"]) // 60
            tests_idx.append({"rel": f"T-{mins // 60}h{mins % 60:02d}m",
                              "extreme": to_idx(t["extreme"])})
        # 参考锚位文本（指数单位，与题干一致，不用原始价）
        # r["anchors"] 在选定阶段已算好（YES/NO6 有，NO 无）
        a = r.get("anchors")
        if a is not None:
            sl_txt = (f"探针{'高' if d == -1 else '低'}点 {to_idx(a['sl_extreme'])} 之外 "
                      f"{'+' if d == -1 else '−'}0.1xATR15")
            if a["capped"]:
                tp_txt = (f"按 3 倍封顶（最近结构目标 {to_idx(a['tp_target'])} 在 3 倍之外）")
            else:
                tp_txt = f"{a['tp_kind']} {to_idx(a['tp_target'])}"
            anchors_out = {"sl": to_idx(a["sl"]), "tp": to_idx(a["tp"]),
                           "rr": round(a["rr"], 2), "capped": a["capped"],
                           "sl_anchor_txt": sl_txt, "tp_txt": tp_txt,
                           "sl_levels": [to_idx(x) for x in a["sl_levels"]],
                           "tp_levels": [to_idx(x) for x in a["tp_levels"]]}
        else:
            anchors_out = None
        # 参考答案
        if kind == "YES":
            setup, ref_dir = True, d
            fail_items, fail_reason = [], ""
            anchors = r["anchors"]
            oc = outcome_bars(ans15, d, ref, anchors["sl"], anchors["tp"])
        elif kind == "NO6":
            setup, ref_dir = False, d
            fail_items = [6]
            fail_reason = ("第 6 项方向一致性不通过：题干早上计划偏向为"
                           f"{'做多' if bias == 1 else '做空'}，与判断方向"
                           f"{'做空' if d == -1 else '做多'}相反；其余 5 项全部通过。")
            anchors = r["anchors"]
            oc = outcome_bars(ans15, d, ref, anchors["sl"], anchors["tp"])
        else:
            setup, ref_dir = False, None
            fails = [CHECK_KEY[k] for k, v in r["checks"].items()
                     if k != "pd" and not v["ok"]]
            fail_items = fails
            fail_reason = r["reason"]
            anchors = None
            oc = None
        # 结构事实（题干用）
        b1h_closed = b1h
        struct_ok, struct_txt = judge_read.structure_1h(b1h_closed, d, r["atr1h"])
        pd_pct, pd_txt = judge_read.premium_discount(b1h_closed)
        fvgs = judge_read.fvg_edges(b1h_closed)
        hi, lo = swing_points(b1h_closed)
        q = {
            "id": f"Q{qi:02d}",
            "coin": coin, "T": T, "direction": d,
            "kind": kind, "morning_bias": bias,
            "stem_1h": [{"label": f"H-{24 - i}", "o": to_idx(b["o"]), "h": to_idx(b["h"]),
                         "l": to_idx(b["l"]), "c": to_idx(b["c"])} for i, b in enumerate(stem1h)],
            "stem_15m": [{"label": f"M-{16 - i}", "o": to_idx(b["o"]), "h": to_idx(b["h"]),
                          "l": to_idx(b["l"]), "c": to_idx(b["c"])} for i, b in enumerate(stem15)],
            "atr1h_idx": round(r["atr1h"] / stem1h[0]["c"] * 100.0, 4),
            "atr15_idx": round(_atr15_full / stem1h[0]["c"] * 100.0, 4),
            "level_idx": to_idx(r["level"]),
            "test_count": len(tests_idx),
            "tests_idx": tests_idx,
            "probe_idx": {"o": to_idx(r["probe"]["o"]), "h": to_idx(r["probe"]["h"]),
                          "l": to_idx(r["probe"]["l"]), "c": to_idx(r["probe"]["c"]),
                          "wick_x": r["probe"]["wick_x"]},
            "confirm_idx": {"o": to_idx(r["confirm"]["o"]), "h": to_idx(r["confirm"]["h"]),
                            "l": to_idx(r["confirm"]["l"]), "c": to_idx(r["confirm"]["c"]),
                            "move_x": r["confirm"]["move_x"]},
            "structure_txt": struct_txt,
            "pd_pct": None if pd_pct is None else round(pd_pct, 1),
            "pd_txt": pd_txt,
            "fvg_idx": [{"kind": f["kind"], "lo": to_idx(f["lo"]), "hi": to_idx(f["hi"])}
                        for f in fvgs[-6:]],
            "swing_high_idx": [to_idx(x) for x in hi[-4:]],
            "swing_low_idx": [to_idx(x) for x in lo[-4:]],
            "ref_idx": to_idx(ref),
            "setup": setup, "ref_direction": ref_dir,
            "fail_items": fail_items, "fail_reason": fail_reason,
            "anchors": anchors_out,
            "answer_15m": [{"label": f"M+{i + 1}", "o": to_idx(b["o"]), "h": to_idx(b["h"]),
                            "l": to_idx(b["l"]), "c": to_idx(b["c"])} for i, b in enumerate(ans15)],
            "outcome": oc,
            "checks_txt": {k: v["txt"] for k, v in r["checks"].items()},
        }
        questions.append(q)
    with open(os.path.join(HERE, "第二期-20题.json"), "w") as f:
        json.dump({"coins": COINS2,
                   "questions": questions}, f, ensure_ascii=False, indent=1)
    print(f"已生成 {len(questions)} 道题，写入 第二期-20题.json")
    for q in questions:
        print(f"  {q['id']} {q['kind']:4s} 方向={'空' if q['direction'] == -1 else '多'} "
              f"setup={'有' if q['setup'] else '无'} fail={q['fail_items']} "
              f"偏向={q['morning_bias']} outcome={None if q['outcome'] is None else q['outcome']['hit']}")


if __name__ == "__main__":
    main()
