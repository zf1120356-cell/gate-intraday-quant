#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分系统盘中主观判断——定时任务入口（sub_judge_tick.py）
====================================================
归属：分系统 SUB-SMC v1.2。每 15 分钟（对齐 15m 收盘）跑一次，流程：
  1. 全天跑（00:00–24:00 UTC；分系统无 23:00 强平）。夜禁时段
     （UTC 17:00–23:00 = 北京时间 01:00–07:00）仍跑预检与读盘、
     留观察记录，但不写触发（write_trigger 会拒掉，记一笔夜禁跳过）。
  2. 轻量预检（sub_judge_precheck）：8 个币最近 15m 是否有候选。
     无候选 → 只记一行日志，退出（省算力）。
  3. 有候选 → 对每个候选做完整主观读盘（sub_judge_read.brief + decide）。
     结论为 write 时：
       a. 方向一致性：与早上偏向相反 → 不写，记日志。
       b. 偏向失效检查：自数据截止后已有 1h 收盘越过早上计划该币的
          失效价 → 偏向作废，不写，记日志。
       c. 调 write_trigger 写进当日分系统计划文件“盘中补充触发”小节
          （写前校验：不在夜禁时段、不跨日、当日无已有补充触发、
          早上偏向未成交、引擎 state 里该币无分系统登记/持仓；
          引擎已支持 mtime 重读与解析，不改引擎、不重启引擎）。
  4. 每步都写日志（JSON 行），日志在 --log 指定的文件；无候选也只记一行。
     日志里记候选属于哪个时段（亚洲/欧洲/美盘）。

用法（cron 每 15 分钟）：
  python3 sub_judge_tick.py [--source gate|file] [--data-dir DIR]
      [--plan-file PATH] [--log PATH] [--now-ts SEC]
  --source file 时用缓存数据（离线调试用）；默认 gate（拉 Gate 公开接口）。
  --now-ts 用于测试（指定“现在”的 UTC 秒）；默认用真实当前时间。
  --plan-file 默认取当日分系统计划
    ~/workspace/赚钱路子/纸面交易/分系统计划/YYYY-MM-DD.md
    （按 UTC 日期；若文件不存在，方向一致性跳过、只按其余规则判断）。
"""
import argparse
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sub_judge_precheck as jp  # noqa: E402
import sub_judge_read as jr  # noqa: E402

COINS = jp.COINS
LOG_DEFAULT = os.path.expanduser("~/workspace/赚钱路子/纸面交易/分系统主观判断.log")


def log_line(log_path, obj):
    obj["ts"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    line = json.dumps(obj, ensure_ascii=False)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line)


def today_plan_path(now_utc):
    d = now_utc.strftime("%Y-%m-%d")
    return os.path.join(jr.PLAN_DIR, f"{d}.md")


def run_tick(source="gate", data_dir=None, plan_file=None, log_path=LOG_DEFAULT,
             now_ts=None):
    now = (datetime.fromtimestamp(now_ts, tz=timezone.utc) if now_ts
           else datetime.now(timezone.utc))
    # 1. 全天跑（分系统无 23:00 强平）；夜禁时段只观察、不写触发
    #    （write_trigger 会拒掉待入场落在夜禁时段的触发）。
    plan = plan_file or today_plan_path(now)
    plan_dirs = jr.plan_directions(plan) if os.path.exists(plan) else {}
    # 2. 预检（只用已收盘的 15m/1h；进行中那根不算）
    now_floor15 = int(now.timestamp()) // 900 * 900
    cands = []
    data = {}
    for coin in COINS:
        try:
            if source == "gate":
                bars15 = jp.fetch_gate_15m(f"{coin}_USDT")
                bars1h = jr.fetch_gate_1h(f"{coin}_USDT")
            else:
                bars15 = jp.load_file_15m(data_dir, coin)
                bars1h = jr.load_file_1h(data_dir, coin)
        except Exception as e:
            log_line(log_path, {"event": "fetch_fail", "coin": coin,
                                "error": str(e)})
            continue
        bars15 = [b for b in bars15 if b["t"] + 900 <= now_floor15]
        bars1h = [b for b in bars1h if b["t"] + 3600 <= now_floor15]
        if not bars15:
            continue
        data[coin] = (bars15, bars1h)
        cands.extend(jp.precheck_coin(bars15, coin))
    if not cands:
        log_line(log_path, {"event": "no_candidate",
                            "time_utc": now.strftime("%H:%M")})
        return {"event": "no_candidate", "candidates": 0}
    # 3. 完整读盘 + 判断 + 写
    results = []
    for cand in cands:
        coin = cand["coin"]
        direction = cand["direction"]
        bars15, bars1h = data[coin]
        # 确认根 = 最近已收盘根
        confirm_t = bars15[-1]["t"]
        b = jr.brief(coin, direction, confirm_t, bars15, bars1h,
                     plan_path=plan if os.path.exists(plan) else None)
        dec, reason, checks = jr.decide(b)
        rec = {"event": "judge", "coin": coin, "direction": direction,
               "time_utc": now.strftime("%H:%M"),
               "session": jr.session_name(confirm_t),
               "decision": dec, "reason": reason}
        if dec == "write":
            # a. 方向一致性
            pd = plan_dirs.get(coin)
            blocked = False
            if pd is not None and pd != direction:
                rec["write"] = False
                rec["write_msg"] = (f"{coin} 早上偏向"
                                    f"{'做多' if pd == 1 else '做空'}，方向相反，不写")
                blocked = True
            # b. 偏向失效检查（有计划文件时才查）
            if not blocked and os.path.exists(plan):
                inv, inv_msg = jr.bias_invalidated(plan, coin, bars1h, confirm_t)
                if inv:
                    rec["write"] = False
                    rec["write_msg"] = inv_msg
                    blocked = True
            if not blocked:
                trig = jr.build_trigger(b, reason)
                ok, msg = jr.write_trigger(plan, trig)
                rec["write"] = ok
                rec["write_msg"] = msg
                if ok:
                    rec["trigger"] = {"pending_entry_t": trig["pending_entry_t"],
                                      "ref_entry": trig["ref_entry"],
                                      "sl": trig["sl"], "tp": trig["tp"]}
        log_line(log_path, rec)
        results.append(rec)
    return {"event": "judged", "candidates": len(cands), "results": results}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", choices=["gate", "file"], default="gate")
    ap.add_argument("--data-dir", default=None)
    ap.add_argument("--plan-file", default=None)
    ap.add_argument("--log", default=LOG_DEFAULT)
    ap.add_argument("--now-ts", type=int, default=None)
    args = ap.parse_args()
    res = run_tick(source=args.source, data_dir=args.data_dir,
                   plan_file=args.plan_file, log_path=args.log,
                   now_ts=args.now_ts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
