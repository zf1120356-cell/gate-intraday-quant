#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分系统盘中主观判断——离线验证（test_sub_judge_replay.py）
====================================================
用 2026-11-20 的真实 15m/1h 数据（取自 paper_2026-11-22_raw.json，
覆盖 11-18 23:00 至 11-21 00:45），按时间顺序重放分系统判断流程。
不碰 live 引擎、不碰主窗口、不改真实计划文件（只写计划副本）。

偏向/失效条件来源：2026-11-20 当天分系统无计划文件（首份是 11-21），
故用当天主计划 `~/workspace/赚钱路子/纸面交易/2026-11-20.md` 的副本
作偏向与 ATR 来源（主计划 ETH 偏向做空、失效价 1,822、ATR 19.28，
与主系统判断层离线验证同一口径）。重放只读副本的偏向/失效/ATR，
触发只写进副本的“盘中补充触发”小节。

分系统与主系统的预期差异（设计 v1.2 (b)(c)；文档时间均为北京时间，
重放内部一律 UTC）：
  - ETH 22:00（北京时间）处：判断结论应与主系统一致（write，ref 1733.45、
    SL 1752.73、TP 1694.89，待入场 14:45 UTC）；待入场不在夜禁内
    （夜禁 UTC 17:00–23:00），夜禁不挡这一处。写出会被去重拦下——
    主计划原文已含主系统写的一条 ETH 行（副本开局即带），这是共用上限
    去重的正确行为，不是分系统逻辑失败。
  - SOL 11:15 UTC 处：判断结论应与主系统一致（write），但偏向失效检查
    应拦下——11-19 06:00 1h 收盘 75.1 上破 SOL 失效价 75.08（实测数据），
    做空偏向在交易日前已作废。这是分系统新增检查按设计工作。
  - ETH 09:00（北京时间）处：判断结论应与主系统一致（no，仅强度一项不通过）。
  - 其余 5 条（BTC/XRP 02:00、DOGE/LINK/ADA 07:30 UTC）应与主系统重放表
    逐值一致地写出。

用法：
  python3 test_sub_judge_replay.py [--day 2026-11-20]
数据提取：首次运行自动从 paper_2026-11-22_raw.json 提取 per-coin 文件到
/tmp/sub_judge_test/nov20/（{COIN}_15m.json / {COIN}_1h.json）。

输出：JSON 到 stdout（含每步的候选、简报结论、理由、写出/拒写结果），
并在末尾给验收结论（PASS/FAIL + 原因）。
"""
import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sub_judge_precheck import precheck_coin, load_file_15m  # noqa: E402
import sub_judge_read as jr  # noqa: E402

COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]
RAW = os.path.expanduser("~/workspace/赚钱路子/data/paper_2026-11-22_raw.json")
MAIN_PLAN_1120 = os.path.expanduser("~/workspace/赚钱路子/纸面交易/2026-11-20.md")


def extract_data(data_dir):
    """从 paper_2026-11-22_raw.json 提取 per-coin 15m/1h 文件。"""
    if all(os.path.exists(os.path.join(data_dir, f"{c}_15m.json")) for c in COINS):
        return
    os.makedirs(data_dir, exist_ok=True)
    with open(RAW, encoding="utf-8") as f:
        raw = json.load(f)
    for coin in COINS:
        for interval, key in (("15m", "candles_15m"), ("1h", "candles_1h")):
            rows = [{"t": r[0], "o": r[1], "h": r[2], "l": r[3], "c": r[4]}
                    for r in raw[key][coin]]
            with open(os.path.join(data_dir, f"{coin}_{interval}.json"), "w") as f:
                json.dump(rows, f)
    print(f"已从 {RAW} 提取数据到 {data_dir}（fetched_at_utc={raw.get('fetched_at_utc')}）",
          file=sys.stderr)


def day_bounds(day_str):
    """交易日 00:00–24:00 UTC（秒）。分系统无 23:00 强平，全天跑。"""
    d = datetime.strptime(day_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return int(d.timestamp()), int((d + timedelta(hours=24)).timestamp())


def replay_day(day_str, data_dir, plan_file, plan_copy):
    extract_data(data_dir)
    start_t, end_t = day_bounds(day_str)
    data = {}
    for coin in COINS:
        b15 = load_file_15m(data_dir, coin)
        b1h = jr.load_file_1h(data_dir, coin)
        data[coin] = (b15, b1h)
    # 计划副本（只写副本，不碰原文）；记下早上计划表的原文以便校验一字不变。
    # 注意：主计划原文第 273 行起已含主系统写的一条 ETH 补充触发行（14:30/14:45，
    # ref 1733.45），副本开局即带这一行；分系统判断对 ETH 的写出会被去重拦下，
    # 这是“共用上限”去重的正确行为，不是分系统逻辑失败。
    shutil.copy(plan_file, plan_copy)
    with open(plan_copy, encoding="utf-8") as f:
        before_text = f.read()
    supp_before = (jr.supp_observer.parse_supp_triggers(before_text)
                   if jr.SUPP_OK else [])
    table_before = before_text.split("## 计划表")[1].split("## ")[0] if "## 计划表" in before_text else ""
    plan_dirs = jr.plan_directions(plan_file)
    eth15 = data["ETH"][0]
    closes = sorted({b["t"] + 900 for b in eth15 if start_t <= b["t"] + 900 < end_t})
    events = []
    written = {}
    night_skips = []
    candidates_total = 0
    for close_t in closes:
        for coin in COINS:
            b15, b1h = data[coin]
            bars15 = [b for b in b15 if b["t"] + 900 <= close_t]
            if len(bars15) < 20:
                continue
            bars1h = [b for b in b1h if b["t"] + 3600 <= close_t]
            cands = precheck_coin(bars15, coin)
            if not cands:
                continue
            candidates_total += len(cands)
            for cand in cands:
                direction = cand["direction"]
                confirm_t = close_t - 900
                b = jr.brief(coin, direction, confirm_t, bars15, bars1h,
                             plan_path=plan_file)
                dec, reason, checks = jr.decide(b)
                ev = {"time_utc": datetime.fromtimestamp(close_t, tz=timezone.utc).strftime("%H:%M"),
                      "coin": coin, "direction": direction,
                      "kinds": cand["kinds"], "decision": dec, "reason": reason,
                      "session": jr.session_name(confirm_t),
                      "brief_level": b.get("level"), "test_count": b.get("test_count"),
                      "probe_wick_x": (b.get("probe") or {}).get("wick_x"),
                      "confirm_move_x": (b.get("confirm") or {}).get("move_x")}
                if dec == "write":
                    pd = plan_dirs.get(coin)
                    if pd is not None and pd != direction:
                        ev["write"] = False
                        ev["write_msg"] = (f"{coin} 早上偏向"
                                           f"{'做多' if pd == 1 else '做空'}，方向相反，不写")
                    elif coin in written:
                        ev["write"] = False
                        ev["write_msg"] = f"{coin} 当天已有补充触发，跳过（共用上限）"
                    else:
                        # 偏向失效检查（SUB 新增）
                        inv, inv_msg = jr.bias_invalidated(plan_copy, coin, bars1h, confirm_t)
                        if inv:
                            ev["write"] = False
                            ev["write_msg"] = inv_msg
                        else:
                            trig = jr.build_trigger(b, reason)
                            # 触发数值先记下来（写出被拒时也要能核对数值是否与主系统一致）
                            ev["trigger"] = {
                                "pending_entry_t": datetime.fromtimestamp(
                                    trig["pending_entry_t"], tz=timezone.utc).strftime("%H:%M"),
                                "ref_entry": trig["ref_entry"],
                                "sl": trig["sl"], "tp": trig["tp"]}
                            ok, msg = jr.write_trigger(plan_copy, trig, lock_path=None)
                            ev["write"] = ok
                            ev["write_msg"] = msg
                            if ok:
                                written[coin] = trig
                            elif "夜禁" in msg:
                                night_skips.append({"coin": coin,
                                                    "confirm_utc": ev["time_utc"],
                                                    "pending_entry_t": ev["trigger"]["pending_entry_t"],
                                                    "ref_entry": trig["ref_entry"]})
                events.append(ev)
    with open(plan_copy, encoding="utf-8") as f:
        after_text = f.read()
    table_after = after_text.split("## 计划表")[1].split("## ")[0] if "## 计划表" in after_text else ""
    supp_after = (jr.supp_observer.parse_supp_triggers(after_text)
                  if jr.SUPP_OK else [])
    return {"day": day_str, "candidates_total": candidates_total,
            "events": events, "written": written, "night_skips": night_skips,
            "table_unchanged": table_before == table_after,
            "supp_rows_before": len(supp_before),
            "supp_rows_after": len(supp_after),
            "supp_rows_written": len(supp_after) - len(supp_before)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day", default="2026-11-20")
    ap.add_argument("--data-dir", default="/tmp/sub_judge_test/nov20")
    ap.add_argument("--plan-copy", default="/tmp/sub_judge_test/plan_copy_2026-11-20.md")
    args = ap.parse_args()
    report = replay_day(args.day, args.data_dir, MAIN_PLAN_1120, args.plan_copy)
    # 验收（时间一律 UTC；主系统文档里的“09:00/22:00”是北京时间，
    # 对应 UTC 01:15 / 14:30 确认根，待入场 01:30 / 14:45 UTC）
    checks = []
    # ETH 09:00（北京时间）= 确认根 01:15 UTC：判断为 no（强度）
    eth_0900 = [e for e in report["events"] if e["coin"] == "ETH"
                and e["time_utc"] in ("01:15", "01:30")]
    checks.append(("ETH 09:00（北京时间）处判断为 no（与主系统一致）",
                   bool(eth_0900) and all(e["decision"] == "no" for e in eth_0900)))
    # ETH 22:00（北京时间）= 确认根 14:30 UTC、待入场 14:45 UTC：
    # 判断为 write，数值与主系统一致（ref 1733.45 / SL 1752.73 / TP 1694.89，
    # ATR 19.28）；写出被去重拦下是因为副本开局已含主系统的 ETH 行
    eth_2200 = [e for e in report["events"] if e["coin"] == "ETH"
                and e["time_utc"] == "14:45" and e["decision"] == "write"]
    if eth_2200:
        trig = eth_2200[0].get("trigger", {})
        checks.append(("ETH 22:00（北京时间）处判断为 write（与主系统一致）", True))
        checks.append(("ETH 触发数值与主系统一致（ref 1733.45 / SL 1752.73 / TP 1694.89）",
                       abs(trig.get("ref_entry", 0) - 1733.45) < 0.01
                       and abs(trig.get("sl", 0) - 1752.73) < 0.01
                       and abs(trig.get("tp", 0) - 1694.89) < 0.01))
        checks.append(("ETH 写出被去重拦下（副本开局已含主系统 ETH 行）",
                       eth_2200[0].get("write") is False
                       and "已有补充触发" in (eth_2200[0].get("write_msg") or "")))
        checks.append(("ETH 22:00（北京时间）待入场 14:45 UTC 不在夜禁内（夜禁不挡这一处）",
                       len([n for n in report["night_skips"] if n["coin"] == "ETH"]) == 0))
    else:
        checks.append(("ETH 22:00（北京时间）处判断为 write（与主系统一致）", False))
        checks.append(("ETH 触发数值与主系统一致（ref 1733.45 / SL 1752.73 / TP 1694.89）", False))
        checks.append(("ETH 写出被去重拦下（副本开局已含主系统 ETH 行）", False))
        checks.append(("ETH 22:00（北京时间）待入场 14:45 UTC 不在夜禁内（夜禁不挡这一处）", False))
    # SOL 11:15 UTC：判断为 write，但偏向失效检查拦下（11-19 06:00 1h 收盘
    # 75.1 上破失效价 75.08，实测数据）——分系统新增检查按设计工作
    sol_1115 = [e for e in report["events"] if e["coin"] == "SOL"
                and e["time_utc"] == "11:15" and e["decision"] == "write"]
    checks.append(("SOL 11:15 UTC 判断为 write 但被偏向失效拦下（11-19 06:00 1h 收盘 75.1>75.08）",
                   bool(sol_1115) and sol_1115[0].get("write") is False
                   and "已失效" in (sol_1115[0].get("write_msg") or "")))
    # 其余 5 条与主系统重放表逐值一致（BTC/XRP 02:00、DOGE/LINK/ADA 07:30）
    expect = {"BTC": ("02:00", 61552.6), "XRP": ("02:00", 0.9528),
              "DOGE": ("07:30", 0.05735), "LINK": ("07:30", 8.841),
              "ADA": ("07:30", 0.1495)}
    for coin, (pend, ref) in expect.items():
        w = report["written"].get(coin)
        ok = (w is not None
              and w["pending_entry_t"] is not None
              and abs(w["ref_entry"] - ref) < max(0.01, abs(ref) * 0.001))
        checks.append((f"{coin} {pend} UTC 写出，ref={ref}（与主系统重放一致）", bool(ok)))
    checks.append(("新写 5 条（ETH 去重、SOL 偏向失效各拦 1 条）",
                   report["supp_rows_written"] == 5))
    checks.append(("早上计划表一字不变", report["table_unchanged"]))
    checks.append(("夜禁跳过 0 次（11-20 无 write 结论落夜禁）",
                   len(report["night_skips"]) == 0))
    report["acceptance"] = [{"name": n, "pass": p} for n, p in checks]
    report["acceptance_pass"] = all(p for _, p in checks)
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
    return 0 if report["acceptance_pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
