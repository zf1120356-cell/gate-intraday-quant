#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分系统盘中主观判断——单元测试（sub_judge_read / sub_judge_tick）。
只测分系统特有的改动（夜禁、跨日、偏向失效、时段、state 检查）与清单逻辑；
与主系统完全相同的预检/读盘逻辑只测一条合成拒绝（全量逻辑以离线重放为准）。
跑法：python3 test_sub_judge_unit.py（全部通过 exit 0，否则 exit 1）。
不联网、不碰真实计划文件与 live 状态（state 用临时文件 monkeypatch）。
"""
import json
import os
import sys
import tempfile
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sub_judge_read as jr
import sub_judge_precheck as jp

COINS = jp.COINS


def ts(y, mo, d, h, mi=0):
    return int(datetime(y, mo, d, h, mi, tzinfo=timezone.utc).timestamp())


def bar(t, o, h, l, c):
    return {"t": t, "o": o, "h": h, "l": l, "c": c}


# ----------------------------------------------------------------------
def test_session_name():
    """S1 时段划分：07:59 亚洲 / 08:00 欧洲 / 15:59 欧洲 / 16:00 美盘 / 00:00 亚洲。"""
    assert jr.session_name(ts(2026, 11, 20, 7, 59)) == "亚洲盘"
    assert jr.session_name(ts(2026, 11, 20, 8, 0)) == "欧洲盘"
    assert jr.session_name(ts(2026, 11, 20, 15, 59)) == "欧洲盘"
    assert jr.session_name(ts(2026, 11, 20, 16, 0)) == "美盘"
    assert jr.session_name(ts(2026, 11, 20, 23, 45)) == "美盘"
    assert jr.session_name(ts(2026, 11, 20, 0, 0)) == "亚洲盘"


def test_write_trigger_night_window():
    """S2 夜禁：待入场 18:00 UTC（北京时间 02:00）不写；16:45 UTC 可写。"""
    tmp = tempfile.mkdtemp()
    plan = os.path.join(tmp, "2026-11-20.md")
    with open(plan, "w") as f:
        f.write("# 分系统计划 2026-11-20\n数据截止：2026-11-20 00:47 UTC\n")
    trig = {"coin": "ETH", "direction": -1, "confirm_bar_t": ts(2026, 11, 20, 17, 45),
            "pending_entry_t": ts(2026, 11, 20, 18, 0), "level_txt": "测试",
            "ref_entry": 1750.0, "sl": 1770.0, "tp": 1710.0, "atr_1h": 20.0,
            "basis": "测试"}
    ok, msg = jr.write_trigger(plan, trig, lock_path=None)
    assert ok is False and "夜禁" in msg, (ok, msg)
    # 16:45 UTC（北京时间 00:45）不在夜禁内 → 可写
    trig2 = dict(trig, confirm_bar_t=ts(2026, 11, 20, 16, 30),
                 pending_entry_t=ts(2026, 11, 20, 16, 45))
    ok2, msg2 = jr.write_trigger(plan, trig2, lock_path=None)
    assert ok2 is True, (ok2, msg2)
    # 23:00 UTC（北京时间 07:00）不在夜禁内 → 可写（分系统无 23:00 强平；
    # 换一个币，避免与已写入的 trig2 同币去重冲突）
    trig3 = dict(trig, coin="SOL", confirm_bar_t=ts(2026, 11, 20, 22, 45),
                 pending_entry_t=ts(2026, 11, 20, 23, 0))
    ok3, msg3 = jr.write_trigger(plan, trig3, lock_path=None)
    assert ok3 is True, (ok3, msg3)


def test_write_trigger_cross_day():
    """S3 跨日：待入场次日 00:00 UTC 不写（次日引擎读不到）。"""
    tmp = tempfile.mkdtemp()
    plan = os.path.join(tmp, "2026-11-20.md")
    with open(plan, "w") as f:
        f.write("# 分系统计划 2026-11-20\n数据截止：2026-11-20 00:47 UTC\n")
    trig = {"coin": "ETH", "direction": -1, "confirm_bar_t": ts(2026, 11, 20, 23, 45),
            "pending_entry_t": ts(2026, 11, 21, 0, 0), "level_txt": "测试",
            "ref_entry": 1750.0, "sl": 1770.0, "tp": 1710.0, "atr_1h": 20.0,
            "basis": "测试"}
    ok, msg = jr.write_trigger(plan, trig, lock_path=None)
    assert ok is False and "跨日" in msg, (ok, msg)


def test_write_trigger_dedup_and_state():
    """S4 去重与 state 检查：已有补充触发行不写；state 里已有分系统登记/
    未平持仓不写；早上计划已成交不写。"""
    tmp = tempfile.mkdtemp()
    plan = os.path.join(tmp, "2026-11-20.md")
    with open(plan, "w") as f:
        f.write("# 分系统计划 2026-11-20\n数据截止：2026-11-20 00:47 UTC\n")
    trig = {"coin": "ETH", "direction": -1, "confirm_bar_t": ts(2026, 11, 20, 14, 30),
            "pending_entry_t": ts(2026, 11, 20, 14, 45), "level_txt": "测试",
            "ref_entry": 1750.0, "sl": 1770.0, "tp": 1710.0, "atr_1h": 20.0,
            "basis": "测试"}
    # 正常写入一次
    ok, _ = jr.write_trigger(plan, trig, lock_path=None)
    assert ok is True
    # 同币再写 → 已有行，拒绝
    ok2, msg2 = jr.write_trigger(plan, trig, lock_path=None)
    assert ok2 is False and "已有补充触发" in msg2, (ok2, msg2)
    # state 里已有未平 sub 持仓 → 拒绝（用临时 state 文件）
    state_path = os.path.join(tmp, "state.json")
    with open(state_path, "w") as f:
        json.dump({"sub_plans": {}, "sub_supp": {},
                   "positions": [{"coin": "SOL", "layer": "sub", "entry_t": 1}]}, f)
    old_state = jr.STATE_PATH
    try:
        jr.STATE_PATH = state_path
        trig_sol = dict(trig, coin="SOL", pending_entry_t=ts(2026, 11, 20, 15, 0),
                        confirm_bar_t=ts(2026, 11, 20, 14, 45))
        ok3, msg3 = jr.write_trigger(plan, trig_sol, lock_path=None)
        assert ok3 is False and "未平分系统持仓" in msg3, (ok3, msg3)
        # 早上计划已成交 → 拒绝
        with open(state_path, "w") as f:
            json.dump({"sub_plans": {"LINK": {"status": "triggered", "trades_done": 1}},
                       "sub_supp": {}, "positions": []}, f)
        trig_link = dict(trig, coin="LINK", pending_entry_t=ts(2026, 11, 20, 15, 0),
                         confirm_bar_t=ts(2026, 11, 20, 14, 45))
        ok4, msg4 = jr.write_trigger(plan, trig_link, lock_path=None)
        assert ok4 is False and "早上计划已成交" in msg4, (ok4, msg4)
    finally:
        jr.STATE_PATH = old_state


def test_bias_invalidated():
    """S5 偏向失效：数据截止后 1h 收盘越过失效价 → 作废；未越过 → 未失效；
    无失效条件 → 不适用。"""
    tmp = tempfile.mkdtemp()
    plan = os.path.join(tmp, "2026-11-20.md")
    with open(plan, "w") as f:
        f.write("# 分系统计划 2026-11-20\n数据截止：2026-11-20 00:47 UTC\n\n"
                "## ETH — 偏向：做空（有计划）\n\n"
                "- **失效条件：** 触发前 1h 收盘上破 70.43（看跌 FVG 上沿）→ 做空偏向作废；"
                "入场后 15m 收盘上破 71.124 即止损。\n")
    # 1h 收盘 71.0（>70.43）在 10:00，确认根 14:30 → 已失效
    bars1h = [bar(ts(2026, 11, 20, 9, 0), 69.0, 69.5, 68.5, 69.2),
              bar(ts(2026, 11, 20, 10, 0), 69.2, 71.2, 69.0, 71.0),
              bar(ts(2026, 11, 20, 11, 0), 71.0, 71.5, 70.5, 71.1)]
    inv, msg = jr.bias_invalidated(plan, "ETH", bars1h, ts(2026, 11, 20, 14, 30))
    assert inv is True and "已失效" in msg, (inv, msg)
    # 未越过：收盘都在 70.43 之下 → 未失效
    bars1h2 = [bar(ts(2026, 11, 20, 9, 0), 69.0, 69.5, 68.5, 69.2),
               bar(ts(2026, 11, 20, 10, 0), 69.2, 70.1, 69.0, 69.8)]
    inv2, _ = jr.bias_invalidated(plan, "ETH", bars1h2, ts(2026, 11, 20, 14, 30))
    assert inv2 is False
    # 截止前收盘的根不算：数据截止 11:00 时，只有 10:00 收盘 71.0 的根
    # 在截止前（收盘 11:00）；去掉 11:00 那根（收盘 12:00，已在截止后），
    # 余下 09:00/10:00 两根中 10:00 根收盘 71.0 恰在截止点上——按
    # “收盘 <= 截止” 不计入，应为未失效
    bars_cut = [bar(ts(2026, 11, 20, 9, 0), 69.0, 69.5, 68.5, 69.2),
                bar(ts(2026, 11, 20, 10, 0), 69.2, 71.2, 69.0, 71.0)]
    with open(plan, "w") as f:
        f.write("# 分系统计划 2026-11-20\n数据截止：2026-11-20 11:00 UTC\n\n"
                "## ETH — 偏向：做空（有计划）\n\n"
                "- **失效条件：** 触发前 1h 收盘上破 70.43（看跌 FVG 上沿）→ 做空偏向作废。\n")
    inv3, _ = jr.bias_invalidated(plan, "ETH", bars_cut, ts(2026, 11, 20, 14, 30))
    assert inv3 is False, "截止前收盘的根不应算失效"
    # 无失效条件 → 不适用
    with open(plan, "w") as f:
        f.write("# 分系统计划 2026-11-20\n数据截止：2026-11-20 00:47 UTC\n\n"
                "## ETH — 偏向：观望（无计划）\n\n- **市场结构：** 空头。\n")
    inv4, msg4 = jr.bias_invalidated(plan, "ETH", bars1h, ts(2026, 11, 20, 14, 30))
    assert inv4 is False and "不适用" in msg4


def _synthetic_bars(weak=False):
    """合成一组 15m/1h：位子 100.1（20、30 两根高点 100.0/100.2，相隔 10 根），
    探针 38 根高 100.8 收 99.6，确认 39 根收 98.2（强）或 99.4（弱）。
    1h 结构缓慢下行（做空对齐），ATR1h 约 1.8。"""
    t0 = ts(2026, 11, 20, 0, 0)
    bars15 = []
    for i in range(40):
        t = t0 + i * 900
        if i == 20:
            bars15.append(bar(t, 99.6, 100.0, 99.2, 99.6))
        elif i == 30:
            bars15.append(bar(t, 99.7, 100.2, 99.3, 99.7))
        elif 21 <= i <= 29 or 31 <= i <= 37:
            bars15.append(bar(t, 99.3, 99.5, 99.1, 99.4))
        elif i == 38:
            bars15.append(bar(t, 99.5, 100.8, 99.0, 99.6))
        elif i == 39:
            c = 99.4 if weak else 98.2
            bars15.append(bar(t, 99.6, 99.8, 98.0 if not weak else 99.2, c))
        else:
            o = 98.0 + i * 0.05
            bars15.append(bar(t, o, o + 0.4, o - 0.4, o + 0.02))
    bars1h = []
    for j in range(24):
        t = t0 - 24 * 3600 + j * 3600 + 3600  # 最后一根 09:00–10:00
        c = 101.0 - j * 0.11
        bars1h.append(bar(t, c + 0.1, c + 0.9, c - 0.9, c))
    return bars15, bars1h


def test_brief_decide_write():
    """S6 合成拒绝：位子两次测试、探针影 1.2x、确认跌幅 1.4x → write，
    理由里写明时段（确认根 09:45 UTC = 欧洲盘）。"""
    bars15, bars1h = _synthetic_bars()
    confirm_t = ts(2026, 11, 20, 9, 45)
    b = jr.brief("ETH", -1, confirm_t, bars15, bars1h, plan_path=None)
    assert "error" not in b, b
    dec, reason, checks = jr.decide(b)
    assert dec == "write", (dec, reason, checks)
    assert "欧洲盘" in reason, reason
    trig = jr.build_trigger(b, reason)
    assert trig["direction"] == -1 and abs(trig["ref_entry"] - 98.2) < 1e-9
    assert abs(trig["sl"] - trig["ref_entry"] - b["atr1h"]) < 1e-9


def test_brief_decide_no_weak():
    """S7 合成弱拒绝：确认只跌 0.2x、无跟进 → no（仅强度一项不通过）。"""
    bars15, bars1h = _synthetic_bars(weak=True)
    confirm_t = ts(2026, 11, 20, 9, 45)
    b = jr.brief("ETH", -1, confirm_t, bars15, bars1h, plan_path=None)
    assert "error" not in b, b
    dec, reason, checks = jr.decide(b)
    assert dec == "no", (dec, reason)
    assert checks["strength"][0] is False, checks


def test_plan_directions_sub():
    """S8 plan_directions 读分系统计划偏向：做空/做多/纯观望。"""
    tmp = tempfile.mkdtemp()
    plan = os.path.join(tmp, "2026-11-20.md")
    with open(plan, "w") as f:
        f.write("## BTC — 偏向：观望（无计划）\n\n"
                "## ETH — 偏向：做空（有计划）\n\n"
                "## SOL — 偏向：做多（有计划）\n\n"
                "## DOGE — 偏向：观望\n")
    d = jr.plan_directions(plan)
    assert d == {"BTC": None, "ETH": -1, "SOL": 1, "DOGE": None}, d


TESTS = [
    ("S1 时段划分", test_session_name),
    ("S2 夜禁不写 / 16:45 与 23:00 可写", test_write_trigger_night_window),
    ("S3 跨日不写", test_write_trigger_cross_day),
    ("S4 去重与 state 检查", test_write_trigger_dedup_and_state),
    ("S5 偏向失效检查", test_bias_invalidated),
    ("S6 合成拒绝 → write（含时段）", test_brief_decide_write),
    ("S7 合成弱拒绝 → no（强度）", test_brief_decide_no_weak),
    ("S8 plan_directions 读分系统偏向", test_plan_directions_sub),
]


def main():
    passed, failed = 0, []
    for name, fn in TESTS:
        try:
            fn()
            print(f"PASS {name}")
            passed += 1
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {type(e).__name__}: {e}")
            failed.append(name)
    print(f"\n{passed}/{len(TESTS)} 通过")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
