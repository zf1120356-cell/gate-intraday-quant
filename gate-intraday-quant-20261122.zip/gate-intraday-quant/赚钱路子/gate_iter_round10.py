#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十轮：多周期共振（只做合约、只做日内、只做 Gate）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（用户指出）：之前 19 个家族基本都是单周期（15m / 30m / 1h 各跑各
的），没有大周期定方向、小周期找入场的多周期共振。本轮补这个缺口。
已核查：ORB+VWAP 只是同周期内的位置过滤，不算多周期；S3、F1、
截面多空等全部是单周期信号。本轮 3 个家族是首次多周期。

锁定的规则（跑前定死，写死在文件头，单组参数，不用全样本挑参数）：
  通用：止损 1xATR（小周期 ATR14），止盈 2xATR（用户要求 1:2，
  在 1.5~3 中间）；每笔保证金 10% 权益、1x；收盘触发、下一根开盘
  成交；止损/止盈用盘中高低价触发（同根同时碰到先判止损）；
  单日 -2% 熔断；单笔最坏情况 (ATR+成本) > 1% 权益跳过；
  成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
  双边）；资金费按实际费率计（08:00/16:00 结算点，前半段
  2026-05-21 之前无数据按 0 计）。M1/M2 只做对照（第九轮同款）。
  M1/M2/M3 各自带一个单周期对照（同信号、去掉大周期过滤），
  用于判断多周期过滤本身有没有增值。

  M1：4h 趋势过滤 + 1h 入场（S3 顺大趋势反转）
      大周期：4h（由 1h 合成，4 根 1h 合 1 根 4h，o=首根 o，
      h=max h，l=min l，c=末根 c，v=求和；只保留满 4 根的块）。
      4h EMA20/EMA60 定方向：EMA20>EMA60 只做多，< 只做空，= 不做。
      小周期：1h，S3 RSI(14,Wilder) 收盘 <20 做多、>80 做空，
      只做与 4h 方向一致的信号；08:00-20:00 UTC；
      本根振幅 > 前 20 根振幅中位数；每天每币最多 2 笔。
      出场：RSI 回 50 / 止损 1xATR(1h) / 止盈 2xATR / 当天 23:00
      收盘强制平仓。
      对照 M1c：同款 S3-1h（TP2.0），去掉 4h 过滤（第九轮已跑过，
      本轮在同一引擎里重跑复核）。
  M2：1h 趋势过滤 + 15m 入场（突破）
      大周期：1h（由 15m 合成，4 根 15m 合 1 根 1h；只保留满 4 根
      的块）。1h EMA20/EMA60 定方向。
      小周期：15m，收盘突破前 8 根（2h）最高价做多 / 最低价做空，
      只做与 1h 方向一致的突破；08:00-20:00 UTC；
      下一根 15m 开盘进；止损 1xATR(15m)、止盈 2xATR；
      最多持 16 根（4h）；每天每币最多 2 笔；当天 23:45 收盘
      强制平仓。
      对照 M2c：同款 15m 突破，去掉 1h 过滤（双向都做）。
  M3：4h 开盘区间 + 1h 动量确认
      大周期：4h（由 1h 合成，同 M1）。当日开盘区间 OR =
      当天 00:00-04:00 四根 1h 的最高价/最低价（即当日首根 4h
      的 h/l）。方向：1h 收盘上破 OR 高点 → 做多候选，下破
      OR 低点 → 做空候选（只取当日首次上破/下破的那根，
      不是全天都高于 OR 就天天发信号）。
      小周期确认：破位那根 1h 收盘价同时在 1h EMA20 之上（做多）
      / 之下（做空）；EMA20 用已收盘 1h 计算。
      信号窗口 04:00-20:00 UTC；下一根 1h 开盘进；止损 1xATR(1h)、
      止盈 2xATR；最多持 8 根（8h）；每天每币最多 2 笔；
      当天 23:00 收盘强制平仓。
      对照 M3c：同款 OR 突破，去掉 EMA20 确认（破位即进）。

  前视防控（写死在代码里，用 assert + 时间戳对齐）：
    - 大周期指标只用“已收盘”的大周期根：对小周期信号根（收盘时刻
      T），只取收盘时刻 <= T 的最近一根大周期根。4h 根收盘时刻 =
      起始 t+4h；1h 根收盘时刻 = 起始 t+1h。代码用 bisect 在
      大周期收盘时刻列表里取 bisect_right(T)-1，绝不用未来根。
    - 4h/1h 合成只用已有的小周期根聚合，不引入外部数据。
    - EMA/RSI/ATR 全部用信号根及之前已收盘的根计算；入场永远是
      信号根的下一根开盘价。
    - M3 的 OR 只用当天 00:00-04:00 已收盘的 4 根 1h，04:00 后才
      可用；破位只取首次上破/下破。

窗口：
  M1 / M3：365 天 1h，2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
    4h EMA60 热身约 10 天，吃掉前半段开头，报告里注明。
  M2：103 天 15m，2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
    1h EMA60 热身约 2.5 天，吃掉前半段开头，报告里注明。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

运行：python3 gate_iter_round10.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round10_summary.json
      + data/gate_iter_round10_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
复核：M1c（S3-1h TP2.0）必须复现第九轮数字（BTC -1.50% /
  ETH -0.68% / SOL -1.76% / DOGE -0.89% / LINK -0.86% /
  XRP -0.73% / BNB -1.00% / ADA -1.90%），在 0.05pp 以内。
"""
import bisect
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
ALTS = [s for s in SYMBOLS if s != "BTC_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005,
              "DOGE_USDT": 0.008333, "LINK_USDT": 0.0065, "XRP_USDT": 0.005,
              "BNB_USDT": 0.0066, "ADA_USDT": 0.0066}

# ---- 锁定的参数：止损 1xATR，止盈 2xATR（用户要求 1:2）----
SL_MULT = 1.0
TP_MULT = 2.0
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)

ROUNDTRIP_COST = 0.0025
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
RSI_LO, RSI_HI = 20, 80
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in ["BTC_USDT", "ETH_USDT", "SOL_USDT"]:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def rsi_wilder(closes, period=14):
    rsi = [None] * len(closes)
    if len(closes) <= period:
        return rsi
    gains, losses = [], []
    for i in range(1, period + 1):
        ch = closes[i] - closes[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    avg_g = sum(gains) / period
    avg_l = sum(losses) / period
    rsi[period] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    for i in range(period + 1, len(closes)):
        ch = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(ch, 0.0)) / period
        avg_l = (avg_l * (period - 1) + max(-ch, 0.0)) / period
        rsi[i] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    return rsi


def ema_series(closes, period):
    """标准 EMA，种子为前 period 根收盘价的 SMA；不足 period 根为 None。"""
    out = [None] * len(closes)
    if len(closes) < period:
        return out
    k = 2.0 / (period + 1)
    out[period - 1] = sum(closes[:period]) / period
    for i in range(period, len(closes)):
        out[i] = closes[i] * k + out[i - 1] * (1 - k)
    return out


def synthesize(bars, per_block, block_secs):
    """把小周期根按时间戳聚合成大周期根；只保留满 per_block 根的块。
    块起始 = t - (t % block_secs)，与 UTC 边界对齐。"""
    blocks = {}
    for b in bars:
        start = b["t"] - (b["t"] % block_secs)
        blocks.setdefault(start, []).append(b)
    out = []
    for start in sorted(blocks):
        grp = sorted(blocks[start], key=lambda x: x["t"])
        if len(grp) != per_block:
            continue
        out.append({"t": start, "o": grp[0]["o"], "h": max(g["h"] for g in grp),
                    "l": min(g["l"] for g in grp), "c": grp[-1]["c"],
                    "v": sum(g["v"] for g in grp),
                    "sum": sum(g["sum"] for g in grp)})
    return out


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def last_completed_idx(big_close_ts, small_close_t):
    """大周期收盘时刻列表里，收盘时刻 <= 小周期信号根收盘时刻的最后一根。
    返回下标，-1 表示当时还没有已收盘的大周期根（热身期）。"""
    return bisect.bisect_right(big_close_ts, small_close_t) - 1


# ----------------------------------------------------------------------
# 通用引擎：信号预生成（key=入场根时间戳），下一根开盘进，
# 止损 1xATR / 止盈 2xATR / 最多持 N 根 / 当天最后一根收盘平仓。
# 同根同时碰止损和止盈先判止损；单日 -2% 熔断。
# ----------------------------------------------------------------------
def simulate_generic(symbol, bars, signals, funding, days_subset, max_per_day,
                     max_hold, label, bars_per_day):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= max_hold - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - SL_MULT * a if sig["direction"] == 1 else entry + SL_MULT * a
                tp = entry + TP_MULT * a if sig["direction"] == 1 else entry - TP_MULT * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": max_hold}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


# ----------------------------------------------------------------------
# M1 引擎：S3-1h 一字不变（第九轮 run_s3_1h，tp=2.0），只加 4h 趋势门。
# trend[i]：1h 根 i 收盘时已收盘的最近 4h 根的 EMA20/EMA60 方向
# （+1 只做多 / -1 只做空 / 0 无方向或热身期）。
# ----------------------------------------------------------------------
def run_m1(bars, funding, symbol, days_subset, trend, label):
    atr = atr_wilder(bars)
    rsi = rsi_wilder([b["c"] for b in bars])
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 24)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                       else (b["h"] - pos["entry"]) / pos["entry"])
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                r = rsi[gi]
                if r is not None:
                    if pos["direction"] == 1 and r >= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                    if pos["direction"] == -1 and r <= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if not (8.0 <= hour < 20.0):
                    continue
                r = rsi[gi]
                if r is None or gi < 20:
                    continue
                ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                    continue
                sig = 0
                if r < RSI_LO:
                    sig = 1
                elif r > RSI_HI:
                    sig = -1
                if sig == 0:
                    continue
                # ---- 多周期门：只做与 4h 趋势一致的信号 ----
                if trend[gi] == 0 or sig != trend[gi]:
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - SL_MULT * a if sig == 1 else entry + SL_MULT * a
                tp = entry + TP_MULT * a if sig == 1 else entry - TP_MULT * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


# ----------------------------------------------------------------------
# 信号生成（全部只用已收盘根；入场键 = 信号根下一根的开盘时间戳）
# ----------------------------------------------------------------------
def build_m1_trend(bars1h, bars4h):
    """返回与 bars1h 等长的 trend 数组：每根 1h 收盘时已收盘的最近
    4h 根的 EMA20/EMA60 方向。"""
    closes4 = [b["c"] for b in bars4h]
    e20 = ema_series(closes4, 20)
    e60 = ema_series(closes4, 60)
    close4_ts = [b["t"] + 4 * 3600 for b in bars4h]
    trend = []
    for b in bars1h:
        j = last_completed_idx(close4_ts, b["t"] + 3600)
        if j < 0 or e20[j] is None or e60[j] is None:
            trend.append(0)
        elif e20[j] > e60[j]:
            trend.append(1)
        elif e20[j] < e60[j]:
            trend.append(-1)
        else:
            trend.append(0)
    return trend


def build_m2_signals(bars15, bars1h_from15, atr15, use_filter):
    """15m 突破信号。use_filter=True 时只保留与 1h EMA 方向一致的。
    返回 (signals, stats)：signals key=入场根 t；stats 含候选/通过数。"""
    closes1 = [b["c"] for b in bars1h_from15]
    e20 = ema_series(closes1, 20)
    e60 = ema_series(closes1, 60)
    close1_ts = [b["t"] + 3600 for b in bars1h_from15]
    sigs = {}
    n_cand = n_pass = 0
    for i in range(8, len(bars15)):
        b = bars15[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour < 20):
            continue
        if atr15[i] is None:
            continue
        hi8 = max(x["h"] for x in bars15[i - 8:i])
        lo8 = min(x["l"] for x in bars15[i - 8:i])
        d = 0
        if b["c"] > hi8:
            d = 1
        elif b["c"] < lo8:
            d = -1
        if d == 0:
            continue
        n_cand += 1
        if use_filter:
            j = last_completed_idx(close1_ts, b["t"] + 900)
            if j < 0 or e20[j] is None or e60[j] is None:
                continue
            tr = 1 if e20[j] > e60[j] else (-1 if e20[j] < e60[j] else 0)
            if tr == 0 or d != tr:
                continue
        n_pass += 1
        if i + 1 >= len(bars15):
            continue
        sigs[bars15[i + 1]["t"]] = {"direction": d, "atr": atr15[i]}
    return sigs, {"candidates": n_cand, "passed": n_pass}


def build_m3_signals_idx(bars1h, atr1h, use_confirm):
    """与 build_m3_signals 同义的下标版（真正使用的版本）：
    按全局下标遍历，OR 取当天前 4 根 1h 的 h/l。"""
    closes = [b["c"] for b in bars1h]
    e20 = ema_series(closes, 20)
    days = group_days(bars1h, 24)
    # 全局下标：用时间戳映射
    idx_of_t = {b["t"]: i for i, b in enumerate(bars1h)}
    sigs = {}
    n_break = n_pass = 0
    for day, day_bars in days.items():
        if len(day_bars) < 5:
            continue
        or_hi = max(b["h"] for b in day_bars[:4])
        or_lo = min(b["l"] for b in day_bars[:4])
        broke_long = broke_short = False
        for b in day_bars:
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            if dt.hour < 4 or dt.hour >= 20:
                continue
            gi = idx_of_t[b["t"]]
            if atr1h[gi] is None or e20[gi] is None:
                continue
            d = 0
            if not broke_long and b["c"] > or_hi:
                broke_long = True
                d = 1
            elif not broke_short and b["c"] < or_lo:
                broke_short = True
                d = -1
            if d == 0:
                continue
            n_break += 1
            if use_confirm:
                if d == 1 and not (b["c"] > e20[gi]):
                    continue
                if d == -1 and not (b["c"] < e20[gi]):
                    continue
            n_pass += 1
            if gi + 1 >= len(bars1h):
                continue
            sigs[bars1h[gi + 1]["t"]] = {"direction": d, "atr": atr1h[gi]}
    return sigs, {"breaks": n_break, "passed": n_pass}


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": sum(1 for t in trades if t.get("liquidated")),
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def main():
    print("盈利策略迭代 · 第十轮：多周期共振（止损 1xATR / 止盈 2xATR，全模拟）")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    # 4h 合成校验：1h 起始时间戳必须落在 4h 边界上
    assert data1h["BTC_USDT"][0][0]["t"] % 14400 == 0, "1h 起始时间戳不在 4h 边界"
    assert data15["BTC_USDT"][0][0]["t"] % 3600 == 0, "15m 起始时间戳不在整点边界"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；"
          "时间戳对齐、零缺口；4h/1h 合成边界对齐。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    all_results, all_trades = [], []

    def record(res, trades_full, family, variant, gran, split_fn):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        all_results.append(res)
        if trades_full is not None:
            for t in trades_full:
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def split_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={res['win_rate']} "
              f"盈亏比={res['profit_factor']} 平均赢={res['avg_win_usdt']:+.0f} "
              f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ================= M1：4h 趋势 + 1h S3 =================
    print("\n=== M1：4h EMA20/60 过滤 + 1h S3 RSI 20/80（365d 1h，8 币）===")
    m1_trend, m1_warm = {}, {}
    for sym in SYMBOLS:
        bars = data1h[sym][0]
        b4 = synthesize(bars, 4, 14400)
        assert len(b4) == 2190, f"{sym} 合成 4h 应为 2190 根，实际 {len(b4)}"
        m1_trend[sym] = build_m1_trend(bars, b4)
        m1_warm[sym] = sum(1 for x in m1_trend[sym] if x == 0)
    print(f"[M1] 4h 合成：每币 2190 根；trend=0（热身/无方向）的 1h 根数："
          f"{ {s: m1_warm[s] for s in SYMBOLS} }")
    for sym in SYMBOLS:
        bars, funding = data1h[sym]
        for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
            trades, curve, ndays = run_m1(bars, funding, sym, subset, m1_trend[sym], "R10-M1")
            res = summarize(sym, trades, curve, "R10-M1")
            res["split"] = wname
            res["days"] = ndays
            record(res, trades if wname == "365d" else None, "M1", "R10-M1", "1h", split_1h)
            show(res, sym, wname)

    # ---- M1c 对照：同款 S3-1h TP2.0，去掉 4h 过滤（第九轮复核）----
    # run_m1c 为第九轮 run_s3_1h 一字不变的复刻（tp=2.0），定义在文件末尾。
    print("\n=== M1c 对照：S3-1h TP2.0，无 4h 过滤（第九轮复核）===")
    for sym in SYMBOLS:
        bars, funding = data1h[sym]
        for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
            trades, curve, ndays = run_m1c(bars, funding, sym, subset, "R10-M1c")
            res = summarize(sym, trades, curve, "R10-M1c")
            res["split"] = wname
            res["days"] = ndays
            record(res, trades if wname == "365d" else None, "M1c", "R10-M1c", "1h", split_1h)
            show(res, sym, wname)

    # ================= M2：1h 趋势 + 15m 突破 =================
    print("\n=== M2：1h EMA20/60 过滤 + 15m 前 8 根突破（103d 15m，8 币）===")
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig_m2, sig_m2c, stats_m2, stats_m2c = {}, {}, {}, {}
    for sym in SYMBOLS:
        bars15 = data15[sym][0]
        bars1h = synthesize(bars15, 4, 3600)
        assert len(bars1h) == 103 * 24, f"{sym} 15m 合成 1h 应为 {103*24} 根，实际 {len(bars1h)}"
        sig_m2[sym], stats_m2[sym] = build_m2_signals(bars15, bars1h, atr15[sym], True)
        sig_m2c[sym], stats_m2c[sym] = build_m2_signals(bars15, bars1h, atr15[sym], False)
    print(f"[M2] 15m 突破候选（全 103d）："
          f"{ {s: stats_m2[s] for s in SYMBOLS} }（对照不过滤 = 候选数）")
    for sym in SYMBOLS:
        bars, funding = data15[sym]
        for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
            trades, curve, ndays = simulate_generic(
                sym, bars, sig_m2[sym], funding, subset, 2, 16, "R10-M2", 96)
            res = summarize(sym, trades, curve, "R10-M2", len(sig_m2[sym]))
            res["split"] = wname
            res["days"] = ndays
            record(res, trades if wname == "103d" else None, "M2", "R10-M2", "15m", split_15)
            show(res, sym, wname)
    print("\n=== M2c 对照：15m 前 8 根突破，无 1h 过滤 ===")
    for sym in SYMBOLS:
        bars, funding = data15[sym]
        for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
            trades, curve, ndays = simulate_generic(
                sym, bars, sig_m2c[sym], funding, subset, 2, 16, "R10-M2c", 96)
            res = summarize(sym, trades, curve, "R10-M2c", len(sig_m2c[sym]))
            res["split"] = wname
            res["days"] = ndays
            record(res, trades if wname == "103d" else None, "M2c", "R10-M2c", "15m", split_15)
            show(res, sym, wname)

    # ================= M3：4h 开盘区间 + 1h EMA20 确认 =================
    print("\n=== M3：4h 开盘区间突破 + 1h EMA20 确认（365d 1h，8 币）===")
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    sig_m3, sig_m3c, stats_m3, stats_m3c = {}, {}, {}, {}
    for sym in SYMBOLS:
        sig_m3[sym], stats_m3[sym] = build_m3_signals_idx(data1h[sym][0], atr1h[sym], True)
        sig_m3c[sym], stats_m3c[sym] = build_m3_signals_idx(data1h[sym][0], atr1h[sym], False)
    print(f"[M3] OR 破位（全 365d）：确认版 { {s: stats_m3[s] for s in SYMBOLS} }；"
          f"对照版破位数 = { {s: stats_m3c[s]['breaks'] for s in SYMBOLS} }")
    for sym in SYMBOLS:
        bars, funding = data1h[sym]
        for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
            trades, curve, ndays = simulate_generic(
                sym, bars, sig_m3[sym], funding, subset, 2, 8, "R10-M3", 24)
            res = summarize(sym, trades, curve, "R10-M3", len(sig_m3[sym]))
            res["split"] = wname
            res["days"] = ndays
            record(res, trades if wname == "365d" else None, "M3", "R10-M3", "1h", split_1h)
            show(res, sym, wname)
    print("\n=== M3c 对照：4h 开盘区间突破，无 EMA20 确认 ===")
    for sym in SYMBOLS:
        bars, funding = data1h[sym]
        for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
            trades, curve, ndays = simulate_generic(
                sym, bars, sig_m3c[sym], funding, subset, 2, 8, "R10-M3c", 24)
            res = summarize(sym, trades, curve, "R10-M3c", len(sig_m3c[sym]))
            res["split"] = wname
            res["days"] = ndays
            record(res, trades if wname == "365d" else None, "M3c", "R10-M3c", "1h", split_1h)
            show(res, sym, wname)

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, wnames) in [
            ("M1", "1h", ["365d", "前185d", "后180d"]),
            ("M1c", "1h", ["365d", "前185d", "后180d"]),
            ("M2", "15m", ["103d", "前51d", "后52d"]),
            ("M2c", "15m", ["103d", "前51d", "后52d"]),
            ("M3", "1h", ["365d", "前185d", "后180d"]),
            ("M3c", "1h", ["365d", "前185d", "后180d"])]:
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["split"] == wname]
            gt = sum(r["gross_usdt"] for r in rs)
            ct = sum(r["taker_cost_sum"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            print(f"  {fam}-{gran} {wname}：Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                  f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                  f"每笔毛利 {gt/nt:+.2f} USDT 胜率 "
                  f"{sum(r['win_rate']*r['trades'] for r in rs)/nt:.3f}")

    # ---- pooled t（全期明细，M1 逐笔）----
    print("\n=== Pooled t 值（M1 逐笔净收益占权益 %，全期明细）===")
    for (fam, gran, wnames, full) in [
            ("M1", "1h", ["365d", "前185d", "后180d"], "365d"),
            ("M1c", "1h", ["365d", "前185d", "后180d"], "365d"),
            ("M2", "15m", ["103d", "前51d", "后52d"], "103d"),
            ("M2c", "15m", ["103d", "前51d", "后52d"], "103d"),
            ("M3", "1h", ["365d", "前185d", "后180d"], "365d"),
            ("M3c", "1h", ["365d", "前185d", "后180d"], "365d")]:
        sub = [t for t in all_trades if t["family"] == fam and t["granularity"] == gran]
        for wname in wnames:
            s2 = [t for t in sub if wname == full or t["split"] == wname]
            vals = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
            vals_t = [t["pnl"] / START_EQUITY for t in s2]
            print(f"  {fam}-{gran} {wname}：n={len(vals)} "
                  f"pooled t(M1)={t_value(vals)} pooled t(Taker)={t_value(vals_t)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    for (fam, gran, syms, wnames) in [
            ("M1", "1h", SYMBOLS, ["前185d", "后180d", "365d"]),
            ("M1c", "1h", SYMBOLS, ["前185d", "后180d", "365d"]),
            ("M2", "15m", SYMBOLS, ["前51d", "后52d", "103d"]),
            ("M2c", "15m", SYMBOLS, ["前51d", "后52d", "103d"]),
            ("M3", "1h", SYMBOLS, ["前185d", "后180d", "365d"]),
            ("M3c", "1h", SYMBOLS, ["前185d", "后180d", "365d"])]:
        row = {}
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["split"] == wname]
            row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
        good = row[wnames[0]] > 0 and row[wnames[1]] > 0 and row[wnames[2]] > 0.02
        print(f"  {fam}-{gran} Taker：前 {row[wnames[0]]*100:+.2f}% / "
              f"后 {row[wnames[1]]*100:+.2f}% / 全 {row[wnames[2]]*100:+.2f}% → "
              f"{'达标' if good else '不达标'}")
        for sym in syms:
            rf = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["symbol"] == sym and r["split"] == wnames[0]][0]
            rb = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["symbol"] == sym and r["split"] == wnames[1]][0]
            both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
            print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                  f"后 {rb['taker_net_pct']*100:+.2f}% → "
                  f"{'★ 两半都为正' if both else ''}")

    # ---- 复核 M1c（S3-1h TP2.0）是否与第九轮一致 ----
    print("\n=== 复核：M1c（S3-1h TP2.0）vs 第九轮已发表数字（Taker，全期）===")
    checks = {"BTC_USDT": -0.0150, "ETH_USDT": -0.0068, "SOL_USDT": -0.0176,
              "DOGE_USDT": -0.0089, "LINK_USDT": -0.0086, "XRP_USDT": -0.0073,
              "BNB_USDT": -0.0100, "ADA_USDT": -0.0190}
    bad = 0
    for sym, expect in sorted(checks.items()):
        r = [x for x in all_results if x["family"] == "M1c" and x["granularity"] == "1h"
             and x["symbol"] == sym and x["split"] == "365d"][0]
        ok = abs(r["taker_net_pct"] - expect) < 0.0005
        bad += 0 if ok else 1
        print(f"  M1c {sym}: 本轮 {r['taker_net_pct']*100:+.2f}% vs 第九轮 "
              f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核结果：{len(checks)-bad}/{len(checks)} 一致" + ("（全部通过）" if bad == 0 else "（有出入，见报告）"))

    with open(os.path.join(DATA_DIR, "gate_iter_round10_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round10_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "variant", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "exit_time_utc", "entry", "exit",
                    "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt", "price_pnl_usdt",
                    "cost_taker_usdt", "cost_maker_usdt", "funding_cost_usdt",
                    "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["family"], x["granularity"], x["symbol"])):
            w.writerow([t["family"], t["variant"], t["granularity"], t["split"],
                        t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t.get("liquidated", False), t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round10_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round10_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益.")


# ----------------------------------------------------------------------
# M1c 对照引擎：第九轮 run_s3_1h 一字不变（tp=2.0），去掉 4h 过滤。
# 定义在 main 之后、调用之前即可（Python 在 main() 执行时才解析名字，
# 但为清晰起见函数体放在文件末尾、if __name__ 之前）。
# ----------------------------------------------------------------------
def run_m1c(bars, funding, symbol, days_subset, label):
    atr = atr_wilder(bars)
    rsi = rsi_wilder([b["c"] for b in bars])
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 24)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                       else (b["h"] - pos["entry"]) / pos["entry"])
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                r = rsi[gi]
                if r is not None:
                    if pos["direction"] == 1 and r >= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                    if pos["direction"] == -1 and r <= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if not (8.0 <= hour < 20.0):
                    continue
                r = rsi[gi]
                if r is None or gi < 20:
                    continue
                ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                    continue
                sig = 0
                if r < RSI_LO:
                    sig = 1
                elif r > RSI_HI:
                    sig = -1
                if sig == 0:
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - SL_MULT * a if sig == 1 else entry + SL_MULT * a
                tp = entry + TP_MULT * a if sig == 1 else entry - TP_MULT * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


if __name__ == "__main__":
    main()
