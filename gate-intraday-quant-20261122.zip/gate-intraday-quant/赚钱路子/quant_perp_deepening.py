#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
只做合约深化版 · 全模拟，不交易、不开户、不碰真钱
数据源：OKX 公开免费接口，无需 API Key
用法：python3 quant_perp_deepening.py
输出：
 1) 资金费率套利深化：BTC/ETH/SOL/DOGE/LINK 基础统计 + 过滤优化
    过滤规则：费率>0.005% 才进；持有期间连续翻负>=6期就平，平后等下一次>0.005%再进
    信号用当期费率，进场从下一期开始收，杜绝前视。
    成本：套利一轮开平 taker 0.30% 名义本金；按实际进出次数计，不是只算一次。
 2) 方向策略再测：MA10/30、Donchian突破(20)、布林均值回归(20,2)
    杠杆只测 1x/2x/3x，不测 20-100x（已有结论引用）。
    成交：信号在收盘确认，下一根K线开盘成交；费用每轮 0.20% 名义。
"""
import datetime, statistics, time, requests
TZ = datetime.timezone(datetime.timedelta(hours=8))
BASE = "https://www.okx.com/api/v5"
HDRS = {"User-Agent": "Mozilla/5.0"}
def fmt(ms): return datetime.datetime.fromtimestamp(ms/1000, TZ).strftime("%Y-%m-%d %H:%M")
def fetch_funding(inst, target_days=100):
    rows, after = [], None
    for _ in range(10):
        p = {"instId": inst, "limit": "100"}
        if after: p["after"] = str(after)
        r = requests.get(f"{BASE}/public/funding-rate-history", params=p, headers=HDRS, timeout=20)
        j = r.json(); assert j.get("code")=="0", f"OKX funding error {inst}: {j}"
        d=j.get("data", [])
        if not d: break
        rows.extend(d); after=int(d[-1]["fundingTime"])
        if (int(rows[0]["fundingTime"])-after)/1000/86400>=target_days: break
        time.sleep(0.2)
    ded={x["fundingTime"]:x for x in rows}
    return sorted(ded.values(), key=lambda x:int(x["fundingTime"]))
def fetch_candles(inst, bar="4H", target_days=180):
    rows, after=[],None
    for _ in range(10):
        p={"instId":inst,"bar":bar,"limit":"300"}
        if after: p["after"]=str(after)
        r=requests.get(f"{BASE}/market/candles", params=p, headers=HDRS, timeout=20)
        j=r.json(); assert j.get("code")=="0", f"OKX candles error {inst}: {j}"
        d=j.get("data", [])
        if not d: break
        rows.extend(d); after=int(d[-1][0])
        if (int(rows[0][0])-after)/1000/86400>=target_days: break
        time.sleep(0.2)
    ded={x[0]:x for x in rows}
    return sorted(ded.values(), key=lambda x:int(x[0]))

def max_consec_neg(rates):
    best=cur=0
    for x in rates:
        cur=cur+1 if x<0 else 0
        best=max(best,cur)
    return best

def funding_base(rates):
    n=len(rates); mean=sum(rates)/n
    days=n/3.0
    gross_apy=mean*1095
    # buy-and-hold net: one round trip 0.30% * L, annualised over days
    def net(L): return gross_apy*L - 0.0030*L*365/days
    return {"n":n,"days":days,"mean":mean,"median":statistics.median(rates),
            "std":statistics.pstdev(rates),"pos":sum(1 for x in rates if x>0),
            "neg":sum(1 for x in rates if x<0),"max_neg_run":max_consec_neg(rates),
            "cum":sum(rates),"gross_apy":gross_apy,"net1":net(1),"net2":net(2),"net3":net(3)}

def funding_filtered(rates, entry_thresh=0.00005, exit_neg_run=6):
    """过滤套利：空仓时当期费率>阈值，下一期开始持有收钱；持有中连续负>=6期，下一期平仓。
    返回：持有期数、收到的资金费合计(占名义)、进出次数、扣费后净收益(占名义)、净年化。"""
    holding=False; neg_run=0; collected=0.0; held=0; rounds=0; entries=[]
    for i, r in enumerate(rates):
        # 本期是否持有收钱：由上一期的信号决定，已在循环里维护 holding（进场在 i 处生效）
        if holding:
            collected+=r; held+=1
            neg_run=neg_run+1 if r<0 else 0
            if neg_run>=exit_neg_run:
                holding=False; rounds+=1; neg_run=0
        else:
            # 空仓：当期费率>阈值，下一期开始持有（本期不收）
            if r>entry_thresh:
                holding=True; neg_run=0; entries.append(i)
                # 注意：进场信号在 i，收钱从 i+1 开始，上面 holding 已在 i 置 True 会导致本期也被收？
                # 为杜绝前视，这里把本期收的钱扣回：因为上面 if holding 在本轮还未执行（我们先判断 else），
                # 实际顺序是：本轮先走到 else 分支置 holding=True，但不收本期钱，下一轮才收。正确。
                pass
    if holding: rounds+=1  # 期末仍持有，算一轮平仓成本
    days=len(rates)/3.0
    # 每轮开平成本 0.30% 名义
    net_nominal=collected - 0.0030*rounds
    net_apy=net_nominal/days*365 if days else 0
    return {"held":held,"held_pct":held/len(rates)*100 if rates else 0,"collected":collected,
            "rounds":rounds,"net_nominal":net_nominal,"net_apy_1x":net_apy,
            "net_apy_2x":net_apy*2,"net_apy_3x":net_apy*3,"entries":len(entries)}

def sma(vals,n):
    out=[None]*len(vals); s=0.0
    for i,v in enumerate(vals):
        s+=v
        if i>=n: s-=vals[i-n]
        if i>=n-1: out[i]=s/n
    return out

def backtest_trades(data, signals):
    """data: list of (ts,open,high,low,close); signals[i] in {1,-1,0} 在收盘确认，下一根开盘成交。
    返回 trades list，每笔含 net(名义), max_adv, hold_days。"""
    trades=[]; pos=None
    for i,sig in enumerate(signals):
        if sig==0: continue
        if pos is None:
            if i+1<len(data): pos={"dir":sig,"entry_idx":i+1,"entry_price":data[i+1][1],"entry_time":data[i+1][0]}
        elif sig!=pos["dir"]:
            if i+1>=len(data): break
            pos.update({"exit_idx":i+1,"exit_price":data[i+1][1],"exit_time":data[i+1][0]})
            g=(pos["exit_price"]-pos["entry_price"])/pos["entry_price"] if pos["dir"]==1 else (pos["entry_price"]-pos["exit_price"])/pos["entry_price"]
            pos["gross"]=g; pos["net"]=g-0.0020; pos["hold_days"]=(pos["exit_idx"]-pos["entry_idx"])*4/24
            rng=range(pos["entry_idx"],pos["exit_idx"]+1)
            pos["max_adv"]=((pos["entry_price"]-min(data[k][3] for k in rng))/pos["entry_price"] if pos["dir"]==1 else (max(data[k][2] for k in rng)-pos["entry_price"])/pos["entry_price"])
            trades.append(pos); pos={"dir":sig,"entry_idx":i+1,"entry_price":data[i+1][1],"entry_time":data[i+1][0]}
    if pos is not None:
        pos.update({"exit_idx":len(data)-1,"exit_price":data[-1][4],"exit_time":data[-1][0]})
        g=(pos["exit_price"]-pos["entry_price"])/pos["entry_price"] if pos["dir"]==1 else (pos["entry_price"]-pos["exit_price"])/pos["entry_price"]
        pos["gross"]=g; pos["net"]=g-0.0020; pos["hold_days"]=(pos["exit_idx"]-pos["entry_idx"])*4/24
        rng=range(pos["entry_idx"],pos["exit_idx"]+1)
        pos["max_adv"]=((pos["entry_price"]-min(data[k][3] for k in rng))/pos["entry_price"] if pos["dir"]==1 else (max(data[k][2] for k in rng)-pos["entry_price"])/pos["entry_price"])
        trades.append(pos)
    return trades

def compound(trades, lev):
    eq=1.0; peak=1.0; mdd=0.0
    for t in trades:
        eq*= (1+ t["net"]*lev)
        if eq<=0: eq=0.0; mdd=1.0; break
        peak=max(peak,eq); mdd=max(mdd,(peak-eq)/peak)
    return eq-1, mdd

def strategy_signals(data, kind):
    closes=[d[4] for d in data]; highs=[d[2] for d in data]; lows=[d[3] for d in data]
    sig=[0]*len(data)
    if kind=="MA10/30":
        f=sma(closes,10); s=sma(closes,30)
        for i in range(len(data)):
            if f[i] is not None and s[i] is not None: sig[i]=1 if f[i]>s[i] else -1
    elif kind=="Donchian20":
        # 突破：收盘 > 前20根最高价(不含当根) 做多；收盘 < 前20根最低价 做空；否则维持上一信号
        cur=0
        for i in range(len(data)):
            if i>=20:
                hi=max(highs[i-20:i]); lo=min(lows[i-20:i])
                if closes[i]>hi: cur=1
                elif closes[i]<lo: cur=-1
            sig[i]=cur
    elif kind=="BollingerMR":
        # 均值回归：收盘 > 上轨(20,2σ) 做空，收盘 < 下轨 做多，回到中轨(MA20)平/翻向
        mid=sma(closes,20)
        cur=0
        for i in range(len(data)):
            if mid[i] is None: sig[i]=0; continue
            window=closes[i-19:i+1]
            sd=statistics.pstdev(window)
            up=mid[i]+2*sd; dn=mid[i]-2*sd
            if closes[i]>up: cur=-1
            elif closes[i]<dn: cur=1
            elif (cur==1 and closes[i]>=mid[i]) or (cur==-1 and closes[i]<=mid[i]): cur=0
            sig[i]=cur
    return sig

def main():
    print(f"取数时间（北京时间）：{datetime.datetime.now(TZ).strftime('%Y-%m-%d %H:%M')}  数据源：OKX 公开接口  全模拟")
    coins=[("BTC-USDT-SWAP","BTC"),("ETH-USDT-SWAP","ETH"),("SOL-USDT-SWAP","SOL"),("DOGE-USDT-SWAP","DOGE"),("LINK-USDT-SWAP","LINK")]
    fund={}
    print("\n=== 1. 资金费率基础统计（taker，一轮0.30%） ===")
    for inst,sym in coins:
        rows=fetch_funding(inst); rates=[float(r["fundingRate"]) for r in rows]
        fund[sym]=rates
        s=funding_base(rates)
        print(f"[{sym}] {fmt(int(rows[0]['fundingTime']))}~{fmt(int(rows[-1]['fundingTime']))} n={s['n']} 天={s['days']:.0f} 均值={s['mean']*100:.4f}%/期 中位={s['median']*100:.4f}% 标差={s['std']*100:.4f}% 正={s['pos']}({s['pos']/s['n']*100:.1f}%) 负={s['neg']} 最长连负={s['max_neg_run']}期 累计={s['cum']*100:.3f}% 毛年化={s['gross_apy']*100:.2f}% 净1x={s['net1']*100:.2f}% 净2x={s['net2']*100:.2f}% 净3x={s['net3']*100:.2f}%")
    print("\n=== 1b. 过滤优化：费率>0.005%才进，连续翻负>=6期平 ===")
    for inst,sym in coins:
        rates=fund[sym]; f=funding_filtered(rates)
        print(f"[{sym}过滤] 持有={f['held']}/{len(rates)}({f['held_pct']:.1f}%) 进出={f['rounds']}轮 收资金费={f['collected']*100:.3f}%名义 扣费后净={f['net_nominal']*100:.3f}%名义 净年化1x={f['net_apy_1x']*100:.2f}% 2x={f['net_apy_2x']*100:.2f}% 3x={f['net_apy_3x']*100:.2f}%")
    # 组合：等权平均各币种每期费率（只算有共同期的部分，按最短对齐尾部）
    print("\n=== 1c. 组合（每期等权平均） ===")
    min_n=min(len(v) for v in fund.values())
    # 对齐到最近 min_n 期
    aligned={k:v[-min_n:] for k,v in fund.items()}
    combos={
        "BTC+ETH": ["BTC","ETH"],
        "BTC+ETH+SOL": ["BTC","ETH","SOL"],
        "BTC+SOL+LINK(优选)": ["BTC","SOL","LINK"],
        "全部5币": ["BTC","ETH","SOL","DOGE","LINK"],
        "SOL+DOGE+LINK(小币)": ["SOL","DOGE","LINK"],
    }
    for name, members in combos.items():
        rates=[sum(aligned[m][i] for m in members)/len(members) for i in range(min_n)]
        s=funding_base(rates); f=funding_filtered(rates)
        print(f"[{name} 买入持有] n={s['n']} 均值={s['mean']*100:.4f}% 正={s['pos']/s['n']*100:.1f}% 最长连负={s['max_neg_run']} 净1x={s['net1']*100:.2f}% 净2x={s['net2']*100:.2f}% 净3x={s['net3']*100:.2f}%")
        print(f"[{name} 过滤] 持有={f['held_pct']:.1f}% {f['rounds']}轮 净年化1x={f['net_apy_1x']*100:.2f}% 2x={f['net_apy_2x']*100:.2f}% 3x={f['net_apy_3x']*100:.2f}%")
    print("\n=== 2. 方向策略再测（4H，180天，费用每轮0.20%名义，all-in复利） ===")
    for inst,sym in [("BTC-USDT-SWAP","BTC"),("ETH-USDT-SWAP","ETH"),("SOL-USDT-SWAP","SOL")]:
        candles=fetch_candles(inst, target_days=180)
        start_ms=int(datetime.datetime(2026,5,21,tzinfo=TZ).timestamp()*1000)
        candles=[c for c in candles if int(c[0])>=start_ms]
        data=[(int(r[0]),float(r[1]),float(r[2]),float(r[3]),float(r[4])) for r in candles]
        print(f"\n[{sym}] {fmt(data[0][0])}~{fmt(data[-1][0])} K={len(data)} 收盘 {data[0][4]:.4g}->{data[-1][4]:.4g} ({(data[-1][4]/data[0][4]-1)*100:+.1f}%)")
        for kind in ["MA10/30","Donchian20","BollingerMR"]:
            sig=strategy_signals(data,kind); trades=backtest_trades(data,sig)
            if not trades:
                print(f"  {kind}: 无交易"); continue
            win=sum(1 for t in trades if t["net"]>0)/len(trades)*100
            r1,m1=compound(trades,1); r2,m2=compound(trades,2); r3,m3=compound(trades,3)
            print(f"  {kind}: 笔数={len(trades)} 胜率={win:.1f}% 平均持仓={sum(t['hold_days'] for t in trades)/len(trades):.1f}天 1x={r1*100:+.1f}% (MDD {m1*100:.1f}%)  2x={r2*100:+.1f}% (MDD {m2*100:.1f}%)  3x={r3*100:+.1f}% (MDD {m3*100:.1f}%)")
    print("\n模拟结束：本脚本不下单、不开户、不碰真钱。20-100x方向结论引用已有回测（20x爆仓18.6%，50x 55.8%，100x 74.4%），本次不再重测。")

if __name__=="__main__":
    main()
