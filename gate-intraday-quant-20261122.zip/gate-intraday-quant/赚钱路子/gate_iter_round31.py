#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十一轮：SUB-15m——每币自己的 15m 动量跟随（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

背景（预注册检验，不是事后挑参）：
  2026-11-20 01:32 用户指示：“每个币按自己的走势和结构做，不用 BTC
  给定死了”——系统层 F1（BTC 领先）自 11 月 20 日起停用（SYS_ENABLED
  = False）。新分系统 sub 层需要一套每币自己的系统规则：本轮是该分
  系统的 gate 2/3 验证（gate 2 单组参数回测 + gate 3 前后两半验证），
  规则与实时引擎将要执行的 sub 层一字相同，跑前写死，不许改。

跑前写死的规则（单组参数）：
  宇宙：8 个币全做，包括 BTC（BTC 也做自己的动量）：BTC、ETH、SOL、
    DOGE、LINK、XRP、BNB、ADA。
  数据：data/gate_15m_103d_{币}_USDT.csv（各 9,888 根 15m，
    2026-08-06~2026-11-16，103 天），用 15m 收盘价。
  信号：任意已收盘 15m 根（收盘时刻 ≤22:30 UTC），本币自己的 2h
    收益 r = close[-1]/close[-9] - 1（8 根 15m）。若 |r| ≥ 0.5%，
    方向 = sign(r)。不看 BTC、不看其他币。不设 Killzone、不设入场
    小时限制。
  入场：信号根下一根 15m 开盘价。止损 = 入场价 ± 1×ATR(15m,14
    Wilder)，止盈 = 入场价 ∓ 2×ATR。ATR 与第二十轮 MAIN-15m 同口径。
  出场：止损 / 止盈（同根先判止损）、最多持 16 根（4h）、23:00 UTC
    强制平仓（22:45 根收盘）；每天每币最多 2 笔；单币单日 -2% 熔断
    （-2000 USDT，按 10 万权益计）。
  口径：每笔名义 10,000、1 倍；成本按标准回测口径 Taker 双边 0.25%
    名义（每笔固定 25 USDT），同时记毛利（价差毛利 − 资金费，未扣
    交易成本）以便算毛利/成本比。资金费：持仓跨过 08:00/16:00 UTC
    结算点的按 Gate 实际费率计（gate_funding_365d）；2026-11-16
    三个结算点无费率数据，按 0 计并在报告中注明。
  前后两半：前半 2026-08-06~09-20、后半 2026-09-21~11-16（按写死
    的日期切，实际为前 46 天 / 后 57 天；任务书“约各 51.5 天”为约数，
    以日期为准）。

引擎：复用第二十轮 simulate_f1（止损先判、同根先判止损、最多持
  16 根、每天每币最多 2 笔、单日 -2% 熔断），只改两处：(1) 信号改
  成本币自己 2h 动量（build_sub_signals），删掉 BTC 领先与入场小时
  限制，BTC 纳入交易宇宙；(2) 每笔名义固定 10,000（第二十轮为权益
  10% 浮动名义，约 10,000，差异 <0.1%；本轮按任务书固定 10,000，
  使每笔成本恰为固定 25 USDT）；(3) 模拟用 K 线截断到开盘 <23:00
  UTC（每天 92 根），使日内强制平仓落在 23:00 UTC（22:45 根收盘），
  ATR 与信号仍在全量 9,888 根上计算。

达标标准（写死，跑完对照，不许事后改）：只有同时满足“全期 1x 净
  收益 >2% 且前后两半都为正”才算通过；否则判定不达标。主口径
  Taker。8 币平均（各币独立 10 万 USDT，1x）。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) 数据校验：8 币各 9,888 根 15m / 103 天，时间戳对齐、零缺口；
      截断后每天 92 根、103 天。
  (b) 信号数人工抽查：任取一币，抽一根 |r|≥0.5% 的信号根核对
      r、方向、入场时刻与止损/止盈。
  (c) 首笔交易人工核对触发链、入场价、止损/止盈、出场原因。

运行：python3 gate_iter_round31.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round31_summary.json
      + data/gate_iter_round31_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]

# ---- 预注册、跑前写死：单组参数，不许改 ----
TP_MULT = 2.0            # 止盈 2xATR（用户要求的 1:2）
SL_MULT = 1.0            # 止损 1xATR
SPLIT_R31 = datetime(2026, 9, 21, tzinfo=timezone.utc)  # 前半段止于 09-20
LOOKBACK = 8             # 2h = 8 根 15m
MAX_HOLD = 16            # 最多持 16 根（4h）
MAX_PER_DAY = 2          # 每天每币最多 2 笔
LAST_SIGNAL_CLOSE_MIN = 22 * 60 + 30  # 信号根收盘时刻 ≤ 22:30 UTC

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
NOTIONAL = 10_000.0      # 每笔固定名义（任务书）；每笔成本恰为固定 25 USDT
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def entry_hour_utc(entry_t):
    """入场小时：入场时间戳的 UTC 小时。"""
    return datetime.fromtimestamp(entry_t, timezone.utc).hour


# ----------------------------------------------------------------------
# SUB 信号：本币自己的 2h 动量跟随（不看 BTC、不看其他币）
# ----------------------------------------------------------------------
def build_sub_signals(bars, atr, lookback, max_hold, tp_mult):
    """信号根：任意已收盘 15m（收盘时刻 ≤22:30 UTC）；本币 2h 收益
    r = close[-1]/close[-9] - 1；|r| ≥ 0.5% 则方向 = sign(r)；
    入场为信号根下一根开盘价。"""
    sigs = {}
    for i in range(lookback, len(bars)):
        b = bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        close_min = dt.hour * 60 + dt.minute + 15
        if close_min > LAST_SIGNAL_CLOSE_MIN:
            continue
        if atr[i] is None:
            continue
        r = bars[i]["c"] / bars[i - lookback]["c"] - 1
        if abs(r) < 0.005:
            continue
        if i + 1 >= len(bars):
            continue
        entry_t = bars[i + 1]["t"]
        sigs[entry_t] = {"direction": 1 if r > 0 else -1,
                         "atr": atr[i], "sl_mult": SL_MULT, "tp_mult": tp_mult,
                         "max_hold": max_hold, "r": r}
    return sigs


# ----------------------------------------------------------------------
# 模拟引擎：第二十轮 simulate_f1 一字不变的逻辑，只改名义固定 10,000
# （调用方传入截断到开盘 <23:00 UTC 的 K 线，每天 92 根，使强制平仓
#  落在 23:00 UTC，即 22:45 根收盘）
# ----------------------------------------------------------------------
def simulate_sub(symbol, bars, signals, funding, days_subset, max_per_day, label, bars_per_day):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= pos["max_hold"] - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                notional = NOTIONAL
                margin = 0.10 * NOTIONAL
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": sig["max_hold"]}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "gross_cost_ratio": round(gross_sum / taker_cost_sum, 4) if taker_cost_sum else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def main():
    print("盈利策略迭代 · 第三十一轮：SUB-15m——每币自己的 15m 动量跟随（全模拟）")
    print("8 币全做（含 BTC，各做自己的 2h 动量）；不看 BTC、不设 Killzone、不设入场小时。")
    print("止损 1xATR(15m,14) / 止盈 2xATR；23:00 UTC 强制平仓；达标标准：前后两半都为正且全期 1x 净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data15 = {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    # ---- 资金费覆盖检查：2026-11-16 三个结算点无数据，按 0 计 ----
    miss_days = set()
    for sym in SYMBOLS:
        funding = data15[sym][1]
        for h in (0, 8, 16):
            s = int((datetime(2026, 11, 16, tzinfo=timezone.utc) + timedelta(hours=h)).timestamp())
            if s not in funding:
                miss_days.add((sym, h))
    print(f"资金费缺失：2026-11-16 的 00:00/08:00/16:00 三个结算点在全部 8 币的费率数据里都不存在"
          f"（费率数据止于 2026-11-15 16:00），共 {len(miss_days)} 个（币，结算点）按 0 计；"
          f"其余结算点均按实际费率计。")

    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_R31.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_R31.date()}
    print(f"窗口：全 103d（前 {len(front_15)} 天 2026-08-06~09-20 / "
          f"后 {len(back_15)} 天 2026-09-21~11-16）。")

    # ---- SUB 信号：每币自己，只生成一次 ----
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig15 = {}
    for sym in SYMBOLS:
        sig15[sym] = build_sub_signals(data15[sym][0], atr15[sym],
                                        LOOKBACK, MAX_HOLD, TP_MULT)
    print(f"[SUB] 信号数（入场时刻）：8 币合计 "
          f"{sum(len(v) for v in sig15.values())}；"
          + "、".join(f"{s.replace('_USDT','')} {len(sig15[s])}" for s in SYMBOLS) + "。")

    # ---- 模拟用 K 线截断到开盘 <23:00 UTC（每天 92 根）----
    trunc15 = {}
    for sym in SYMBOLS:
        bars, funding = data15[sym]
        tb = [b for b in bars
              if (datetime.fromtimestamp(b["t"], timezone.utc).hour * 60
                  + datetime.fromtimestamp(b["t"], timezone.utc).minute) < 23 * 60]
        days = group_days(tb, 92)
        assert len(days) == 103, f"{sym} 截断后完整日应为 103 天，实际 {len(days)}"
        assert len(tb) == 103 * 92, f"{sym} 截断后应为 {103*92} 根，实际 {len(tb)}"
        trunc15[sym] = (tb, funding)
    print("截断校验通过：模拟用 K 线每天 92 根（开盘 00:00~22:45），103 天；"
          "强制平仓落在 23:00 UTC（22:45 根收盘）。")

    windows = [("103d", None), ("前46d", front_15), ("后57d", back_15)]
    split_fn = lambda et: ("前46d" if datetime.fromtimestamp(et, timezone.utc).date()
                           < SPLIT_R31.date() else "后57d")

    all_results, all_trades = [], []
    for sym in SYMBOLS:
        bars, funding = trunc15[sym]
        sigs = sig15[sym]
        for wname, subset in windows:
            trades, curve, ndays = simulate_sub(
                sym, bars, sigs, funding, subset, MAX_PER_DAY, "SUB-15m-own", 92)
            res = summarize(sym, trades, curve, "SUB-15m-own", len(sigs))
            res["arm"] = "SUB"
            res["variant"] = "SUB-15m-own"
            res["family"] = "SUB"
            res["tp_mult"] = TP_MULT
            res["granularity"] = "15m"
            res["split"] = wname
            res["days"] = ndays
            res["signals_total"] = len(sigs)
            res["signals_pass"] = len(sigs)
            res["signal_pass_rate"] = 1.0
            all_results.append(res)
            if wname == "103d":
                for t in trades:
                    t2 = dict(t)
                    t2["arm"] = "SUB"
                    t2["variant"] = "SUB-15m-own"
                    t2["family"] = "SUB"
                    t2["tp_mult"] = TP_MULT
                    t2["granularity"] = "15m"
                    t2["split"] = split_fn(t["entry_t"])
                    t2["entry_hour_utc"] = entry_hour_utc(t["entry_t"])
                    all_trades.append(t2)
            print(f"[SUB-15m {sym} {wname}] n={res['trades']} "
                  f"信号 {len(sigs)} 胜率={res['win_rate']} "
                  f"盈亏比={res['profit_factor']} Taker {res['taker_net_pct']*100:+.2f}% "
                  f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                  f"毛利={res['gross_usdt']:+.0f} 每笔毛利={res['gross_per_trade_usdt']:+.2f} "
                  f"毛利/成本={res['gross_cost_ratio']} 成本={res['taker_cost_sum']:+.0f} "
                  f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均（8 币独立 10 万 USDT，1x，主口径 Taker）----
    print("\n=== 汇总：平均净收益（8 币独立 10 万 USDT，1x，主口径 Taker）===")
    agg = {}
    for wname, _ in windows:
        rs = [r for r in all_results if r["split"] == wname]
        gt = sum(r["gross_usdt"] for r in rs)
        ct = sum(r["taker_cost_sum"] for r in rs)
        nt = sum(r["trades"] for r in rs)
        wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
        avg_pct = sum(r["taker_net_pct"] for r in rs) / len(rs)
        agg[wname] = avg_pct
        print(f"  SUB-15m {wname}：Taker 平均 {avg_pct*100:+.2f}% / "
              f"M1 平均 {sum(r['m1_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
              f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
              f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
              f"每笔毛利 {gt/nt:+.2f} USDT 毛利/成本 {gt/ct:.3f} "
              f"胜率 {wr:.3f}" if wr is not None else
              f"  SUB-15m {wname}：Taker 平均 {avg_pct*100:+.2f}% | "
              f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} 每笔毛利 — 胜率 —")

    # ---- pooled t（全期明细，逐笔净收益占权益 %）----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    pooled = {}
    for wname, _ in windows:
        s2 = all_trades if wname == "103d" else [t for t in all_trades if t["split"] == wname]
        vt = [t["pnl"] / START_EQUITY for t in s2]
        vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in s2]
        pooled[wname] = t_value(vt)
        print(f"  SUB-15m {wname}：n={len(s2)} pooled t(Taker)={t_value(vt)} "
              f"pooled t(毛利)={t_value(vg)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    good = agg["前46d"] > 0 and agg["后57d"] > 0 and agg["103d"] > 0.02
    print(f"  SUB-15m Taker：前 {agg['前46d']*100:+.2f}% / "
          f"后 {agg['后57d']*100:+.2f}% / 全 {agg['103d']*100:+.2f}% → "
          f"{'达标' if good else '不达标'}")
    for sym in SYMBOLS:
        rf = [r for r in all_results if r["symbol"] == sym and r["split"] == "前46d"][0]
        rb = [r for r in all_results if r["symbol"] == sym and r["split"] == "后57d"][0]
        both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
        print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
              f"后 {rb['taker_net_pct']*100:+.2f}% → "
              f"{'★ 两半都为正' if both else ''}")
    print(f"\n  本轮判定：{'通过' if good else '不通过'}")

    # ---- 资金费汇总 ----
    ftot = sum(t["funding_cost_usdt"] for t in all_trades)
    fcross = sum(1 for t in all_trades if t["funding_cost_usdt"] != 0)
    print(f"\n资金费：全期合计 {ftot:+.2f} USDT（{fcross}/{len(all_trades)} 笔跨结算点被计费，"
          f"其余为 0——含 2026-11-16 缺失结算点按 0 计的笔数）。")

    with open(os.path.join(DATA_DIR, "gate_iter_round31_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round31_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round31_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round31_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
