#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十二轮：SMC 严格形式化版（只做合约、只做日内、只做 Gate）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

背景：第十一轮测的是 SMC 的一种宽松客观形式化（摆动点 N=2、
订单块取 BOS 前 10 根内最后一根反向 K 线、FVG 无尺寸过滤），三个
家族全亏（S1 -2.05%、S2 -2.61%、S3 -7.64%，365d 1h + 103d 15m，
8 币，9,633 笔）。本轮按第十一轮报告 §5.2 / §8 的预告，测 SMC 的
严格形式化版：大摆动点 + 强势腿订单块 + FVG 最小尺寸 + Killzone
+ 三者对齐才出手。规则跑前写死、单组参数，绝对不许用第十一轮
的数字挑参数。

锁定的严格定义（跑前定死，单组参数）：
  大摆动点：N=5（11 根分形）。bar i 为摆动高，当且仅当 h[i] 是
    h[i-5..i+5] 的最大值且严格大于左侧 h[i-1]（右侧允许相等，
    平顶取最早一根）；摆动低对称。摆动点在 bar i+5 收盘时才
    “确认”，确认之前不存在、不能用。结构一律用 1h 摆动点
    （15m 家族的结构 1h 由 15m 合成）。
  结构破位（BOS/CHOCH 统一口径）：收盘价上破最近一个已确认摆动高
    = 看涨破位，下破最近一个已确认摆动低 = 看跌破位。BOS 与 CHOCH
    不再区分：任何一次收盘破位都是一次结构破位，方向即破位方向；
    CHOCH 只是破位方向与上一次破位相反的特例（代码里单独计数，
    不改变规则）。只用已确认摆动点。
  强势位移腿起点订单块（OB）：位移腿 = 从最近已确认摆动低（看涨
    破位）或最近已确认摆动高（看跌破位）那根起，到破位收盘那根止。
    在“位移腿 ∩ 破位根之前 10 根（含破位根本身）”内，取破位方向
    同向 K 线中实体 |c-o| 最大的一根（看涨取阳线中实体最大者，
    看跌取阴线中实体最大者；并列取最早一根），区间为该根 [l, h]。
    10 根内无同向 K 线则无 OB。不要用“最后一根反向 K 线”。
    若当时还没有已确认的反向摆动点（无位移腿起点），则无 OB。
  FVG 最小尺寸：连续三根缺口（定义与第十一轮相同：看涨
    l[i] > h[i-2] 且 c[i] > c[i-2]，区间 [h[i-2], l[i]]；看跌对称），
    只有缺口宽度 >= 0.5 x ATR14（形成根 i 的 ATR）才算有效 FVG，
    小于则忽略。FVG 被“填补”= 有根收盘价穿过区间远端（看涨为
    收盘 < 区间下沿，看跌为收盘 > 区间上沿）。
  Killzone 时段：只做 08:00-11:00 UTC 和 13:00-16:00 UTC 两个时段
    的触发（触发根的起始时间落在这两个区间内才算）。窗口外触发
    不算也不消耗 setup（沿用第十一轮约定：窗口外触及不触发、
    不作废，setup 继续等窗口内的触及）。
  三者对齐才出手：一个完整 setup 必须同时满足——(a) 大摆动点
    结构破位（BOS/CHOCH），(b) 价格回踩到强势腿 OB 区间，
    (c) 回踩区间内或附近存在未填补的有效 FVG（>=0.5xATR）。
    “附近”写死为：FVG 区间与 OB 区间重叠，或两者间隔 <= 0.5 x
    破位根的 ATR14。FVG 须与破位同向，且形成于位移腿内
    （形成根下标在 [位移腿起点, 破位根] 内），且在破位收盘时
    尚未被填补。缺任何一个都不做。方向顺破位方向。
  回踩触发：破位后 24 根（1h）/ 12h（15m，48 根）内，首次触及 OB
    区间（看涨 l <= OB 上沿且 c >= OB 下沿，看跌对称）即触发，
    入场为触发根下一根开盘。触及前若收盘穿过 OB 区间远端（看涨
    c < OB 下沿）则 setup 作废；触及前若对齐的 FVG 被填补（收盘
    穿过 FVG 远端）则对齐被破坏、setup 作废；窗口内未触及则过期。
  入场与风控：止损 1xATR、止盈 2xATR（用户要求的 1:2）；每笔保证金
    10% 权益、1x；触发根收盘、下一根开盘成交；止损/止盈用盘中高低
    价触发（同根同时碰到先判止损）；单日 -2% 熔断；单笔最坏情况
    (ATR+成本) > 1% 权益跳过；成本主口径 Taker（一轮名义 x 0.25%，
    taker 0.075% + 滑点 0.05%，双边）；资金费按实际费率计（08:00/
    16:00 结算点，前半段 2026-05-21 之前无数据按 0 计）。
    最多持 8 根（1h）或 16 根（15m）；每天每币最多 2 笔；
    当天 23:00（1h）/ 23:45（15m）收盘强制平仓。

  两个组合（同为严格三者对齐，只差执行粒度）：
    R12-S1：全 1h，365d，结构/OB/FVG/入场全在 1h，最多持 8 根。
    R12-S2：1h 定结构（由 15m 合成）、15m 找入场，103d；OB/FVG
      仍在 1h 上定义，回踩在 15m 上监测（12h 内），止损/止盈用
      15m ATR，最多持 16 根。

  前视防控（写死在代码里）：
    - 摆动点、破位、OB、FVG 全部只用已收盘的根；摆动点须在确认根
      （bar i+5）收盘后才可用。
    - 入场永远是触发根的下一根开盘价。
    - 新形成的 FVG 从下一根起才可参与对齐判定（形成根本身即破位
      根时除外——它在破位收盘时已形成，可用；回踩监测从破位根
      下一根起，同一根不既当破位根又当回踩根）。
    - S2 的 15m 触发根须严格晚于 1h 破位根收盘时刻。

窗口：
  S1：365 天 1h，2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  S2：103 天 15m，2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

对照：本轮不另跑对照家族；与第十一轮宽松版同口径对照（信号数、
每笔毛利、净收益变化）直接读 data/gate_iter_round11_summary.json
的 S1（1h 365d）与 S2（15m 入场 103d）全期行。

运行：python3 gate_iter_round12.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round12_summary.json
      + data/gate_iter_round12_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import os
import sys
from collections import Counter
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round11 as R11  # 复用第十一轮已验证的通用引擎与成本口径

DATA_DIR = os.path.join(SCRIPT_DIR, "data")
SYMBOLS = R11.SYMBOLS
START_EQUITY = R11.START_EQUITY
SPLIT_1H = R11.SPLIT_1H
SPLIT_15M = R11.SPLIT_15M

# ---- 锁定的参数：止损 1xATR，止盈 2xATR（用户要求 1:2）----
SL_MULT = 1.0
TP_MULT = 2.0
SWING_N = 5            # 大摆动点 N=5（11 根分形）
FVG_MIN_ATR = 0.5      # FVG 最小尺寸 0.5xATR
NEAR_ATR = 0.5          # FVG 与 OB“附近”：间隔 <= 0.5xATR（破位根 ATR）
OB_LOOKBACK = 10        # OB 候选：破位根之前 10 根（含破位根）
RETRACE_BARS_1H = 24    # 1h 回踩窗口 24 根
RETRACE_BARS_15M = 48   # 15m 回踩窗口 12h = 48 根
MAX_HOLD_1H = 8
MAX_HOLD_15M = 16


def killzone(t):
    """触发根起始时间是否在 Killzone：08:00-11:00 或 13:00-16:00 UTC。"""
    dt = datetime.fromtimestamp(t, timezone.utc)
    h = dt.hour + dt.minute / 60.0
    return (8.0 <= h < 11.0) or (13.0 <= h < 16.0)


# ----------------------------------------------------------------------
# 严格 SMC：有效 FVG（>=0.5xATR）与三者对齐 setup
# ----------------------------------------------------------------------
def valid_fvgs(bars, atr):
    """返回 {形成根下标 i: [(dir, lo, hi, width), ...]}，只含有效 FVG
    （缺口宽度 >= 0.5xATR，形成根 ATR）。定义与第十一轮相同。"""
    out = {}
    for i in range(2, len(bars)):
        if atr[i] is None:
            continue
        d = 0
        if bars[i]["l"] > bars[i - 2]["h"] and bars[i]["c"] > bars[i - 2]["c"]:
            d, lo, hi = 1, bars[i - 2]["h"], bars[i]["l"]
        elif bars[i]["h"] < bars[i - 2]["l"] and bars[i]["c"] < bars[i - 2]["c"]:
            d, lo, hi = -1, bars[i]["h"], bars[i - 2]["l"]
        else:
            continue
        width = hi - lo
        if width >= FVG_MIN_ATR * atr[i]:
            out.setdefault(i, []).append((d, lo, hi, width))
    return out


def raw_fvg_count(bars):
    n = 0
    for i in range(2, len(bars)):
        if bars[i]["l"] > bars[i - 2]["h"] and bars[i]["c"] > bars[i - 2]["c"]:
            n += 1
        elif bars[i]["h"] < bars[i - 2]["l"] and bars[i]["c"] < bars[i - 2]["c"]:
            n += 1
    return n


def build_strict_setups(bars, atr):
    """在 1h 结构根上扫描全部破位，生成三者对齐的 setup。
    返回 (setups, stats)。setups 每项：
      {dir, bos_idx, bos_t, ob_lo, ob_hi, ob_bar, fvg_lo, fvg_hi, fvg_idx}"""
    closes = [b["c"] for b in bars]
    sh_level, sh_idx, sl_level, sl_idx = R11.confirmed_levels(bars, n=SWING_N)
    fvgs = valid_fvgs(bars, atr)
    setups = []
    stats = {"breaks": 0, "choch_breaks": 0, "no_leg": 0, "no_ob": 0,
             "ob_found": 0, "ob_no_fvg": 0, "fvg_aligned": 0,
             "setups": 0, "raw_fvg": raw_fvg_count(bars),
             "valid_fvg": sum(len(v) for v in fvgs.values())}
    last_break_dir = 0
    for j in range(1, len(bars)):
        bos_dir = 0
        sh, sl = sh_level[j], sl_level[j]
        pc, c = closes[j - 1], closes[j]
        if sh is not None and pc <= sh < c:
            bos_dir = 1
        elif sl is not None and pc >= sl > c:
            bos_dir = -1
        if bos_dir == 0:
            continue
        stats["breaks"] += 1
        if last_break_dir != 0 and bos_dir == -last_break_dir:
            stats["choch_breaks"] += 1
        last_break_dir = bos_dir
        # ---- (b) 强势腿 OB：位移腿起点 -> 破位根，取最后 10 根内同向最大实体 ----
        leg_start = sl_idx[j] if bos_dir == 1 else sh_idx[j]
        if leg_start is None or leg_start < 0:
            stats["no_leg"] += 1
            continue
        lo_k = max(leg_start, j - OB_LOOKBACK + 1)
        best_k, best_body = None, -1.0
        for k in range(lo_k, j + 1):
            body = bars[k]["c"] - bars[k]["o"]
            if bos_dir == 1 and body <= 0:
                continue
            if bos_dir == -1 and body >= 0:
                continue
            if abs(body) > best_body:
                best_body, best_k = abs(body), k
        if best_k is None:
            stats["no_ob"] += 1
            continue
        stats["ob_found"] += 1
        ob_lo, ob_hi = bars[best_k]["l"], bars[best_k]["h"]
        # ---- (c) 对齐的有效 FVG：同向、形成于位移腿内、破位时未填补、
        #      与 OB 重叠或间隔 <= 0.5xATR（破位根 ATR）----
        if atr[j] is None:
            stats["ob_no_fvg"] += 1
            continue
        gap_thresh = NEAR_ATR * atr[j]
        best_fvg, best_gap = None, None
        for i in range(leg_start, j + 1):
            for (d, flo, fhi, _w) in fvgs.get(i, []):
                if d != bos_dir:
                    continue
                # 破位收盘时是否已被填补（形成根之后、破位根收盘前的收盘价）
                filled = False
                for k in range(i + 1, j + 1):
                    if bos_dir == 1 and closes[k] < flo:
                        filled = True
                        break
                    if bos_dir == -1 and closes[k] > fhi:
                        filled = True
                        break
                if filled:
                    continue
                if fhi < ob_lo:
                    gap = ob_lo - fhi
                elif ob_hi < flo:
                    gap = flo - ob_hi
                else:
                    gap = 0.0
                if gap <= gap_thresh and (best_gap is None or gap < best_gap):
                    best_gap, best_fvg = gap, (flo, fhi, i)
        if best_fvg is None:
            stats["ob_no_fvg"] += 1
            continue
        stats["fvg_aligned"] += 1
        setups.append({"dir": bos_dir, "bos_idx": j, "bos_t": bars[j]["t"],
                       "ob_lo": ob_lo, "ob_hi": ob_hi, "ob_bar": best_k,
                       "fvg_lo": best_fvg[0], "fvg_hi": best_fvg[1],
                       "fvg_idx": best_fvg[2]})
        stats["setups"] += 1
    return setups, stats


def trigger_setups(setups, mon_bars, atr_mon, starts, horizon):
    """在监测根（1h 或 15m）上推进 setup：回踩触及 / 作废 / 过期。
    starts: {setup 下标: 监测起始根下标}；horizon: 最多监测根数。
    返回 (signals, stats)，signals key=入场根 t。"""
    sigs = {}
    stats = {"triggered": 0, "invalidated": 0, "ob_broken": 0,
             "fvg_filled": 0, "expired": 0, "killzone_skipped": 0,
             "no_monitor": 0, "signals": 0}
    for si, s in enumerate(setups):
        start = starts.get(si)
        if start is None or start >= len(mon_bars) - 1:
            stats["no_monitor"] += 1
            continue
        outcome = None
        end = min(start + horizon, len(mon_bars) - 1)
        for m in range(start, end):
            b = mon_bars[m]
            d = s["dir"]
            if d == 1:
                if b["c"] < s["ob_lo"]:
                    outcome = "invalidated"
                    stats["ob_broken"] += 1
                    break
                if b["c"] < s["fvg_lo"]:
                    outcome = "invalidated"
                    stats["fvg_filled"] += 1
                    break
                touched = b["l"] <= s["ob_hi"] and b["c"] >= s["ob_lo"]
            else:
                if b["c"] > s["ob_hi"]:
                    outcome = "invalidated"
                    stats["ob_broken"] += 1
                    break
                if b["c"] > s["fvg_hi"]:
                    outcome = "invalidated"
                    stats["fvg_filled"] += 1
                    break
                touched = b["h"] >= s["ob_lo"] and b["c"] <= s["ob_hi"]
            if touched:
                if killzone(b["t"]):
                    outcome = "triggered"
                    stats["triggered"] += 1
                    if atr_mon[m] is not None:
                        entry_t = mon_bars[m + 1]["t"]
                        if entry_t not in sigs:
                            sigs[entry_t] = {
                                "direction": d, "atr": atr_mon[m],
                                "tag": ("strict OB[%.4g,%.4g]@%d FVG[%.4g,%.4g]@%d"
                                        % (s["ob_lo"], s["ob_hi"], s["ob_bar"],
                                           s["fvg_lo"], s["fvg_hi"], s["fvg_idx"])),
                                "ob_lo": s["ob_lo"], "ob_hi": s["ob_hi"],
                                "fvg_lo": s["fvg_lo"], "fvg_hi": s["fvg_hi"],
                                "bos_t": s["bos_t"]}
                            stats["signals"] += 1
                    break
                else:
                    # 窗口外触及不算也不消耗，setup 继续等窗口内触及
                    stats["killzone_skipped"] += 1
                    continue
        if outcome is None:
            stats["expired"] += 1
        elif outcome == "invalidated":
            stats["invalidated"] += 1
    return sigs, stats


def main():
    print("盈利策略迭代 · 第十二轮：SMC 严格形式化版（止损 1xATR / 止盈 2xATR，全模拟）")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    print("严格定义：摆动点 N=5 / 强势腿最大实体 OB / FVG>=0.5xATR / "
          "Killzone 08:00-11:00 与 13:00-16:00 UTC / 三者对齐才出手。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = R11.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = R11.load_funding(sym)
        data1h[sym] = (bars, funding)
        days = R11.group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = R11.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R11.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R11.group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    assert data1h["BTC_USDT"][0][0]["t"] % 14400 == 0, "1h 起始时间戳不在 4h 边界"
    assert data15["BTC_USDT"][0][0]["t"] % 3600 == 0, "15m 起始时间戳不在整点边界"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；"
          "时间戳对齐、零缺口。")

    days_all_1h = set(R11.group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(R11.group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    all_results, all_trades = [], []
    pooled = {}

    def record(res, trades_full, family, variant, gran, split_fn, setup_stats=None):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        if setup_stats is not None:
            res["setup_stats"] = setup_stats
        all_results.append(res)
        if trades_full is not None:
            pooled.setdefault(family, [])
            for t in trades_full:
                pooled[family].append(t["pnl"] / START_EQUITY)
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def split_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={res['win_rate']} "
              f"盈亏比={res['profit_factor']} 平均赢={res['avg_win_usdt']:+.0f} "
              f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    def run_family(family, label, bars_by_sym, signals_by_sym, funding_by_sym,
                   subsets, max_per_day, max_hold, bars_per_day, split_fn, gran,
                   setup_stats_by_sym=None):
        for sym in SYMBOLS:
            bars = bars_by_sym[sym]
            funding = funding_by_sym[sym]
            for wname, subset in subsets:
                trades, curve, ndays = R11.simulate_generic(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    max_per_day, max_hold, label, bars_per_day)
                # 把 setup 细节（OB/FVG/破位时刻）补进明细，供手工复核
                for t in trades:
                    sig = signals_by_sym[sym].get(t["entry_t"])
                    if sig is not None:
                        t["ob_lo"] = sig.get("ob_lo")
                        t["ob_hi"] = sig.get("ob_hi")
                        t["fvg_lo"] = sig.get("fvg_lo")
                        t["fvg_hi"] = sig.get("fvg_hi")
                        t["bos_t"] = sig.get("bos_t")
                res = R11.summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                ss = setup_stats_by_sym.get(sym) if setup_stats_by_sym else None
                record(res, trades if subset is None else None, family, label,
                       gran, split_fn, setup_stats=ss if subset is None else None)
                show(res, sym, wname)

    # ================= R12-S1：严格三者对齐，全 1h，365d =================
    print("\n=== R12-S1：严格三者对齐（全 1h，365d，8 币）===")
    atr1h = {s: R11.atr_wilder(data1h[s][0]) for s in SYMBOLS}
    sig_s1, setups_s1, st_s1 = {}, {}, {}
    for sym in SYMBOLS:
        bars = data1h[sym][0]
        setups, st = build_strict_setups(bars, atr1h[sym])
        setups_s1[sym] = setups
        starts = {i: s["bos_idx"] + 1 for i, s in enumerate(setups)}
        sig_s1[sym], trg = trigger_setups(setups, bars, atr1h[sym], starts,
                                          RETRACE_BARS_1H)
        st_s1[sym] = dict(st, **{f"trig_{k}": v for k, v in trg.items()})
    tot = lambda k: sum(v[k] for v in st_s1.values())
    print(f"[S1] setup 漏斗（8 币合计）：破位 {tot('breaks')} 次（其中 CHOCH 型 "
          f"{tot('choch_breaks')}）/ 无位移腿 {tot('no_leg')} / 有 OB "
          f"{tot('ob_found')} / 无 OB {tot('no_ob')} / OB 齐 FVG 对齐 "
          f"{tot('fvg_aligned')} / OB 有但无 FVG 对齐 {tot('ob_no_fvg')} / "
          f"setup {tot('setups')} / 触发 {tot('trig_triggered')} / 作废 "
          f"{tot('trig_invalidated')}（OB 穿破 {tot('trig_ob_broken')} / FVG 填补 "
          f"{tot('trig_fvg_filled')}）/ 过期 {tot('trig_expired')} / Killzone 外触及跳过 "
          f"{tot('trig_killzone_skipped')} / 信号 {tot('trig_signals')} 个；"
          f"原始 FVG {tot('raw_fvg')} 个 -> 有效 FVG(>=0.5xATR) {tot('valid_fvg')} 个")
    run_family("S1", "R12-S1", {s: data1h[s][0] for s in SYMBOLS}, sig_s1,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               2, MAX_HOLD_1H, 24, split_1h, "1h", st_s1)

    # ================= R12-S2：1h 结构、15m 入场，103d =================
    print("\n=== R12-S2：严格三者对齐（1h 结构、15m 入场，103d，8 币）===")
    atr15 = {s: R11.atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig_s2, st_s2 = {}, {}
    bars1h_from15 = {}
    for sym in SYMBOLS:
        bars15 = data15[sym][0]
        bars1h = R11.synthesize(bars15, 4, 3600)
        assert len(bars1h) == 103 * 24, f"{sym} 15m 合成 1h 应为 {103*24} 根，实际 {len(bars1h)}"
        bars1h_from15[sym] = bars1h
        atr1h15 = R11.atr_wilder(bars1h)
        setups, st = build_strict_setups(bars1h, atr1h15)
        idx15_of_t = {b["t"]: i for i, b in enumerate(bars15)}
        starts = {}
        for i, s in enumerate(setups):
            starts[i] = idx15_of_t.get(s["bos_t"] + 3600)
        sig_s2[sym], trg = trigger_setups(setups, bars15, atr15[sym], starts,
                                          RETRACE_BARS_15M)
        st_s2[sym] = dict(st, **{f"trig_{k}": v for k, v in trg.items()})
    tot2 = lambda k: sum(v[k] for v in st_s2.values())
    print(f"[S2] setup 漏斗（8 币合计）：破位 {tot2('breaks')} 次（其中 CHOCH 型 "
          f"{tot2('choch_breaks')}）/ 无位移腿 {tot2('no_leg')} / 有 OB "
          f"{tot2('ob_found')} / 无 OB {tot2('no_ob')} / OB 齐 FVG 对齐 "
          f"{tot2('fvg_aligned')} / OB 有但无 FVG 对齐 {tot2('ob_no_fvg')} / "
          f"setup {tot2('setups')} / 触发 {tot2('trig_triggered')} / 作废 "
          f"{tot2('trig_invalidated')}（OB 穿破 {tot2('trig_ob_broken')} / FVG 填补 "
          f"{tot2('trig_fvg_filled')}）/ 过期 {tot2('trig_expired')} / Killzone 外触及跳过 "
          f"{tot2('trig_killzone_skipped')} / 信号 {tot2('trig_signals')} 个；"
          f"原始 FVG {tot2('raw_fvg')} 个 -> 有效 FVG(>=0.5xATR) {tot2('valid_fvg')} 个")
    run_family("S2", "R12-S2", {s: data15[s][0] for s in SYMBOLS}, sig_s2,
               {s: data15[s][1] for s in SYMBOLS},
               [("103d", None), ("前51d", front_15), ("后52d", back_15)],
               2, MAX_HOLD_15M, 96, split_15, "15m", st_s2)

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, wnames) in [
            ("S1", "1h", ["365d", "前185d", "后180d"]),
            ("S2", "15m", ["103d", "前51d", "后52d"])]:
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["split"] == wname]
            n_tr = sum(r["trades"] for r in rs)
            avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
            avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
            avg_g = sum(r["gross_usdt"] for r in rs)
            avg_c = sum(r["taker_cost_sum"] for r in rs)
            print(f"[{fam} {gran} {wname}] 币均 Taker {avg_t*100:+.2f}% | "
                  f"M2 {avg_m2*100:+.2f}% | 笔数 {n_tr} | "
                  f"毛利合计 {avg_g:+.0f} | 成本合计 {avg_c:+.0f}")

    # ---- pooled t（全期逐笔，Taker）----
    print("\n=== Pooled t（全期逐笔，Taker，1x）===")
    for fam in ["S1", "S2"]:
        pnls = pooled.get(fam, [])
        print(f"[{fam}] n={len(pnls)} pooled t={R11.t_value(pnls)}")

    # ---- 与第十一轮宽松版同口径对照 ----
    print("\n=== 与第十一轮宽松版同口径对照（全期，Taker）===")
    try:
        with open(os.path.join(DATA_DIR, "gate_iter_round11_summary.json")) as f:
            r11 = json.load(f)
        for fam12, fam11, gran in [("S1", "S1", "1h"), ("S2", "S2", "15m")]:
            old = [r for r in r11 if r["family"] == fam11 and r["granularity"] == gran
                   and r["split"] in ("365d", "103d")]
            new = [r for r in all_results if r["family"] == fam12 and r["granularity"] == gran
                   and r["split"] in ("365d", "103d")]
            o_n = sum(r["trades"] for r in old)
            n_n = sum(r["trades"] for r in new)
            o_t = sum(r["taker_net_pct"] for r in old) / len(old)
            n_t = sum(r["taker_net_pct"] for r in new) / len(new)
            o_g = sum(r["gross_usdt"] for r in old) / max(1, o_n)
            n_g = (sum(r["gross_usdt"] for r in new) / n_n) if n_n else None
            print(f"[{fam12} vs R11-{fam11}] 笔数 {o_n} -> {n_n} "
                  f"（{n_n/o_n*100:.1f}%）| 币均 Taker {o_t*100:+.2f}% -> {n_t*100:+.2f}% "
                  f"（{n_t*100-o_t*100:+.2f}pp）| 每笔毛利 {o_g:+.2f} -> "
                  f"{n_g:+.2f}" if n_g is not None else
                  f"[{fam12} vs R11-{fam11}] 笔数 {o_n} -> {n_n} | "
                  f"币均 Taker {o_t*100:+.2f}% -> {n_t*100:+.2f}% | 每笔毛利 {o_g:+.2f} -> 无交易")
    except FileNotFoundError:
        print("未找到第十一轮汇总文件，跳过对照。")

    # ---- 写文件 ----
    out_sum = os.path.join(DATA_DIR, "gate_iter_round12_summary.json")
    out_tr = os.path.join(DATA_DIR, "gate_iter_round12_trades.csv")
    with open(out_sum, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    if all_trades:
        keys = list(all_trades[0].keys())
        with open(out_tr, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(all_trades)
    else:
        with open(out_tr, "w", newline="") as f:
            f.write("")
    print(f"\n写出：{out_sum}（{len(all_results)} 条）")
    print(f"写出：{out_tr}（{len(all_trades)} 笔）")


if __name__ == "__main__":
    main()
