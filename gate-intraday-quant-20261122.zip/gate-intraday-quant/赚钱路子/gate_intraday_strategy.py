#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gate 日内永续合约完整策略（全模拟，不下单、不开户、不碰真钱）
================================================================
交易所：Gate (gate.io) USDT 永续合约
标的：BTC_USDT / ETH_USDT / SOL_USDT
周期：15m K 线，UTC 自然日，当天 23:45 强制平仓、不过夜
数据：读 data/ 缓存（Gate 公开接口已取，2026-08-18 ~ 2026-11-15，
      90 个完整 UTC 日，每币 8,641 根 15m K 线），离线可复现。

策略名：ORB + VWAP + ATR 组合（以下简称 ORB-VWAP-ATR）
设计动机（针对前三个策略的教训，见《只做日内-Gate-模拟.md》）：
  1. ORB-1h 原版每天必做 1 笔（90 天 90 笔），突破后经常回落，
     平均持仓 6.6~7.8 小时、胜率仅 31~42%，说明“每天都交易”是错的，
     必须加过滤，只做方向和位置同向的日子。
  2. VWAP 原版胜率在 SOL 上 60% 仍亏钱（赢小输大），说明只看胜率会骗人，
     必须用 ATR 定出不对称的盈亏比（止损 1x ATR、止盈 2x ATR），
     让赢一笔能覆盖两笔亏损。
  3. EMA 原版胜率仅 22~24%，15m 金叉死叉在震荡市反复横跳，
     所以本策略不用 EMA 做入场信号，只用趋势+位置双重确认，
     且每天每币最多 1 笔，降低换手省手续费。

入场（多空对称，收盘价触发、下一根开盘价成交）：
  做多需同时满足（做空镜像）：
    a) ORB 方向：收盘价 > 开盘区间上沿（前 4 根 15m，00:00-01:00 UTC 的最高价）
    b) VWAP 位置：收盘价 > 当日 VWAP（典型价 x 成交额加权）
    c) 区间有效性：开盘区间宽度 >= 0.4 x ATR(14)（区间太小是噪音，不做）
    d) 波动率适中：ATR / 价格 在 0.05% ~ 1.0% 之间（太死不做，太暴不做）
  入场窗口：01:00-20:00 UTC（太晚不进，避免没时间走完止盈止损就被收盘平掉）

出场（按优先级）：
  1. 止损：入场价 - 1x ATR（多）；入场价 + 1x ATR（空），盘中高/低价触发，按止损价成交
  2. 止盈：入场价 + 2x ATR（多）；入场价 - 2x ATR（空），盘中高/低价触发，按止盈价成交
  3. VWAP 反穿：收盘价反向穿过 VWAP（多头收盘 < VWAP，空头收盘 > VWAP），按收盘价出场
  4. 当天 23:45（最后一根 K 线收盘）强制平仓，绝不过夜

风控（硬规则，写进代码）：
  - 每笔保证金 = 当前权益 x 10%，杠杆只测 1x / 2x，名义 = 保证金 x 杠杆
  - 单笔最坏亏损（止损 1x ATR + 一轮成本 0.25% 名义）约 0.055% 权益（1x），
    远低于单笔最大亏 1% 权益的上限；代码里仍做检查，超限则跳过该笔
  - 单日已实现亏损 <= -2% 权益，当天不再开新仓
  - 强平检查：反向波动达到 (1/杠杆 - 维持保证金率) 即爆仓，亏掉全部保证金
    （BTC/ETH 维持保证金率 0.3%，SOL 0.5%，Gate API 2026-11-17 实测）

成本（与前面三个策略同一口径，可并排对比）：
  - taker 手续费 0.075%/边（Gate API 实测，高于官网公布 VIP0 的 0.05%，保守口径）
  - 滑点 0.05%/边；一轮开平总成本 = 名义 x 0.25%
  - 资金费：持仓跨过 UTC 08:00/16:00 结算点时，按 data/ 缓存的实际费率计

运行：python3 gate_intraday_strategy.py
输出：终端打印汇总 + 对比表；明细写入
  data/gate_strategy_trades.csv（每笔交易）
  data/gate_strategy_summary.json（汇总指标）
"""
import csv
import json
import math
import os
import statistics
from datetime import datetime, timezone, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005}
TAKER = 0.00075    # Gate API 实测 2026-11-17（保守口径，官网 VIP0 公布 0.05%）
SLIPPAGE = 0.0005  # 每边
ROUNDTRIP_COST = (TAKER + SLIPPAGE) * 2  # 0.25% 名义本金
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10       # 每笔保证金占权益 10%
MAX_TRADES_PER_DAY = 1   # 每天每币最多 1 笔（硬上限）
# 注意：旧版曾设为 2 笔，结果变成“每天正好打满 2 笔”（539 笔），
# 因为平仓后价格仍在区间外、仍在 VWAP 同侧，下一根就立刻重新开仓。
# 改为 1 笔 + 下面的重新武装规则，才是“降低换手”的本意。
MAX_LOSS_PER_TRADE = 0.01  # 单笔最大亏 1% 权益（硬上限）
DAILY_STOP = -0.02        # 单日 -2% 停手
ATR_PERIOD = 14
ORB_MIN_RANGE_ATR = 0.4   # 开盘区间宽度 >= 0.4 x ATR 才有效
ATR_PCT_MIN = 0.0005      # ATR/价格下限 0.05%
ATR_PCT_MAX = 0.010       # ATR/价格上限 1.0%
STOP_ATR = 1.0            # 止损 1x ATR
TP_ATR = 2.0              # 止盈 2x ATR
ENTRY_END_HOUR = 20.0     # 20:00 UTC 之后不再开新仓


# ---------------------------------------------------------------- 数据
def load_bars(symbol):
    path = os.path.join(DATA_DIR, f"gate_15m_{symbol}.csv")
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    path = os.path.join(DATA_DIR, f"gate_funding_{symbol}.json")
    with open(path) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == 96}


def atr_wilder(bars, period=ATR_PERIOD):
    """Wilder ATR(14)，只用当前及之前的 K 线，无前视。返回与 bars 等长的列表，前 period 项为 None。"""
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            prev_c = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - prev_c), abs(b["l"] - prev_c)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


# ---------------------------------------------------------------- 交易记录
class Trade:
    __slots__ = ("symbol", "direction", "entry_t", "exit_t", "entry", "exit",
                 "stop", "tp", "atr", "pnl", "pnl_pct_equity", "liquidated",
                 "reason", "notional", "margin", "funding_cost", "hold_min")

    def __init__(self, symbol, direction, entry_t, entry, stop, tp, atr, notional, margin):
        self.symbol = symbol
        self.direction = direction  # 1 多 / -1 空
        self.entry_t = entry_t
        self.entry = entry
        self.stop = stop
        self.tp = tp
        self.atr = atr
        self.notional = notional
        self.margin = margin
        self.exit_t = None
        self.exit = None
        self.pnl = 0.0
        self.pnl_pct_equity = 0.0
        self.liquidated = False
        self.reason = ""
        self.funding_cost = 0.0
        self.hold_min = None


# ---------------------------------------------------------------- 回测
def run_strategy(symbol, leverage):
    bars = load_bars(symbol)
    funding = load_funding(symbol)
    atr = atr_wilder(bars)
    # bar 全局下标（用于取 ATR）
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars)
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / leverage - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    liquidations = 0
    # 过滤统计（用于诊断：多少天被哪条过滤挡掉）
    filter_stats = {"days": 0, "no_signal": 0, "range_too_small": 0,
                    "atr_out_of_range": 0, "daily_stop": 0}

    for day, day_bars in days.items():
        filter_stats["days"] += 1
        closes = [b["c"] for b in day_bars]
        # 日内 VWAP（典型价 x 成交额加权，与前面脚本同一口径）
        cum_pv, cum_v, vwap = 0.0, 0.0, [None] * len(day_bars)
        for i, b in enumerate(day_bars):
            tp = (b["h"] + b["l"] + b["c"]) / 3
            cum_pv += tp * b["sum"]
            cum_v += b["sum"]
            vwap[i] = cum_pv / cum_v if cum_v else b["c"]
        or_high = max(b["h"] for b in day_bars[:4])
        or_low = min(b["l"] for b in day_bars[:4])
        or_range = or_high - or_low

        pos = None
        trades_today = 0
        day_start_equity = equity
        day_pnl = 0.0
        day_stopped = False
        # 重新武装：某方向信号触发并开仓后，该方向信号失效；
        # 只有收盘价回到开盘区间内，该方向才能重新武装（防止平仓后立刻追在同一位置）

        armed = {1: True, -1: True}

        def funding_cost(tr):
            cost = 0.0
            day_start = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
            for h in (8, 16):
                s = int((day_start + timedelta(hours=h)).timestamp())
                if tr.entry_t < s <= tr.exit_t and s in funding:
                    rate = funding[s]
                    # 多头费率>0 付钱，空头收钱；反之亦然
                    cost += rate * tr.notional * (1 if tr.direction == 1 else -1)
            return cost

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, liquidations, day_pnl
            tr.exit_t, tr.exit = exit_t, exit_price
            tr.reason = reason
            tr.liquidated = liquidated
            tr.hold_min = (exit_t - tr.entry_t) / 60
            tr.funding_cost = funding_cost(tr)
            if liquidated:
                liquidations += 1
                tr.pnl = -tr.margin - tr.notional * (TAKER + SLIPPAGE)
            else:
                move = (exit_price - tr.entry) / tr.entry * tr.direction
                tr.pnl = tr.notional * move - tr.notional * ROUNDTRIP_COST - tr.funding_cost
            tr.pnl_pct_equity = tr.pnl / day_start_equity
            equity += tr.pnl
            day_pnl += tr.pnl
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            bar_dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = bar_dt.hour + bar_dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]

            # ---- 持仓管理：止损/止盈用盘中高低价触发，按止损/止盈价成交 ----
            if pos is not None:
                # 强平检查（1x/2x 下 ATR 止损远小于强平线，理论上不会触发，仍保留检查）
                if pos.direction == 1:
                    adv = (pos.entry - b["l"]) / pos.entry
                else:
                    adv = (b["h"] - pos.entry) / pos.entry
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos.direction == 1:
                    if b["l"] <= pos.stop:
                        close_trade(pos, b["t"], pos.stop, "stop_loss")
                        exited = True
                    elif b["h"] >= pos.tp:
                        close_trade(pos, b["t"], pos.tp, "take_profit")
                        exited = True
                    elif b["c"] < vwap[i]:
                        close_trade(pos, b["t"], b["c"], "vwap_recross")
                        exited = True
                else:
                    if b["h"] >= pos.stop:
                        close_trade(pos, b["t"], pos.stop, "stop_loss")
                        exited = True
                    elif b["l"] <= pos.tp:
                        close_trade(pos, b["t"], pos.tp, "take_profit")
                        exited = True
                    elif b["c"] > vwap[i]:
                        close_trade(pos, b["t"], b["c"], "vwap_recross")
                        exited = True
                if exited:
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue

            # ---- 开仓：收盘价触发，下一根开盘价成交 ----
            if pos is None and not day_stopped and trades_today < MAX_TRADES_PER_DAY \
                    and i >= 4 and hour < ENTRY_END_HOUR and i < len(day_bars) - 1:
                # 单日熔断：已实现亏损 <= -2% 权益，当天不再开仓
                if day_pnl / day_start_equity <= DAILY_STOP:
                    day_stopped = True
                    filter_stats["daily_stop"] += 1
                    continue
                if a is None:
                    continue
                atr_pct = a / b["c"]
                # 过滤 c/d 先行判断（用于诊断统计）
                if or_range < ORB_MIN_RANGE_ATR * a:
                    filter_stats["range_too_small"] += 1
                    continue
                if not (ATR_PCT_MIN <= atr_pct <= ATR_PCT_MAX):
                    filter_stats["atr_out_of_range"] += 1
                    continue
                sig = 0
                # 重新武装：收盘价回到区间内，两侧信号重新武装
                if or_low <= b["c"] <= or_high:
                    armed[1] = armed[-1] = True
                if b["c"] > or_high and b["c"] > vwap[i] and armed[1]:
                    sig = 1
                elif b["c"] < or_low and b["c"] < vwap[i] and armed[-1]:
                    sig = -1
                if sig == 0:
                    filter_stats["no_signal"] += 1
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * leverage
                # 单笔最坏亏损检查：止损 1x ATR + 一轮成本，超过 1% 权益则跳过
                worst_loss = notional * (STOP_ATR * a / entry + ROUNDTRIP_COST)
                if worst_loss / equity > MAX_LOSS_PER_TRADE:
                    continue
                if sig == 1:
                    stop = entry - STOP_ATR * a
                    tp = entry + TP_ATR * a
                else:
                    stop = entry + STOP_ATR * a
                    tp = entry - TP_ATR * a
                armed[sig] = False  # 该方向信号已消耗，需价格收回区间内才能重新武装
                pos = Trade(symbol, sig, nxt["t"], entry, stop, tp, a, notional, margin)
                trades_today += 1

        # 日内收尾：最后一根才触发的信号不持仓过夜（本策略因 i < len-1 的限制不会发生，保留兜底）
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None

    wins = [t for t in trades if t.pnl > 0]
    total_ret = (equity - START_EQUITY) / START_EQUITY
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    hold = [t.hold_min for t in trades if t.hold_min is not None]
    # 盈亏比：平均盈利 / 平均亏损（按每笔 pnl）
    avg_win = sum(t.pnl for t in wins) / len(wins) if wins else 0.0
    losses = [t for t in trades if t.pnl <= 0]
    avg_loss = abs(sum(t.pnl for t in losses) / len(losses)) if losses else 0.0
    return {
        "symbol": symbol, "leverage": leverage,
        "days": len(days), "trades": len(trades),
        "win_rate": round(len(wins) / len(trades), 4) if trades else None,
        "net_return": round(total_ret, 4),
        "final_equity": round(equity, 2),
        "max_dd": round(mdd, 4),
        "avg_hold_min": round(sum(hold) / len(hold), 1) if hold else None,
        "liquidations": liquidations,
        "total_pnl": round(sum(t.pnl for t in trades), 2),
        "avg_win_usdt": round(avg_win, 2),
        "avg_loss_usdt": round(avg_loss, 2),
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "filter_stats": filter_stats,
    }, trades


def main():
    bj = datetime.now(timezone.utc) + timedelta(hours=8)
    print(f"取数时间（北京时间）：{bj.strftime('%Y-%m-%d %H:%M')}  数据源：data/ 缓存（Gate 公开接口，2026-08-18~2026-11-15） 全模拟")
    print("策略：ORB + VWAP + ATR 组合 | 止损 1x ATR / 止盈 2x ATR | 当天 23:45 强制平仓")
    print("成本：一轮开平名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边），资金费按实际费率计")
    print("仓位：每笔保证金 10% 权益 | 每天每币最多 1 笔 | 单笔最坏亏上限 1% 权益 | 单日 -2% 停手\n")

    all_trades = []
    results = []
    for sym in SYMBOLS:
        for lev in [1, 2]:
            r, trades = run_strategy(sym, lev)
            results.append(r)
            all_trades.extend(trades)
            fs = r["filter_stats"]
            print(f"[{sym} {lev}x] 笔数={r['trades']} 胜率={r['win_rate']} "
                  f"净收益={r['net_return']*100:.2f}% 最大回撤={r['max_dd']*100:.2f}% "
                  f"平均持仓={r['avg_hold_min']}分钟 爆仓={r['liquidations']} "
                  f"盈亏比={r['profit_factor']} 平均赢={r['avg_win_usdt']} 平均亏={r['avg_loss_usdt']}")
            print(f"    过滤统计：交易日={fs['days']} 无信号={fs['no_signal']} "
                  f"区间太小={fs['range_too_small']} ATR越界={fs['atr_out_of_range']} 单日熔断={fs['daily_stop']}")

    print("\n=== 汇总：三币平均净收益（各币独立 10 万 USDT 虚拟权益）===")
    for lev in [1, 2]:
        rs = [r for r in results if r["leverage"] == lev]
        avg = sum(r["net_return"] for r in rs) / len(rs)
        tot = sum(r["trades"] for r in rs)
        tot_liq = sum(r["liquidations"] for r in rs)
        print(f"ORB-VWAP-ATR {lev}x：平均净收益 {avg*100:.2f}%  总笔数 {tot}  总爆仓 {tot_liq}")

    # ---- 与前面三个策略并排对比（1x，取 gate_intraday_summary.json 的实测值）----
    print("\n=== 并排对比：前面三个策略 1x（90 天同一批数据，同一成本口径）===")
    prior = {}
    try:
        with open(os.path.join(DATA_DIR, "gate_intraday_summary.json")) as f:
            for r in json.load(f):
                if r["leverage"] == 1:
                    prior.setdefault(r["strategy"], []).append(r)
        for strat, rs in prior.items():
            avg = sum(r["net_return"] for r in rs) / len(rs)
            tot = sum(r["trades"] for r in rs)
            wrs = [r["win_rate"] for r in rs if r["win_rate"] is not None]
            print(f"{strat} 1x：平均净收益 {avg*100:.2f}%  总笔数 {tot}  "
                  f"胜率 {min(wrs)*100:.1f}%~{max(wrs)*100:.1f}%")
    except FileNotFoundError:
        print("（未找到 gate_intraday_summary.json，跳过对比；按报告记录：ORB -2.64%、VWAP -4.80%、EMA -3.80%）")
    new1x = [r for r in results if r["leverage"] == 1]
    avg_new = sum(r["net_return"] for r in new1x) / len(new1x)
    print(f"ORB-VWAP-ATR 1x：平均净收益 {avg_new*100:.2f}%  总笔数 {sum(r['trades'] for r in new1x)}")

    # ---- 明细落盘 ----
    trades_path = os.path.join(DATA_DIR, "gate_strategy_trades.csv")
    with open(trades_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["symbol", "leverage", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "stop", "tp", "atr", "notional", "pnl_usdt",
                    "pnl_pct_equity", "reason", "liquidated", "hold_min", "funding_cost_usdt"])
        for t in sorted(all_trades, key=lambda x: (x.entry_t, x.symbol)):
            # 杠杆信息从回测循环里无法直接挂在 Trade 上，用 notional/margin 反推
            lev = round(t.notional / t.margin) if t.margin else None
            w.writerow([t.symbol, lev, "LONG" if t.direction == 1 else "SHORT",
                        datetime.fromtimestamp(t.entry_t, timezone.utc).isoformat(),
                        datetime.fromtimestamp(t.exit_t, timezone.utc).isoformat() if t.exit_t else "",
                        t.entry, t.exit, t.stop, t.tp, t.atr, t.notional,
                        round(t.pnl, 2), round(t.pnl_pct_equity, 6), t.reason,
                        t.liquidated, t.hold_min, round(t.funding_cost, 2)])
    with open(os.path.join(DATA_DIR, "gate_strategy_summary.json"), "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\n明细已写入：{trades_path}")
    print("汇总已写入：data/gate_strategy_summary.json")
    print("\n模拟结束：本脚本不下单、不开户、不碰真钱。")


if __name__ == "__main__":
    main()
