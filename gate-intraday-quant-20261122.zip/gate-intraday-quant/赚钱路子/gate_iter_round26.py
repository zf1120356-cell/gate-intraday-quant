#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十六轮：新发明方向——工作日/周末拆分检验（全模拟）
======================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（预注册检验，不是事后挑参）：
  第二十轮的 09:00/15:00 时段效应（伦敦开盘、纽约开盘附近）暗示
  机构资金流可能只在工作日出现。加密货币虽然 24/7 交易，但周末
  流动性更薄、参与者结构不同。本轮的问题是：F1 的时段效应是不是
  一个工作日现象？之前没有任何一轮按星期几拆分过样本（第四轮只
  诊断了 1h 收益滞后自相关约等于 0、截面动量相关 0.004、24 个 UTC
  小时无一显著——那是按小时切分，不是按星期几）。

跑前写死的规则（单组参数，不许用全样本挑）：
  信号源 F1（第七轮原版规则一字不变，引擎照抄第二十轮
  gate_iter_round20.py 的 build_f1_signals + simulate_f1，
  本脚本 import r20 复用，零口径漂移；止盈固定 2.0）：
    信号根 08:00~19:00 UTC 收盘：BTC 2h 收益 |rBTC| >= 0.5%，且山寨
    自身 2h 收益 |rALT| < 0.5*|rBTC|；方向 = sign(rBTC)；
    下一根开盘进场；止损 1xATR、止盈 2xATR；最多持 4h（1h 版 4 根，
    15m 版 16 根）；每天每币最多 2 笔；当天最后一根收盘强制平仓
    （1h 版 23:00，15m 版 23:45）；单日 -2% 熔断；同根同时碰止损
    和止盈先判止损；只做 7 个山寨，不做 BTC 本身。
    1h 版 ATR(14,1h)、lookback 2 根；15m 版 ATR(14,15m)、lookback 8 根。
  工作日/周末定义（跑前写死）：按入场时间戳的 UTC 日期，
    weekday() < 5（周一至周五）为工作日，>= 5（周六、周日）为周末。
    与入场小时口径一致（第二十轮 entry_hour_utc 的同款定义）。
  六臂（唯一变量是入场时段 + 星期几过滤，过滤在信号层执行：
  不在范围内的信号直接丢弃，不占每日 2 笔上限、不占持仓）：
    A        主臂 A：MAIN-15m（F1 + 只在 09:00/15:00 UTC 入场，
             第二十轮原样）+ 只在工作日入场。
    B        主臂 B：同一规则 + 只在周末入场。
    CTRL1    对照 1：MAIN-15m 全周（第二十轮已发表数字作复核）。
    CTRL2-WD 对照 2 工作日：原版 F1（无时段限制）+ 只在工作日入场。
    CTRL2-WE 对照 2 周末：原版 F1（无时段限制）+ 只在周末入场。
    CTRL2-FULL 对照 2 全周：原版 F1 全周，只为复核引擎对照
             第九轮/第二十轮 CTRL1 已发表数字，不参与判定。
  主臂按任务要求是 15m 粒度；1h 粒度用同一组六臂再跑一遍，只作
  跨粒度稳健性对照，不参与达标判定（报告里写清）。

窗口：
  F1-1h：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  F1-15m：全 103 天 2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
双边）；M1/M2 对照同第七/九/二十轮；资金费按实际费率计（08:00/
16:00 结算点，前半段 2026-05-21 之前无数据按 0 计）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。
  判定规则（跑前写死）：主臂 A 要算通过，必须同时满足两条——
  (1) A 自身前后两半都为正且全期 >2%；
  (2) 合并样本（CTRL1，MAIN 全周）同样前后两半都为正且全期 >2%
      ——这是任务要求的合并样本再验证，防止只挑工作日子集过关。
  主臂 B 同理（B + CTRL1 合并）。1h 粒度只作稳健性对照。

诊断（必须给）：
  工作日与周末各自的信号数、每笔毛利、t 值、胜率，以及工作日 vs
  周末每笔毛利的差值检验（Welch 双样本 t，毛利与 Taker 净各一版，
  分粒度；|t|>=1.96 视为名义 5% 显著，正态近似，报告里写清）。
  周末样本只有约 2/7，报告里写清样本量局限。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) CTRL1（MAIN 全周）全期 Taker 逐币对照第二十轮已发表数字
      （MAIN-1h：ETH -0.06% / SOL +0.41% / DOGE -0.58% /
      LINK -0.50% / XRP +0.29% / BNB -0.88% / ADA +0.59%；
      MAIN-15m：ETH -0.13% / SOL -0.47% / DOGE -0.13% /
      LINK +0.05% / XRP +0.30% / BNB -0.48% / ADA +0.76%），
      误差 <0.05pp。
  (b) CTRL2-FULL（原版 F1 全周）全期 Taker 逐币对照第二十轮
      CTRL1 已发表数字（F1-1h：ETH +0.10% / SOL -1.29% /
      DOGE -3.72% / LINK -4.21% / XRP -3.66% / BNB -5.00% /
      ADA -0.93%；F1-15m：ETH -0.66% / SOL -1.45% / DOGE -1.24% /
      LINK -0.83% / XRP -1.77% / BNB -1.71% / ADA -0.62%），
      误差 <0.05pp。
  (c) 信号分区校验：每币每粒度，A 信号 + B 信号 == CTRL1 信号；
      CTRL2-WD 信号 + CTRL2-WE 信号 == CTRL2-FULL 信号。
      （成交笔数不要求相等：信号层过滤改变每日上限与持仓占用，
      见第二十轮 §0.2 的同款说明。）
  (d) 主臂 A 首笔交易人工核对触发链、入场星期几、止损/止盈。

运行：python3 gate_iter_round26.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round26_summary.json
      + data/gate_iter_round26_trades.csv
      + data/gate_iter_round26_weekday_diag.json
复现：跑两遍，三个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_iter_round20 as r20  # noqa: E402  引擎复用，保证口径零漂移

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = r20.SYMBOLS
ALTS = r20.ALTS
TARGET_HOURS = r20.TARGET_HOURS   # {9, 15}，第二十轮原样
TP_MULT = 2.0                     # 止盈 2xATR（用户要求的 1:2）
SL_MULT = 1.0                     # 止损 1xATR
SPLIT_1H = r20.SPLIT_1H
SPLIT_15M = r20.SPLIT_15M
START_EQUITY = r20.START_EQUITY

WEEKDAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def entry_dt(entry_t):
    return datetime.fromtimestamp(entry_t, timezone.utc)


def is_weekday(entry_t):
    """工作日：入场 UTC 日期 weekday() < 5（周一至周五）。"""
    return entry_dt(entry_t).weekday() < 5


def entry_weekday(entry_t):
    return entry_dt(entry_t).weekday()


def welch_t(a, b):
    """Welch 双样本 t 检验：返回 (t, 自由度, n1, n2, 均值差)。
    显著性按正态近似判读（|t|>=1.96 视为名义 5% 显著），报告里写清。"""
    n1, n2 = len(a), len(b)
    if n1 < 2 or n2 < 2:
        return None, None, n1, n2, None
    m1 = sum(a) / n1
    m2 = sum(b) / n2
    v1 = sum((x - m1) ** 2 for x in a) / (n1 - 1)
    v2 = sum((x - m2) ** 2 for x in b) / (n2 - 1)
    se2 = v1 / n1 + v2 / n2
    if se2 <= 0:
        return None, None, n1, n2, round(m1 - m2, 2)
    t = (m1 - m2) / math.sqrt(se2)
    df = se2 ** 2 / ((v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1))
    return round(t, 2), round(df, 1), n1, n2, round(m1 - m2, 2)


def main():
    print("盈利策略迭代 · 第二十六轮：工作日/周末拆分检验（全模拟）")
    print("主臂 A：MAIN-15m + 工作日；主臂 B：MAIN-15m + 周末；"
          "对照 1：MAIN-15m 全周；对照 2：原版 F1 按工作日/周末拆分。")
    print("止损 1xATR / 止盈 2xATR；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = r20.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = r20.load_funding(sym)
        data1h[sym] = (bars, funding)
        days = r20.group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = r20.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = r20.load_funding(sym)
        data15[sym] = (bars, funding)
        days = r20.group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    days_all_1h = set(r20.group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(r20.group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- 工作日/周末天数（UTC 日期）----
    def wd_counts(dayset):
        wd = sum(1 for d in dayset if d.weekday() < 5)
        return wd, len(dayset) - wd
    day_counts = {
        "1h": {"365d": wd_counts(days_all_1h), "前185d": wd_counts(front_1h), "后180d": wd_counts(back_1h)},
        "15m": {"103d": wd_counts(days_all_15), "前51d": wd_counts(front_15), "后52d": wd_counts(back_15)},
    }
    print("\n=== 工作日/周末天数（UTC 日期）===")
    for gran, d in day_counts.items():
        for wname, (wd, we) in d.items():
            print(f"  {gran} {wname}：工作日 {wd} 天 / 周末 {we} 天（周末占比 {we/(wd+we)*100:.1f}%）")

    # ---- F1 信号：同一粒度只生成一次，六臂共用同一组信号 ----
    atr1h = {s: r20.atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: r20.atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig1h, sig15 = {}, {}
    for sym in ALTS:
        sig1h[sym] = r20.build_f1_signals(data1h[sym][0], data1h["BTC_USDT"][0],
                                          atr1h[sym], 2, 4, TP_MULT)
        sig15[sym] = r20.build_f1_signals(data15[sym][0], data15["BTC_USDT"][0],
                                          atr15[sym], 8, 16, TP_MULT)
    print(f"[F1] 信号数（与过滤无关，六臂共用）：1h 合计 "
          f"{sum(len(v) for v in sig1h.values())}，15m 合计 "
          f"{sum(len(v) for v in sig15.values())}。")

    def filter_signals(sigs, keep):
        """keep(entry_t) -> bool。过滤在信号层执行。"""
        return {t: v for t, v in sigs.items() if keep(t)}

    def in_hours(t):
        return r20.entry_hour_utc(t) in TARGET_HOURS

    ARMS = [
        ("A", "MAIN-WD", lambda t: in_hours(t) and is_weekday(t)),
        ("B", "MAIN-WE", lambda t: in_hours(t) and not is_weekday(t)),
        ("CTRL1", "MAIN-FULL", lambda t: in_hours(t)),
        ("CTRL2-WD", "F1-WD", lambda t: is_weekday(t)),
        ("CTRL2-WE", "F1-WE", lambda t: not is_weekday(t)),
        ("CTRL2-FULL", "F1-FULL", lambda t: True),
    ]
    GRANS = [
        ("1h", data1h, sig1h, 24,
         [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
         lambda et: "前185d" if entry_dt(et).date() < SPLIT_1H.date() else "后180d"),
        ("15m", data15, sig15, 96,
         [("103d", None), ("前51d", front_15), ("后52d", back_15)],
         lambda et: "前51d" if entry_dt(et).date() < SPLIT_15M.date() else "后52d"),
    ]

    all_results, all_trades = [], []
    pass_stats = {}  # (arm, gran, sym) -> (n_sig_total, n_sig_pass)
    for arm, label, keep in ARMS:
        for gran, data, sigs_all, bpd, windows, split_fn in GRANS:
            print(f"\n=== {arm} {label} · F1-{gran}（TP {TP_MULT}，SL {SL_MULT}）===")
            for sym in ALTS:
                sigs_full = sigs_all[sym]
                sigs = filter_signals(sigs_full, keep)
                pass_stats[(arm, gran, sym)] = (len(sigs_full), len(sigs))
                for wname, subset in windows:
                    bars, funding = data[sym]
                    trades, curve, ndays = r20.simulate_f1(
                        sym, bars, sigs, funding, subset, 2, label, bpd)
                    res = r20.summarize(sym, trades, curve, label, len(sigs))
                    res["arm"] = arm
                    res["variant"] = label
                    res["family"] = "F1"
                    res["tp_mult"] = TP_MULT
                    res["granularity"] = gran
                    res["split"] = wname
                    res["days"] = ndays
                    res["signals_total"] = len(sigs_full)
                    res["signals_pass"] = len(sigs)
                    res["signal_pass_rate"] = round(len(sigs) / len(sigs_full), 4) if sigs_full else None
                    all_results.append(res)
                    if wname in ("365d", "103d"):
                        for t in trades:
                            t2 = dict(t)
                            t2["arm"] = arm
                            t2["variant"] = label
                            t2["family"] = "F1"
                            t2["tp_mult"] = TP_MULT
                            t2["granularity"] = gran
                            t2["split"] = split_fn(t["entry_t"])
                            t2["entry_hour_utc"] = r20.entry_hour_utc(t["entry_t"])
                            t2["entry_weekday"] = entry_weekday(t["entry_t"])
                            t2["entry_weekday_label"] = WEEKDAY_NAMES[entry_weekday(t["entry_t"])]
                            t2["weekday_flag"] = "WD" if is_weekday(t["entry_t"]) else "WE"
                            all_trades.append(t2)
                    gp = f"{res['gross_per_trade_usdt']:+.2f}" if res['gross_per_trade_usdt'] is not None else "—"
                    print(f"[{arm} F1-{gran} {sym} {wname}] n={res['trades']} "
                          f"信号 {len(sigs)}/{len(sigs_full)} 胜率={res['win_rate']} "
                          f"盈亏比={res['profit_factor']} Taker {res['taker_net_pct']*100:+.2f}% "
                          f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                          f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                          f"每笔毛利={gp} 成本={res['taker_cost_sum']:+.0f} "
                          f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label, _ in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            for wname, _ in windows:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                wr = (sum((r["win_rate"] or 0) * r["trades"] for r in rs) / nt) if nt else None
                gpt = f"{gt/nt:+.2f}" if nt else "—"
                print(f"  {arm} F1-{gran} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                      f"每笔毛利 {gpt} USDT 胜率 {wr:.3f}" if wr is not None else
                      f"  {arm} F1-{gran} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} 每笔毛利 {gpt} 胜率 —")

    # ---- 信号通过率 ----
    print("\n=== 信号通过率 ===")
    for arm, label, _ in ARMS:
        for gran, _, _, _, _, _ in GRANS:
            st = sum(pass_stats[(arm, gran, s)][0] for s in ALTS)
            sp = sum(pass_stats[(arm, gran, s)][1] for s in ALTS)
            print(f"  {arm} F1-{gran}：信号通过 {sp}/{st} = {sp/st*100:.1f}%")

    # ---- pooled t（全期明细，Taker 与 M1）----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for arm, label, _ in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            full = windows[0][0]
            sub = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
            for wname, _ in windows:
                s2 = [t for t in sub if wname == full or t["split"] == wname]
                vt = [t["pnl"] / START_EQUITY for t in s2]
                vm = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
                vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in s2]
                print(f"  {arm} F1-{gran} {wname}：n={len(s2)} "
                      f"pooled t(Taker)={r20.t_value(vt)} pooled t(M1)={r20.t_value(vm)} "
                      f"pooled t(毛利)={r20.t_value(vg)}")

    # ---- 工作日 vs 周末：每笔毛利差值检验（Welch）----
    print("\n=== 工作日 vs 周末差值检验（Welch 双样本 t，正态近似，|t|>=1.96 名义 5% 显著）===")
    diff_tests = []
    for gran, _, _, _, _, _ in GRANS:
        for pair, g1, g2 in [("MAIN (A vs B)", "A", "B"),
                             ("F1 原版 (CTRL2-WD vs CTRL2-WE)", "CTRL2-WD", "CTRL2-WE")]:
            for metric, key in [("每笔毛利", lambda t: t["price_pnl"] - t["funding_cost_usdt"]),
                                ("每笔 Taker 净", lambda t: t["pnl"])]:
                a = [key(t) for t in all_trades if t["arm"] == g1 and t["granularity"] == gran]
                b = [key(t) for t in all_trades if t["arm"] == g2 and t["granularity"] == gran]
                tstat, df, n1, n2, diff = welch_t(a, b)
                m1 = sum(a) / n1 if n1 else None
                m2 = sum(b) / n2 if n2 else None
                diff_tests.append({"granularity": gran, "pair": pair, "metric": metric,
                                   "n_weekday": n1, "n_weekend": n2,
                                   "mean_weekday": round(m1, 2) if m1 is not None else None,
                                   "mean_weekend": round(m2, 2) if m2 is not None else None,
                                   "diff_usdt": diff, "welch_t": tstat, "welch_df": df})
                print(f"  {gran} {pair} {metric}：工作日 n={n1} 均值 {m1:+.2f} / "
                      f"周末 n={n2} 均值 {m2:+.2f} / 差值 {diff:+.2f} USDT "
                      f"/ Welch t={tstat} (df={df}) → "
                      f"{'名义显著' if tstat is not None and abs(tstat) >= 1.96 else '不显著'}")

    # ---- 达标判定（主口径 Taker）----
    print("\n=== 达标判定（主口径 Taker）===")
    verdict = {}
    for arm, label, _ in ARMS:
        for gran, _, _, _, windows, _ in GRANS:
            wnames = [w for w, _ in windows]
            row = {}
            for wname in wnames:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            good = row[wnames[1]] > 0 and row[wnames[2]] > 0 and row[wnames[0]] > 0.02
            verdict[(arm, gran)] = good
            print(f"  {arm} F1-{gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
                  f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}% → "
                  f"{'达标' if good else '不达标'}")
    # 合并样本再验证：主臂 A/B 要算通过，自身达标且 CTRL1（合并样本）同样达标
    for gran in ("15m", "1h"):
        for main_arm in ("A", "B"):
            eff = verdict[(main_arm, gran)] and verdict[("CTRL1", gran)]
            print(f"  主臂 {main_arm} F1-{gran} 有效判定：自身 "
                  f"{'达标' if verdict[(main_arm, gran)] else '不达标'} + 合并样本 CTRL1 "
                  f"{'达标' if verdict[('CTRL1', gran)] else '不达标'} → "
                  f"{'通过' if eff else '不通过'}")
    print("  （15m 为任务指定判定粒度；1h 只作跨粒度稳健性对照。）")

    # ---- 复核 (a)：CTRL1 vs 第二十轮 MAIN 已发表数字 ----
    print("\n=== 复核 (a)：CTRL1 vs 第二十轮 MAIN 已发表数字（Taker，全期）===")
    checks_a = {
        ("1h", "ETH_USDT"): -0.0006, ("1h", "SOL_USDT"): 0.0041,
        ("1h", "DOGE_USDT"): -0.0058, ("1h", "LINK_USDT"): -0.0050,
        ("1h", "XRP_USDT"): 0.0029, ("1h", "BNB_USDT"): -0.0088,
        ("1h", "ADA_USDT"): 0.0059,
        ("15m", "ETH_USDT"): -0.0013, ("15m", "SOL_USDT"): -0.0047,
        ("15m", "DOGE_USDT"): -0.0013, ("15m", "LINK_USDT"): 0.0005,
        ("15m", "XRP_USDT"): 0.0030, ("15m", "BNB_USDT"): -0.0048,
        ("15m", "ADA_USDT"): 0.0076,
    }
    full_name = {"1h": "365d", "15m": "103d"}
    bad_a = 0
    for (gran, sym), expect in sorted(checks_a.items()):
        r = [x for x in all_results if x["arm"] == "CTRL1" and x["granularity"] == gran
             and x["symbol"] == sym and x["split"] == full_name[gran]][0]
        ok = abs(r["taker_net_pct"] - expect) < 0.0005
        bad_a += 0 if ok else 1
        print(f"  CTRL1 F1-{gran} {sym}: 本轮 {r['taker_net_pct']*100:+.2f}% vs 第二十轮 "
              f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核 (a) 结果：{len(checks_a)-bad_a}/{len(checks_a)} 一致"
          + ("（全部通过）" if bad_a == 0 else "（有出入，见报告）"))

    # ---- 复核 (b)：CTRL2-FULL vs 第二十轮 CTRL1 已发表数字 ----
    print("\n=== 复核 (b)：CTRL2-FULL vs 第二十轮 CTRL1 已发表数字（Taker，全期）===")
    checks_b = {
        ("1h", "ETH_USDT"): 0.0010, ("1h", "SOL_USDT"): -0.0129,
        ("1h", "DOGE_USDT"): -0.0372, ("1h", "LINK_USDT"): -0.0421,
        ("1h", "XRP_USDT"): -0.0366, ("1h", "BNB_USDT"): -0.0500,
        ("1h", "ADA_USDT"): -0.0093,
        ("15m", "ETH_USDT"): -0.0066, ("15m", "SOL_USDT"): -0.0145,
        ("15m", "DOGE_USDT"): -0.0124, ("15m", "LINK_USDT"): -0.0083,
        ("15m", "XRP_USDT"): -0.0177, ("15m", "BNB_USDT"): -0.0171,
        ("15m", "ADA_USDT"): -0.0062,
    }
    bad_b = 0
    for (gran, sym), expect in sorted(checks_b.items()):
        r = [x for x in all_results if x["arm"] == "CTRL2-FULL" and x["granularity"] == gran
             and x["symbol"] == sym and x["split"] == full_name[gran]][0]
        ok = abs(r["taker_net_pct"] - expect) < 0.0005
        bad_b += 0 if ok else 1
        print(f"  CTRL2-FULL F1-{gran} {sym}: 本轮 {r['taker_net_pct']*100:+.2f}% vs 第二十轮 "
              f"{expect*100:+.2f}% → {'一致' if ok else '不一致！！'}")
    print(f"  复核 (b) 结果：{len(checks_b)-bad_b}/{len(checks_b)} 一致"
          + ("（全部通过）" if bad_b == 0 else "（有出入，见报告）"))

    # ---- 复核 (c)：信号分区校验 ----
    print("\n=== 复核 (c)：信号分区校验（A+B==CTRL1；CTRL2-WD+CTRL2-WE==CTRL2-FULL）===")
    bad_c = 0
    for gran, _, _, _, _, _ in GRANS:
        for sym in ALTS:
            a = pass_stats[("A", gran, sym)][1]
            b = pass_stats[("B", gran, sym)][1]
            c1 = pass_stats[("CTRL1", gran, sym)][1]
            ok1 = (a + b) == c1
            w1 = pass_stats[("CTRL2-WD", gran, sym)][1]
            w2 = pass_stats[("CTRL2-WE", gran, sym)][1]
            cf = pass_stats[("CTRL2-FULL", gran, sym)][1]
            ok2 = (w1 + w2) == cf
            bad_c += (0 if ok1 else 1) + (0 if ok2 else 1)
            if not (ok1 and ok2):
                print(f"  !! {gran} {sym}: A+B={a}+{b}={a+b} vs CTRL1={c1}；"
                      f"WD+WE={w1}+{w2}={w1+w2} vs FULL={cf}")
    print(f"  复核 (c) 结果：{14*2-bad_c}/{14*2} 组分区一致"
          + ("（全部通过）" if bad_c == 0 else "（有出入，见报告）"))

    # ---- 复核 (d)：主臂 A 首笔交易（打印出来，报告里人工核对）----
    a_trades = sorted([t for t in all_trades if t["arm"] == "A"],
                      key=lambda x: x["entry_t"])
    if a_trades:
        t = a_trades[0]
        print("\n=== 复核 (d)：主臂 A 首笔交易 ===")
        print(f"  {t['granularity']} {t['symbol']} {t['direction']} "
              f"入场 {datetime.fromtimestamp(t['entry_t'], timezone.utc).isoformat()} "
              f"({t['entry_weekday_label']}，{t['weekday_flag']}) "
              f"入场价 {t['entry']} 止损 {t['stop']} 止盈 {t['tp']} "
              f"出场 {t['exit']} 原因 {t['reason']} 价差 PnL {t['price_pnl']:+.2f} "
              f"Taker 净 {t['pnl']:+.2f}")

    with open(os.path.join(DATA_DIR, "gate_iter_round26_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round26_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "entry_weekday",
                    "entry_weekday_label", "weekday_flag", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["arm"], x["granularity"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"], t["entry_weekday"], t["entry_weekday_label"],
                        t["weekday_flag"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round26_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round26_trades.csv ({len(all_trades)} 笔)")

    diag = {
        "weekday_counts": day_counts,
        "welch_diff_tests": diff_tests,
        "target_hours": sorted(TARGET_HOURS),
        "note": "工作日=入场 UTC 日期 weekday()<5；周末=weekday()>=5。"
                "Welch t 为双样本 t（毛利与 Taker 净各一版，分粒度）；"
                "|t|>=1.96 视为名义 5% 显著（正态近似）。",
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round26_weekday_diag.json"), "w") as f:
        json.dump(diag, f, indent=2, ensure_ascii=False)
    print("工作日/周末诊断已写入：data/gate_iter_round26_weekday_diag.json")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
