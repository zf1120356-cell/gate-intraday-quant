#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第四十二轮：FBO 假突破陷阱反转（分系统 SUB-SMC，新信号第二次测）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

预注册（跑前写死，不可改；来源：分系统下一代信号设计.md §2 FBO + §4 测试计划）：
  测什么：FBO 假突破陷阱反转——价格收盘突破上一会话区间又在 2 根内收回
  区间内，顺失败方向入场，止损放在突破极值之外，吃被套突破追单者的止损
  推动的反转；不用 OB/FVG/OTE/CHOCH，不等回踩。
  信号定义（设计 §2.1，参数一字不改；全部用已收盘 15m K 线，入场一律
  下一根 15m 开盘；多空对称）：
    - 位子：上一完整会话的区间——亚洲 00:00-08:00 UTC、欧洲 08:00-16:00 UTC、
      美国 16:00-24:00 UTC（与 36 轮时段划分一致）。每会话 32 根 15m；
      数据自 2026-08-09 00:00 UTC 起连续，故 bar i 的上一完整会话 =
      bars[32*(s-1) .. 32*s-1]，其中 s = i // 32；i < 32 无上一完整会话。
    - 突破：一根 15m 收盘价站上上一会话最高（做空陷阱）或跌破上一会话
      最低（做多陷阱）；且突破极值离位子 <= 1.0xATR(14)（跑得太远就不是
      陷阱，是真突破，不做）。
    - 失败：突破后的 2 根收盘 K 线内，出现一根收盘价回到
      [上一会话最低，上一会话最高] 区间内。2 根内不回来 = 突破成立，
      无信号，不追。
    - 入场：失败根收盘后的下一根 15m 开盘，顺失败方向
      （破上沿失败 -> 做空；破下沿失败 -> 做多）。
    - 止损（结构止损）：做空 -> 突破极值（突破过程中达到的最高价）
      + 0.1xATR；做多 -> 突破极值（最低价）- 0.1xATR。
    - 止盈/出场、执行口径：与 §1.1 完全相同（SUB 现行标准 + 同一成本模型
      + 同一风控）：无固定止盈；有利 >=2xATR 时跟踪止盈激活，止损上移至
      峰值 -/+1xATR；无 23:00 强平；名义 10,000/笔，1 倍；每币每天最多
      2 笔；北京 01:00-07:00（UTC 17:00-23:00）不开新单；单币单日 -2000
      熔断；成本模型 = 现行真实口径（Taker 主口径）。主臂 16 根持满上限；
      诊断臂去掉持满上限（设计 §4.3，与 41 轮一致）。
  口径裁定（设计 §2.1 有六处须在跑前写死，见报告 §0）：
    (1) “突破极值”在两处是两个量：突破句的门（<=1.0xATR）用突破根自身的
        极值（做空陷阱 = 突破根最高价，做多陷阱 = 突破根最低价）；止损句的
        极值用突破过程（突破根..失败根）的最高/最低价。两者定义分别写在
        §2.1 的突破句与止损句里，本轮按字面各取各的量。
    (2) ATR 口径：门用突破根收盘时的 ATR[i]；止损垫用失败根收盘时的
        ATR[f]（0.1xATR[f]）。
    (3) “突破后的 2 根” = 突破根之后的两根收盘 K 线（i+1、i+2）；失败根
        是其中第一根收盘价回到区间内的根。字面规则只定义了两种结局
        （2 根内回来 = 失败发信号；不回来 = 突破成立无信号），窗口内出现
        反向边界外的收盘不改变这一判定——只作诊断计数
        （opposite_close_in_window），不取消陷阱。
    (4) 连续突破根：突破根只认“第一根”——前一根收盘价已在同侧边界之外
        的，不算新的突破事件（与 SQZ 的第一根突破根规则同源；同一突破事件
        只发一次陷阱，避免重复信号）。前一根收盘在同侧边界之外 = 连续根，
        计入 continuation_skip。
    (5) 入场撞车：两个陷阱若共享同一入场根（须反向突破连发才可能），保留
        突破根最早的那个，后写的丢弃并计入 entry_collision。
    (6) R1 的对照臂：FBO 是新信号、没有“未过滤版”可作 R1 基准，沿用 41 轮
        裁定：基准 = 同宇宙同窗口的 A/B/C 三模板全量臂的合并；另报 FBO
        相对每个单模板的 R1 作诊断。判定以合池为准。
  数据：与 41 轮同一宇宙、同一窗口——BCH/PUMP/APT/ICP/AAVE/ONDO/JCT/PIPPIN
  （设计 §4.1，排除 40 个已回测币：32 + 41 轮的 8 个；选择文件
  data/gate_iter_round42_selection.json），窗口 2026-08-09~11-16（100 天，
  9,600 根 15m），半段切分 2026-09-21（前 43 天 / 后 57 天，与 37/40/41 轮
  同）。1h 2025-11-16~2026-11-16（8,761 根，仅对照臂用）；资金费
  2026-08-01 起（7 天 chunk，8 币各 321 条、零缺口，41 轮已修好）。
  取数：直接复用 41 轮的数据文件（不重新拉取）——41 轮取数时 15m 距
  10,000 根上限只剩约 4 根余量，现在重拉起点会漂移约 1 根，窗口不再与
  41 轮一字相同；任务书要求“窗口与两半切分点与 41 轮完全一致”，故复用
  并跑前后核对 md5（输入文件一字不改）。
  对照臂（设计 §4.2，每轮必做）：同宇宙、同窗口、不加新信号的 A/B/C
  全量臂（37 轮 FULL 口径，15m ATR，2 笔/天，16 根持满，跟踪 2xATR 激活；
  35 轮 builders 一字不改）。本轮重跑对照臂并断言与 41 轮公布数字一字
  相同（A 205 笔/-1,511.58、B 432 笔/-1,134.71、C 500 笔/-7,873.55），
  作为引擎与数据未漂移的交叉核对。
  第一关（设计 §4.2，跑全量回测之前）：信号率与联合样本量——目标
  >=100 笔；<50 笔则该信号不可测，测试停止并如实报告，不放宽条件凑数。
  报什么：FBO 主臂：信号数、笔数、全期 Taker 净（币均）、前/后半段
  Taker 净、每笔毛利、毛利/成本、P(到 1xATR)、P(2x|到 1x)、R1 三项
  分解；逐币表；§4.4 诊断（止损距离分布、P(1x)/P(2x|1x) vs 0.51/0.60
  基准、每币 1xATR 的 USDT 值与每币毛利、时段拆分、信号率与跳过原因拆分）；
  另报诊断 D1：假突破后“被套追单者止损推动”的幅度分布——从突破极值起、
  失败方向上的最大回撤深度（ATR 倍数），分桶 <0.5x / 0.5-1x / 1-2x /
  >=2x，另报 >=1xATR 的占比（纯描述，不参与判定；定义见 D1 函数注释，
  含入场前腿的对照量）。
  通过标准（设计 §2.4，四项全过才算）：(i) 全期 1 倍 Taker 净 > +2%
  （币均）；(ii) 前后两半都为正；(iii) 每笔毛利 > 25 USDT 且两半都
  > 25；(iv) R1 省成本占比 <= 80%（基准 = A/B/C 合池，见裁定 (6)）。
  证伪：四项任一不过，则 FBO 证伪，下一轮按设计顺序测 VWF（不许调 FBO
  的阈值重测、不许换批币重测 FBO）。
  定位：验证轮（新信号、新宇宙第二次测），计 1 个方向；若通过，它仍只
  是在一个新宇宙上的一次通过，后续验证须在 2026-11-16 之后的实盘纸面
  数据上看（12 月 18 日月度复核时判）。
  预期（设计 §5.1，跑前写死）：毛利 +10~+20/笔，不通过；四项里 (i)(iii)
  不过。若败，区分点是：P(走到 1x) 若显著低于 A 的 0.51，说明“假突破”
  信号比“扫荡反转”更差——反转类信号整体关闭；若 P(走到 1x) 与 A 相当
  但毛利仍不过，说明问题不在信号而在成本线本身。
  累计：本轮前 50 个方向、0 达标（36 时段拆分、37 多币同发、39 强度分档、
  40 4h 背景、41 SQZ 全部证伪；38 轮是主系统 S1 验证，不属于分系统队列）。
  本轮计 1 个方向（“FBO 有效”）。

无未来数据（用户 2026-11-21 硬性要求，执行前自查，写死在代码里）：
  - FBO 信号只用已收盘 15m K 线：会话区间用已完整收盘的上一会话 32 根；
    突破判定用突破根收盘价；失败判定用突破后两根的收盘价；止损极值用
    突破根..失败根已收盘根的最高/最低；入场一律是失败根的下一根 15m
    开盘价（信号字典的键就是入场根时刻）。“第一根突破根”判定只用突破根
    及其前一根的收盘价，不读任何未来根。
  - 对照臂复用 R15 builders 与 R35.simulate_stream 一字不改（合规性见
    37 轮脚本说明）；模拟每根只用当根高低收与已持仓状态；资金费只计
    入场日与入场日+1 的 08:00/16:00 结算点（35 轮口径）。
  - 主臂模拟复用 R41.simulate_sqz（与 R35.simulate_stream 等价自测已通过，
    见 41 轮附录 C(b)；本轮再跑一次等价自测）。
  数据绝对不能做假：算不出就写算不出（33 轮缺 atr 列即是先例）。

运行：python3 gate_iter_round42.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round42_summary.json
      + data/gate_iter_round42_cells.json + data/gate_iter_round42_trades.csv
复现：跑两遍，三个文件的 md5 应完全一致。
"""

import bisect
import csv
import hashlib
import json
import math
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round15 as R15  # 三个 SMC 模板 builders（原样恢复）
import gate_iter_round35 as R35  # 复用 35 轮引擎：load / atr / simulate_stream / summarize
import gate_iter_round37 as R37  # 复用 37 轮新宇宙 1h 合并函数、格子统计口径、时段划分
import gate_iter_round41 as R41  # 复用 41 轮引擎：simulate_sqz / cell_stats_r41 / funding_cost_full

DATA_DIR = os.path.join(SCRIPT_DIR, "data")

# ---- 新宇宙（跑前定死；设计 §4.1 + data/gate_iter_round42_selection.json；
#      与 41 轮同一批，排除集 40 = 32 + 41 轮的 8 个）----
SYMBOLS = ["BCH_USDT", "PUMP_USDT", "APT_USDT", "ICP_USDT",
           "AAVE_USDT", "ONDO_USDT", "JCT_USDT", "PIPPIN_USDT"]
for _sym in SYMBOLS:
    if _sym not in R35.FILL:
        R35.FILL[_sym] = R35.FILL["SOL_USDT"]
        R35.PENALTY[_sym] = R35.PENALTY["SOL_USDT"]
SPLIT_R35 = R35.SPLIT_R35  # 2026-09-21；前半段 08-09~09-20（43 天）/ 后 57 天
START_EQUITY = R35.START_EQUITY
NOTIONAL = R35.NOTIONAL
MAX_PER_DAY = R35.MAX_PER_DAY
MAX_HOLD_MAIN = R35.MAX_HOLD_MAIN  # 主臂 16 根（与 35/40/41 轮一致，见裁定 §4.3）

# FBO 参数（设计 §2.1，跑前写死，不许改）
FBO_ATR_PERIOD = 14
FBO_SESSION_BARS = 32       # 每会话 32 根 15m
FBO_EXTREME_MULT = 1.0      # 突破极值离位子 <= 1.0xATR(14)
FBO_FAIL_BARS = 2           # 突破后 2 根内收回
FBO_STOP_PAD_MULT = 0.1     # 止损在突破极值之外 0.1xATR
FBO_FIRST_GATE_MIN_TRADES = 50   # 第一关：<50 笔不可测
FBO_FIRST_GATE_TARGET_TRADES = 100

TEMPLATES = [("A", "R15-A 扫荡反转做多", R15.build_A),
             ("B", "R15-B FVG 回踩做多", R15.build_B),
             ("C", "R15-C 供给拒绝做空", R15.build_C)]

# 对照臂交叉核对：41 轮公布的同宇宙同窗口 A/B/C 全量臂数字（重跑后断言一字相同）
CTRL_EXPECTED = {"A": (205, -1511.58), "B": (432, -1134.71), "C": (500, -7873.55)}


def split_of(et):
    return R41.split_of(et)


def session_of(entry_t):
    return R37.session_of(entry_t)


def fav_atr(t):
    return R41.fav_atr(t)


def md5_of_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def input_file_list():
    files = []
    for sym in SYMBOLS:
        files.append(f"gate_15m_103d_{sym}.csv")
        files.append(f"gate_1h_365d_{sym}.csv")
        files.append(f"gate_funding_365d_{sym}.json")
    return files


# ----------------------------------------------------------------------
# FBO 信号 builder（设计 §2.1，裁定 (1)-(5) 见文件头）
#   突破根 i（信号在失败根 f 收盘时生成，入场 = bars[f+1] 的开盘）：
#     位子：上一完整会话 bars[32*(s-1) .. 32*s-1] 的最高/最低，s = i // 32
#     突破：c[i] > sess_hi（做空陷阱）或 c[i] < sess_lo（做多陷阱）；
#       且突破根自身极值离位子 <= 1.0xATR[i]（裁定 (1)）
#     第一根：前一根收盘价未在同侧边界之外（裁定 (4)）
#     失败：bars[i+1..i+2] 中第一根收盘价回到 [sess_lo, sess_hi] 区间内
#     止损：做空 -> max(h[i..f]) + 0.1xATR[f]；做多 -> min(l[i..f]) - 0.1xATR[f]
# ----------------------------------------------------------------------
def prev_session_range(bars, i):
    """bar i 所在会话的上一完整会话的 (hi, lo)；i < 32 时无，返回 None。"""
    s = i // FBO_SESSION_BARS
    if s < 1:
        return None
    seg = bars[FBO_SESSION_BARS * (s - 1):FBO_SESSION_BARS * s]
    return max(b["h"] for b in seg), min(b["l"] for b in seg)


def build_fbo(bars, atr):
    """返回 (signals, funnel)：
    signals: {entry_t: {direction, atr, stop, range_hi, range_lo, expand_t,
                        sess_hi, sess_lo, break_t, fail_t, extreme, tag}}
      其中 range_hi/range_lo/expand_t 复用 R41 的键名（= 上一会话区间 /
      突破根时刻），供 R41.simulate_sqz 原样记录；sess_hi/sess_lo/break_t/
      fail_t/extreme 为 FBO 自有字段，供本轮 CSV 与诊断用。
    funnel: 逐阶段漏斗计数。"""
    n = len(bars)
    signals = {}
    funnel = Counter()
    funnel["bars_eval"] = 0
    funnel["breakout_up"] = 0
    funnel["breakout_down"] = 0
    funnel["breakout"] = 0
    funnel["continuation_skip"] = 0
    funnel["extreme_gate_fail"] = 0
    funnel["failure"] = 0
    funnel["signals"] = 0
    funnel["opposite_close_in_window"] = 0
    funnel["entry_collision"] = 0
    funnel["warmup_bars"] = 32  # i=0..31 无上一完整会话，不能作突破根
    # 突破根 i 须满足：i >= 32（有上一完整会话）；失败根 f <= i+2，
    # 入场根 f+1 <= n-1，故 i <= n-4。
    for i in range(32, n - 3):
        funnel["bars_eval"] += 1
        rng = prev_session_range(bars, i)
        if rng is None:
            continue
        sess_hi, sess_lo = rng
        a = atr[i]
        if a is None or a <= 0:
            continue
        c = bars[i]["c"]
        direction = 0
        if c > sess_hi:
            direction = -1  # 破上沿失败 -> 做空
        elif c < sess_lo:
            direction = 1   # 破下沿失败 -> 做多
        else:
            continue
        # 裁定 (4)：第一根突破根——前一根收盘价未在同侧边界之外
        c_prev = bars[i - 1]["c"]
        if direction == -1 and c_prev > sess_hi:
            funnel["continuation_skip"] += 1
            continue
        if direction == 1 and c_prev < sess_lo:
            funnel["continuation_skip"] += 1
            continue
        funnel["breakout"] += 1
        if direction == -1:
            funnel["breakout_up"] += 1
        else:
            funnel["breakout_down"] += 1
        # 裁定 (1)：门用突破根自身的极值离位子
        if direction == -1:
            ext_dist = bars[i]["h"] - sess_hi
        else:
            ext_dist = sess_lo - bars[i]["l"]
        if ext_dist > FBO_EXTREME_MULT * a:
            funnel["extreme_gate_fail"] += 1
            continue
        # 裁定 (3)：失败 = 突破后 2 根内第一根收盘价回到区间内
        fail_idx = None
        for k in range(1, FBO_FAIL_BARS + 1):
            f = i + k
            if f >= n - 1:
                break  # 入场根 f+1 不存在
            cf = bars[f]["c"]
            if sess_lo <= cf <= sess_hi:
                fail_idx = f
                break
            if (direction == -1 and cf < sess_lo) or (direction == 1 and cf > sess_hi):
                funnel["opposite_close_in_window"] += 1
        if fail_idx is None:
            continue
        funnel["failure"] += 1
        f = fail_idx
        a_f = atr[f]
        if a_f is None or a_f <= 0:
            continue
        # 止损极值：突破过程（突破根..失败根）的最高/最低（裁定 (1)）
        if direction == -1:
            extreme = max(b["h"] for b in bars[i:f + 1])
            stop = extreme + FBO_STOP_PAD_MULT * a_f
        else:
            extreme = min(b["l"] for b in bars[i:f + 1])
            stop = extreme - FBO_STOP_PAD_MULT * a_f
        entry_t = bars[f + 1]["t"]
        if entry_t in signals:
            # 裁定 (5)：入场撞车，保留突破根最早的陷阱
            funnel["entry_collision"] += 1
            continue
        signals[entry_t] = {
            "direction": direction, "atr": a_f, "atr_basis": "15m",
            "stop": stop,
            "range_hi": sess_hi, "range_lo": sess_lo,
            "expand_t": bars[i]["t"],
            "sess_hi": sess_hi, "sess_lo": sess_lo,
            "break_t": bars[i]["t"], "fail_t": bars[f]["t"],
            "extreme": extreme,
            "tag": f"FBO-{'S' if direction == -1 else 'L'}",
        }
        funnel["signals"] += 1
    return signals, funnel


def _selftest_fbo():
    """FBO builder 自测（合成数据，不读任何真实数据）。
    构造 100 根 15m，自 UTC 午夜起（t 对齐 00:00）：前 32 根为亚洲会话
    （o=100.0, h=100.2, l=99.8, c=100.0，TR=0.4，ATR=0.4）；第 33 根
    （下标 32，欧洲会话首根）起做各类情形。预期：
      (a) 下标 32 破上沿：o=100.0, h=100.5, l=100.0, c=100.4
          （极值离位子 0.3 <= 1.0xATR[32]）；下标 33 收盘 100.1 回到
          [99.8, 100.2] 内 -> 失败根，下标 34 开盘入场做空；
          止损 = max(h[32..33]) + 0.1xATR[33] = 100.5 + 0.1xATR[33]。
      (b) 极值门：把下标 32 的 h 改为 100.8（离位子 0.6 > 0.4）-> 无信号。
      (c) 不失败：下标 32 破上沿，下标 33、34 收盘仍在区间外 -> 无信号。
      (d) 做多陷阱：下标 32 破下沿（c=99.6, l=99.5，离位子 0.3 <= 0.4），
          下标 33 收盘 99.9 回到区间内 -> 入场做多，止损 = min(l[32..33])
          - 0.1xATR[33]。
      (e) 连续根：下标 32 破上沿（c=100.4），下标 33 收盘 100.5 仍在区间外
          （连续根，不算新陷阱），下标 34 收盘 100.1 回到区间内 -> 只有一个
          信号（突破根为下标 32），入场为下标 35 开盘。
      (f) 首个会话内（下标 < 32）无信号。"""
    base_t = 1760000000 - (1760000000 % 86400)  # 对齐 UTC 午夜
    def flat_bars(n=100):
        return [{"t": base_t + i * 900, "o": 100.0, "h": 100.2, "l": 99.8,
                 "c": 100.0, "v": 10.0, "sum": 1000.0} for i in range(n)]

    # (a) 做空陷阱
    bars = flat_bars()
    bars[32] = {"t": base_t + 32 * 900, "o": 100.0, "h": 100.5, "l": 100.0,
                "c": 100.4, "v": 50.0, "sum": 5000.0}
    bars[33] = {"t": base_t + 33 * 900, "o": 100.4, "h": 100.45, "l": 100.0,
                "c": 100.1, "v": 40.0, "sum": 4000.0}
    atr = R35.atr_wilder(bars)
    sig, fun = build_fbo(bars, atr)
    assert len(sig) == 1, f"自测(a)失败：应恰好 1 个信号，实际 {len(sig)}"
    et = bars[34]["t"]
    assert et in sig, "自测(a)失败：信号入场根应为失败根的下一根"
    s = sig[et]
    assert s["direction"] == -1, f"自测(a)失败：方向应为做空，实际 {s['direction']}"
    assert s["sess_hi"] == 100.2 and s["sess_lo"] == 99.8, \
        f"自测(a)失败：上一会话区间应为 [99.8, 100.2]，实际 [{s['sess_lo']}, {s['sess_hi']}]"
    assert s["extreme"] == 100.5, f"自测(a)失败：突破极值应为 100.5，实际 {s['extreme']}"
    assert abs(s["stop"] - (100.5 + 0.1 * atr[33])) < 1e-9, \
        f"自测(a)失败：止损应为极值 + 0.1xATR[失败根]，实际 {s['stop']}"
    assert s["break_t"] == bars[32]["t"] and s["fail_t"] == bars[33]["t"], \
        "自测(a)失败：突破根/失败根时刻不对"
    assert fun["signals"] == 1 and fun["failure"] == 1, \
        f"自测(a)失败：漏斗 signals/failure 应为 1，实际 {fun}"

    # (b) 极值门
    bars_b = flat_bars()
    bars_b[32] = {"t": base_t + 32 * 900, "o": 100.0, "h": 100.8, "l": 100.0,
                  "c": 100.4, "v": 50.0, "sum": 5000.0}
    bars_b[33] = {"t": base_t + 33 * 900, "o": 100.4, "h": 100.45, "l": 100.0,
                  "c": 100.1, "v": 40.0, "sum": 4000.0}
    sig_b, _ = build_fbo(bars_b, R35.atr_wilder(bars_b))
    assert len(sig_b) == 0, f"自测(b)失败：极值超 1.0xATR 时应 0 信号，实际 {len(sig_b)}"

    # (c) 不失败
    bars_c = flat_bars()
    bars_c[32] = {"t": base_t + 32 * 900, "o": 100.0, "h": 100.5, "l": 100.0,
                  "c": 100.4, "v": 50.0, "sum": 5000.0}
    bars_c[33] = {"t": base_t + 33 * 900, "o": 100.4, "h": 100.6, "l": 100.3,
                  "c": 100.5, "v": 40.0, "sum": 4000.0}
    bars_c[34] = {"t": base_t + 34 * 900, "o": 100.5, "h": 100.7, "l": 100.4,
                  "c": 100.6, "v": 40.0, "sum": 4000.0}
    sig_c, _ = build_fbo(bars_c, R35.atr_wilder(bars_c))
    assert len(sig_c) == 0, f"自测(c)失败：2 根内不回来应 0 信号，实际 {len(sig_c)}"

    # (d) 做多陷阱
    bars_d = flat_bars()
    bars_d[32] = {"t": base_t + 32 * 900, "o": 100.0, "h": 100.0, "l": 99.5,
                  "c": 99.6, "v": 50.0, "sum": 5000.0}
    bars_d[33] = {"t": base_t + 33 * 900, "o": 99.6, "h": 100.0, "l": 99.55,
                  "c": 99.9, "v": 40.0, "sum": 4000.0}
    sig_d, _ = build_fbo(bars_d, R35.atr_wilder(bars_d))
    assert len(sig_d) == 1, f"自测(d)失败：应恰好 1 个做多信号，实际 {len(sig_d)}"
    s_d = sig_d[bars_d[34]["t"]]
    assert s_d["direction"] == 1, f"自测(d)失败：方向应为做多，实际 {s_d['direction']}"
    assert s_d["extreme"] == 99.5, f"自测(d)失败：突破极值应为 99.5，实际 {s_d['extreme']}"
    assert abs(s_d["stop"] - (99.5 - 0.1 * R35.atr_wilder(bars_d)[33])) < 1e-9, \
        f"自测(d)失败：止损应为极值 - 0.1xATR[失败根]，实际 {s_d['stop']}"

    # (e) 连续根只发一个信号
    bars_e = flat_bars()
    bars_e[32] = {"t": base_t + 32 * 900, "o": 100.0, "h": 100.5, "l": 100.0,
                  "c": 100.4, "v": 50.0, "sum": 5000.0}
    bars_e[33] = {"t": base_t + 33 * 900, "o": 100.4, "h": 100.6, "l": 100.3,
                  "c": 100.5, "v": 40.0, "sum": 4000.0}
    bars_e[34] = {"t": base_t + 34 * 900, "o": 100.5, "h": 100.55, "l": 100.0,
                  "c": 100.1, "v": 40.0, "sum": 4000.0}
    sig_e, fun_e = build_fbo(bars_e, R35.atr_wilder(bars_e))
    assert len(sig_e) == 1, f"自测(e)失败：连续突破应只发 1 个信号，实际 {len(sig_e)}"
    assert bars_e[35]["t"] in sig_e, "自测(e)失败：信号入场根应为失败根的下一根"
    assert fun_e["continuation_skip"] == 1, \
        f"自测(e)失败：连续根应计 1 次，实际 {fun_e['continuation_skip']}"
    assert sig_e[bars_e[35]["t"]]["break_t"] == bars_e[32]["t"], \
        "自测(e)失败：信号的突破根应为最早的下标 32"
    print("[FBO builder 自测 ✓] 做空/做多陷阱、极值门、不失败无信号、连续根只发一个信号、"
          "止损=突破过程极值 ± 0.1xATR[失败根] 均正确")


# ----------------------------------------------------------------------
# 诊断 D1：假突破后“被套追单者止损推动”的幅度分布（纯描述，不参与判定）
#   定义（跑前写死）：对每笔已执行 FBO 交易，从突破极值起、沿失败方向量
#   最大回撤深度（ATR 倍数）：做空 = (extreme - 持仓窗口内最低价) / atr；
#   做多 = (持仓窗口内最高价 - extreme) / atr；持仓窗口 = 入场根..出场根（含）。
#   任务书括号里的“突破极值外 1xATR 内回撤”按此度量解读：回撤 = 价格从突破
#   极值向失败方向的回落幅度；1xATR 是分桶线（>=1xATR 的占比即“回撤到
#   1xATR 之外”的占比）。另计入场前腿（extreme -> 入场价）作对照：D1 的
#   深度里有一段是失败本身（极值到失败根收盘）已走完的，入场前腿的中位数/
#   均值单独报，避免把失败前已走的幅度算成“止损推动”。
# ----------------------------------------------------------------------
def attach_reversal_depth(trades, bars_by_sym):
    """把 D1 回撤深度逐笔并回交易记录（供 CSV 与诊断共用同一份数）。
    做空 = (extreme - 持仓窗口内最低价) / atr；做多 = (持仓窗口内最高价 - extreme) / atr；
    持仓窗口 = 入场根..出场根（含）。"""
    idx_map = {s: {b["t"]: i for i, b in enumerate(bars)} for s, bars in bars_by_sym.items()}
    for t in trades:
        bars = bars_by_sym[t["symbol"]]
        imap = idx_map[t["symbol"]]
        ei = imap.get(t["entry_t"])
        xi = imap.get(t["exit_t"])
        a = t.get("atr")
        ext = t.get("extreme")
        if ei is None or xi is None or xi < ei or not a or a <= 0 or ext is None:
            t["reversal_depth_atr"] = None
            continue
        if t["direction"] == -1:
            trough = min(b["l"] for b in bars[ei:xi + 1])
            t["reversal_depth_atr"] = (ext - trough) / a
        else:
            peak = max(b["h"] for b in bars[ei:xi + 1])
            t["reversal_depth_atr"] = (peak - ext) / a


def main():
    R41._selftest_sqz()
    R41._selftest_sim_equivalence()
    R41._selftest_cell_stats()
    _selftest_fbo()

    # ---- 选择文件（跑前写死；与 41 轮同一宇宙、同一窗口，复用 41 轮数据文件）----
    md5_before = {fn: md5_of_file(os.path.join(DATA_DIR, fn)) for fn in input_file_list()}
    sel = {
        "fetch_time_utc": "2026-11-21T02:38:56.464767+00:00（复用 41 轮取数，未重新拉取）",
        "source": "data/gate_iter_round41_selection.json（同一宇宙、同一窗口、同一批数据文件）",
        "rule": "宇宙跑前定死（设计 §4.1）：BCH/PUMP/APT/ICP/AAVE/ONDO/JCT/PIPPIN，替补 TRX；"
                "排除 40 个已回测币（旧 20 + 37 轮新 8 + 38 轮另 4 + 41 轮新 8）；spread<=0.07%；"
                "1h首周>=160根；全量复核1h 8761根连续、15m自实际起点连续且与BTC对齐；"
                "15m窗口起点 2026-08-09（9600 根）；半段切分点 2026-09-21（与 37/40/41 轮同）",
        "data_reuse": "直接复用 41 轮的数据文件（gate_15m_103d_* / gate_1h_365d_* / "
                      "gate_funding_365d_*），不重新拉取——41 轮取数时 15m 距 10,000 根上限"
                      "只剩约 4 根余量，现在重拉起点会漂移约 1 根，窗口不再与 41 轮一字相同；"
                      "任务书要求窗口与两半切分点与 41 轮完全一致。跑前后核对 md5，输入文件一字不改。",
        "selected_symbols": SYMBOLS,
        "start_15m": "2026-08-09",
        "excluded_40": ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA", "ZEC", "EVAA",
                        "HYPE", "LTC", "BLESS", "XLM", "AKE", "NEAR", "PEPE", "UNI", "SUI", "XAUT",
                        "MMT", "WLD", "PIEVERSE", "AVAX", "PAXG", "ARB", "FIL", "TAO",
                        "KERNEL", "CYBER", "ENA", "INJ",
                        "BCH", "PUMP", "APT", "ICP", "AAVE", "ONDO", "JCT", "PIPPIN"],
        "md5_before": md5_before,
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round42_selection.json"), "w") as f:
        json.dump(sel, f, indent=2, ensure_ascii=False)
    print("盈利策略迭代 · 第四十二轮：FBO 假突破陷阱反转（分系统 SUB-SMC，新信号第二次测）")
    print(f"新宇宙：{', '.join(s.replace('_USDT', '') for s in SYMBOLS)}（与 41 轮同一批）")
    print("信号（设计 §2.1）：收盘突破上一会话区间 + 突破极值离位子 <=1.0xATR + "
          "2 根内收盘回到区间内，下一根开盘顺失败方向入场；止损 = 突破过程极值 ± 0.1xATR；"
          "出场跟踪止盈 2xATR 激活、主臂 16 根持满上限。")
    print("通过标准（四项全过才算）：(i) 全期币均 Taker 净 > +2%，(ii) 前后两半都为正，"
          "(iii) 每笔毛利 > 25 USDT 且两半都 > 25，(iv) R1 省成本占比 ≤ 80%"
          "（基准 = A/B/C 三模板全量臂合池，见裁定 (6)）。")

    # ---- 数据校验（与 41 轮同口径，窗口 2026-08-09~11-16，100 天；复用文件）----
    data15 = {}
    for sym in SYMBOLS:
        bars = R35.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R35.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R35.group_days(bars, 96)
        assert len(days) == 100, f"{sym} 15m 完整日应为 100 天，实际 {len(days)}"
        assert len(bars) == 100 * 96, f"{sym} 15m 应为 {100*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15[SYMBOLS[0]][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 {SYMBOLS[0]} 不对齐"
    print("数据校验通过：8 币各 9,600 根 15m / 100 天；时间戳对齐、零缺口（复用 41 轮文件）。")
    for sym in SYMBOLS:
        f = data15[sym][1]
        assert len(f) == 321, f"{sym} 资金费应为 321 条，实际 {len(f)}"
    print("资金费校验通过：8 币各 321 条（2026-08-01~11-15），零缺口（7 天 chunk，41 轮已修好）。")

    data1h = R37.build_1h_combined_new(SYMBOLS)
    days_all_15 = set(R35.group_days(data15[SYMBOLS[0]][0], 96).keys())
    front_43 = {d for d in days_all_15 if d < SPLIT_R35.date()}
    back_57 = {d for d in days_all_15 if d >= SPLIT_R35.date()}
    print(f"窗口：全 100d（前 {len(front_43)} 天 2026-08-09~09-20 / "
          f"后 {len(back_57)} 天 2026-09-21~11-16）。")

    windows = [("100d", None), ("前43d", front_43), ("后57d", back_57)]
    atr15 = {s: R35.atr_wilder(data15[s][0]) for s in SYMBOLS}
    bars_by_sym = {s: data15[s][0] for s in SYMBOLS}

    # ---- FBO 信号 ----
    fbo_sig_raw, funnel_tot = {}, Counter()
    for sym in SYMBOLS:
        sig, fun = build_fbo(data15[sym][0], atr15[sym])
        fbo_sig_raw[sym] = sig
        funnel_tot.update(fun)
        print(f"[FBO 信号 {sym.replace('_USDT', '')}] 信号 {len(sig)} 个；"
              f"漏斗：评估根 {fun['bars_eval']} → 突破 {fun['breakout']}"
              f"（上 {fun['breakout_up']} / 下 {fun['breakout_down']}，连续根跳过 "
              f"{fun['continuation_skip']}）→ 极值门拦掉 {fun['extreme_gate_fail']} → "
              f"失败 {fun['failure']} → 信号 {fun['signals']}"
              f"（入场撞车 {fun['entry_collision']}，窗口内反向收盘根 "
              f"{fun['opposite_close_in_window']}）")
    print(f"[FBO 信号合计] 8 币合计 {sum(len(v) for v in fbo_sig_raw.values())} 个信号；"
          f"评估根数 {funnel_tot['bars_eval']}；预热期 {funnel_tot['warmup_bars']} 根无信号。")

    # 夜间禁单过滤
    fbo_sig, night_blocked = {}, {}
    for sym in SYMBOLS:
        fbo_sig[sym], night_blocked[sym] = {}, 0
        for et, s in fbo_sig_raw[sym].items():
            if R35._entry_in_no_new_window(et):
                night_blocked[sym] += 1
                continue
            fbo_sig[sym][et] = s
    n_sig = sum(len(v) for v in fbo_sig.values())
    print(f"[FBO 信号] 夜间禁单时段拦掉 {sum(night_blocked.values())} 个信号；"
          f"入场信号 {n_sig} 个。")

    # ---- 第一关（设计 §4.2）：信号样本量 ----
    print(f"\n=== 第一关（定义审计）：FBO 信号 {n_sig} 个（目标 >=100 笔，<50 笔不可测）===")
    gate_ok = n_sig >= FBO_FIRST_GATE_MIN_TRADES
    if not gate_ok:
        print(f"  第一关不通过：信号仅 {n_sig} 个 < 50，FBO 不可测，测试停止并如实报告。")
        with open(os.path.join(DATA_DIR, "gate_iter_round42_summary.json"), "w") as f:
            json.dump([{"family": "FBO", "group": "MAIN", "verdict": "UNMEASURABLE",
                        "signals": n_sig,
                        "funnel": dict(funnel_tot),
                        "night_blocked": dict(night_blocked)}], f, indent=2, ensure_ascii=False)
        print("已写入 data/gate_iter_round42_summary.json（仅第一关结果）。")
        return
    print(f"  第一关通过：信号 {n_sig} 个（{'达到' if n_sig >= FBO_FIRST_GATE_TARGET_TRADES else '未达到'}"
          f" 100 笔目标），继续全量回测。")

    # ---- 对照臂信号：35 轮三模板（去 Killzone → 夜禁过滤 → 15m ATR），与 41 轮一字相同 ----
    R15.in_killzone = lambda t: True
    idx_of_t = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in SYMBOLS}
    ctrl_sig, ctrl_night, ctrl_warmup = {}, {}, {}
    for fam, label, builder in TEMPLATES:
        ms, nb, wb = {}, {}, {}
        for sym in SYMBOLS:
            bars1h, a1h = data1h[sym]
            raw, _fun = builder(data15[sym][0], bars1h, a1h)
            ms[sym], nb[sym], wb[sym] = {}, 0, 0
            for et, s in raw.items():
                if R35._entry_in_no_new_window(et):
                    nb[sym] += 1
                    continue
                gi = idx_of_t[sym][et]
                a15 = atr15[sym][gi - 1] if gi - 1 >= 0 else None
                if a15 is None:
                    wb[sym] += 1
                    continue
                ms[sym][et] = {"direction": s["direction"], "atr": a15,
                               "atr_basis": "15m", "tag": s.get("tag", "")}
        ctrl_sig[fam] = ms
        ctrl_night[fam] = nb
        ctrl_warmup[fam] = wb
        print(f"[对照信号 {fam}] 夜间禁单拦掉 {sum(nb.values())} 个；ATR 未预热跳过 "
              f"{sum(wb.values())} 个；入场信号 {sum(len(v) for v in ms.values())} 个。")

    # ---- 模拟：FBO 主臂（16 根上限）+ 诊断臂（无上限）+ 对照臂 ----
    all_results, all_trades = [], []

    def run_fbo_arm(arm, max_hold):
        fam_trades = []
        skip_tot = Counter()
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            trades, curve, stats = R41.simulate_sqz(
                sym, bars, fbo_sig[sym], funding, MAX_PER_DAY,
                f"R42-FBO-{arm}", max_hold=max_hold)
            # 把 FBO 自有字段并回逐笔（simulate_sqz 只透传 range_hi/range_lo/expand_t）
            for t in trades:
                sig = fbo_sig[sym].get(t["entry_t"])
                if sig is not None:
                    t["sess_hi"] = sig["sess_hi"]
                    t["sess_lo"] = sig["sess_lo"]
                    t["break_t"] = sig["break_t"]
                    t["fail_t"] = sig["fail_t"]
                    t["extreme"] = sig["extreme"]
            attach_reversal_depth(trades, bars_by_sym)
            fam_trades.extend(trades)
            skip_tot.update(stats)
        fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
        print(f"[FBO-{arm}] 全期 n={len(fam_trades)}；跳过信号：持仓中 {skip_tot['skip_open']} / "
              f"满2笔 {skip_tot['skip_cap']} / 熔断 {skip_tot['skip_breaker']} / "
              f"入场穿止损 {skip_tot['skip_gap']}")
        for sym in SYMBOLS:
            st = [t for t in fam_trades if t["symbol"] == sym]
            for wname, _ in windows:
                wt = [t for t in st if wname == "100d" or split_of(t["entry_t"]) == wname]
                wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                eq = START_EQUITY
                wcurve = [eq]
                for t in wt_sorted:
                    eq += t["pnl"]
                    wcurve.append(eq)
                res = R35.summarize(sym, wt_sorted, wcurve,
                                    f"R42-FBO-{arm}", len(fbo_sig[sym]))
                res["arm"] = f"FBO-{arm}"
                res["family"] = "FBO"
                res["template"] = "FBO"
                res["variant"] = f"R42-FBO-{arm}"
                res["granularity"] = "15m"
                res["atr_basis"] = "15m"
                res["split"] = wname
                res["days"] = 100 if wname == "100d" else (43 if wname == "前43d" else 57)
                res["signals_total"] = len(fbo_sig[sym])
                res["signals_blocked_night"] = night_blocked[sym]
                res["group"] = "FBO"
                all_results.append(res)
        for t in fam_trades:
            t2 = dict(t)
            t2["arm"] = f"FBO-{arm}"
            t2["family"] = "FBO"
            t2["template"] = "FBO"
            t2["variant"] = f"R42-FBO-{arm}"
            t2["granularity"] = "15m"
            t2["atr_basis"] = "15m"
            t2["split"] = split_of(t["entry_t"])
            t2["entry_hour_utc"] = R35.entry_hour_utc(t["entry_t"])
            t2["session"] = session_of(t["entry_t"])
            t2["group"] = "FBO"
            all_trades.append(t2)
        return fam_trades

    print("\n=== FBO 主臂（16 根持满上限）===")
    fbo_main = run_fbo_arm("MAIN", MAX_HOLD_MAIN)
    print("\n=== FBO 诊断臂（去掉持满上限，仅报告）===")
    fbo_diag = run_fbo_arm("DIAG", None)

    # 第一关的第二层：执行笔数 <50 同样不可测
    if len(fbo_main) < FBO_FIRST_GATE_MIN_TRADES:
        print(f"\n[第一关] FBO 主臂执行仅 {len(fbo_main)} 笔 < 50，信号不可测，"
              "四项标准不作判定（样本不足）。")
    print("\n=== 对照臂：A/B/C 全量（= 35 轮主臂口径，新宇宙复算；断言与 41 轮一字相同）===")
    ctrl_trades = {}
    for fam, label, builder in TEMPLATES:
        fam_trades = []
        skip_tot = Counter()
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            trades, curve, stats = R35.simulate_stream(
                sym, bars, ctrl_sig[fam][sym], funding, MAX_PER_DAY,
                f"R42-CTRL-{fam}")
            fam_trades.extend(trades)
            skip_tot.update(stats)
        fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
        ctrl_trades[fam] = fam_trades
        print(f"[CTRL {fam}] 全期 n={len(fam_trades)}；跳过信号：持仓中 {skip_tot['skip_open']} / "
              f"满2笔 {skip_tot['skip_cap']} / 熔断 {skip_tot['skip_breaker']}")
        for sym in SYMBOLS:
            st = [t for t in fam_trades if t["symbol"] == sym]
            for wname, _ in windows:
                wt = [t for t in st if wname == "100d" or split_of(t["entry_t"]) == wname]
                wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                eq = START_EQUITY
                wcurve = [eq]
                for t in wt_sorted:
                    eq += t["pnl"]
                    wcurve.append(eq)
                res = R35.summarize(sym, wt_sorted, wcurve,
                                    f"R42-CTRL-{fam}", len(ctrl_sig[fam][sym]))
                res["arm"] = "CTRL"
                res["family"] = fam
                res["template"] = fam
                res["variant"] = f"R42-CTRL-{fam}"
                res["granularity"] = "15m"
                res["atr_basis"] = "15m"
                res["split"] = wname
                res["days"] = 100 if wname == "100d" else (43 if wname == "前43d" else 57)
                res["signals_total"] = len(ctrl_sig[fam][sym])
                res["signals_blocked_night"] = ctrl_night[fam][sym]
                res["signals_blocked_warmup"] = ctrl_warmup[fam][sym]
                res["group"] = "FULL"
                all_results.append(res)
        for t in fam_trades:
            t2 = dict(t)
            t2["arm"] = "CTRL"
            t2["family"] = fam
            t2["template"] = fam
            t2["variant"] = f"R42-CTRL-{fam}"
            t2["granularity"] = "15m"
            t2["atr_basis"] = "15m"
            t2["split"] = split_of(t["entry_t"])
            t2["entry_hour_utc"] = R35.entry_hour_utc(t["entry_t"])
            t2["session"] = session_of(t["entry_t"])
            t2["group"] = "FULL"
            all_trades.append(t2)
        # 交叉核对：与 41 轮公布的对照臂数字一字相同
        exp_n, exp_net = CTRL_EXPECTED[fam]
        act_net = sum(t["pnl"] for t in fam_trades)
        assert len(fam_trades) == exp_n, \
            f"对照臂交叉核对失败：{fam} 笔数 {len(fam_trades)} ≠ 41 轮 {exp_n}"
        assert abs(act_net - exp_net) <= 0.05, \
            f"对照臂交叉核对失败：{fam} 净 {act_net:.2f} ≠ 41 轮 {exp_net}"
        print(f"  [CTRL {fam} 交叉核对 ✓] n={len(fam_trades)} 净 {act_net:+.2f} 与 41 轮一字相同")

    # ---- 格子统计：FBO 主臂（基准 = A/B/C 合池）+ 诊断臂（基准 = FBO 主臂）----
    print("\n=== 格子统计 ===")
    bench_pool = {"net": 0.0, "gross": 0.0, "cost": 0.0}
    for fam in ("A", "B", "C"):
        ftr = ctrl_trades[fam]
        bench_pool["net"] += sum(t["pnl"] for t in ftr)
        bench_pool["gross"] += sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ftr)
        bench_pool["cost"] += sum(t["cost_usdt"] for t in ftr)
        print(f"  [对照 CTRL {fam}] n={len(ftr)} 毛利 "
              f"{sum(t['price_pnl'] - t['funding_cost_usdt'] for t in ftr):+.2f} "
              f"成本 {sum(t['cost_usdt'] for t in ftr):.2f} 净 {sum(t['pnl'] for t in ftr):+.2f} "
              f"每笔毛利 {sum(t['price_pnl'] - t['funding_cost_usdt'] for t in ftr)/len(ftr) if ftr else 0:+.2f}")
    print(f"  [基准合池 A+B+C] n={sum(len(ctrl_trades[f]) for f in ('A','B','C'))} "
          f"毛利 {bench_pool['gross']:+.2f} 成本 {bench_pool['cost']:.2f} 净 {bench_pool['net']:+.2f}")
    cells = []
    c_main = R41.cell_stats_r41("FBO", "MAIN", fbo_main, bench_pool, SYMBOLS)
    cells.append(c_main)
    print(f"  [FBO MAIN] n={c_main['n']}（前 {c_main['n_front']} / 后 {c_main['n_back']}）"
          f"币均 Taker 全 {c_main['coin_mean_pct_full']*100:+.2f}% / 前 {c_main['coin_mean_pct_front']*100:+.2f}% / "
          f"后 {c_main['coin_mean_pct_back']*100:+.2f}% | 每笔毛利 {c_main['gross_per_trade']} "
          f"（前 {c_main['gross_per_trade_front']} / 后 {c_main['gross_per_trade_back']}）"
          f"毛利/成本 {c_main['gross_cost_ratio']} | P(1x)={c_main['p_reach_1x']} "
          f"P(2x|1x)={c_main['p_reach_2x_given_1x']} | R1 Δ净 {c_main['r1_d_net']:+.0f} "
          f"Δ毛利 {c_main['r1_d_gross']:+.0f} 省成本 {c_main['r1_saved_cost']:+.0f} "
          f"占比 {c_main['r1_saved_share'] if c_main['r1_saved_share'] is not None else '—'} | "
          f"四项 {'✓ 全过' if c_main['pass_all'] else '✗ 不过'} "
          f"(i){'✓' if c_main['pass_c1_net_gt_2pct'] else '✗'} "
          f"(ii){'✓' if c_main['pass_c2_both_halves_pos'] else '✗'} "
          f"(iii){'✓' if c_main['pass_c3_gross_per_trade_gt_25'] else '✗'} "
          f"(iv){'✓' if c_main['pass_c4_r1_le_80pct'] else '✗'}")
    bench_main = {"net": sum(t["pnl"] for t in fbo_main),
                  "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in fbo_main),
                  "cost": sum(t["cost_usdt"] for t in fbo_main)}
    c_diag = R41.cell_stats_r41("FBO", "DIAG", fbo_diag, bench_main, SYMBOLS)
    cells.append(c_diag)
    print(f"  [FBO DIAG（仅报告）] n={c_diag['n']} 币均 Taker 全 {c_diag['coin_mean_pct_full']*100:+.2f}% "
          f"每笔毛利 {c_diag['gross_per_trade']}（前 {c_diag['gross_per_trade_front']} / "
          f"后 {c_diag['gross_per_trade_back']}）P(1x)={c_diag['p_reach_1x']} "
          f"P(2x|1x)={c_diag['p_reach_2x_given_1x']} | 相对主臂 R1 Δ净 {c_diag['r1_d_net']:+.0f} "
          f"Δ毛利 {c_diag['r1_d_gross']:+.0f} 省成本 {c_diag['r1_saved_cost']:+.0f}")
    for fam in ("A", "B", "C"):
        ftr = ctrl_trades[fam]
        bench1 = {"net": sum(t["pnl"] for t in ftr),
                  "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ftr),
                  "cost": sum(t["cost_usdt"] for t in ftr)}
        c1 = R41.cell_stats_r41("FBO", f"vs-{fam}", fbo_main, bench1, SYMBOLS)
        cells.append(c1)
        print(f"  [FBO vs 单模板 {fam}（诊断）] Δ净 {c1['r1_d_net']:+.0f} Δ毛利 {c1['r1_d_gross']:+.0f} "
              f"省成本 {c1['r1_saved_cost']:+.0f} 占比 "
              f"{c1['r1_saved_share'] if c1['r1_saved_share'] is not None else '—'}")

    # ---- 诊断 §4.4 ----
    print("\n=== 诊断 §4.4（机制是否成立）===")
    sd_atr = sorted(t["stop_dist_atr"] for t in fbo_main if t.get("stop_dist_atr") is not None)
    sd_usdt = sorted(t["stop_dist_usdt"] for t in fbo_main if t.get("stop_dist_usdt") is not None)
    if sd_atr:
        n_sd = len(sd_atr)
        med_atr = sd_atr[n_sd // 2] if n_sd % 2 == 1 else (sd_atr[n_sd // 2 - 1] + sd_atr[n_sd // 2]) / 2
        mean_atr = sum(sd_atr) / n_sd
        med_usdt = sd_usdt[n_sd // 2] if n_sd % 2 == 1 else (sd_usdt[n_sd // 2 - 1] + sd_usdt[n_sd // 2]) / 2
        mean_usdt = sum(sd_usdt) / n_sd
        n_le_07 = sum(1 for x in sd_atr if x <= 0.7 + 1e-9)
        print(f"  (1) 止损距离（主臂 {n_sd} 笔）：中位数 {med_atr:.3f}xATR / {med_usdt:.2f} USDT；"
              f"均值 {mean_atr:.3f}xATR / {mean_usdt:.2f} USDT；<=0.7xATR 的笔数 {n_le_07}/{n_sd}；"
              f"机制要求中位数 <=0.7xATR：{'✓' if med_atr <= 0.7 else '✗'}")
    else:
        print("  (1) 止损距离：主臂 0 笔，算不出")
    print(f"  (2) P(走到 1x)={c_main['p_reach_1x']}（基准 0.51，A 模板 0.51）| "
          f"P(2x|1x)={c_main['p_reach_2x_given_1x']}（基准 0.60）| "
          f"走到 1x 笔数 {c_main['n_reach_1x']}/{c_main['n']}，走到 2x 笔数 {c_main['n_reach_2x']}")
    print("  (3) 逐币：")
    for sym in SYMBOLS:
        st = [t for t in fbo_main if t["symbol"] == sym]
        if not st:
            print(f"    {sym.replace('_USDT', '')}：0 笔")
            continue
        atr_usdt = sum(t["atr"] / t["entry"] * NOTIONAL for t in st) / len(st)
        g = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in st)
        g_atr = sum((t["price_pnl"] - t["funding_cost_usdt"]) / (t["atr"] / t["entry"] * NOTIONAL)
                    for t in st) / len(st)
        f_wt = [t for t in st if split_of(t["entry_t"]) == "前43d"]
        b_wt = [t for t in st if split_of(t["entry_t"]) == "后57d"]
        print(f"    {sym.replace('_USDT', '')}：n={len(st)}（前 {len(f_wt)} / 后 {len(b_wt)}）"
              f" 1xATR 均值 {atr_usdt:.2f} USDT | 毛利 {g:+.2f} USDT（{g_atr:+.2f}xATR/笔）| "
              f"每笔毛利 {g/len(st):+.2f} USDT | 净 {sum(t['pnl'] for t in st):+.2f} "
              f"（币均 {sum(t['pnl'] for t in st)/START_EQUITY*100:+.2f}%）")
    print("  (4) 时段拆分（诊断）：")
    for ses in ("ASIA", "EURO", "US"):
        st = [t for t in fbo_main if session_of(t["entry_t"]) == ses]
        if not st:
            print(f"    {ses}：0 笔")
            continue
        g = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in st)
        print(f"    {ses}：n={len(st)} 毛利 {g:+.2f} 每笔毛利 {g/len(st):+.2f} "
              f"净 {sum(t['pnl'] for t in st):+.2f} P(1x)="
              f"{sum(1 for t in st if fav_atr(t) >= 1.0 - 1e-9)/len(st):.3f}")
    print("  (5) 信号率与跳过原因：")
    print(f"    信号 {n_sig} 个 → 执行 {len(fbo_main)} 笔（执行率 "
          f"{len(fbo_main)/n_sig*100:.1f}%）；跳过：夜禁 {sum(night_blocked.values())} / "
          f"持仓中/满2笔/熔断/入场穿止损见主臂统计。")
    for arm_name, at in [("FBO-MAIN", fbo_main), ("FBO-DIAG", fbo_diag)]:
        rc = Counter(t["reason"] for t in at)
        ovn = [t for t in at
               if datetime.fromtimestamp(t["exit_t"], timezone.utc).date()
               > datetime.fromtimestamp(t["entry_t"], timezone.utc).date()]
        act = [t for t in at if t.get("trail_active")]
        long_holds = [t for t in at if t["hold_min"] is not None and t["hold_min"] > 2 * 24 * 60]
        print(f"  [{arm_name}] 出场：{dict(sorted(rc.items()))}（共 {len(at)} 笔）；"
              f"激活 {len(act)}/{len(at)}（{len(act)/len(at)*100:.1f}%）" if at else
              f"  [{arm_name}] 0 笔")
        if at:
            print(f"    跨夜 {len(ovn)} 笔净 {sum(t['pnl'] for t in ovn):+.0f}；"
                  f"资金费（引擎口径）{sum(t['funding_cost_usdt'] for t in at):+.2f}；"
                  f"持仓 >2 天 {len(long_holds)} 笔")
    if fbo_diag:
        diff_tot = 0.0
        n_long = 0
        for t in fbo_diag:
            full = R41.funding_cost_full(data15[t["symbol"]][1], t["entry_t"], t["exit_t"],
                                         t["notional"], t["direction"])
            diff = full - t["funding_cost_usdt"]
            if abs(diff) > 1e-9:
                n_long += 1
            diff_tot += diff
        print(f"  [FBO-DIAG 资金费差额] 全口径资金费 − 引擎口径资金费 = {diff_tot:+.2f} USDT"
              f"（{n_long} 笔有差额；诊断臂净若按全口径计为 "
              f"{sum(t['pnl'] for t in fbo_diag) - diff_tot:+.2f}，仅供参考，不参与判定）")
    for arm_name, at in [("FBO-MAIN", fbo_main), ("FBO-DIAG", fbo_diag)]:
        lo = [t for t in at if t["direction"] == 1]
        sh = [t for t in at if t["direction"] == -1]
        if at:
            print(f"  [{arm_name} 多空] LONG n={len(lo)} 净 {sum(t['pnl'] for t in lo):+.0f} "
                  f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in lo)/len(lo) if lo else 0:+.2f}；"
                  f"SHORT n={len(sh)} 净 {sum(t['pnl'] for t in sh):+.0f} "
                  f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in sh)/len(sh) if sh else 0:+.2f}")
    # D1 诊断：从突破极值起的回撤深度分布（用 run_fbo_arm 已并回逐笔的同一份数）
    print("  (D1) 假突破后回撤深度（从突破极值起、失败方向，纯描述）：")
    d1_vals = [t["reversal_depth_atr"] for t in fbo_main
               if t.get("reversal_depth_atr") is not None]
    if d1_vals:
        buckets = Counter({"<0.5x": 0, "0.5-1x": 0, "1-2x": 0, ">=2x": 0})
        for d in d1_vals:
            if d < 0.5:
                buckets["<0.5x"] += 1
            elif d < 1.0:
                buckets["0.5-1x"] += 1
            elif d < 2.0:
                buckets["1-2x"] += 1
            else:
                buckets[">=2x"] += 1
        share_ge_1x = sum(1 for d in d1_vals if d >= 1.0) / len(d1_vals)
        pre_legs = [abs(t["extreme"] - t["entry"]) / t["atr"] for t in fbo_main
                    if t.get("extreme") is not None and t.get("atr")]
        pre_sorted = sorted(pre_legs)
        n_pre = len(pre_sorted)
        pre_med = (pre_sorted[n_pre // 2] if n_pre % 2 == 1
                   else (pre_sorted[n_pre // 2 - 1] + pre_sorted[n_pre // 2]) / 2)
        pre_mean = sum(pre_legs) / n_pre
        print(f"    主臂 {len(d1_vals)} 笔：<0.5x {buckets['<0.5x']} / 0.5-1x {buckets['0.5-1x']} / "
              f"1-2x {buckets['1-2x']} / >=2x {buckets['>=2x']}；"
              f">=1xATR 的占比 {share_ge_1x:.3f}（即回撤到 1xATR 之外的占比）")
        print(f"    入场前腿（极值 -> 入场价）：中位数 {pre_med:.3f}xATR，均值 {pre_mean:.3f}xATR"
              f"——D1 深度里这一段是失败本身已走完的，不是入场后的止损推动")
    else:
        print("    主臂 0 笔，算不出")

    # ---- 首笔人工核对（FBO 主臂首笔：触发链与原始 K 线逐项核对）----
    print("\n=== 首笔人工核对（FBO 主臂首笔）===")
    if fbo_main:
        t = sorted(fbo_main, key=lambda x: x["entry_t"])[0]
        bars = data15[t["symbol"]][0]
        idx = {b["t"]: i for i, b in enumerate(bars)}
        ei = idx[t["entry_t"]]
        fi = idx[t["fail_t"]]
        bi = idx[t["break_t"]]
        fb = bars[fi]
        bb = bars[bi]
        sess = prev_session_range(bars, bi)
        a_f = atr15[t["symbol"]][fi]
        a_b = atr15[t["symbol"]][bi]
        ext = max(b["h"] for b in bars[bi:fi + 1]) if t["direction"] == -1 else min(b["l"] for b in bars[bi:fi + 1])
        print(f"  首笔 {t['symbol']} {'做多' if t['direction'] == 1 else '做空'} "
              f"突破根 {datetime.fromtimestamp(bb['t'], timezone.utc).isoformat()} "
              f"o={bb['o']} h={bb['h']} l={bb['l']} c={bb['c']} ATR {a_b:.4g}；"
              f"上一会话区间 [{sess[1]}, {sess[0]}]；"
              f"突破极值离位子 "
              f"{(bb['h'] - sess[0]) / a_b if t['direction'] == -1 else (sess[1] - bb['l']) / a_b:.3f}xATR"
              f"（须 <=1.0）")
        print(f"    失败根 {datetime.fromtimestamp(fb['t'], timezone.utc).isoformat()} "
              f"c={fb['c']}（须在 [{sess[1]}, {sess[0]}] 内）；"
              f"突破过程极值 {ext}（信号记录 {t.get('extreme')}）；"
              f"止损 = 极值 {'+' if t['direction'] == -1 else '-'} 0.1xATR[{a_f:.4g}] = {t['stop']:.4g}；"
              f"入场 {datetime.fromtimestamp(t['entry_t'], timezone.utc).isoformat()} 价 {t['entry']} "
              f"止损距离 {t.get('stop_dist_atr')}xATR / {t.get('stop_dist_usdt')} USDT；"
              f"出场 {datetime.fromtimestamp(t['exit_t'], timezone.utc).isoformat()} 价 {t['exit']} "
              f"原因 {t['reason']} 净 {t['pnl']:+.2f}")
        assert abs(ext - t["extreme"]) < 1e-12, "首笔核对失败：突破过程极值与信号记录不一致"
        assert abs(sess[0] - t["sess_hi"]) < 1e-12 and abs(sess[1] - t["sess_lo"]) < 1e-12, \
            "首笔核对失败：上一会话区间与信号记录不一致"

    # ---- 账目核对 ----
    print("\n=== 账目核对 ===")
    for arm_name, at in [("FBO-MAIN", fbo_main), ("FBO-DIAG", fbo_diag),
                         ("CTRL-A", ctrl_trades["A"]), ("CTRL-B", ctrl_trades["B"]),
                         ("CTRL-C", ctrl_trades["C"])]:
        cost = sum(t["cost_usdt"] for t in at)
        gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in at)
        net = sum(t["pnl"] for t in at)
        assert abs(cost - len(at) * 25.0) < 0.01, f"账目不对：{arm_name} 成本 {cost} ≠ 笔数x25"
        assert abs(gross - cost - net) < 0.01, f"账目不对：{arm_name} 毛利-成本≠净"
        print(f"  [{arm_name}] 笔数 {len(at)} x 25 = {len(at)*25:.0f} = 成本合计 {cost:.2f} ✓；"
              f"毛利 {gross:+.2f} − 成本 {cost:.2f} = 净 {net:+.2f} ✓")

    # ---- 输入文件 md5 跑后核对 ----
    md5_after = {fn: md5_of_file(os.path.join(DATA_DIR, fn)) for fn in input_file_list()}
    assert md5_after == md5_before, "输入数据文件在运行中被改动，停止"
    print("输入文件 md5 跑前后一字相同（24 个文件未改动）。")

    # ---- 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round42_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round42_cells.json"), "w") as f:
        json.dump(cells, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round42_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "template", "variant", "atr_basis", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "session", "group", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min", "peak", "trail_active",
                    "max_favour_usdt", "atr", "stop", "stop_dist_atr", "stop_dist_usdt",
                    "range_hi", "range_lo", "expand_time_utc",
                    "break_time_utc", "fail_time_utc", "extreme", "reversal_depth_atr"])
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["family"], x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["template"], t["variant"], t.get("atr_basis", ""),
                        t["granularity"], t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"], t["session"], t["group"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"], t.get("peak"), t.get("trail_active"),
                        round(t.get("max_favour_usdt", 0.0), 2), t.get("atr"),
                        t.get("stop", ""), t.get("stop_dist_atr", ""), t.get("stop_dist_usdt", ""),
                        t.get("range_hi", ""), t.get("range_lo", ""),
                        datetime.fromtimestamp(t["expand_t"], timezone.utc).isoformat()
                        if t.get("expand_t") else "",
                        datetime.fromtimestamp(t["break_t"], timezone.utc).isoformat()
                        if t.get("break_t") else "",
                        datetime.fromtimestamp(t["fail_t"], timezone.utc).isoformat()
                        if t.get("fail_t") else "",
                        t.get("extreme", ""),
                        round(t["reversal_depth_atr"], 4)
                        if t.get("reversal_depth_atr") is not None else ""])
    print(f"\n汇总已写入：data/gate_iter_round42_summary.json ({len(all_results)} 条)")
    print(f"格子已写入：data/gate_iter_round42_cells.json ({len(cells)} 个格子)")
    print(f"明细已写入：data/gate_iter_round42_trades.csv ({len(all_trades)} 笔)")

    print("\n=== 最终判定（FBO，四项全过才算）===")
    print(f"  FBO–MAIN：{'通过' if c_main['pass_all'] else '不通过'}"
          f"（币均 Taker {c_main['coin_mean_pct_full']*100:+.2f}%，"
          f"每笔毛利 {c_main['gross_per_trade']}，R1 省成本占比 "
          f"{c_main['r1_saved_share'] if c_main['r1_saved_share'] is not None else '—'}）")
    if len(fbo_main) < FBO_FIRST_GATE_MIN_TRADES:
        print("  执行笔数 < 50：FBO 不可测，四项标准不作判定。")
    elif c_main["pass_all"]:
        print("  FBO 四项全过 → 仍只是在一个新宇宙上的一次通过：按 R2 不得换另一批"
              "新币重验同一发现，后续验证须在 2026-11-16 之后的实盘纸面数据上看"
              "（12 月 18 日月度复核时判）。")
    else:
        print("  FBO 证伪：下一轮按设计顺序测 VWF（不许调 FBO 的阈值重测、"
              "不许换批币重测 FBO）。")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
