#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十二轮：执行层 Maker 实测——第二十轮 MAIN 臂的成本线复核
================================================================================
状态：只做日内、只做 Gate（gate.io）虚拟币永续合约。其他全停。不做资金费率套利。
全程模拟，不动真钱、不开户、不交易、不建议投真钱、不承诺收益。

背景（跑前写死，不许事后改口径）
--------------------------------
- 第二十轮 MAIN-15m 是全系列离盈亏平衡最近的一次（Taker -0.01%，每笔毛利
  +24.34 USDT，只够付约 25 USDT/笔成本的 97%，扣完每笔净 -0.63 USDT）；
  MAIN-1h 是 -0.10% / 每笔 +21.76 USDT。Maker 上界 M1（第二十轮口径，
  入场 Maker + 止盈 Maker / 止损与收盘 Taker，见下）是 +0.42% / +0.42%。
- 第一轮 B 已证明：1m 实测触及率 ~99% 是触及率上限不是成交率；止损必须市价；
  S3 的 Maker 混合现实口径是 -0.28%（Taker -1.61%）。本轮把同一套测量方法
  搬到第二十轮 MAIN 臂上，问：Maker 执行到底能不能把 MAIN 臂推过成本线。

测量对象（跑前写死）
--------------------
- 第二十轮 MAIN-1h（226 笔）与 MAIN-15m（160 笔）的全部交易，信号、入场价、
  止损、止盈一律照抄 data/gate_iter_round20_trades.csv，不许改。
- 1m 数据：Gate 公开接口 GET /futures/usdt/candlesticks，limit 单次上限 2000，
  只能取最近 10000 根（第一轮 B 实测），分页取满；8 个合约（BTC + 7 山寨，
  BTC 只用于窗口内生成信号）。

测量方法（跑前写死）
--------------------
A. 窗口内真实信号复核：把 1m 聚合成 15m/1h，用第二十轮引擎原样（import
   gate_iter_round20.build_f1_signals / simulate_f1，lookback 1h=2/15m=8，
   max_hold 1h=4 根/15m=16 根，SL 1xATR / TP 2xATR，入场小时 ∈ {9,15}，
   每天每币最多 2 笔）在约 7 天窗口内重跑 MAIN，对每笔窗口交易用 1m K 线测：
   - 入场限价（下一根开盘价）在入场后 30 分钟内是否触及；
   - 止盈限价（2xATR）在 4 小时持有窗口内、止损之前是否触及（TP 到达率）；
   - 止损限价是否先触及（仅诊断；止损一律按市价，不算 Maker）。
B. 通用触及率测试（第一轮 B §2.1 原样）：每个 1h 对齐 bar（1h 臂）/ 15m 对齐
   bar（15m 臂）收盘价为信号价，双向各挂一单（d=0，即信号价本身），窗口
   30 分钟与 120 分钟，用 1m bar 的 low/high 判定是否触及（且该分钟成交量>0）。
   此为 τ_gen：限价单在价位被触及的概率上界。另测漂移口径逆向选择惩罚（诊断）。
C. 历史 386 笔的成本口径（四档 + 一档天花板，跑前写死）：
   (1) Taker 原口径：已发表（-0.10% / -0.01%），本轮从 CSV 复核；
   (2) M1（第十六轮/第二十轮口径）：混合结构 + Maker 腿 100% 填充——入场
       Maker（-0.01%）、止盈 Maker（-0.01%）、止损/收盘 Taker（0.125%/边），
       即 CSV 的 pnl_maker_m1_usdt（+0.42% / +0.42%），本轮从 CSV 复核；
   (3) Maker 混合现实口径：入场腿、止盈腿按实测触及率 τ_gen（分币、分粒度）
       折算期望成本——触及按 Maker（-0.01%），未触及按市价补（0.125%/边，
       滑点照旧）；止损/收盘腿一律市价。价差毛利与资金费照抄历史值不变。
   (4) 敏感性：触及率打 7 折（τ×0.7），留出排队、部分成交、adverse selection
       的余地；价差毛利不变。
   (M0) 绝对天花板（仅作参照，不计入达标判定）：两条腿都按 Maker（-0.01%/
       边，一轮 -2 USDT/笔），即止损也能用限价成交——现实中不可能。
   注意：M1 与混合现实档的区别只在 Maker 腿的填充率（100% vs 实测 τ）；
   M0 与 M1 的区别只在止损/收盘腿能不能用 Maker。

判断标准（跑前写死）
--------------------
- 只有混合现实口径（3）下 MAIN 臂前后两半都为正且全期 1 倍净收益 >2% 才算通过；
- 只过成本线（净收益 >0 但 <2%）定性为“执行改善但仍不达标”，不追；
- M1 / M0 只是上界参照，不过线也不追（第一轮 B 的教训）。

局限（必须读，报告正文也要写）
--------------------------------
1. 1m 数据只有约 7 天，触及率是在小窗口（急跌周）上测的，外推到 103 天 /
   365 天要打折扣；窗口内真实 MAIN 信号只有个位数到十余笔，TP 到达率的
   样本很小。
2. touch 不等于 fill：1m K 线没有订单簿、没有排队量，触及率是填充率的上界，
   真实成交率只会更低，低多少测不到。
3. Maker 单要排队，adverse selection 会让实际成交价比限价差；混合现实口径
   仍可能是乐观估计，7 折敏感性档是为此留的余地。
4. 历史 TP 交易在粗粒度 bar 上本已触及止盈——对这些笔，1m 的 TP“到达率”
   不能再打折（那是重复计算条件概率）；TP 腿只能用通用触及率 τ_gen 作
   “触及后成交”的代理，这本身就是乐观假设，见报告 §3.3。

用法：python3 gate_iter_round22.py（先联网取 1m，再本地算；已跑两遍 md5 一致）
输出：data/gate_iter_round22_summary.json、data/gate_iter_round22_trades_tiers.csv、
      data/gate_1m_7d_r22_{SYM}_USDT.csv（8 个合约）
"""

import csv
import json
import math
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gate_iter_round20 as r20  # noqa: E402  (引擎原样复用，不改)

WORK_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(WORK_DIR, "data")
BASE = "https://api.gateio.ws/api/v4/futures/usdt/candlesticks"

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT", "DOGE_USDT",
           "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
ALTS = [s for s in SYMBOLS if s != "BTC_USDT"]
TARGET_HOURS = {9, 15}
START_EQUITY_PER_COIN = 100_000.0
N_COINS_MAIN = 7  # MAIN 只做 7 个山寨，不做 BTC

# ---- 成本口径（跑前写死，与系列一致）----
TAKER_LEG = 0.00125    # Taker 0.075% 费 + 0.05% 滑点 = 0.125%/边
MAKER_LEG = -0.0001    # Maker -0.01%/边（返佣口径，系列 M1/M2 同款）
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc).date()
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc).date()

LIMIT_MAX = 2000
MAX_POINTS = 10000


# ----------------------------------------------------------------------
# 1. 取 1m 数据（第一轮 B 的 fetch_1m 原样）
# ----------------------------------------------------------------------
def fetch_page(contract, interval, limit, frm=None):
    url = f"{BASE}?contract={contract}&interval={interval}&limit={limit}"
    if frm is not None:
        url += f"&from={frm}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)


def fetch_1m(contract):
    notes, bars = [], []
    page = fetch_page(contract, "1m", LIMIT_MAX)
    bars.extend(page)
    notes.append(f"page1: {len(page)} bars, "
                 f"{datetime.fromtimestamp(min(b['t'] for b in page), timezone.utc)}"
                 f" -> {datetime.fromtimestamp(max(b['t'] for b in page), timezone.utc)}")
    while len(bars) < MAX_POINTS:
        earliest = min(b["t"] for b in bars)
        frm = earliest - LIMIT_MAX * 60
        try:
            page = fetch_page(contract, "1m", LIMIT_MAX, frm=frm)
        except urllib.error.HTTPError as e:
            notes.append(f"pagination stopped at {len(bars)} bars: HTTP {e.code} "
                         f"{e.read().decode()[:160]}")
            break
        new = [b for b in page if b["t"] < earliest]
        if not new:
            notes.append(f"pagination stopped at {len(bars)} bars: empty page")
            break
        bars.extend(new)
        notes.append(f"page from={datetime.fromtimestamp(frm, timezone.utc)}: "
                     f"{len(new)} new bars")
    bars.sort(key=lambda b: b["t"])
    for b in bars:
        for k in ("o", "h", "l", "c", "v", "sum"):
            b[k] = float(b[k])
    seen, dedup = set(), []
    for b in bars:
        if b["t"] not in seen:
            seen.add(b["t"])
            dedup.append(b)
    gaps = [(a["t"], c["t"]) for a, c in zip(dedup, dedup[1:])
            if c["t"] - a["t"] != 60]
    return dedup, notes, gaps


def save_1m_csv(bars, path):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t", "o", "h", "l", "c", "v", "sum"])
        for b in bars:
            w.writerow([b["t"], b["o"], b["h"], b["l"], b["c"], b["v"], b["sum"]])


def load_1m_csv(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def aggregate(bars_1m, minutes):
    """1m 聚合成 N 分钟 bar（按时间戳对齐）；返回与 r20.load_bars 同格式的列表。"""
    step = minutes * 60
    buckets = {}
    for b in bars_1m:
        key = (b["t"] // step) * step
        if key not in buckets:
            buckets[key] = {"t": key, "o": b["o"], "h": b["h"], "l": b["l"],
                            "c": b["c"], "v": 0.0, "sum": 0.0}
        bk = buckets[key]
        bk["h"] = max(bk["h"], b["h"])
        bk["l"] = min(bk["l"], b["l"])
        bk["c"] = b["c"]
        bk["v"] += b["v"]
        bk["sum"] += b["sum"]
    return [buckets[k] for k in sorted(buckets)]


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return 0.0
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    return m / sd * math.sqrt(n) if sd > 0 else 0.0


# ----------------------------------------------------------------------
# 2. 触及率测量（1m K 线）
# ----------------------------------------------------------------------
def touch_in_window(bars_1m, start_t, end_t, price, direction):
    """在 [start_t, end_t] 的 1m bar 里，价格是否触及 price。
    direction=+1：触及当 high >= price（卖限价、多单止盈）；
    direction=-1：触及当 low <= price（买限价、空单止盈）。
    返回 (touched, minutes_to_touch or None)。第 0 分钟即触及也如实记录。"""
    for b in bars_1m:
        if b["t"] < start_t:
            continue
        if b["t"] > end_t:
            break
        if b["v"] <= 0:
            continue
        hit = (b["h"] >= price) if direction == 1 else (b["l"] <= price)
        if hit:
            return True, (b["t"] - start_t) // 60
    return False, None


def first_touch_time(bars_1m, start_t, end_t, price, direction):
    """返回首次触及 price 的 1m bar 时间戳，未触及返回 None。"""
    for b in bars_1m:
        if b["t"] < start_t:
            continue
        if b["t"] > end_t:
            break
        if b["v"] <= 0:
            continue
        hit = (b["h"] >= price) if direction == 1 else (b["l"] <= price)
        if hit:
            return b["t"]
    return None


def measure_window_trades(trades, bars_1m_by_sym):
    """对窗口内 MAIN 交易逐笔测 1m 触及：入场限价（30 分钟）、止盈限价与止损限价
    （4 小时持有窗口内，先触及者）。返回逐笔记录与汇总。"""
    recs = []
    for tr in trades:
        sym = tr["symbol"]
        bars = bars_1m_by_sym[sym]
        d = tr["direction"]
        entry_t = tr["entry_t"]
        # 入场限价 = 入场价（下一根开盘价），30 分钟窗口。
        # 多单入场是买限价（low<=entry 触及，即 direction=-1）；空单入场是卖限价
        # （high>=entry，即 direction=+1）；合起来 direction=-d。
        # 注意：第 0 分钟的 1m bar 开盘价就是入场价，low<=open<=high 恒成立，
        # 所以 d=0 入场触及在第 0 分钟自动成立——这是定义使然，不是实测结论。
        e_hit, e_min = touch_in_window(bars, entry_t, entry_t + 30 * 60,
                                       tr["entry"], -d)
        # 止盈/止损：4 小时窗口内先触及者
        end_t = entry_t + 4 * 3600
        tp_t = first_touch_time(bars, entry_t, end_t, tr["tp"],
                                1 if d == 1 else -1)
        sl_t = first_touch_time(bars, entry_t, end_t, tr["stop"],
                                -1 if d == 1 else 1)
        tp_first = tp_t is not None and (sl_t is None or tp_t <= sl_t)
        recs.append({
            "symbol": sym, "granularity": tr.get("_gran", ""),
            "direction": d, "entry_t": entry_t,
            "entry": tr["entry"], "stop": tr["stop"], "tp": tr["tp"],
            "reason": tr["reason"], "hold_min": tr["hold_min"],
            "entry_touch_30m": bool(e_hit), "entry_touch_min": e_min,
            "tp_touch_4h": tp_t is not None, "tp_first": bool(tp_first),
            "tp_touch_min": (tp_t - entry_t) // 60 if tp_t is not None else None,
            "sl_touch_4h": sl_t is not None,
            "sl_first": bool(sl_t is not None and (tp_t is None or sl_t < tp_t)),
        })
    return recs


def generic_touch_test(bars_1m, align_minutes, windows=(30, 120), post_min=30):
    """通用触及率测试（第一轮 B generic_fill_test 原样，只取 d=0）：
    每个对齐 bar 的收盘价为信号价，双向各挂一单（买限价/卖限价都在收盘价
    本身，d=0）；从收盘后下一根 1m bar 起算（k=i+1，信号 bar 本身不计入，
    否则第 0 分钟恒触及），窗口 W 分钟内是否触及；另测触及后 30 分钟漂移
    与逆向 excursion、漂移口径逆向惩罚（诊断用）。
    返回 {window: {...}, drift_penalty_frac, ...}。"""
    step = align_minutes * 60
    idx = {b["t"]: i for i, b in enumerate(bars_1m)}
    closes = [b["c"] for b in bars_1m]
    out = {}
    aligned_idx = [i for i, b in enumerate(bars_1m) if b["t"] % step == 0]
    for W in windows:
        filled, missed = [], []
        for i in aligned_idx:
            if i + max(W, post_min) + 1 >= len(bars_1m):
                continue
            b = bars_1m[i]
            for direction in (1, -1):  # 1=买限价，-1=卖限价；d=0 时限价=收盘价
                limit = b["c"]
                taker_drift = direction * (closes[i + post_min] - b["c"]) / b["c"]
                fill_i = None
                for k in range(i + 1, i + W + 1):
                    bk = bars_1m[k]
                    touched = (bk["l"] <= limit) if direction == 1 else (bk["h"] >= limit)
                    if touched and bk["v"] > 0:
                        fill_i = k
                        break
                if fill_i is None:
                    missed.append({"taker_drift": taker_drift})
                    continue
                seg = bars_1m[fill_i + 1: fill_i + 1 + post_min]
                if len(seg) < post_min:
                    continue
                if direction == 1:
                    adv_exc = (limit - min(s["l"] for s in seg)) / limit
                else:
                    adv_exc = (max(s["h"] for s in seg) - limit) / limit
                post_drift = direction * (seg[-1]["c"] - limit) / limit
                filled.append({"taker_drift": taker_drift,
                               "post_drift": post_drift,
                               "adv_exc": adv_exc,
                               "mins_to_fill": fill_i - i})
        n = len(filled) + len(missed)
        mean_taker_all = (sum(x["taker_drift"] for x in filled + missed) / n
                          if n else 0.0)
        mean_post = (sum(x["post_drift"] for x in filled) / len(filled)
                     if filled else None)
        mean_taker_filled = (sum(x["taker_drift"] for x in filled) / len(filled)
                             if filled else None)
        out[W] = {
            "n": n, "touched": len(filled),
            "touch_rate": len(filled) / n if n else 0.0,
            "median_touch_min": (sorted(x["mins_to_fill"] for x in filled)[len(filled) // 2]
                                 if filled else None),
            "mean_taker_drift_all": round(mean_taker_all, 5),
            "mean_taker_drift_filled": (round(mean_taker_filled, 5)
                                        if mean_taker_filled is not None else None),
            "mean_post_fill_drift_30m": (round(mean_post, 5)
                                         if mean_post is not None else None),
            "mean_adverse_excursion_30m": (round(sum(x["adv_exc"] for x in filled) / len(filled), 5)
                                           if filled else None),
            "frac_filled_with_adv_exc_over_0.1pct": (
                round(sum(1 for x in filled if x["adv_exc"] >= 0.001) / len(filled), 4)
                if filled else None),
            "mean_taker_drift_missed": (round(sum(x["taker_drift"] for x in missed) / len(missed), 5)
                                        if missed else None),
        }
    # 漂移口径逆向惩罚（30 分钟窗口）：全体信号 30m 漂移 − 已触及单触及后 30m 漂移
    w30 = out[30]
    out["drift_penalty_frac"] = (
        w30["mean_taker_drift_all"] - w30["mean_post_fill_drift_30m"]
        if w30["mean_post_fill_drift_30m"] is not None else 0.0)
    out["n_aligned_bars"] = len(aligned_idx)
    return out


# ----------------------------------------------------------------------
# 3. 历史 MAIN 交易的成本口径重算
# ----------------------------------------------------------------------
def tier_costs(tr, tau_e, tau_tp):
    """返回一笔历史 MAIN 交易在各口径下的成本（USDT，正数为付费）。
    taker_leg/maker_leg 按该笔名义计；TP 腿只在 reason==take_profit 时为 Maker 候选。"""
    notional = tr["notional"]
    taker_leg = notional * TAKER_LEG
    maker_leg = notional * MAKER_LEG  # 负数（返佣）
    cost_taker = tr["cost_taker_usdt"]
    cost_m1 = tr["cost_maker_usdt"]  # 第二十轮口径：入场 Maker + TP Maker/其余 Taker
    cost_m0 = 2 * maker_leg          # 绝对天花板：两条腿都 Maker（止损也能限价，不现实）

    def exp_leg(tau):
        return tau * maker_leg + (1 - tau) * taker_leg

    entry_mix = exp_leg(tau_e)
    if tr["reason"] == "take_profit":
        exit_mix = exp_leg(tau_tp)
    else:
        exit_mix = taker_leg
    cost_mix = entry_mix + exit_mix
    entry_mix07 = exp_leg(tau_e * 0.7)
    exit_mix07 = exp_leg(tau_tp * 0.7) if tr["reason"] == "take_profit" else taker_leg
    cost_mix07 = entry_mix07 + exit_mix07
    return {"taker": cost_taker, "m1": cost_m1, "m0": cost_m0,
            "mix": cost_mix, "mix07": cost_mix07}


def summarize_tiers(rows, label):
    """rows: 每笔含 net 各口径（USDT）与 split；返回分窗口汇总。"""
    res = {}
    for split in ("full", "front", "back"):
        if split == "full":
            sub = rows
        else:
            sub = [r for r in rows if r["split"] == split]
        n = len(sub)
        denom = N_COINS_MAIN * START_EQUITY_PER_COIN
        d = {"label": label, "split": split, "n": n}
        for tier in ("taker", "m1", "m0", "mix", "mix07"):
            net = sum(r[f"net_{tier}_usdt"] for r in sub)
            d[f"net_{tier}_usdt"] = round(net, 2)
            d[f"net_{tier}_pct"] = round(net / denom * 100, 4)
            d[f"per_trade_net_{tier}"] = round(net / n, 2) if n else 0.0
            d[f"t_{tier}"] = round(t_value([r[f"net_{tier}_usdt"] / START_EQUITY_PER_COIN
                                           for r in sub]), 2)
        # 毛利口径与第二十轮 summarize 一致：gross = Σ(价差 − 资金费)
        d["gross_usdt"] = round(sum(r["price_pnl_usdt"] - r["funding_cost_usdt"]
                                    for r in sub), 2)
        d["gross_per_trade"] = round(d["gross_usdt"] / n, 2) if n else 0.0
        res[split] = d
    return res


# ----------------------------------------------------------------------
# 4. 主流程
# ----------------------------------------------------------------------
def main():
    print("盈利策略迭代 · 第二十二轮：执行层 Maker 实测——第二十轮 MAIN 臂成本线复核")
    print("信号/入场/止损/止盈照抄第二十轮 MAIN；1m 触及率实测；四档成本口径跑前写死。")
    fetch_ts = datetime.now(timezone.utc)
    print(f"取数时间（UTC）：{fetch_ts.isoformat()}")

    # ---- 1. 取 1m 数据 ----
    # R22_USE_SAVED=1 时不联网，改读已落盘的 1m CSV（用于复现校验；此时
    # fetch_ts 取数据最后一根时间戳，保证两次运行 md5 一致）。
    use_saved = os.environ.get("R22_USE_SAVED") == "1"
    bars_1m_by_sym = {}
    fetch_report = {}
    for sym in SYMBOLS:
        path = os.path.join(DATA_DIR, f"gate_1m_7d_r22_{sym}.csv")
        if use_saved:
            bars = load_1m_csv(path)
            notes, gaps = ["loaded from saved csv (R22_USE_SAVED=1)"], []
            fetch_ts = datetime.fromtimestamp(max(b["t"] for b in bars),
                                              timezone.utc)
        else:
            for attempt in range(3):
                try:
                    bars, notes, gaps = fetch_1m(sym)
                    break
                except Exception as e:
                    print(f"  {sym} 取数失败（第 {attempt+1} 次）：{e}")
                    time.sleep(5)
                    bars, notes, gaps = [], [], []
            save_1m_csv(bars, path)
        # 剔除最后一根未走完的进行中 bar（第一轮 B 同款处理）
        if bars:
            bars = bars[:-1]
        bars_1m_by_sym[sym] = bars
        t0 = datetime.fromtimestamp(bars[0]["t"], timezone.utc)
        t1 = datetime.fromtimestamp(bars[-1]["t"], timezone.utc)
        zero_vol = sum(1 for b in bars if b["v"] <= 0)
        fetch_report[sym] = {
            "n_bars": len(bars), "window_start_utc": t0.isoformat(),
            "window_end_utc": t1.isoformat(), "gaps": len(gaps),
            "zero_vol_minutes": zero_vol, "notes": notes,
        }
        print(f"  {sym}: {len(bars)} 根，{t0} -> {t1}，缺口 {len(gaps)}，"
              f"零成交量分钟 {zero_vol}")

    # ---- 2. 窗口内重跑 MAIN（引擎原样）----
    window_recs = []
    window_trades = []
    for gran, minutes, lookback, max_hold, bars_per_day in (
            ("1h", 60, 2, 4, 24), ("15m", 15, 8, 16, 96)):
        agg = {}
        for sym in SYMBOLS:
            agg[sym] = aggregate(bars_1m_by_sym[sym], minutes)
        atr = {s: r20.atr_wilder(agg[s]) for s in SYMBOLS}
        all_sigs = {}
        for sym in ALTS:
            sigs = r20.build_f1_signals(agg[sym], agg["BTC_USDT"], atr[sym],
                                        lookback, max_hold, r20.TP_MULT)
            sigs = {t: v for t, v in sigs.items()
                    if r20.entry_hour_utc(t) in TARGET_HOURS}
            all_sigs[sym] = sigs
        n_sig = sum(len(v) for v in all_sigs.values())
        n_tr = 0
        for sym in ALTS:
            trades, _curve, _ndays = r20.simulate_f1(
                sym, agg[sym], all_sigs[sym], {}, None, 2, "MAIN", bars_per_day)
            for tr in trades:
                tr["_gran"] = gran
            window_trades.extend(trades)
            n_tr += len(trades)
        print(f"  窗口 MAIN-{gran}：信号 {n_sig} 个，成交 {n_tr} 笔")
        recs = measure_window_trades(
            [t for t in window_trades if t["_gran"] == gran], bars_1m_by_sym)
        window_recs.extend(recs)

    # ---- 3. 通用触及率测试（第一轮 B §2.1 原样，分粒度、分币）----
    generic = {}
    for gran, minutes in (("1h", 60), ("15m", 15)):
        generic[gran] = {}
        for sym in SYMBOLS:
            g = generic_touch_test(bars_1m_by_sym[sym], minutes)
            generic[gran][sym] = g
            print(f"  通用触及 {gran} {sym}：30m {g[30]['touch_rate']*100:.1f}% "
                  f"(n={g[30]['n']})，120m {g[120]['touch_rate']*100:.1f}% "
                  f"(n={g[120]['n']})，漂移惩罚 {g['drift_penalty_frac']*100:+.4f}%")

    # ---- 4. 历史 MAIN 交易：四档成本重算 ----
    hist = []
    with open(os.path.join(DATA_DIR, "gate_iter_round20_trades.csv"),
              newline="") as f:
        for r in csv.DictReader(f):
            if r["arm"] != "MAIN":
                continue
            hist.append({
                "granularity": r["granularity"], "split": r["split"],
                "symbol": r["symbol"], "direction": r["direction"],
                "entry_time_utc": r["entry_time_utc"],
                "reason": r["reason"],
                "notional": float(r["notional"]),
                "price_pnl_usdt": float(r["price_pnl_usdt"]),
                "funding_cost_usdt": float(r["funding_cost_usdt"]),
                "cost_taker_usdt": float(r["cost_taker_usdt"]),
                "cost_maker_usdt": float(r["cost_maker_usdt"]),
                "pnl_taker_usdt": float(r["pnl_taker_usdt"]),
                "pnl_maker_m1_usdt": float(r["pnl_maker_m1_usdt"]),
            })
    assert len(hist) == 386, f"MAIN 笔数应为 386，实际 {len(hist)}"
    # 复核已发表数字：Taker 与 M1（第二十轮口径）必须与报告一致
    for gran, pub_taker, pub_m1 in (("1h", -0.10, 0.42), ("15m", -0.01, 0.42)):
        sub = [r for r in hist if r["granularity"] == gran]
        tak = sum(r["pnl_taker_usdt"] for r in sub) / (7 * 100_000) * 100
        m1 = sum(r["pnl_maker_m1_usdt"] for r in sub) / (7 * 100_000) * 100
        print(f"  复核 MAIN-{gran}：Taker {tak:+.3f}%（已发表 {pub_taker:+.2f}%），"
              f"M1 {m1:+.3f}%（已发表 {pub_m1:+.2f}%）")
        assert abs(tak - pub_taker) < 0.05 and abs(m1 - pub_m1) < 0.05

    # τ：分币、分粒度，用通用测试 30 分钟窗口 d=0 的触及率
    tau = {}
    for gran in ("1h", "15m"):
        tau[gran] = {sym: generic[gran][sym][30]["touch_rate"] for sym in SYMBOLS}

    tier_rows = []
    for r in hist:
        gran = r["granularity"]
        t_e = tau[gran][r["symbol"]]
        t_tp = tau[gran][r["symbol"]]
        costs = tier_costs(r, t_e, t_tp)
        row = dict(r)
        for tier, c in costs.items():
            row[f"cost_{tier}_usdt"] = round(c, 2)
            row[f"net_{tier}_usdt"] = round(
                r["price_pnl_usdt"] - r["funding_cost_usdt"] - c, 2)
        row["tau_entry"] = round(t_e, 4)
        row["tau_tp"] = round(t_tp, 4)
        tier_rows.append(row)

    # ---- 5. 汇总：分粒度 × 分窗口 ----
    summary = {"round": 22, "fetch_ts_utc": fetch_ts.isoformat(),
               "fetch": fetch_report,
               "tiers": {}, "tau": tau,
               "window_trades": window_recs,
               "generic": generic}
    for gran in ("1h", "15m"):
        sub = [r for r in tier_rows if r["granularity"] == gran]
        # split 标签与第二十轮一致：1h 前 185d/后 180d，15m 前 51d/后 52d
        for r in sub:
            r["split"] = ("front" if r["split"].startswith("前") else "back")
        summary["tiers"][gran] = summarize_tiers(sub, f"MAIN-{gran}")

    # ---- 6. 达标判定与缺口算术（逐笔精确值，不用 12.5/-1 近似）----
    verdict = {}
    for gran in ("1h", "15m"):
        tiers = summary["tiers"][gran]
        mix = tiers["full"]
        passed = (tiers["front"]["net_mix_pct"] > 0
                  and tiers["back"]["net_mix_pct"] > 0
                  and mix["net_mix_pct"] > 2.0)
        sub = [r for r in tier_rows if r["granularity"] == gran]
        n = len(sub)
        gross = sum(r["price_pnl_usdt"] for r in sub)
        fund = sum(r["funding_cost_usdt"] for r in sub)
        target_net = 0.02 * 7 * 100_000
        taker_legs = {id(r): r["notional"] * TAKER_LEG for r in sub}
        maker_legs = {id(r): r["notional"] * MAKER_LEG for r in sub}
        # 入场腿成本固定为实测 tau_e 下的期望值
        entry_cost = sum(
            r["tau_entry"] * maker_legs[id(r)]
            + (1 - r["tau_entry"]) * taker_legs[id(r)] for r in sub)
        tp_rows = [r for r in sub if r["reason"] == "take_profit"]
        n_tp = len(tp_rows)
        b_tp = sum(taker_legs[id(r)] - maker_legs[id(r)] for r in tp_rows)
        # tau_tp=0 时的净收益 A：出场腿全按 Taker
        exit_cost_0 = sum(taker_legs[id(r)] for r in sub)
        a_net = gross - fund - entry_cost - exit_cost_0
        tau_tp_needed = (target_net - a_net) / b_tp if b_tp else None
        # tau_e = tau_tp = tau 单一触及率：tau=0 时净收益 = Taker 净收益
        taker_net = sum(r["net_taker_usdt"] for r in sub)
        d_single = (sum(taker_legs[id(r)] - maker_legs[id(r)] for r in sub)
                    + b_tp)
        tau_single_needed = ((target_net - taker_net) / d_single
                             if d_single else None)
        # M0 口径下 +2% 需要的每笔毛利（毛利口径同上）：
        # net = gross* − m0_cost → gross* = target + m0_cost
        m0_cost = sum(2 * maker_legs[id(r)] for r in sub)
        gross_needed_m0 = (target_net + m0_cost) / n if n else None
        tau_e_mean = sum(tau[gran].values()) / len(tau[gran])
        verdict[gran] = {
            "mix_pass": passed,
            "mix_front_pct": tiers["front"]["net_mix_pct"],
            "mix_back_pct": tiers["back"]["net_mix_pct"],
            "mix_full_pct": mix["net_mix_pct"],
            "m1_full_pct": tiers["full"]["net_m1_pct"],
            "m0_full_pct": tiers["full"]["net_m0_pct"],
            "n_tp": n_tp, "tau_entry_mean": round(tau_e_mean, 4),
            "tau_tp_needed_for_2pct": (round(tau_tp_needed, 3)
                                       if tau_tp_needed is not None else None),
            "tau_single_needed_for_2pct": (round(tau_single_needed, 3)
                                           if tau_single_needed is not None
                                           else None),
            "gross_per_trade_needed_for_2pct_at_m0": round(gross_needed_m0, 2),
        }
    summary["verdict"] = verdict

    # ---- 7. 落盘 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round22_summary.json"),
              "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round22_trades_tiers.csv"),
              "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["granularity", "split", "symbol", "direction",
                    "entry_time_utc", "reason", "notional", "price_pnl_usdt",
                    "funding_cost_usdt", "tau_entry", "tau_tp",
                    "cost_taker_usdt", "cost_m1_usdt", "cost_m0_usdt",
                    "cost_mix_usdt", "cost_mix07_usdt",
                    "net_taker_usdt", "net_m1_usdt", "net_m0_usdt",
                    "net_mix_usdt", "net_mix07_usdt"])
        for r in tier_rows:
            w.writerow([r["granularity"], r["split"], r["symbol"],
                        r["direction"], r["entry_time_utc"], r["reason"],
                        r["notional"], r["price_pnl_usdt"],
                        r["funding_cost_usdt"], r["tau_entry"], r["tau_tp"],
                        r["cost_taker_usdt"], r["cost_m1_usdt"],
                        r["cost_m0_usdt"], r["cost_mix_usdt"],
                        r["cost_mix07_usdt"], r["net_taker_usdt"],
                        r["net_m1_usdt"], r["net_m0_usdt"],
                        r["net_mix_usdt"], r["net_mix07_usdt"]])

    # ---- 8. 打印主表 ----
    for gran in ("1h", "15m"):
        print(f"\n== MAIN-{gran}（分币 10 万 × 7 币 = 70 万权益）==")
        print("窗口      笔数  毛利/笔   Taker      M1        M0(天花板)  "
              "混合现实   混合×0.7")
        for split in ("front", "back", "full"):
            d = summary["tiers"][gran][split]
            print(f"{split:6s} {d['n']:5d} {d['gross_per_trade']:+8.2f}  "
                  f"{d['net_taker_pct']:+7.2f}% {d['net_m1_pct']:+7.2f}%  "
                  f"{d['net_m0_pct']:+7.2f}%   {d['net_mix_pct']:+7.2f}%  "
                  f"{d['net_mix07_pct']:+7.2f}%")
        v = verdict[gran]
        print(f"判定：混合现实通过？{v['mix_pass']}；τ_tp 达 +2% 所需 "
              f"{v['tau_tp_needed_for_2pct']}；单一 τ 达 +2% 所需 "
              f"{v['tau_single_needed_for_2pct']}；M0 口径下 +2% 需每笔毛利 "
              f"{v['gross_per_trade_needed_for_2pct_at_m0']:+.2f} USDT")

    print("\n== 窗口内真实信号触及汇总 ==")
    for gran in ("1h", "15m"):
        recs = [r for r in window_recs if r["granularity"] == gran]
        if not recs:
            print(f"  {gran}：窗口内无 MAIN 成交")
            continue
        n = len(recs)
        e = sum(1 for r in recs if r["entry_touch_30m"])
        tp = sum(1 for r in recs if r["tp_touch_4h"])
        tpf = sum(1 for r in recs if r["tp_first"])
        slf = sum(1 for r in recs if r["sl_first"])
        mins = [r["entry_touch_min"] for r in recs
                if r["entry_touch_min"] is not None]
        print(f"  {gran}：{n} 笔，入场触及 {e}/{n}（中位 {sorted(mins)[len(mins)//2]} 分钟），"
              f"止盈 4h 内触及 {tp}/{n}，止盈先于止损 {tpf}/{n}，止损先 {slf}/{n}")
    print("\n已写入：data/gate_iter_round22_summary.json、"
          "data/gate_iter_round22_trades_tiers.csv、"
          "data/gate_1m_7d_r22_{SYM}_USDT.csv")


if __name__ == "__main__":
    main()
