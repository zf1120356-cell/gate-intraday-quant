#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十五轮：分系统 SMC 版 SUB-SMC v1.0（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

背景（预注册，不可改）：
  2026-11-20 02:51 用户纠正：他说的分系统是“按照主系统的来，只是
  没有猎杀时刻、不需要 23 点平仓”，即主观 SMC 那套画法。动量版
  SUB-15m（每币自己 2h 动量跟随）是理解错了自己发明的信号，
  第三十一/三十三/三十四轮测的都是那个错信号，结论只对动量信号
  有效，不能算分系统的验证。动量版已停用。
  本轮测的是纠正后的分系统 SUB-SMC v1.0：第十五轮的三个 SMC 模板，
  去掉 Killzone、去掉 23:00 平仓、加跟踪止盈。

主臂 SUB-SMC v1.0：三个模板各改三处，其余一字不变——
  (a) 去掉 Killzone 过滤，入场全天任何 15m 根都可触发（只保留一条
      用户定的禁单：北京时间 01:00–07:00 不开新单，即 UTC 17:00–23:00）；
  (b) 取消 23:00 强制平仓；
  (c) 出场改为跟踪止盈：初始止损 1xATR(15m,14)，有利浮动 ≥2xATR 时
      激活（价格先触及原 2xATR 止盈位），激活后止损 = 极值 ∓1xATR
      （做多取入场以来已收盘 15m 最高价 −1xATR，做空取最低价 +1xATR，
      只朝有利方向棘轮，ATR 用入场时数值，只按已收盘 15m 根更新；
      未激活前止损保持初始 1xATR）；最多持 16 根（4h）是唯一硬上限，
      持仓可跨 00:00 UTC。
  对照臂：三个模板原样（带 Killzone、带日内强制平仓、固定止盈 2xATR），
  用于 isolate“去掉 Killzone 和 23:00 平仓到底是变好还是变差”。
  诊断臂（不参与判定）：与主臂相同信号、同样去 Killzone、无平仓、
  同样跟踪止盈，但 ATR 口径用第十五轮原版的 1h ATR14（见下“第四处
  改动”说明），用于量化 ATR 口径变化的影响。

必须诚实写明的两处口径差异（跑前写死，报告里逐条交代）：
  1. ATR 口径：第十五轮的止损/止盈用 1h ATR14；本轮主臂任务书明确
     写“初始止损 1xATR(15m,14)”，即 ATR 改为 15m ATR14——这是除
     上述三处之外的第四处实质改动（15m ATR 约为 1h ATR 的 65%，
     止损更紧、激活位更近）。“其余一字不变”指信号定义、入场、笔数
     上限、熔断不变，不包括 ATR 口径。诊断臂就是为了把这一项单独
     量出来。
  2. 日内强制平仓时刻：第十五轮原文写“23:45 强制平仓”，即 UTC 日
     最后一根 15m（23:45 开盘、00:00 收盘）的收盘价平仓；任务书里
     的“23:00 平仓”是同一机制的简称。对照臂原样复用第十五轮引擎，
     平仓时刻仍是 23:45 根收盘，不是 23:00——复现校验（对照臂全期
     必须与第十五轮公布数字一字不差）以此为准。

模板原样恢复：三个模板（A 扫荡反转做多 / B FVG 回踩做多 / C 供给拒绝
  做空）的机械化定义直接复用 gate_iter_round15.py 的 build_A /
  build_B / build_C（1h 结构、FVG、等高簇、48h 滚动最低、确认窗口、
  失效规则一字不变）；对照臂直接调用原函数，主臂通过把模块的
  in_killzone 换成恒真函数来去掉 Killzone 过滤（其余状态机逻辑
  不动），并单独统计“若保留 Killzone 会被拦掉几笔”。

数据与口径：
  8 币 BTC/ETH/SOL/DOGE/LINK/XRP/BNB/ADA；15m 数据
  data/gate_15m_103d_{币}_USDT.csv（2026-08-06~2026-11-16，103 天）；
  1h 结构数据复用第十五轮的合成方法（365 天缓存 + 15m 合成 11-16 当天
  24 根，重叠段校验）；资金费复用 data/gate_funding_365d_{币}.json，
  只计 08:00/16:00 结算点（00:00 结算点不计，与第十一/三十一轮同口径），
  2026-11-16 三个结算点无费率数据，按 0 计。
  每笔名义 10,000、1 倍；主口径 Taker（双边固定 25 USDT/笔，主臂；
  对照臂复用第十五轮引擎，名义 = 10% x 当时权益，围绕 10,000 轻微漂移，
  见报告说明）；同时报 M1/M2 maker 口径；毛利 = 价差毛利 − 资金费
  （未扣交易成本）；单币单日 -2000 USDT 熔断（按平仓实现盈亏的 UTC
  日期计）；每天每币最多 2 笔（按入场 UTC 日期计）。
  前后两半：前 46 天 2026-08-06~09-20、后 57 天 2026-09-21~11-16
  （与第三十一/三十三/三十四轮同一切法；注意第十五轮原文是前 51 天 /
  后 52 天（09-26 分界），对照臂的全期数字与第十五轮一字相同，半段
  数字因分界不同会有轻微出入，报告里对照时以全期为准）。

达标标准（不变）：全期 1x 净收益 >2% 且前后两半都正才算通过，否则
  诚实写不达标。主口径 Taker。只看主臂三个模板。

本轮与动量版三轮的关系：测的是不同信号，数字不可直接拼成“分系统
  第几版更好”。第三十一/三十三/三十四轮（-5.25%/-4.33%/-4.67%）
  否定的是动量信号，本轮否定或通过的是 SMC 信号，两者互不覆盖。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) 数据校验：8 币各 9,888 根 15m / 103 天，时间戳对齐、零缺口；
      1h 合成重叠段最大相对误差 <1e-9。
  (b) 对照臂复现：三个模板全期 Taker 与第十五轮公布数字一字不差
      （A -0.27% / B -0.61% / C -0.55%，笔数 59/193/226），且逐币
      全期 Taker 与 data/gate_iter_round15_summary.json 的 103d 行
      逐项相等；不等即模板恢复有误，停止出报告。
  (c) 信号抽查：第十五轮报告 §7 的三条首信号（A SOL 2026-08-06
      14:45 @73.48 / B ETH 2026-08-06 08:30 @1912.78 /
      C XRP 2026-08-06 09:15 @1.0488）必须在对照臂信号里一字出现，
      且在主臂信号里同样出现（Killzone 去掉不删信号，禁单时段不拦
      这三条）；另抽一笔主臂 trailing_stop 交易人工核对触发链、
      入场价、极值、激活点、出场原因与原始 K 线一致。
  (d) 账目核对：主臂/诊断臂笔数 x 25 = Taker 成本合计；毛利 − 成本
      = Taker 净；对照臂成本合计 ≈ 笔数 x 25（权益漂移，误差 <1%），
      毛利 − 成本 = Taker 净精确成立。

运行：python3 gate_iter_round35.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round35_summary.json
      + data/gate_iter_round35_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""

import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round11 as R11  # 通用引擎（对照臂原样复用）
import gate_iter_round15 as R15  # 三个 SMC 模板 builders（原样恢复）
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = R11.SYMBOLS
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]

# ---- 预注册、跑前写死：单组参数，不许改 ----
SPLIT_R35 = datetime(2026, 9, 21, tzinfo=timezone.utc)  # 前46d止于09-20
SL_MULT = 1.0
TRAIL_ATR_MULT = 1.0      # 跟踪距离：极值回撤 1xATR 即触发跟踪止损
TRAIL_ACTIVATE_MULT = 2.0  # 激活门槛：有利浮动 ≥2xATR（到原止盈位）
MAX_HOLD_MAIN = 16         # 主臂/诊断臂：最多持 16 根（4h）
MAX_HOLD_CTRL = 96         # 对照臂：第十五轮原版（日内 EOD 平仓为准）
MAX_PER_DAY = 2
DAILY_HALT = -2000.0       # 单币单日 -2000 USDT 熔断

ROUNDTRIP_COST = 0.0025
START_EQUITY = 100_000.0
NOTIONAL = 10_000.0
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, entry_t, exit_t, notional, direction):
    """与第三十四轮同口径：只计 08:00/16:00 结算点（00:00 不计），
    入场日与入场日+1 两天内 entry_t < 结算点 <= exit_t 的点按实际费率计。"""
    if not funding:
        return 0.0
    cost = 0.0
    day = datetime.fromtimestamp(entry_t, timezone.utc).date()
    for d_offset in (0, 1):
        ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc) + timedelta(days=d_offset)
        for h in (8, 16):
            s = int((ds + timedelta(hours=h)).timestamp())
            if entry_t < s <= exit_t and s in funding:
                cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def _entry_in_no_new_window(entry_t):
    """入场时刻是否落在北京时间 01:00–07:00 不开新单时段（= UTC 17:00–23:00）。
    与第三十四轮 / 引擎同口径。"""
    dt_utc = datetime.fromtimestamp(entry_t, timezone.utc)
    beijing_hour = (dt_utc.hour + 8) % 24
    return 1 <= beijing_hour < 7


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def entry_hour_utc(entry_t):
    return datetime.fromtimestamp(entry_t, timezone.utc).hour


def _fmt(x, spec):
    return "—" if x is None else format(x, spec)


# ----------------------------------------------------------------------
# 流式模拟：跟踪止盈版（整条 9,888 根连续走，不按天截断）
# 与第三十四轮 simulate_stream 一字相同（主臂 / 诊断臂共用，区别只在
# 信号字典里带的 atr 数值：主臂 = 15m ATR14，诊断臂 = 1h ATR14）。
# ----------------------------------------------------------------------
def simulate_stream(symbol, bars, signals, funding, max_per_day, label,
                    activate_mult=TRAIL_ACTIVATE_MULT):
    """取消日内强制平仓，持仓可跨 00:00 UTC，最多持 16 根封顶。
    每根处理顺序与引擎回放一致：
      (1) 已持仓先判止损（跟踪已激活记 trailing_stop，未激活记 stop_loss；
          用上一根收盘后更新的止损）；
      (2) 判持满 16 根（入场后第 15 根收盘平，原因 max_hold）；
      (3) 用本根高低更新极值与跟踪止损（激活门槛 2xATR，棘轮只朝有利方向）；
      (4) 无持仓时按信号入场（本根开盘价）。
    出场发生在当根之内，故 exit_t 记本根开盘时刻（与第三十一轮同口径）。
    每天每币最多 2 笔按入场 UTC 日期计；单币单日 -2000 熔断按平仓实现
    盈亏的 UTC 日期计（与引擎 sub_day_pnl 口径一致）。
    入场开盘价已穿初始止损（跳空）时跳过，与引擎 sub_entry_skipped_gap_stop
    同口径。某根收盘平掉一笔后，当根不再开新仓（与第三十一轮 simulate_sub
    的 continue 口径一致）。"""
    trades = []
    curve = [START_EQUITY]
    equity = START_EQUITY
    trades_by_entry_date = {}
    day_pnl = {}
    pos = None
    n_skip_open = 0
    n_skip_cap = 0
    n_skip_breaker = 0

    def close_trade(tr, exit_t, exit_price, reason):
        nonlocal equity
        tr["exit_t"], tr["exit"] = exit_t, exit_price
        tr["reason"] = reason
        tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
        tr["funding_cost_usdt"] = funding_cost_between(
            funding, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
        tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
        tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
        move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
        tr["price_pnl"] = tr["notional"] * move
        tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
        tr["pnl_pct_equity"] = tr["pnl"] / START_EQUITY
        tr["peak"] = tr.get("peak")
        tr["trail_active"] = tr.get("trail_active", False)
        tr["max_favour_usdt"] = (((tr["peak"] - tr["entry"]) / tr["entry"]) * tr["direction"]
                                 * tr["notional"]) if tr.get("peak") is not None else 0.0
        equity += tr["pnl"]
        exit_date = datetime.fromtimestamp(exit_t, timezone.utc).date()
        day_pnl[exit_date] = day_pnl.get(exit_date, 0.0) + tr["pnl"]
        trades.append(tr)
        curve.append(equity)

    for gi, b in enumerate(bars):
        if pos is not None and b["t"] in signals:
            n_skip_open += 1
        just_closed = False
        if pos is not None:
            d = pos["direction"]
            exited = False
            if d == 1:
                if b["l"] <= pos["stop"]:
                    reason = "trailing_stop" if pos["trail_active"] else "stop_loss"
                    close_trade(pos, b["t"], pos["stop"], reason)
                    exited = True
            else:
                if b["h"] >= pos["stop"]:
                    reason = "trailing_stop" if pos["trail_active"] else "stop_loss"
                    close_trade(pos, b["t"], pos["stop"], reason)
                    exited = True
            if exited:
                pos = None
                just_closed = True
            elif gi - pos["entry_gi"] >= MAX_HOLD_MAIN - 1:
                close_trade(pos, b["t"], b["c"], "max_hold")
                pos = None
                just_closed = True
            else:
                a = pos["atr"]
                if d == 1:
                    if b["h"] > pos["peak"]:
                        pos["peak"] = b["h"]
                else:
                    if b["l"] < pos["peak"]:
                        pos["peak"] = b["l"]
                if not pos["trail_active"]:
                    favour = (pos["peak"] - pos["entry"]) * d
                    if favour >= activate_mult * a:
                        pos["trail_active"] = True
                if pos["trail_active"]:
                    cand = (pos["peak"] - TRAIL_ATR_MULT * a if d == 1
                            else pos["peak"] + TRAIL_ATR_MULT * a)
                    if d == 1:
                        if cand > pos["stop"]:
                            pos["stop"] = cand
                    else:
                        if cand < pos["stop"]:
                            pos["stop"] = cand
        if pos is None and not just_closed:
            sig = signals.get(b["t"])
            if sig is None:
                continue
            entry_date = datetime.fromtimestamp(b["t"], timezone.utc).date()
            if trades_by_entry_date.get(entry_date, 0) >= max_per_day:
                n_skip_cap += 1
                continue
            if day_pnl.get(entry_date, 0.0) <= DAILY_HALT:
                n_skip_breaker += 1
                continue
            entry = b["o"]
            a = sig["atr"]
            stop = entry - SL_MULT * a if sig["direction"] == 1 else entry + SL_MULT * a
            if (sig["direction"] == 1 and entry <= stop) or (sig["direction"] == -1 and entry >= stop):
                continue
            pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                   "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                   "stop": stop, "tp": None, "atr": a,
                   "peak": entry, "trail_active": False,
                   "notional": NOTIONAL, "margin": 0.10 * NOTIONAL,
                   "exit_t": None, "exit": None, "pnl": 0.0,
                   "reason": "", "funding_cost_usdt": 0.0,
                   "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                   "hold_min": None, "pnl_pct_equity": 0.0,
                   "max_hold": MAX_HOLD_MAIN,
                   "atr_basis": sig.get("atr_basis", ""), "tag": sig.get("tag", "")}
            trades_by_entry_date[entry_date] = trades_by_entry_date.get(entry_date, 0) + 1
    if pos is not None:
        close_trade(pos, bars[-1]["t"], bars[-1]["c"], "data_end")
        pos = None
    stats = {"skip_open": n_skip_open, "skip_cap": n_skip_cap,
             "skip_breaker": n_skip_breaker}
    return trades, curve, stats


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "gross_cost_ratio": round(gross_sum / taker_cost_sum, 4) if taker_cost_sum else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


# ----------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------
def main():
    print("盈利策略迭代 · 第三十五轮：分系统 SMC 版 SUB-SMC v1.0（全模拟）")
    print("第十五轮三模板（A 扫荡反转做多 / B FVG 回踩做多 / C 供给拒绝做空）"
          "去掉 Killzone、去掉日内强制平仓、改跟踪止盈（2xATR 激活）。")
    print("对照臂 = 第十五轮原样（Killzone + 日内强制平仓 + 固定止盈 2xATR）；"
          "诊断臂 = 主臂信号 + 1h ATR14（不参与判定）。")
    print("达标标准：前后两半都为正且全期 1x 净收益 >2%（主口径 Taker，只看主臂）。")

    # ---- 数据校验（只读本地缓存，不联网）----
    data15 = {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    miss = set()
    for sym in SYMBOLS:
        funding = data15[sym][1]
        for h in (0, 8, 16):
            s = int((datetime(2026, 11, 16, tzinfo=timezone.utc) + timedelta(hours=h)).timestamp())
            if s not in funding:
                miss.add((sym, h))
    print(f"资金费缺失：2026-11-16 的 00:00/08:00/16:00 三个结算点在全部 8 币的费率数据里都不存在"
          f"（费率数据止于 2026-11-15 16:00），共 {len(miss)} 个（币，结算点）按 0 计；其余结算点均按实际费率计。")

    # ---- 1h 合成（第十五轮同方法）----
    data1h = R15.build_1h_combined()

    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_46 = {d for d in days_all_15 if d < SPLIT_R35.date()}
    back_57 = {d for d in days_all_15 if d >= SPLIT_R35.date()}
    print(f"窗口：全 103d（前 {len(front_46)} 天 2026-08-06~09-20 / "
          f"后 {len(back_57)} 天 2026-09-21~11-16）。")

    windows = [("103d", None), ("前46d", front_46), ("后57d", back_57)]
    split_fn = lambda et: ("前46d" if datetime.fromtimestamp(et, timezone.utc).date()
                           < SPLIT_R35.date() else "后57d")

    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    idx_of_t = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in SYMBOLS}

    templates = [("A", "R15-A 扫荡反转做多", R15.build_A),
                 ("B", "R15-B FVG 回踩做多", R15.build_B),
                 ("C", "R15-C 供给拒绝做空", R15.build_C)]

    # ---- 1. 对照臂信号：第十五轮 builders 原样（含 Killzone）----
    ctrl_sig, ctrl_fun = {}, {}
    for fam, label, builder in templates:
        sig, fun = {}, {}
        for sym in SYMBOLS:
            bars1h, a1h = data1h[sym]
            sig[sym], fun[sym] = builder(data15[sym][0], bars1h, a1h)
        ctrl_sig[fam], ctrl_fun[fam] = sig, fun
        tot = sum(len(v) for v in sig.values())
        print(f"[对照 {fam}] 信号数（入场时刻）：8 币合计 {tot}；"
              + "、".join(f"{s.replace('_USDT', '')} {len(sig[s])}" for s in SYMBOLS)
              + f"；Killzone 拦掉 {sum(c.get('killzone_skipped', 0) for c in fun.values())} 个确认。")

    # ---- 2. 首信号核对（第十五轮报告 §7，三条一字核对）----
    first_checks = [
        ("A", "SOL_USDT", datetime(2026, 8, 6, 14, 45, tzinfo=timezone.utc), 73.48, 1),
        ("B", "ETH_USDT", datetime(2026, 8, 6, 8, 30, tzinfo=timezone.utc), 1912.78, 1),
        ("C", "XRP_USDT", datetime(2026, 8, 6, 9, 15, tzinfo=timezone.utc), 1.0488, -1),
    ]
    for fam, sym, dt, exp_price, exp_dir in first_checks:
        et = int(dt.timestamp())
        assert et in ctrl_sig[fam][sym], f"首信号缺失：{fam} {sym} {dt}"
        assert ctrl_sig[fam][sym][et]["direction"] == exp_dir, f"首信号方向不对：{fam} {sym}"
        actual_open = data15[sym][0][idx_of_t[sym][et]]["o"]
        assert abs(actual_open - exp_price) < 0.01, \
            f"首信号入场价不对：{fam} {sym} 实际 {actual_open} vs 报告 {exp_price}"
        print(f"[首信号核对 ✓] {fam} {sym} {dt.strftime('%Y-%m-%d %H:%M')} UTC "
              f"入场 {actual_open}（报告 {exp_price}）方向 {'多' if exp_dir == 1 else '空'}")

    # ---- 3. 对照臂：第十五轮引擎原样（固定止盈 2xATR + 日内强制平仓）----
    all_results, all_trades = [], []
    ctrl_trades_by_fam = {}

    def record_ctrl(res, trades_full, fam, variant):
        res["arm"] = "CTRL"
        res["family"] = fam
        res["template"] = fam
        res["variant"] = variant
        res["granularity"] = "15m"
        res["atr_basis"] = "1h"
        if res.get("taker_cost_sum"):
            res["gross_cost_ratio"] = round(res["gross_usdt"] / res["taker_cost_sum"], 4)
        all_results.append(res)

    for fam, label, builder in templates:
        print(f"\n=== 对照臂 {label}（第十五轮原样）===")
        fam_trades = []
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            for wname, subset in windows:
                trades, curve, ndays = R11.simulate_generic(
                    sym, bars, ctrl_sig[fam][sym], funding, subset,
                    MAX_PER_DAY, MAX_HOLD_CTRL, label, 96)
                res = R11.summarize(sym, trades, curve, label, len(ctrl_sig[fam][sym]))
                res["split"] = wname
                res["days"] = ndays
                res["signals_total"] = len(ctrl_sig[fam][sym])
                res["signals_blocked_night"] = 0
                res["killzone_skipped"] = ctrl_fun[fam][sym].get("killzone_skipped", 0)
                record_ctrl(res, trades if subset is None else None, fam, label)
                if subset is None:
                    fam_trades.extend(trades)
                print(f"[对照 {fam} {sym} {wname}] n={res['trades']} "
                      f"胜率={res['win_rate']} Taker {res['taker_net_pct']*100:+.2f}% "
                      f"(t={res['t_taker']}) | 毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={_fmt(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
                      f"出场={res['reason_counts']}")
        ctrl_trades_by_fam[fam] = fam_trades
        for t in fam_trades:
            t2 = dict(t)
            t2["arm"] = "CTRL"
            t2["family"] = fam
            t2["template"] = fam
            t2["variant"] = label
            t2["granularity"] = "15m"
            t2["atr_basis"] = "1h"
            t2["split"] = split_fn(t["entry_t"])
            t2["entry_hour_utc"] = entry_hour_utc(t["entry_t"])
            all_trades.append(t2)

    # ---- 4. 复现校验：对照臂全期必须与第十五轮公布数字一字不差 ----
    print("\n=== 复现校验：对照臂 vs 第十五轮公布数字 ===")
    r15 = json.load(open(os.path.join(DATA_DIR, "gate_iter_round15_summary.json")))
    r15_full = {(r["family"], r["symbol"]): r for r in r15 if r["split"] == "103d"}
    published = {"A": (-0.0027, 59), "B": (-0.0061, 193), "C": (-0.0055, 226)}
    ok = True
    for fam, (pub_pct, pub_n) in published.items():
        rs = [r for r in all_results if r["arm"] == "CTRL" and r["family"] == fam and r["split"] == "103d"]
        avg_pct = sum(r["taker_net_pct"] for r in rs) / len(rs)
        tot_n = sum(r["trades"] for r in rs)
        # 公布的平均值是 2 位小数显示（-0.27% 即 -0.0027），而 avg_pct 是
        # 8 个已四舍五入到 4 位小数的逐币值再平均，舍入误差可达 0.00005；
        # 故公布值对照用 0.0001 容差，逐币逐项相等才是硬校验。
        match_pub = abs(avg_pct - pub_pct) < 0.0001 and tot_n == pub_n
        per_coin_ok = all(
            [r for r in all_results if r["arm"] == "CTRL" and r["family"] == fam
             and r["symbol"] == sym and r["split"] == "103d"][0]["taker_net_pct"]
            == r15_full[(fam, sym)]["taker_net_pct"]
            and [r for r in all_results if r["arm"] == "CTRL" and r["family"] == fam
                 and r["symbol"] == sym and r["split"] == "103d"][0]["trades"]
            == r15_full[(fam, sym)]["trades"]
            for sym in SYMBOLS)
        print(f"  [{fam}] 对照臂全期 Taker 平均 {avg_pct*100:+.2f}%（公布 {pub_pct*100:+.2f}%）"
              f"笔数 {tot_n}（公布 {pub_n}）→ {'✓ 一致' if match_pub else '✗ 不一致'}；"
              f"逐币与 round15 summary.json 103d 行逐项相等：{'✓' if per_coin_ok else '✗'}")
        ok = ok and match_pub and per_coin_ok
    assert ok, "复现校验失败：对照臂与第十五轮数字不一致，模板恢复有误，停止出报告！"
    print("  复现校验通过：三个模板原样恢复正确。")

    # ---- 5. 主臂信号：去掉 Killzone（in_killzone 恒真），再拦夜间禁单时段 ----
    R15.in_killzone = lambda t: True
    main_sig_raw, main_fun = {}, {}
    for fam, label, builder in templates:
        sig, fun = {}, {}
        for sym in SYMBOLS:
            bars1h, a1h = data1h[sym]
            sig[sym], fun[sym] = builder(data15[sym][0], bars1h, a1h)
        main_sig_raw[fam], main_fun[fam] = sig, fun
        tot = sum(len(v) for v in sig.values())
        ctrl_tot = sum(len(v) for v in ctrl_sig[fam].values())
        print(f"[主臂信号 {fam}] 去 Killzone 后信号数：8 币合计 {tot}（对照 {ctrl_tot}，"
              f"新增 {tot - ctrl_tot} 个，+{(tot - ctrl_tot) / ctrl_tot * 100:.1f}%）；"
              + "、".join(f"{s.replace('_USDT', '')} {len(sig[s])}" for s in SYMBOLS))

    # 首信号必须同样出现在主臂信号里（Killzone 去掉不删信号，禁单时段不拦这三条）
    for fam, sym, dt, exp_price, exp_dir in first_checks:
        et = int(dt.timestamp())
        assert et in main_sig_raw[fam][sym], f"主臂信号缺失首信号：{fam} {sym} {dt}"
        assert not _entry_in_no_new_window(et), f"首信号不应被禁单时段拦掉：{fam} {sym}"
    print("[首信号核对 ✓] 三条首信号同样在主臂信号里，且均不在禁单时段。")

    # 夜间禁单过滤 + ATR 口径分流（主臂 15m ATR / 诊断臂 1h ATR）
    main_sig, diag_sig, night_blocked = {}, {}, {}
    for fam, label, builder in templates:
        ms, ds, nb = {}, {}, {}
        for sym in SYMBOLS:
            ms[sym], ds[sym], nb[sym] = {}, {}, 0
            for et, s in main_sig_raw[fam][sym].items():
                if _entry_in_no_new_window(et):
                    nb[sym] += 1
                    continue
                gi = idx_of_t[sym][et]
                a15 = atr15[sym][gi - 1] if gi - 1 >= 0 else None
                assert a15 is not None, f"15m ATR 缺失：{fam} {sym} {et}"
                ms[sym][et] = {"direction": s["direction"], "atr": a15,
                               "atr_basis": "15m", "tag": s.get("tag", "")}
                ds[sym][et] = {"direction": s["direction"], "atr": s["atr"],
                               "atr_basis": "1h", "tag": s.get("tag", "")}
        main_sig[fam], diag_sig[fam] = ms, ds
        night_blocked[fam] = nb
        print(f"[主臂信号 {fam}] 夜间禁单时段拦掉 {sum(nb.values())} 个信号"
              f"（8 币合计）；入场信号 {sum(len(v) for v in ms.values())} 个。")

    # ---- 6. 主臂与诊断臂：跟踪止盈流式模拟 ----
    def run_stream_arm(arm, variant, sig_by_fam):
        arm_trades = {}
        for fam, label, builder in templates:
            print(f"\n=== {arm} {label} ===")
            fam_trades = []
            for sym in SYMBOLS:
                bars, funding = data15[sym]
                trades, curve, stats = simulate_stream(
                    sym, bars, sig_by_fam[fam][sym], funding, MAX_PER_DAY, variant)
                fam_trades.extend(trades)
                print(f"[{arm} {fam} {sym} 全期] n={len(trades)} 跳过信号：持仓中 {stats['skip_open']} / "
                      f"满2笔 {stats['skip_cap']} / 熔断 {stats['skip_breaker']}")
            fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
            arm_trades[fam] = fam_trades
            for sym in SYMBOLS:
                st = [t for t in fam_trades if t["symbol"] == sym]
                for wname, _ in windows:
                    wt = [t for t in st if wname == "103d" or split_fn(t["entry_t"]) == wname]
                    wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                    eq = START_EQUITY
                    wcurve = [eq]
                    for t in wt_sorted:
                        eq += t["pnl"]
                        wcurve.append(eq)
                    res = summarize(sym, wt_sorted, wcurve, variant, len(sig_by_fam[fam][sym]))
                    res["arm"] = arm
                    res["family"] = fam
                    res["template"] = fam
                    res["variant"] = variant
                    res["granularity"] = "15m"
                    res["atr_basis"] = "15m" if arm == "MAIN" else "1h"
                    res["split"] = wname
                    res["days"] = 103 if wname == "103d" else (46 if wname == "前46d" else 57)
                    res["signals_total"] = len(sig_by_fam[fam][sym])
                    res["signals_blocked_night"] = night_blocked[fam][sym]
                    res["killzone_skipped"] = ctrl_fun[fam][sym].get("killzone_skipped", 0)
                    all_results.append(res)
                    print(f"[{arm} {fam} {sym} {wname}] n={res['trades']} "
                          f"胜率={res['win_rate']} Taker {res['taker_net_pct']*100:+.2f}% "
                          f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                          f"毛利={res['gross_usdt']:+.0f} 每笔毛利={_fmt(res['gross_per_trade_usdt'], '+.2f')} "
                          f"毛利/成本={res['gross_cost_ratio']} 成本={res['taker_cost_sum']:+.0f} "
                          f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")
            for t in fam_trades:
                t2 = dict(t)
                t2["arm"] = arm
                t2["family"] = fam
                t2["template"] = fam
                t2["variant"] = variant
                t2["granularity"] = "15m"
                t2["atr_basis"] = "15m" if arm == "MAIN" else "1h"
                t2["split"] = split_fn(t["entry_t"])
                t2["entry_hour_utc"] = entry_hour_utc(t["entry_t"])
                all_trades.append(t2)
        return arm_trades

    main_trades = run_stream_arm("MAIN", "SUB-SMC-v1.0", main_sig)
    diag_trades = run_stream_arm("DIAG", "SUB-SMC-v1.0-1hATR", diag_sig)

    # ---- 7. 汇总、pooled t、达标判定 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    verdict = {}
    for arm in ["CTRL", "MAIN", "DIAG"]:
        for fam in ["A", "B", "C"]:
            line = []
            for wname, _ in windows:
                rs = [r for r in all_results if r["arm"] == arm and r["family"] == fam and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                avg_pct = sum(r["taker_net_pct"] for r in rs) / len(rs)
                line.append(f"{wname} Taker {avg_pct*100:+.2f}% / M1 "
                            f"{sum(r['m1_net_pct'] for r in rs)/len(rs)*100:+.2f}% / M2 "
                            f"{sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                            f"毛利 {gt:+.0f} 成本 {ct:+.0f} 笔数 {nt} "
                            f"每笔毛利 {gt/nt:+.2f} 毛利/成本 {gt/ct:.3f}" if ct else
                            f"{wname} Taker {avg_pct*100:+.2f}% | 笔数 {nt}")
            print(f"  [{arm} {fam}] " + " || ".join(line))
            if arm == "MAIN":
                agg = {w: sum(r["taker_net_pct"] for r in all_results
                              if r["arm"] == "MAIN" and r["family"] == fam and r["split"] == w) / 8
                       for w, _ in windows}
                good = agg["前46d"] > 0 and agg["后57d"] > 0 and agg["103d"] > 0.02
                verdict[fam] = good
                both = sum(1 for sym in SYMBOLS
                           if [r for r in all_results if r["arm"] == "MAIN" and r["family"] == fam
                               and r["symbol"] == sym and r["split"] == "前46d"][0]["taker_net_pct"] > 0
                           and [r for r in all_results if r["arm"] == "MAIN" and r["family"] == fam
                                and r["symbol"] == sym and r["split"] == "后57d"][0]["taker_net_pct"] > 0)
                print(f"    → 模板 {fam} 判定：{'达标' if good else '不达标'}"
                      f"（前 {agg['前46d']*100:+.2f}% / 后 {agg['后57d']*100:+.2f}% / "
                      f"全 {agg['103d']*100:+.2f}%；前后两半都为正的币 {both}/8）")

    print("\n=== Pooled t（全期逐笔，Taker，1x）===")
    for arm, trades_by_fam in [("CTRL", ctrl_trades_by_fam), ("MAIN", main_trades), ("DIAG", diag_trades)]:
        for fam in ["A", "B", "C"]:
            ts = trades_by_fam[fam]
            vt = [t["pnl"] / START_EQUITY for t in ts]
            vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in ts]
            print(f"  [{arm} {fam}] n={len(ts)} pooled t(Taker)={t_value(vt)} pooled t(毛利)={t_value(vg)}")

    # ---- 8. 诊断 ----
    print("\n=== 诊断 ===")
    for fam, label, builder in templates:
        tot_fun = Counter()
        for c in ctrl_fun[fam].values():
            tot_fun.update(c)
        print(f"  [{fam} 漏斗·对照臂] {dict(sorted(tot_fun.items()))}")
    for fam in ["A", "B", "C"]:
        cm = sum(len(v) for v in main_sig[fam].values())
        cc = sum(len(v) for v in ctrl_sig[fam].values())
        print(f"  [{fam} Killzone 效应] 信号：对照 {cc} → 主臂（去 Killzone、扣禁单后）{cm}"
              f"（+{cm - cc}，+{(cm - cc) / cc * 100:.1f}%）；"
              f"对照臂漏斗里 Killzone 拦掉 "
              f"{sum(c.get('killzone_skipped', 0) for c in ctrl_fun[fam].values())} 个确认；"
              f"主臂夜间禁单拦掉 {sum(night_blocked[fam].values())} 个信号。")
    for arm, trades_by_fam in [("CTRL", ctrl_trades_by_fam), ("MAIN", main_trades), ("DIAG", diag_trades)]:
        for fam in ["A", "B", "C"]:
            at = trades_by_fam[fam]
            rc = Counter(t["reason"] for t in at)
            ovn = [t for t in at
                   if datetime.fromtimestamp(t["exit_t"], timezone.utc).date()
                   > datetime.fromtimestamp(t["entry_t"], timezone.utc).date()]
            ftot = sum(t["funding_cost_usdt"] for t in at)
            fcross = sum(1 for t in at if t["funding_cost_usdt"] != 0)
            print(f"  [{arm} {fam}] 出场原因：{dict(sorted(rc.items()))}（共 {len(at)} 笔）；"
                  f"跨夜持仓 {len(ovn)} 笔，净 {sum(t['pnl'] for t in ovn):+.0f}；"
                  f"资金费合计 {ftot:+.2f}（{fcross}/{len(at)} 笔跨结算点）。")
    for arm, trades_by_fam in [("MAIN", main_trades), ("DIAG", diag_trades)]:
        for fam in ["A", "B", "C"]:
            at = trades_by_fam[fam]
            act = [t for t in at if t.get("trail_active")]
            unact = [t for t in at if not t.get("trail_active")]
            if act:
                print(f"  [{arm} {fam} 激活诊断] 激活 {len(act)}/{len(at)}（{len(act)/len(at)*100:.1f}%）；"
                      f"激活笔峰值有利毛利均值 {sum(t['max_favour_usdt'] for t in act)/len(act):+.2f} / "
                      f"实际价差毛利均值 {sum(t['price_pnl'] for t in act)/len(act):+.2f} / "
                      f"平均回吐 {sum(t['max_favour_usdt']-t['price_pnl'] for t in act)/len(act):+.2f} / "
                      f"平均保住比例 {sum(t['price_pnl'] for t in act)/sum(t['max_favour_usdt'] for t in act)*100:.1f}%；"
                      f"激活笔净盈利 {sum(1 for t in act if t['pnl'] > 0)}/{len(act)}；"
                      f"激活笔里价差毛利 <25 USDT 的有 {sum(1 for t in act if t['price_pnl'] < 25)} 笔")
            print(f"    未激活 {len(unact)} 笔，出场原因 {dict(sorted(Counter(t['reason'] for t in unact).items()))}，"
                  f"净 {sum(t['pnl'] for t in unact):+.0f}，毛利 "
                  f"{sum(t['price_pnl']-t['funding_cost_usdt'] for t in unact):+.0f}")
            # 峰值有利浮动分布（按 ATR 计）
            buckets = Counter()
            for t in at:
                fav_atr = (t.get("max_favour_usdt", 0.0) / NOTIONAL) / (t["atr"] / t["entry"]) if t.get("atr") else 0.0
                if fav_atr < 0:
                    buckets["<0"] += 1
                elif fav_atr < 1:
                    buckets["0–1xATR"] += 1
                elif fav_atr < 2:
                    buckets["1–2xATR"] += 1
                else:
                    buckets[">=2xATR"] += 1
            print(f"    峰值有利浮动分布（按 ATR）：{dict(sorted(buckets.items()))}")
    for arm, trades_by_fam in [("CTRL", ctrl_trades_by_fam), ("MAIN", main_trades), ("DIAG", diag_trades)]:
        for fam in ["A", "B", "C"]:
            at = trades_by_fam[fam]
            lo = [t for t in at if t["direction"] == 1]
            sh = [t for t in at if t["direction"] == -1]
            print(f"  [{arm} {fam}] 多空拆分：LONG n={len(lo)} 净 {sum(t['pnl'] for t in lo):+.0f} "
                  f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in lo)/len(lo) if lo else 0:+.2f}；"
                  f"SHORT n={len(sh)} 净 {sum(t['pnl'] for t in sh):+.0f} "
                  f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in sh)/len(sh) if sh else 0:+.2f}")
    # 主臂 vs 对照臂、主臂 vs 诊断臂的差
    for fam in ["A", "B", "C"]:
        m, c, d = main_trades[fam], ctrl_trades_by_fam[fam], diag_trades[fam]
        mk = {(t["symbol"], t["entry_t"]) for t in m}
        ck = {(t["symbol"], t["entry_t"]) for t in c}
        dk = {(t["symbol"], t["entry_t"]) for t in d}
        print(f"  [{fam} 主臂 − 对照臂] 笔数 {len(m)-len(c):+d}，Taker 净 "
              f"{sum(t['pnl'] for t in m)-sum(t['pnl'] for t in c):+.0f}，毛利 "
              f"{sum(t['price_pnl']-t['funding_cost_usdt'] for t in m)-sum(t['price_pnl']-t['funding_cost_usdt'] for t in c):+.0f}；"
              f"相同 (symbol, entry_t) 的入场 {len(mk & ck)} 笔"
              f"（主臂独有 {len(mk-ck)}、对照臂独有 {len(ck-mk)}）")
        print(f"  [{fam} 主臂 − 诊断臂（ATR 口径效应）] 笔数 {len(m)-len(d):+d}，Taker 净 "
              f"{sum(t['pnl'] for t in m)-sum(t['pnl'] for t in d):+.0f}，毛利 "
              f"{sum(t['price_pnl']-t['funding_cost_usdt'] for t in m)-sum(t['price_pnl']-t['funding_cost_usdt'] for t in d):+.0f}；"
              f"相同入场 {len(mk & dk)} 笔")

    # ---- 9. 账目核对 ----
    print("\n=== 账目核对 ===")
    for arm, trades_by_fam in [("MAIN", main_trades), ("DIAG", diag_trades)]:
        for fam in ["A", "B", "C"]:
            ts = trades_by_fam[fam]
            cost = sum(t["cost_usdt"] for t in ts)
            gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ts)
            net = sum(t["pnl"] for t in ts)
            assert abs(cost - len(ts) * 25.0) < 0.01, f"账目不对：{arm} {fam} 成本 {cost} ≠ 笔数x25"
            assert abs(gross - cost - net) < 0.01, f"账目不对：{arm} {fam} 毛利-成本≠净"
            print(f"  [{arm} {fam}] 笔数 {len(ts)} x 25 = {len(ts)*25:.0f} = 成本合计 {cost:.2f} ✓；"
                  f"毛利 {gross:+.2f} − 成本 {cost:.2f} = 净 {net:+.2f} ✓")
    for fam in ["A", "B", "C"]:
        ts = ctrl_trades_by_fam[fam]
        cost = sum(t["cost_usdt"] for t in ts)
        gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ts)
        net = sum(t["pnl"] for t in ts)
        assert abs(gross - cost - net) < 0.01, f"账目不对：CTRL {fam} 毛利-成本≠净"
        print(f"  [CTRL {fam}] 笔数 {len(ts)}，成本合计 {cost:.2f}（名义随权益漂移，"
              f"笔均 {cost/len(ts):.2f}，与 25 的偏差 {(cost/len(ts)-25)/25*100:+.2f}%）；"
              f"毛利 {gross:+.2f} − 成本 {cost:.2f} = 净 {net:+.2f} ✓")

    # ---- 10. 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round35_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round35_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "template", "variant", "atr_basis", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min", "peak", "trail_active",
                    "max_favour_usdt", "atr"])
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["family"], x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["template"], t["variant"], t.get("atr_basis", ""),
                        t["granularity"], t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"], t.get("peak"), t.get("trail_active"),
                        round(t.get("max_favour_usdt", 0.0), 2), t.get("atr")])
    print(f"\n汇总已写入：data/gate_iter_round35_summary.json ({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round35_trades.csv ({len(all_trades)} 笔)")
    print("\n=== 最终判定（主臂 SUB-SMC v1.0，主口径 Taker）===")
    for fam in ["A", "B", "C"]:
        print(f"  模板 {fam}：{'达标' if verdict[fam] else '不达标'}")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
