#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十七轮：多币同发信号层面检验（分系统 SUB-SMC，全新币种宇宙验证）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

预注册（跑前写死，不可改；来源：盈利策略迭代-分系统回测挖掘.md §2.3；
用户 2026-11-21 指示：换个币种，不能用回测过的币种）：
  测什么：35 轮三模板（A 扫荡反转做多 / B FVG 回踩做多 / C 供给拒绝做空）
  的信号，按（UTC 日、时段、方向）分组——同日同时段同向 ≥2 币信号为
  多币组，单币信号为单币组——分别算净收益与毛利/成本。直接回答
  “多币同发是否有效”。
  新宇宙：8 个从未回测过的币（见 NEW_SYMBOLS；选择过程与成交额表见
  报告附录与 data/gate_iter_round37_selection.json）。原 8 币与 24 轮
  12 币（共 20 个已回测币）全部排除。
  信号：复用 gate_iter_round35.py 的 builders 与 simulate_stream，不改
  信号定义；输出全部信号（含被每天 2 笔上限拦掉的、含持仓中跳过的），
  不要只输出执行笔。
  分组（因果版，见下“无未来数据”一节）：多币/单币的分组按信号的入场
  时刻判定——一个信号是多币组，当且仅当在它入场之前（含同一根入场根）
  已有另一个币在同一（UTC 日、时段、方向）里发出信号；否则为单币组。
  时段划分与 36 轮一致：亚洲 00:00–08:00、欧洲 08:00–16:00、
  美盘 16:00–24:00 UTC。
  出场（跟踪止盈 2xATR 激活）、成本（Taker 0.075% + 真实成本模型口径与
  35 轮一致）、熔断、每天每币 2 笔上限、夜禁（UTC 17:00–23:00）全部与
  35 轮主臂一字相同，包括 16 根持满上限——为隔离变量，不与 v1.1 的
  “取消持满上限”混在一起。
  对照臂：新宇宙上不分组的三模板全量结果（相当于 35 轮主臂在新宇宙上
  的复算），与分组结果同表报出。
  报什么：每模板 × 每组（多币/单币/全量对照）：笔数、全期 Taker 净
  （币均）、前/后半段 Taker 净、每笔毛利、毛利/成本、P(到 1xATR)、
  P(到 2x|到 1x)、R1 三项分解（多币组 vs 全模板；单币组 vs 全模板）。
  通过标准（与 36 轮同，不放宽）：某模板 × 多币组同时满足 (i) 全期
  1 倍 Taker 净 > +2%（币均），(ii) 前后两半都为正，(iii) 每笔毛利
  > 25 USDT 且两半都 > 25，(iv) R1 省成本占比 ≤ 80%——四项全过才算
  “多币同发有效”。
  证伪：若没有一个模板的多币组四项全过，则多币同发不进判断层作加权。
  若某组通过，它仍只是“一轮验证通过”——按 R2 它已经用掉了全新宇宙
  的唯一一次检验机会，不得再在另一批新币上重复验证同一发现。
  预期（跑前写死）：挖掘报告 §2.3 的描述数字（执行笔层面 A 组 +25.77/
  笔）是在旧宇宙执行笔上切出来的、已被上限扭曲；信号层面 + 新宇宙
  的数字未知，预期是不通过。这轮的价值是给判断层一个干净的信号层面
  答案，不是找 edge。

无未来数据（用户 2026-11-21 硬性要求，执行前自查，写死在代码里）：
  - 信号只用已收盘 K 线：R15 builders（A/B/C）只用已收盘的 1h 根
    （FVG/等高位只在 formed_close_t 之后可用；48h 滚动最低取入场根
    之前最后一个已收盘 1h 根）与已收盘的 15m 根（触及/确认都按收盘价
    判定）；入场一律是确认根的下一根 15m 开盘价（信号字典的键就是
    入场根时刻，simulate_stream 在该根开盘价入场）。
  - 分组不用未来信号：多币组的判定只用入场时刻之前（含同一根）已
    发生的信号；同日同时段里晚于入场时刻的信号不计入（字面上的
    “全桶分组”会用到入场之后的信号，是未来数据，本轮明确拒绝）。
  - 模拟不用未来数据：simulate_stream 每根只用当根高低收与已持仓
    状态；资金费只计入场日与入场日+1 的 08:00/16:00 结算点。
  -  builders 与引擎一字不改就是合规；本脚本只加分组逻辑，分组逻辑
    本身不读任何价格、只读信号的入场时刻与方向。
  数据绝对不能做假：算不出就写算不出（33 轮缺 atr 列即是先例）。

窗口偏差（实测，非推测；见 gate_iter_round37_fetch.py）：
  Gate /futures/usdt/candlesticks 对 15m 只提供最近 10,000 根回溯，
  35/36 轮的 103 天窗口（2026-08-06 起）对任何新币都已无法复现；
  本轮 15m 窗口为 2026-08-09~2026-11-16（100 天，9,600 根），
  前半段 2026-08-09~09-20（43 天）、后半段 2026-09-21~11-16（57 天，
  与 35/36 轮后半段一字相同）。1h 仍为 365 天（8,761 根）。
  本偏差不影响多币/单币/全量三臂之间的内部比较（同窗口、同信号），
  但 37 轮数字与 35/36 轮不是同一窗口，不可逐项等同比较。

运行：python3 gate_iter_round37.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round37_summary.json
      + data/gate_iter_round37_cells.json + data/gate_iter_round37_trades.csv
复现：跑两遍，三个文件的 md5 应完全一致。
"""

import csv
import json
import math
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round15 as R15  # 三个 SMC 模板 builders（原样恢复）
import gate_iter_round35 as R35  # 复用 35 轮引擎：load / atr / simulate_stream / summarize

DATA_DIR = os.path.join(SCRIPT_DIR, "data")

# ---- 新宇宙（跑前定死；选择见 data/gate_iter_round37_selection.json）----
# 新宇宙（已定死，2026-11-21 01:22 UTC tickers 快照，按 24h 成交额降序取前 8 个通过全部筛查的币；
# 名单与成交额见 data/gate_iter_round37_selection.json；跑前定死，跑后不换）。
NEW_SYMBOLS = ["MMT_USDT", "WLD_USDT", "PIEVERSE_USDT", "AVAX_USDT",
               "PAXG_USDT", "ARB_USDT", "FIL_USDT", "TAO_USDT"]
SYMBOLS = NEW_SYMBOLS
# R35.summarize 用 FILL/PENALTY（Maker 混合诊断 M2）且只在原 8 币上有值。
# 沿用 R35 自身的规则（gate_iter_round35.py 第 145–147 行：无实测成交率的币
# 一律取 SOL 的值）：新宇宙 8 币同样取 SOL 的 FILL/PENALTY。
# M2 只是诊断量（R4：执行口径只认混合现实，M1/M0 作诊断）；本轮四项通过标准
# 只用 Taker 净与毛利，M2 默认值不影响证伪/通过结论（见报告 §0.5）。
for _sym in SYMBOLS:
    if _sym not in R35.FILL:
        R35.FILL[_sym] = R35.FILL["SOL_USDT"]
        R35.PENALTY[_sym] = R35.PENALTY["SOL_USDT"]
SPLIT_R35 = R35.SPLIT_R35  # 2026-09-21；前半段 08-09~09-20（43 天）/ 后 57 天
START_EQUITY = R35.START_EQUITY
NOTIONAL = R35.NOTIONAL
MAX_PER_DAY = R35.MAX_PER_DAY

SESSIONS = [
    ("ASIA", "亚洲 00:00–08:00 UTC", 0, 8),
    ("EURO", "欧洲 08:00–16:00 UTC", 8, 16),
    ("US", "美盘 16:00–24:00 UTC", 16, 24),
]
TEMPLATES = [("A", "R15-A 扫荡反转做多", R15.build_A),
             ("B", "R15-B FVG 回踩做多", R15.build_B),
             ("C", "R15-C 供给拒绝做空", R15.build_C)]
# 方向：A/B 做多（+1），C 做空（-1）。分组按方向合池：多头池 = A+B 信号，
# 空头池 = C 信号（与挖掘报告 §2.3“同日同时段同向”一字相同）。


def session_of(entry_t):
    h = datetime.fromtimestamp(entry_t, timezone.utc).hour
    if 0 <= h < 8:
        return "ASIA"
    if 8 <= h < 16:
        return "EURO"
    return "US"


def fav_atr(t):
    """峰值有利浮动（ATR 倍数）。与 35/36 轮诊断同口径：
    max_favour_usdt / (10,000 x ATR / 入场价)。"""
    if not t.get("atr"):
        return 0.0
    return (t.get("max_favour_usdt", 0.0) / NOTIONAL) / (t["atr"] / t["entry"])


def split_of(et):
    return ("前43d" if datetime.fromtimestamp(et, timezone.utc).date()
            < SPLIT_R35.date() else "后57d")


def group_key(entry_t, direction):
    """分组键：（UTC 日、时段、方向）。"""
    dt = datetime.fromtimestamp(entry_t, timezone.utc)
    return (dt.date(), session_of(entry_t), direction)


def label_signals_causal(pooled):
    """因果分组：pooled = [(entry_t, symbol, direction)]（已按入场时刻排序）。
    一个信号是多币组，当且仅当在它入场之前（含同一根入场根）已有另一个币
    在同一（UTC 日、时段、方向）里发出信号；否则为单币组。
    返回 {(entry_t, symbol): 'MULTI' | 'SINGLE'}。
    不读价格、不读未来信号：只用信号自身的入场时刻与方向。"""
    labels = {}
    seen_coins = defaultdict(set)  # group_key -> {coins already signaled}
    # 同一时刻的多信号按币名排序处理：同一根的信号彼此可见（同根收盘时
    # 同时已知），因此先把同根的所有信号记入，再统一打标。
    i = 0
    pooled = sorted(pooled, key=lambda x: (x[0], x[1]))
    while i < len(pooled):
        j = i
        while j < len(pooled) and pooled[j][0] == pooled[i][0]:
            j += 1
        batch = pooled[i:j]
        # 同根的信号彼此可见（同一根收盘时同时已知）：先把同根的币并入
        # 可见集再打标；同一币自己的另一模板信号不算“另一个币”。
        batch_coins = defaultdict(set)
        for entry_t, sym, direction in batch:
            batch_coins[group_key(entry_t, direction)].add(sym)
        for entry_t, sym, direction in batch:
            k = group_key(entry_t, direction)
            others = (seen_coins[k] | batch_coins[k]) - {sym}
            labels[(entry_t, sym)] = "MULTI" if others else "SINGLE"
        for entry_t, sym, direction in batch:
            seen_coins[group_key(entry_t, direction)].add(sym)
        i = j
    return labels


def _selftest_labels():
    """因果分组自测（合成例子，不读任何真实数据）：
    bucket (2026-08-10, ASIA, +1)：A币 00:00、B币 00:00（同根）、C币 00:15、
    A币 01:00；另一 bucket (2026-08-10, EURO, +1)：D币 08:00；
    再一 bucket (2026-08-11, ASIA, +1)：只有 A 币发两根（00:00、02:00，
    同一币自己的另一模板信号不算“另一个币”）。
    预期：A@00:00 与 B@00:00 同根彼此可见 → 都是 MULTI；C@00:15 MULTI；
    A@01:00 MULTI；D@08:00 SINGLE；08-11 的 A@00:00 与 A@02:00 都是 SINGLE。"""
    from datetime import datetime as _dt
    base = int(_dt(2026, 8, 10, tzinfo=timezone.utc).timestamp())
    day = 86400
    pooled = [
        (base + 0 * 900, "A_USDT", 1),
        (base + 0 * 900, "B_USDT", 1),
        (base + 1 * 900, "C_USDT", 1),
        (base + 4 * 900, "A_USDT", 1),
        (base + 32 * 900, "D_USDT", 1),  # 08:00，EURO 时段
        (base + day, "A_USDT", 1),  # 次日 00:00，只有 A 币
        (base + day + 7200, "A_USDT", 1),  # 次日 02:00，仍只有 A 币
    ]
    lb = label_signals_causal(pooled)
    assert lb[(base, "A_USDT")] == "MULTI", "同根 A 应为 MULTI"
    assert lb[(base, "B_USDT")] == "MULTI", "同根 B 应为 MULTI"
    assert lb[(base + 900, "C_USDT")] == "MULTI", "后发 C 应为 MULTI"
    assert lb[(base + 3600, "A_USDT")] == "MULTI", "01:00 的 A 应为 MULTI"
    assert lb[(base + 28800, "D_USDT")] == "SINGLE", "EURO 首币 D 应为 SINGLE"
    assert lb[(base + day, "A_USDT")] == "SINGLE", "次日首根 A 应为 SINGLE"
    assert lb[(base + day + 7200, "A_USDT")] == "SINGLE", "次日只有 A 币发过，应为 SINGLE"
    print("[因果分组自测 ✓] 同根互见、后发多币、单币、跨时段隔离均正确")


def cell_stats(fam, group, trades, bench):
    """一个模板 x 分组格子的全部上报数字。bench = 同模板全量对照臂的
    USDT 合计（净/毛利/成本），用于 R1 三项分解。"""
    n = len(trades)
    gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    cost = sum(t["cost_usdt"] for t in trades)
    net = sum(t["pnl"] for t in trades)
    per_coin_pct = {}
    for sym in SYMBOLS:
        st = [t for t in trades if t["symbol"] == sym]
        per_coin_pct[sym] = sum(t["pnl"] for t in st) / START_EQUITY
    coin_mean_pct = sum(per_coin_pct.values()) / len(SYMBOLS)
    half = {}
    for w in ("前43d", "后57d"):
        wt = [t for t in trades if split_of(t["entry_t"]) == w]
        wg = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in wt)
        wpc = {}
        for sym in SYMBOLS:
            st = [t for t in wt if t["symbol"] == sym]
            wpc[sym] = sum(t["pnl"] for t in st) / START_EQUITY
        half[w] = {
            "n": len(wt),
            "gross": wg,
            "gross_per_trade": (wg / len(wt)) if wt else None,
            "coin_mean_pct": sum(wpc.values()) / len(SYMBOLS),
            "net_usdt": sum(t["pnl"] for t in wt),
        }
    n1 = sum(1 for t in trades if fav_atr(t) >= 1.0 - 1e-9)
    n2 = sum(1 for t in trades if fav_atr(t) >= 2.0 - 1e-9)
    p1 = (n1 / n) if n else None
    p2_given_1 = (n2 / n1) if n1 else None
    d_net = net - bench["net"]
    d_gross = gross - bench["gross"]
    saved_cost = bench["cost"] - cost
    if abs(d_net - (d_gross + saved_cost)) > 0.01:
        raise AssertionError(f"R1 账目不对：{fam} {group} Δ净 {d_net} ≠ Δ毛利 {d_gross} + 省成本 {saved_cost}")
    saved_share = (saved_cost / d_net) if d_net > 0 else None
    c1 = coin_mean_pct > 0.02
    c2 = half["前43d"]["coin_mean_pct"] > 0 and half["后57d"]["coin_mean_pct"] > 0
    gpt = (gross / n) if n else None
    c3 = (gpt is not None and gpt > 25
          and half["前43d"]["gross_per_trade"] is not None and half["前43d"]["gross_per_trade"] > 25
          and half["后57d"]["gross_per_trade"] is not None and half["后57d"]["gross_per_trade"] > 25)
    c4 = (d_net > 0 and saved_share is not None and saved_share <= 0.80)
    return {
        "family": fam, "group": group, "n": n,
        "gross_usdt": round(gross, 2), "cost_usdt": round(cost, 2),
        "net_usdt": round(net, 2),
        "gross_per_trade": round(gpt, 2) if gpt is not None else None,
        "gross_cost_ratio": round(gross / cost, 4) if cost else None,
        "coin_mean_pct_full": round(coin_mean_pct, 4),
        "coin_mean_pct_front": round(half["前43d"]["coin_mean_pct"], 4),
        "coin_mean_pct_back": round(half["后57d"]["coin_mean_pct"], 4),
        "gross_per_trade_front": (round(half["前43d"]["gross_per_trade"], 2)
                                  if half["前43d"]["gross_per_trade"] is not None else None),
        "gross_per_trade_back": (round(half["后57d"]["gross_per_trade"], 2)
                                 if half["后57d"]["gross_per_trade"] is not None else None),
        "n_front": half["前43d"]["n"], "n_back": half["后57d"]["n"],
        "p_reach_1x": round(p1, 4) if p1 is not None else None,
        "p_reach_2x_given_1x": round(p2_given_1, 4) if p2_given_1 is not None else None,
        "n_reach_1x": n1, "n_reach_2x": n2,
        "r1_d_net": round(d_net, 2), "r1_d_gross": round(d_gross, 2),
        "r1_saved_cost": round(saved_cost, 2),
        "r1_saved_share": round(saved_share, 4) if saved_share is not None else None,
        "pass_c1_net_gt_2pct": c1, "pass_c2_both_halves_pos": c2,
        "pass_c3_gross_per_trade_gt_25": c3, "pass_c4_r1_le_80pct": c4,
        "pass_all": bool(c1 and c2 and c3 and c4),
    }


def build_1h_combined_new(symbols):
    """与 R15.build_1h_combined 同一合并规则（缓存 1h 去末根 + 15m 合成补 11-16 当天 24 根），
    仅两处改动（R15 原函数硬编码原 8 币 + 对 1h/15m 不一致零容忍，在新宇宙上跑不通）：
    (1) 遍历传入的新宇宙币种，不读 R15.SYMBOLS、不打印硬编码的 BTC_USDT；
    (2) 重叠段 1h/15m 不一致不再一票否决：改为逐币报告最大相对误差与超差根数，
    仅当某币最大相对误差 > 5%（灾难性错误，如序列错位、错币）才停。
    5% 门槛为跑前预注册：实测新宇宙最大不一致 MMT 约 0.7%（见报告 §0.5），
    5% 约为实测值的 7 倍，只拦灾难、不拦 tick 级口径差异。
    合并规则本身与 15/35/36 轮一字相同：builders 看到的仍是缓存 1h（Gate 官方 1h），
    11-16 当天 24 根来自 15m 合成（缓存末根 2026-11-16 00:00 是零成交量平值占位根，
    与 35/36 轮原 8 币数据里同一位置的占位根同一性质，见报告 §0.5）。"""
    R11 = R15.R11
    out = {}
    per_coin_err = {}
    for sym in symbols:
        cached = R11.load_bars(os.path.join(R15.DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        bars15 = R11.load_bars(os.path.join(R15.DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        synth = R11.synthesize(bars15, 4, 3600)
        cache_by_t = {b["t"]: b for b in cached}
        last_t = cached[-1]["t"]
        max_rel_err = 0.0
        n_over = 0
        for b in synth:
            if b["t"] in cache_by_t and b["t"] != last_t:
                c = cache_by_t[b["t"]]
                for k in ("o", "h", "l", "c"):
                    denom = abs(c[k]) if c[k] != 0 else 1.0
                    err = abs(b[k] - c[k]) / denom
                    if err > max_rel_err:
                        max_rel_err = err
                    if err > 1e-9:
                        n_over += 1
        extra = [b for b in synth if b["t"] >= last_t]
        assert len(extra) == 24, f"{sym} 合成 1h 补 11-16 应为 24 根，实际 {len(extra)}"
        assert extra[0]["t"] == last_t and extra[-1]["t"] == last_t + 23 * 3600
        combined = cached[:-1] + extra
        assert all(combined[i]["t"] < combined[i + 1]["t"] for i in range(len(combined) - 1))
        out[sym] = (combined, R11.atr_wilder(combined))
        per_coin_err[sym] = (max_rel_err, n_over)
        assert max_rel_err <= 0.05, f"{sym} 1h/15m 最大相对误差 {max_rel_err:.2%} > 5%，数据灾难性不一致，停止！"
    print("1h 合成校验（合并规则与 15/35/36 轮相同；末根占位根除外）：")
    for sym in symbols:
        err, n_over = per_coin_err[sym]
        print(f"  {sym.replace('_USDT', '')}: 重叠段最大相对误差 {err:.2e}，超 1e-9 的 (根，字段) {n_over} 个；"
              f"合并后 {len(out[sym][0])} 根 1h。")
    return out


def main():
    _selftest_labels()
    assert len(SYMBOLS) == 8, f"新宇宙应为 8 个币，实际 {len(SYMBOLS)}（取数未完成或名单未定死）"
    print("盈利策略迭代 · 第三十七轮：多币同发信号层面检验（全新币种宇宙验证）")
    print(f"新宇宙：{', '.join(s.replace('_USDT', '') for s in SYMBOLS)}")
    print("35 轮三模板信号 ×（UTC 日、时段、方向）因果分组：多币组 vs 单币组 vs 全量对照。")
    print("通过标准（四项全过才算）：(i) 全期币均 Taker 净 > +2%，(ii) 前后两半都为正，"
          "(iii) 每笔毛利 > 25 USDT 且两半都 > 25，(iv) R1 省成本占比 ≤ 80%。")

    # ---- 数据校验（与 35/36 轮同口径，窗口起点改为 2026-08-09）----
    data15 = {}
    for sym in SYMBOLS:
        bars = R35.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R35.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R35.group_days(bars, 96)
        assert len(days) == 100, f"{sym} 15m 完整日应为 100 天，实际 {len(days)}"
        assert len(bars) == 100 * 96, f"{sym} 15m 应为 {100*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15[SYMBOLS[0]][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 {SYMBOLS[0]} 不对齐"
    print("数据校验通过：8 币各 9,600 根 15m / 100 天；时间戳对齐、零缺口。")

    # 1h 合并：R15.build_1h_combined 硬编码原 8 币且对 1h/15m 不一致零容忍，
    # 在新宇宙上跑不通（MMT 61 处 tick 级不一致 + 打印硬编码 BTC_USDT）。
    # 改用本脚本的 build_1h_combined_new（合并规则一字相同，见函数注释），
    # R15.build_A/B/C 本身是纯函数（显式传参，不读 SYMBOLS），一字不改。
    data1h = build_1h_combined_new(SYMBOLS)
    days_all_15 = set(R35.group_days(data15[SYMBOLS[0]][0], 96).keys())
    front_43 = {d for d in days_all_15 if d < SPLIT_R35.date()}
    back_57 = {d for d in days_all_15 if d >= SPLIT_R35.date()}
    print(f"窗口：全 100d（前 {len(front_43)} 天 2026-08-09~09-20 / "
          f"后 {len(back_57)} 天 2026-09-21~11-16）。")

    windows = [("100d", None), ("前43d", front_43), ("后57d", back_57)]
    atr15 = {s: R35.atr_wilder(data15[s][0]) for s in SYMBOLS}
    idx_of_t = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in SYMBOLS}

    # ---- 主臂信号：与 35 轮 §5 / 36 轮一字相同（去 Killzone → 夜禁过滤 → 15m ATR）----
    R15.in_killzone = lambda t: True
    main_sig_raw = {}
    for fam, label, builder in TEMPLATES:
        sig = {}
        for sym in SYMBOLS:
            bars1h, a1h = data1h[sym]
            sig[sym], _fun = builder(data15[sym][0], bars1h, a1h)
        main_sig_raw[fam] = sig
        print(f"[主臂信号 {fam}] 去 Killzone 后信号数：8 币合计 {sum(len(v) for v in sig.values())}")

    main_sig, night_blocked, warmup_blocked = {}, {}, {}
    for fam, label, builder in TEMPLATES:
        ms, nb, wb = {}, {}, {}
        for sym in SYMBOLS:
            ms[sym], nb[sym], wb[sym] = {}, 0, 0
            for et, s in main_sig_raw[fam][sym].items():
                if R35._entry_in_no_new_window(et):
                    nb[sym] += 1
                    continue
                gi = idx_of_t[sym][et]
                a15 = atr15[sym][gi - 1] if gi - 1 >= 0 else None
                if a15 is None:
                    # 入场落在窗口最初 14 根 15m 内（2026-08-09 00:00–03:30），
                    # Wilder ATR(14) 尚未预热：无 ATR 就无法定 SL/TP。
                    # 不能用未来的 ATR（看未来），也不能编一个数，故跳过该信号并计数。
                    # 35/36 轮同一行是 assert（103 天窗口里没有信号落在这个区间，
                    # 故从未触发）；37 轮窗口起点不同，PIEVERSE-B 有 1 个信号落在这里，
                    # 改跳过+计数是唯一不看未来、不编数的处理。
                    wb[sym] += 1
                    continue
                ms[sym][et] = {"direction": s["direction"], "atr": a15,
                               "atr_basis": "15m", "tag": s.get("tag", "")}
        main_sig[fam] = ms
        night_blocked[fam] = nb
        warmup_blocked[fam] = wb
        print(f"[主臂信号 {fam}] 夜间禁单时段拦掉 {sum(nb.values())} 个信号；"
              f"ATR 未预热跳过 {sum(wb.values())} 个信号；"
              f"入场信号 {sum(len(v) for v in ms.values())} 个。")

    # ---- 因果分组：多头池 = A+B 信号，空头池 = C 信号；按入场时刻判定 ----
    # pooled 键：(entry_t, symbol, direction)。标签只用入场时刻之前
    # （含同一根）的信号，不读价格、不读未来信号。
    pooled_long, pooled_short = [], []
    for fam in ("A", "B"):
        for sym in SYMBOLS:
            for et, s in main_sig[fam][sym].items():
                pooled_long.append((et, sym, s["direction"]))
    for sym in SYMBOLS:
        for et, s in main_sig["C"][sym].items():
            pooled_short.append((et, sym, s["direction"]))
    assert all(d == 1 for _, _, d in pooled_long), "多头池方向应全为 +1"
    assert all(d == -1 for _, _, d in pooled_short), "空头池方向应全为 -1"
    labels_long = label_signals_causal(pooled_long)
    labels_short = label_signals_causal(pooled_short)
    labels = {}
    for fam in ("A", "B"):
        for sym in SYMBOLS:
            for et in main_sig[fam][sym]:
                labels[(fam, sym, et)] = labels_long[(et, sym)]
    for sym in SYMBOLS:
        for et in main_sig["C"][sym]:
            labels[("C", sym, et)] = labels_short[(et, sym)]
    # 分组完整性断言：每个信号恰好一个标签；多币+单币信号数 = 全量信号数
    for fam in ("A", "B", "C"):
        tot = sum(len(main_sig[fam][s]) for s in SYMBOLS)
        nm = sum(1 for (f, s, et), lb in labels.items() if f == fam and lb == "MULTI")
        ns = sum(1 for (f, s, et), lb in labels.items() if f == fam and lb == "SINGLE")
        assert nm + ns == tot, f"分组信号数不对：{fam} 多币 {nm} + 单币 {ns} ≠ 全量 {tot}"
        print(f"[因果分组 {fam}] 全量信号 {tot} 个 → 多币组 {nm} 个 / 单币组 {ns} 个")

    group_sig = {}
    for fam, label, builder in TEMPLATES:
        group_sig[fam] = {}
        for gname in ("MULTI", "SINGLE"):
            gs = {}
            for sym in SYMBOLS:
                gs[sym] = {et: s for et, s in main_sig[fam][sym].items()
                           if labels[(fam, sym, et)] == gname}
            group_sig[fam][gname] = gs

    # ---- 模拟：对照臂（全量）+ 多币臂 + 单币臂 ----
    all_results, all_trades = [], []
    arm_trades = {}   # (arm, fam) -> trades

    def run_arm(arm, sig_by_fam):
        for fam, label, builder in TEMPLATES:
            fam_trades = []
            skip_tot = Counter()
            for sym in SYMBOLS:
                bars, funding = data15[sym]
                trades, curve, stats = R35.simulate_stream(
                    sym, bars, sig_by_fam[fam][sym], funding, MAX_PER_DAY,
                    f"R37-{arm}-{fam}")
                fam_trades.extend(trades)
                skip_tot.update(stats)
            fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
            arm_trades[(arm, fam)] = fam_trades
            print(f"[{arm} {fam}] 全期 n={len(fam_trades)}；跳过信号：持仓中 {skip_tot['skip_open']} / "
                  f"满2笔 {skip_tot['skip_cap']} / 熔断 {skip_tot['skip_breaker']}")
            for sym in SYMBOLS:
                st = [t for t in fam_trades if t["symbol"] == sym]
                for wname, _ in windows:
                    wt = [t for t in st if wname == "100d" or split_of(t["entry_t"]) == wname]
                    wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                    eq = START_EQUITY
                    wcurve = [eq]
                    for t in wt_sorted:
                        eq += t["pnl"]
                        wcurve.append(eq)
                    res = R35.summarize(sym, wt_sorted, wcurve,
                                        f"R37-{arm}-{fam}", len(sig_by_fam[fam][sym]))
                    res["arm"] = arm
                    res["family"] = fam
                    res["template"] = fam
                    res["variant"] = f"R37-{arm}"
                    res["granularity"] = "15m"
                    res["atr_basis"] = "15m"
                    res["split"] = wname
                    res["days"] = 100 if wname == "100d" else (43 if wname == "前43d" else 57)
                    res["signals_total"] = len(sig_by_fam[fam][sym])
                    res["signals_blocked_night"] = night_blocked[fam][sym]
                    res["signals_blocked_warmup"] = warmup_blocked[fam][sym]
                    res["group"] = arm
                    all_results.append(res)
            for t in fam_trades:
                t2 = dict(t)
                t2["arm"] = arm
                t2["family"] = fam
                t2["template"] = fam
                t2["variant"] = f"R37-{arm}"
                t2["granularity"] = "15m"
                t2["atr_basis"] = "15m"
                t2["split"] = split_of(t["entry_t"])
                t2["entry_hour_utc"] = R35.entry_hour_utc(t["entry_t"])
                t2["session"] = session_of(t["entry_t"])
                t2["group"] = labels[(fam, t["symbol"], t["entry_t"])]
                all_trades.append(t2)

    print("\n=== 对照臂：全量（= 35 轮主臂口径，新宇宙复算）===")
    run_arm("FULL", main_sig)
    print("\n=== 分组臂 ===")
    for gname in ("MULTI", "SINGLE"):
        print(f"--- {gname} ---")
        run_arm(gname, {fam: group_sig[fam][gname] for fam, _, _ in TEMPLATES})

    # ---- 格子统计：3 模板 ×（多币/单币）格子，基准 = 同模板全量臂 ----
    print("\n=== 格子统计（每模板 × 每组）===")
    cells = []
    for fam, label, builder in TEMPLATES:
        ftr = arm_trades[("FULL", fam)]
        bench = {"net": sum(t["pnl"] for t in ftr),
                 "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ftr),
                 "cost": sum(t["cost_usdt"] for t in ftr)}
        print(f"  [基准 FULL {fam}] n={len(ftr)} 毛利 {bench['gross']:+.2f} "
              f"成本 {bench['cost']:.2f} 净 {bench['net']:+.2f}")
        for gname in ("MULTI", "SINGLE"):
            st = arm_trades[(gname, fam)]
            c = cell_stats(fam, gname, st, bench)
            cells.append(c)
            print(f"  [{fam} {gname}] n={c['n']}（前 {c['n_front']} / 后 {c['n_back']}）"
                  f"币均 Taker 全 {c['coin_mean_pct_full']*100:+.2f}% / 前 {c['coin_mean_pct_front']*100:+.2f}% / "
                  f"后 {c['coin_mean_pct_back']*100:+.2f}% | 每笔毛利 {c['gross_per_trade']} "
                  f"（前 {c['gross_per_trade_front']} / 后 {c['gross_per_trade_back']}）"
                  f"毛利/成本 {c['gross_cost_ratio']} | P(1x)={c['p_reach_1x']} "
                  f"P(2x|1x)={c['p_reach_2x_given_1x']} | R1 Δ净 {c['r1_d_net']:+.0f} "
                  f"Δ毛利 {c['r1_d_gross']:+.0f} 省成本 {c['r1_saved_cost']:+.0f} "
                  f"占比 {c['r1_saved_share'] if c['r1_saved_share'] is not None else '—'} | "
                  f"四项 {'✓ 全过' if c['pass_all'] else '✗ 不过'} "
                  f"(i){'✓' if c['pass_c1_net_gt_2pct'] else '✗'} "
                  f"(ii){'✓' if c['pass_c2_both_halves_pos'] else '✗'} "
                  f"(iii){'✓' if c['pass_c3_gross_per_trade_gt_25'] else '✗'} "
                  f"(iv){'✓' if c['pass_c4_r1_le_80pct'] else '✗'}")

    # ---- 诊断：出场原因、跨夜、激活 ----
    print("\n=== 诊断 ===")
    for arm in ["FULL", "MULTI", "SINGLE"]:
        for fam in ["A", "B", "C"]:
            at = arm_trades[(arm, fam)]
            rc = Counter(t["reason"] for t in at)
            ovn = [t for t in at
                   if datetime.fromtimestamp(t["exit_t"], timezone.utc).date()
                   > datetime.fromtimestamp(t["entry_t"], timezone.utc).date()]
            act = [t for t in at if t.get("trail_active")]
            if at:
                print(f"  [{arm} {fam}] 出场：{dict(sorted(rc.items()))}（共 {len(at)} 笔）；"
                      f"激活 {len(act)}/{len(at)}（{len(act)/len(at)*100:.1f}%）；"
                      f"跨夜 {len(ovn)} 笔净 {sum(t['pnl'] for t in ovn):+.0f}；"
                      f"资金费 {sum(t['funding_cost_usdt'] for t in at):+.2f}")
            else:
                print(f"  [{arm} {fam}] 0 笔")

    # ---- 首笔人工核对（触发链、入场小时、止损/盈亏）----
    print("\n=== 首笔人工核对（全量臂每模板首笔）===")
    for fam in ["A", "B", "C"]:
        at = sorted(arm_trades[("FULL", fam)], key=lambda t: t["entry_t"])
        if not at:
            print(f"  [{fam}] 全量臂 0 笔")
            continue
        t = at[0]
        grp = labels[(fam, t["symbol"], t["entry_t"])]
        print(f"  [{fam}] 首笔 {t['symbol']} {'做多' if t['direction'] == 1 else '做空'} "
              f"入场 {datetime.fromtimestamp(t['entry_t'], timezone.utc).isoformat()} "
              f"价 {t['entry']} ATR {t['atr']:.4g} 出场 "
              f"{datetime.fromtimestamp(t['exit_t'], timezone.utc).isoformat()} 价 {t['exit']} "
              f"原因 {t['reason']} 净 {t['pnl']:+.2f} 组 {grp}")

    # ---- 账目核对 ----
    print("\n=== 账目核对 ===")
    for arm in ["FULL", "MULTI", "SINGLE"]:
        for fam in ["A", "B", "C"]:
            ts = arm_trades[(arm, fam)]
            cost = sum(t["cost_usdt"] for t in ts)
            gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ts)
            net = sum(t["pnl"] for t in ts)
            assert abs(cost - len(ts) * 25.0) < 0.01, f"账目不对：{arm} {fam} 成本 {cost} ≠ 笔数x25"
            assert abs(gross - cost - net) < 0.01, f"账目不对：{arm} {fam} 毛利-成本≠净"
            print(f"  [{arm} {fam}] 笔数 {len(ts)} x 25 = {len(ts)*25:.0f} = 成本合计 {cost:.2f} ✓；"
                  f"毛利 {gross:+.2f} − 成本 {cost:.2f} = 净 {net:+.2f} ✓")

    # ---- 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round37_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round37_cells.json"), "w") as f:
        json.dump(cells, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round37_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "template", "variant", "atr_basis", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "session", "group", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min", "peak", "trail_active",
                    "max_favour_usdt", "atr"])
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["family"], x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["template"], t["variant"], t.get("atr_basis", ""),
                        t["granularity"], t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"], t["session"], t["group"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"], t.get("peak"), t.get("trail_active"),
                        round(t.get("max_favour_usdt", 0.0), 2), t.get("atr")])
    print(f"\n汇总已写入：data/gate_iter_round37_summary.json ({len(all_results)} 条)")
    print(f"格子已写入：data/gate_iter_round37_cells.json ({len(cells)} 个格子)")
    print(f"明细已写入：data/gate_iter_round37_trades.csv ({len(all_trades)} 笔)")

    print("\n=== 最终判定（多币同发信号层面检验，四项全过才算）===")
    n_pass = sum(1 for c in cells if c["group"] == "MULTI" and c["pass_all"])
    for c in cells:
        print(f"  {c['family']}–{c['group']}：{'通过' if c['pass_all'] else '不通过'}"
              f"（币均 Taker {c['coin_mean_pct_full']*100:+.2f}%，"
              f"每笔毛利 {c['gross_per_trade']}，R1 省成本占比 "
              f"{c['r1_saved_share'] if c['r1_saved_share'] is not None else '—'}）")
    if n_pass == 0:
        print("  没有一个模板的多币组四项全过 → 多币同发证伪：不进判断层作加权。")
    else:
        print(f"  {n_pass} 个模板的多币组四项全过 → 仍只是一轮验证通过：按 R2 它已经"
              "用掉了全新宇宙的唯一一次检验机会，不得再在另一批新币上重复验证同一发现。")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
