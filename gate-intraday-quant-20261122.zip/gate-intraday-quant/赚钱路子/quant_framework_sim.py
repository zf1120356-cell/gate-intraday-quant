#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
量化主线 · 模拟盘框架（只做模拟，不交易、不开户、不碰真钱）
数据：OKX 公开免费接口（资金费率历史 + 4H K线），无需 API Key
用法：python3 quant_framework_sim.py
输出：资金费率套利统计 + 双均线趋势纸上回测 + 爆仓率统计
注意：Binance fapi 在本机返回 451（受限地区），Bybit 返回 403，
      故默认数据源为 OKX；如 OKX 不可达，脚本会如实报错退出，不编数字。
"""
import json, time, datetime, statistics, sys
import requests

TZ = datetime.timezone(datetime.timedelta(hours=8))
BASE = "https://www.okx.com/api/v5"
HDRS = {"User-Agent": "Mozilla/5.0"}

def fmt(ms):
    return datetime.datetime.fromtimestamp(ms / 1000, TZ).strftime("%Y-%m-%d %H:%M")

def fetch_funding(inst, target_days=100):
    """OKX 资金费率历史：分页用 after=最老 fundingTime（倒序返回）。"""
    rows, after = [], None
    for _ in range(10):
        p = {"instId": inst, "limit": "100"}
        if after:
            p["after"] = str(after)
        r = requests.get(f"{BASE}/public/funding-rate-history", params=p, headers=HDRS, timeout=20)
        j = r.json()
        assert j.get("code") == "0", f"OKX funding error: {j}"
        d = j.get("data", [])
        if not d:
            break
        rows.extend(d)
        after = int(d[-1]["fundingTime"])
        if (int(rows[0]["fundingTime"]) - after) / 1000 / 86400 >= target_days:
            break
        time.sleep(0.2)
    ded = {x["fundingTime"]: x for x in rows}
    return sorted(ded.values(), key=lambda x: int(x["fundingTime"]))

def fetch_candles(inst, bar="4H", target_days=180):
    rows, after = [], None
    for _ in range(10):
        p = {"instId": inst, "bar": bar, "limit": "300"}
        if after:
            p["after"] = str(after)
        r = requests.get(f"{BASE}/market/candles", params=p, headers=HDRS, timeout=20)
        j = r.json()
        assert j.get("code") == "0", f"OKX candles error: {j}"
        d = j.get("data", [])
        if not d:
            break
        rows.extend(d)
        after = int(d[-1][0])
        if (int(rows[0][0]) - after) / 1000 / 86400 >= target_days:
            break
        time.sleep(0.2)
    ded = {x[0]: x for x in rows}
    return sorted(ded.values(), key=lambda x: int(x[0]))

def liquidation_distance(leverage, maintenance=0.005):
    """逐仓近似强平距离（价格反向波动幅度），忽略维持保证金则为 1/L。
    返回：反向走多少 % 会强平。例 20x -> 约 4.5%（扣 0.5% 维持保证金后）。"""
    return 1.0 / leverage - maintenance

def funding_stats(rates):
    n = len(rates)
    mean = sum(rates) / n
    cum, c, peak, maxdd = [], 0.0, None, 0.0
    for x in rates:
        c += x
        cum.append(c)
        peak = c if peak is None else max(peak, c)
        maxdd = max(maxdd, peak - c)
    return {
        "n": n, "mean": mean, "median": statistics.median(rates),
        "pos": sum(1 for x in rates if x > 0), "neg": sum(1 for x in rates if x < 0),
        "sum": sum(rates), "gross_apy_1x": mean * 1095, "maxdd_1x": maxdd,
    }

def ma(vals, n):
    out, s = [None] * len(vals), 0.0
    for i, v in enumerate(vals):
        s += v
        if i >= n:
            s -= vals[i - n]
        if i >= n - 1:
            out[i] = s / n
    return out

def trend_backtest(candles, fast=10, slow=30, fee_rt=0.0020):
    """双均线 4H：信号在收盘确认，下一根 K 线开盘成交；多空双向翻仓，无硬止损。"""
    data = [(int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4])) for r in candles]
    closes = [d[4] for d in data]
    maf, mas = ma(closes, fast), ma(closes, slow)
    trades, pos = [], None
    for i in range(len(data)):
        if maf[i] is None or mas[i] is None:
            continue
        sig = 1 if maf[i] > mas[i] else -1
        if pos is None:
            if i + 1 < len(data):
                pos = {"dir": sig, "entry_idx": i + 1, "entry_price": data[i + 1][1], "entry_time": data[i + 1][0]}
        elif sig != pos["dir"]:
            if i + 1 >= len(data):
                break
            pos.update({"exit_idx": i + 1, "exit_price": data[i + 1][1], "exit_time": data[i + 1][0]})
            g = (pos["exit_price"] - pos["entry_price"]) / pos["entry_price"] if pos["dir"] == 1 else (pos["entry_price"] - pos["exit_price"]) / pos["entry_price"]
            pos["gross"], pos["net"] = g, g - fee_rt
            pos["hold_days"] = (pos["exit_idx"] - pos["entry_idx"]) * 4 / 24
            rng = range(pos["entry_idx"], pos["exit_idx"] + 1)
            pos["max_adv"] = ((pos["entry_price"] - min(data[k][3] for k in rng)) / pos["entry_price"] if pos["dir"] == 1
                              else (max(data[k][2] for k in rng) - pos["entry_price"]) / pos["entry_price"])
            trades.append(pos)
            pos = {"dir": sig, "entry_idx": i + 1, "entry_price": data[i + 1][1], "entry_time": data[i + 1][0]}
    if pos is not None:  # 期末按最后一根收盘平仓
        pos.update({"exit_idx": len(data) - 1, "exit_price": data[-1][4], "exit_time": data[-1][0]})
        g = (pos["exit_price"] - pos["entry_price"]) / pos["entry_price"] if pos["dir"] == 1 else (pos["entry_price"] - pos["exit_price"]) / pos["entry_price"]
        pos["gross"], pos["net"] = g, g - fee_rt
        pos["hold_days"] = (pos["exit_idx"] - pos["entry_idx"]) * 4 / 24
        rng = range(pos["entry_idx"], pos["exit_idx"] + 1)
        pos["max_adv"] = ((pos["entry_price"] - min(data[k][3] for k in rng)) / pos["entry_price"] if pos["dir"] == 1
                          else (max(data[k][2] for k in rng) - pos["entry_price"]) / pos["entry_price"])
        trades.append(pos)
    return data, trades

def main():
    print(f"取数时间（北京时间）：{datetime.datetime.now(TZ).strftime('%Y-%m-%d %H:%M')}  数据源：OKX 公开接口")
    print(f"强平距离（扣 0.5% 维持保证金）：3x={liquidation_distance(3)*100:.1f}%  5x={liquidation_distance(5)*100:.1f}%  20x={liquidation_distance(20)*100:.1f}%  50x={liquidation_distance(50)*100:.1f}%  100x={liquidation_distance(100)*100:.1f}%")
    all_trades = []
    for inst, sym in [("BTC-USDT-SWAP", "BTCUSDT"), ("ETH-USDT-SWAP", "ETHUSDT")]:
        rows = fetch_funding(inst)
        rates = [float(r["fundingRate"]) for r in rows]
        s = funding_stats(rates)
        print(f"\n[{sym} 资金费率] {fmt(int(rows[0]['fundingTime']))} ~ {fmt(int(rows[-1]['fundingTime']))} n={s['n']} "
              f"均值={s['mean']*100:.4f}%/期 正={s['pos']} 负={s['neg']} 毛年化1x={s['gross_apy_1x']*100:.2f}% 最大回撤1x={s['maxdd_1x']*100:.3f}%")
        candles = fetch_candles(inst, target_days=180)
        # 截取最近 180 天做趋势回测
        start_ms = int(datetime.datetime(2026, 5, 21, tzinfo=TZ).timestamp() * 1000)
        candles = [c for c in candles if int(c[0]) >= start_ms]
        data, trades = trend_backtest(candles)
        all_trades += trades
        for lev in (3, 5, 20):
            liq = [t for t in trades if t["max_adv"] >= 1 / lev]
            print(f"[{sym} 趋势 MA10/30] 交易={len(trades)}笔 胜率={sum(1 for t in trades if t['net']>0)/len(trades)*100:.1f}% "
                  f"{lev}x爆仓={len(liq)}/{len(trades)} ({len(liq)/len(trades)*100:.1f}%)")
    for lev in (20, 50, 100):
        liq = [t for t in all_trades if t["max_adv"] >= 1 / lev]
        print(f"[汇总] {lev}x 爆仓 {len(liq)}/{len(all_trades)} = {len(liq)/len(all_trades)*100:.1f}%")
    print("\n模拟结束：本脚本不下单、不开户、不碰真钱。")

if __name__ == "__main__":
    main()
