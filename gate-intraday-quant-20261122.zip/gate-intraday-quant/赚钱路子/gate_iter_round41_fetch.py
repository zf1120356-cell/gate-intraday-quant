#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第四十一轮取数：SQZ 新信号的新宇宙 1h/15m/资金费（Gate 公开接口）。
只做取数与选择记录，不跑回测。

宇宙（跑前定死；见 分系统下一代信号设计.md §4.1；名单与快照核对见本脚本）：
  BCH、PUMP、APT、ICP、AAVE、ONDO、JCT、PIPPIN；第一替补 TRX。
  排除集 32 个已回测币（旧 20 + 37 轮新 8 + 38 轮另 4 KERNEL/CYBER/ENA/INJ），
  不是任务书一度写的 28 个（设计文档 §4.1 已纠正，38 轮 S1 的 4 个新币漏计）。
  快照：data/gate_tickers_2026-11-21_0227UTC.json（2026-11-21 02:27 UTC，
  1,037 个合约，按 volume_24h_quote 降序；本脚本只核对、不重选）。
取数窗口（设计 §4.1）：
  15m：2026-08-09~2026-11-16（100 天，9,600 根），与 37/40 轮同窗口；
  Gate 15m 只提供最近 10,000 根回溯，取数时 08-09 距今约 9,996 根，
  边界极紧——先探针（BCH 首段），08-09 取不到则全宇宙统一顺延至
  08-10（99 天，9,504 根）或 08-11，绝不出现各币窗口不一致；
  若顺延，半段切分点取窗口中点（设计 §4.1），并在选择文件与报告里写明。
  1h：2025-11-16~2026-11-16（8,761 根）；资金费：2026-08-01 起。
筛查（设计 §4.1；任一币不通过则按排名顺延替补 TRX，不事后挑币）：
  (1) 快照价差 <= 0.07%；(2) 1h 首周（2025-11-16~11-23）>= 160 根；
  (3) 全量复核：1h 8,761 根连续、15m 自实际起点连续且时间戳与 BTC 对齐段一致。
取数方法照抄第三十七轮 fetch（15m/1h/资金费）。

运行：python3 gate_iter_round41_fetch.py（联网拉 Gate 公开接口）
输出：data/gate_1h_365d_{币}.csv、data/gate_15m_103d_{币}.csv、
      data/gate_funding_365d_{币}.json、data/gate_iter_round41_selection.json
"""
import csv
import json
import os
import time
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
BASE = "https://api.gateio.ws/api/v4"
SNAPSHOT = os.path.join(DATA_DIR, "gate_tickers_2026-11-21_0227UTC.json")

SYMBOLS = ["BCH_USDT", "PUMP_USDT", "APT_USDT", "ICP_USDT",
           "AAVE_USDT", "ONDO_USDT", "JCT_USDT", "PIPPIN_USDT"]
SUBSTITUTE = "TRX_USDT"
# 32 个已回测币（设计 §4.1）：旧 20 + 37 轮新 8 + 38 轮另 4
EXCLUDED_32 = {
    "BTC_USDT", "ETH_USDT", "SOL_USDT", "DOGE_USDT", "LINK_USDT",
    "XRP_USDT", "BNB_USDT", "ADA_USDT", "ZEC_USDT", "EVAA_USDT",
    "HYPE_USDT", "LTC_USDT", "BLESS_USDT", "XLM_USDT", "AKE_USDT",
    "NEAR_USDT", "PEPE_USDT", "UNI_USDT", "SUI_USDT", "XAUT_USDT",
    "MMT_USDT", "WLD_USDT", "PIEVERSE_USDT", "AVAX_USDT", "PAXG_USDT",
    "ARB_USDT", "FIL_USDT", "TAO_USDT",
    "KERNEL_USDT", "CYBER_USDT", "ENA_USDT", "INJ_USDT",
}
SPREAD_MAX = 0.0007
FIRST_WEEK_MIN_BARS = 160

START_1H = datetime(2025, 11, 16, tzinfo=timezone.utc)
END_1H = datetime(2026, 11, 16, tzinfo=timezone.utc)
START_15M_CANDIDATES = [datetime(2026, 8, 9, tzinfo=timezone.utc),
                         datetime(2026, 8, 10, tzinfo=timezone.utc),
                         datetime(2026, 8, 11, tzinfo=timezone.utc)]
END_15M = datetime(2026, 11, 17, tzinfo=timezone.utc)
FUNDING_START = datetime(2026, 8, 1, tzinfo=timezone.utc)
FIRST_WEEK_END = datetime(2025, 11, 23, tzinfo=timezone.utc)


def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "gate-r41-fetch/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles(contract, interval, start, end, path):
    bars = []
    cur = start
    while cur < end:
        nxt = min(cur + timedelta(days=7), end)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval={interval}"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    if interval == "15m":
        bars = [b for b in bars
                if int(start.timestamp()) <= b["t"] < int(end.timestamp())]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] {interval} 已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}", flush=True)
    return bars


def fetch_candles_15m_first_chunk(contract, start):
    """探针：只取 15m 首段（7 天），判断 08-09 起点是否还在 10,000 根回溯内。
    返回 True（可取）/ False（HTTP 400，滑出边界）。"""
    nxt = start + timedelta(days=7)
    url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=15m"
           f"&from={int(start.timestamp())}&to={int(nxt.timestamp())}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "gate-r41-fetch/1.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
        return len(data) > 0
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode()[:160]
        except Exception:
            pass
        print(f"[探针 {contract}] 15m 起点 {start.date()} 取数失败（{e.code}）：{body}",
              flush=True)
        return False


def fetch_funding(contract):
    """资金费：7 天一 chunk（不要 30 天）。
    实测教训（2026-11-21）：Gate funding_rate 每调用最多返回 100 条、
    按时间倒序截断，且部分币种每 8h 结算点有 2 条记录——30 天 chunk
    （约 180 条）会被截成最近 100 条（约 17 天），造成 08-30~09-13、
    09-29~10-13 两段约 14 天的缺口（PUMP/ONDO/JCT/PIPPIN 首轮即如此，
    各缺 121 个结算点；BCH/APT/ICP/AAVE 每结算点 1 条记录，30 天 chunk
    未超限故完整）。7 天 chunk 每调用约 42 条，远低于上限，无截断。
    资金费合计可忽略（约 0.1 USDT/笔），但缺口是取数 bug 不是数据缺失，
    必须修好重取，不许将缺失按 0 计了事。"""
    path = os.path.join(DATA_DIR, f"gate_funding_365d_{contract}.json")
    out = {}
    cur = FUNDING_START
    while cur < END_1H:
        nxt = min(cur + timedelta(days=7), END_1H)
        url = (f"{BASE}/futures/usdt/funding_rate?contract={contract}&limit=100"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            t = int(d["t"])
            t = (t // 28800) * 28800
            out[t] = float(d["r"])
        cur = nxt
        time.sleep(0.3)
    with open(path, "w") as f:
        json.dump(out, f)
    print(f"[{contract}] 资金费率已取：{len(out)} 条", flush=True)
    return out


def first_week_bars(contract):
    url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=1h"
           f"&from={int(START_1H.timestamp())}&to={int(FIRST_WEEK_END.timestamp())}")
    data = http_get(url)
    return len(data)


def check_continuity_1h(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    ts = [int(r["t"]) for r in rows]
    ok = (len(ts) == 8761 and ts[0] == int(START_1H.timestamp())
          and ts[-1] == int(END_1H.timestamp())
          and all(ts[i + 1] - ts[i] == 3600 for i in range(len(ts) - 1)))
    return ok, len(ts), ts[0] if ts else None, ts[-1] if ts else None


def file_bar_count(path):
    if not os.path.exists(path):
        return 0
    with open(path, newline="") as f:
        return sum(1 for _ in f) - 1


def check_continuity_15m(path, base_ts, start):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    ts = [int(r["t"]) for r in rows]
    base_seg = [t for t in base_ts if t >= int(start.timestamp())]
    ok = (len(ts) == len(base_seg) and ts == base_seg)
    return ok, len(ts), len(base_seg)


def fetch_one_coin_15m(sym, start):
    p15 = os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv")
    return fetch_candles(sym, "15m", start, END_15M, p15)


def fetch_one_coin_rest(sym):
    """1h + 资金费（无 10,000 根边界风险；已有合规缓存的跳过）。"""
    p1h = os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv")
    pf = os.path.join(DATA_DIR, f"gate_funding_365d_{sym}.json")
    if file_bar_count(p1h) != 8761:
        fetch_candles(sym, "1h", START_1H, END_1H, p1h)
    else:
        print(f"[{sym}] 1h 用缓存（8,761 根）", flush=True)
    if not os.path.exists(pf):
        fetch_funding(sym)
    else:
        print(f"[{sym}] 资金费率用缓存", flush=True)


def main():
    # ---- 快照核对（只核对、不重选；设计 §4.1 的名单与排名/成交额/价差）----
    with open(SNAPSHOT) as f:
        tickers = json.load(f)
    rows = []
    for t in tickers:
        try:
            vol = float(t["volume_24h_quote"])
            bid = float(t["highest_bid"]); ask = float(t["lowest_ask"])
        except (KeyError, TypeError, ValueError):
            continue
        mid = (bid + ask) / 2
        spread = (ask - bid) / mid if mid else 9.99
        rows.append({"contract": t["contract"], "vol": vol, "spread": spread})
    rows.sort(key=lambda r: -r["vol"])
    rank_of = {r["contract"]: (i + 1, r) for i, r in enumerate(rows)}
    snap_check = {}
    for sym in SYMBOLS + [SUBSTITUTE]:
        assert sym in rank_of, f"快照里没有 {sym}"
        rk, r = rank_of[sym]
        assert sym not in EXCLUDED_32, f"{sym} 在 32 币排除集里，不应入选"
        assert r["spread"] <= SPREAD_MAX, f"{sym} 价差 {r['spread']*100:.4f}% > 0.07%"
        snap_check[sym] = {"rank": rk, "vol_24h_quote_usdt": r["vol"],
                           "spread_pct": round(r["spread"] * 100, 4)}
        print(f"[快照核对] #{rk} {sym} 成交额 {r['vol']:,.0f} 价差 {r['spread']*100:.4f}% ✓",
              flush=True)

    # BTC 的 15m 时间戳作对齐基准
    with open(os.path.join(DATA_DIR, "gate_15m_103d_BTC_USDT.csv"), newline="") as f:
        base_ts = [int(r["t"]) for r in csv.DictReader(f)]
    assert len(base_ts) == 9888, f"BTC 15m 基准应为 9888 根，实际 {len(base_ts)}"

    # ---- 1h 首周筛查（先筛后取；JCT 是 2025-11-10 上币，重点看）----
    fw = {}
    for sym in SYMBOLS + [SUBSTITUTE]:
        n_fw = first_week_bars(sym)
        fw[sym] = n_fw
        print(f"[1h 首周] {sym}：{n_fw} 根（须 >= 160）", flush=True)

    # ---- 15m 起点探针 + 并行取数（起点统一：任一币 400 则全宇宙顺延）----
    start15 = None
    for cand in START_15M_CANDIDATES:
        if fetch_candles_15m_first_chunk(SYMBOLS[0], cand):
            start15 = cand
            print(f"[15m 起点] {cand.date()} 探针通过，全宇宙统一用该起点", flush=True)
            break
        print(f"[15m 起点] {cand.date()} 探针失败，顺延下一候选起点", flush=True)
    assert start15 is not None, "15m 三个候选起点全部取数失败"

    selection = {
        "fetch_time_utc": datetime.now(timezone.utc).isoformat(),
        "source": "data/gate_tickers_2026-11-21_0227UTC.json（2026-11-21 02:27 UTC，1,037 个合约）",
        "rule": ("宇宙跑前定死（设计 §4.1）：BCH/PUMP/APT/ICP/AAVE/ONDO/JCT/PIPPIN，"
                 "替补 TRX；排除 32 个已回测币（旧 20 + 37 轮新 8 + 38 轮另 4）；"
                 "spread<=0.07%；1h首周>=160根；全量复核1h 8761根连续、15m自实际起点连续且与BTC对齐；"
                 "15m窗口起点以实际为准（08-09 优先，400 则统一顺延，绝不各币不一致）；"
                 "半段切分点：窗口 08-09~11-16 时为 2026-09-21（与 37/40 轮同），顺延时取窗口中点"),
        "snapshot_check": snap_check,
        "first_week_1h": fw,
        "start_15m": start15.date().isoformat(),
        "skipped": [],
        "selected": [],
    }

    # 15m 并行取数（8 币同时发首段请求，漂移 < 2 根，避免顺序取数滑出 10,000 根边界）
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(fetch_one_coin_15m, sym, start15): sym for sym in SYMBOLS}
        for fut in futs:
            fut.result()  # 任一失败即抛错，整个起点作废
    # 1h + 资金费并行取数
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(fetch_one_coin_rest, sym): sym for sym in SYMBOLS}
        for fut in futs:
            fut.result()

    selected = []
    for sym in SYMBOLS:
        p1h = os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv")
        p15 = os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv")
        entry = {"symbol": sym, "rank": snap_check[sym]["rank"],
                 "vol_24h_quote_usdt": snap_check[sym]["vol_24h_quote_usdt"],
                 "spread_pct": snap_check[sym]["spread_pct"],
                 "first_week_1h": fw[sym]}
        if fw[sym] < FIRST_WEEK_MIN_BARS:
            entry["reason"] = f"1h首周仅 {fw[sym]} 根 < 160 根（365天历史不足）"
            selection["skipped"].append(entry)
            print(f"{sym} 跳过：{entry['reason']}", flush=True)
            continue
        ok1, n1, t0, t1 = check_continuity_1h(p1h)
        ok15, n15, n15_exp = check_continuity_15m(p15, base_ts, start15)
        if not ok1:
            entry["reason"] = f"1h全量复核不通过：{n1} 根（应 8761），首 {t0} 末 {t1}"
            selection["skipped"].append(entry)
            print(f"{sym} 跳过：{entry['reason']}", flush=True)
            continue
        if not ok15:
            entry["reason"] = (f"15m全量复核不通过：{n15} 根（应 {n15_exp}，"
                               f"起点 {start15.date()}，与BTC不对齐）")
            selection["skipped"].append(entry)
            print(f"{sym} 跳过：{entry['reason']}", flush=True)
            continue
        entry["reason"] = "入选"
        entry["start_15m"] = start15.date().isoformat()
        entry["bars_15m"] = n15
        entry["bars_1h"] = n1
        selection["selected"].append(entry)
        selected.append(sym)
        print(f"{sym} 入选（15m 起点 {start15.date()}，{n15} 根；1h {n1} 根）", flush=True)

    # 替补：任一币不通过则取 TRX（同流程；本脚本只在需要时取）
    if len(selected) < 8:
        print(f"只有 {len(selected)} 个入选，启动替补 {SUBSTITUTE}（同流程）", flush=True)
        n_fw = fw[SUBSTITUTE]
        if n_fw < FIRST_WEEK_MIN_BARS:
            raise RuntimeError(f"替补 {SUBSTITUTE} 1h首周仅 {n_fw} 根 < 160，无更多替补，停止")
        fetch_one_coin_15m(SUBSTITUTE, start15)
        fetch_one_coin_rest(SUBSTITUTE)
        p1h = os.path.join(DATA_DIR, f"gate_1h_365d_{SUBSTITUTE}.csv")
        p15 = os.path.join(DATA_DIR, f"gate_15m_103d_{SUBSTITUTE}.csv")
        ok1, n1, t0, t1 = check_continuity_1h(p1h)
        ok15, n15, n15_exp = check_continuity_15m(p15, base_ts, start15)
        assert ok1 and ok15, f"替补 {SUBSTITUTE} 复核不通过（1h {ok1} / 15m {ok15}），停止"
        selection["selected"].append({
            "symbol": SUBSTITUTE, "rank": snap_check[SUBSTITUTE]["rank"],
            "vol_24h_quote_usdt": snap_check[SUBSTITUTE]["vol_24h_quote_usdt"],
            "spread_pct": snap_check[SUBSTITUTE]["spread_pct"],
            "first_week_1h": n_fw, "reason": "替补入选",
            "start_15m": start15.date().isoformat(), "bars_15m": n15, "bars_1h": n1})
        selected.append(SUBSTITUTE)
        print(f"{SUBSTITUTE} 替补入选（15m 起点 {start15.date()}，{n15} 根；1h {n1} 根）",
              flush=True)

    selection["selected_symbols"] = selected
    with open(os.path.join(DATA_DIR, "gate_iter_round41_selection.json"), "w") as f:
        json.dump(selection, f, indent=2, ensure_ascii=False)
    print(f"\n新宇宙（{len(selected)} 个）：{selected}")
    print(f"15m 起点：{start15.date()}；跳过记录：{len(selection['skipped'])} 条，"
          "见 data/gate_iter_round41_selection.json")
    assert len(selected) == 8, f"只选出 {len(selected)} 个，不足 8 个"


if __name__ == "__main__":
    main()
