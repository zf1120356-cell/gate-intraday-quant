#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十一轮：SMT 笔记原文版（BTC/ETH ±3 根确认，S2c 基础信号）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因：第十九轮按任务书执行（基础信号 F1+S3、窗口 20 根、8 币全做），
与学习笔记原文的 SMT 写法有出入（第十九轮报告 §0.1 已写明那是另一
个版本）。本轮测笔记原文版，看换写法会不会不一样。

----------------------------------------------------------------------
原文依据（开工前已读，不凭记忆写规则）
----------------------------------------------------------------------
1) 学习笔记 §3 方向 5 原文（SMT 背离作“清扫 vs 真突破”的否决器）：
   “赌的假设：BTC 单独突破而 ETH 不跟，大概率是扫流动性而不是真突破；
    双币确认的突破才值得跟。规则先写死：信号源复用第十一轮 S1 的扫荡
    +CHOCH 或 S2c 的 BOS 直接追（只取其一，跑前定死，建议取 S2c 因为
    它的每笔毛利是正的 +3.89）。否决器：以 BTC 的破位根收盘时刻为基准，
    往前/往后各 3 根 1h 内，ETH 必须出现同方向的收盘破位（破各自最近已
    确认摆动点）；否则 BTC 的破位按‘疑似清扫’处理。只做 BTC 的信号
    （ETH 只作验证器，不单独开仓），避免样本翻倍后多重检验。分两组汇报：
    双币确认组 vs 单币否决组，比较两组的每笔毛利和胜率。数据：365 天
    1h，BTC + ETH（SOL 可作第三验证币，但跑前定死只用 BTC/ETH，避免
    事后挑币）。”
2) 06-进阶概念与入场模型.md §A9 SMT 背离（ICT 口径）：
   “两个高度相关的品种，一个创了新低（或新高），另一个没有。例子：
    EURUSD 创新低、GBPUSD 没有创新低 → 下方的新低更可能只是一次扫流
    动性，而不是真跌。常见配对：EURUSD/GBPUSD、纳指/标普、BTC/ETH。
    用法：作为‘清扫 vs 真突破’的额外证据，不单独作为入场信号。”
3) 第十一轮 S2c 定义（对照：直接追 BOS，不等回踩）：
   “1h BOS 后直接下一根 1h 开盘顺 BOS 入场，其余与 S2 一模一样
    （止损 1xATR、止盈 2xATR、最多持 16 根、每天每币最多 2 笔、
    23:45 收盘）”——任务书引文；实际第十一轮脚本里 S2c 跑的是
    max_hold=8 根 1h、每天最多 2 笔、EOD 当天最后一根 1h 收盘
    （23:00），本轮对照 1 复用第十一轮脚本原样（见下），不按引文
    的 16 根/23:45 改——引文与脚本不一致处以脚本为准，报告 §0.3
    写明。

----------------------------------------------------------------------
锁定的规则（跑前定死，单组参数，不用全样本挑）
----------------------------------------------------------------------
基础信号 S2c（第十一轮脚本原样复用 gate_iter_round11.build_s2c_signals）：
  1h BOS：收盘价上破最近已确认摆动高（看涨）/ 下破最近已确认摆动低
  （看跌）；摆动点分形 N=2，确认根 bar i+2 收盘后才可用；BOS 根须在
  08:00–20:00 UTC；信号 ATR 取 BOS 根的 ATR(14, 1h)。
  对照 1（C1）：BOS 后直接下一根 1h 开盘顺 BOS 入场。
SMT 否决器（本轮唯一新规则，笔记原文版）：
  对照币跑前写死只用 ETH 一个（BTC/ETH 配对，笔记原文；不事后加 SOL
  或换币）。ETH 只作验证器，不单独开仓。只做 BTC 一个币。
  确认定义：以 BTC 破位根 i 收盘时刻为基准，窗口 [i-3, i+3]（前后各
  3 根 1h）内，ETH 必须出现同方向的收盘破位——ETH 收盘价上破/下破其
  各自最近已确认摆动高/低（与 BTC 的 BOS 判定同一规则、同一 N=2，
  只用该根收盘时已确认的摆动点）。出现即“双币确认”，否则为背离。
  与任务书“BTC 创新高而对照币未创新高（否决做多）”的等价性：BTC 的
  BOS 本身就是 BTC 收盘创新高/低（破最近已确认摆动点）；“对照币未
  创新高”在本轮操作化为“窗口内 ETH 无同方向收盘破位”。两者是同一
  判定的两种说法。
  无前视处理（关键）：“往后 3 根”只能在 i+3 收盘后才知道，因此否决
  判定在 i+3 收盘时做；通过的信号在 i+4 开盘入场（不是 S2c 的 i+1
  开盘）。被否决的信号直接跳过。——这意味着 SMT 臂相对 C1 有两个
  变化：否决 + 入场延迟 3 根。为把两者拆开，另设诊断臂 C1d（全部
  信号、同样 i+4 入场、不否决），C1 vs C1d 隔离延迟效应，
  C1d vs MAIN 隔离否决效应。
  与笔记原文的一处出入（任务书为准）：笔记原文在 S2c 逻辑下写的是
  “反向做（赌它是扫荡后反转，止损放在扫荡极端之外）”，本轮任务书
  定为“跳过该信号”，以任务书为准，不反向做。
对照：
  对照 1（C1）：原版 S2c-BTC，无否决，i+1 入场。
  对照 2（C2）：第十九轮写法在本轮数据子集上的结果——F1+S3 写法只取
    BTC。F1 按定义只做 7 个山寨、BTC 是领涨源从不作为交易腿，故 F1
    在 BTC 上贡献 0 笔；C2 实际为 S3-BTC：C2a 原版（无否决）、C2b
    +第十九轮 SMT（20 根窗口、两币最近两摆动点比较、只否决冲突方向），
    引擎复用 gate_iter_round19.run_s3_1h_veto 原样。
  诊断臂 D：只做被 SMT-21 否决掉的信号（i+4 入场），不作候选策略，
    只回答“被否掉的信号是不是真的更差”。诊断臂 C1d：见上。
引擎（全臂一致，除注明外）：止损 1xATR、止盈 2xATR（用户要求的 1:2）；
  每笔保证金 10% 权益、1x；最多持 8 根 1h；每天每币最多 2 笔；当天
  最后一根 1h 收盘（23:00）强制平仓；单日 -2% 熔断；单笔最坏情况
  (ATR+成本) > 1% 权益跳过；同根同时碰止损和止盈先判止损。
  SMT 臂信号的 ATR 仍取 BOS 根的 ATR（与 C1 同一信号定义），不改。
成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
  双边）；资金费按实际费率计（08:00/16:00 结算点，前半段 2026-05-21
  之前无数据按 0 计）。M1/M2 只做对照（第十一轮同款），主口径是 Taker。

窗口：
  1h：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~2026-05-19
    （185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  15m：只用于对照 1 的复核——第十一轮 S2c-BTC 发表在 103 天
    1h-from-15m 上（2026-08-06~11-16，前 51 天 / 后 52 天），本轮
    用同一合成路径重建后复核；另校验原生 1h 与 15m 合成 1h 在重叠
    窗口是否一致。
  各窗口重置 10 万 USDT 虚拟权益（BTC 独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。
特别注意：本轮只有 BTC 一个币，样本比 8 币小，报告里写清单币样本
量的局限；若不达标，SMT 两个写法全部结案，不再开第三种写法。

运行：python3 gate_iter_round21.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round21_summary.json
      + data/gate_iter_round21_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
复核：对照 1 的 103d 子窗口必须复现第十一轮 S2c-BTC 已发表数字
  （容差 0.05pp，见脚本末尾 checks）；对照 2 必须复现第十九轮
  S3-BTC 已发表数字（C1 -1.50% / C3 -1.41%，容差 0.05pp）。
首信号人工核对：脚本打印第一个 S2c-BTC 信号的 SMT 输入（BTC 破位
  根、窗口内 ETH 各根的破位判定、判定结果、入场根），报告里手工复核。
"""
import csv
import hashlib
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round11 as r11
import gate_iter_round19 as r19

SYMBOLS_1H = ["BTC_USDT", "ETH_USDT"]
BTC = "BTC_USDT"
ETH = "ETH_USDT"
START_EQUITY = r11.START_EQUITY
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)   # 前半段止于 05-19
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)  # 前半段止于 09-25
TP_MULT = 2.0
SL_MULT = 1.0

# ---- SMT-21 否决器：跑前写死的参数 ----
SMT_HALF_WINDOW = 3   # 破位根前后各 3 根 1h
SMT_SWING_N = 2       # 摆动点分形半宽 N=2（第十一轮同款）

load_bars = r11.load_bars
load_funding = r11.load_funding
group_days = r11.group_days
atr_wilder = r11.atr_wilder
summarize = r11.summarize
t_value = r11.t_value


# ----------------------------------------------------------------------
# ETH 收盘破位序列：与第十一轮 build_s2c_signals 同一 BOS 判定，
# 只用每根收盘时已确认的摆动点（confirmed_levels），无前视。
# 返回与 bars 等长的数组：+1 看涨破位 / -1 看跌破位 / 0 无破位。
# ----------------------------------------------------------------------
def eth_bos_series(bars):
    closes = [b["c"] for b in bars]
    sh_level, _, sl_level, _ = r11.confirmed_levels(bars, SMT_SWING_N)
    out = [0] * len(bars)
    for j in range(1, len(bars)):
        sh, sl = sh_level[j], sl_level[j]
        pc, c = closes[j - 1], closes[j]
        if sh is not None and pc <= sh < c:
            out[j] = 1
        elif sl is not None and pc >= sl > c:
            out[j] = -1
    return out


def smt21_confirmed(eth_bos, i, direction):
    """BTC 破位根 i（方向 direction）是否得到 ETH 确认：
    窗口 [i-3, i+3] 内 ETH 出现同方向收盘破位即确认。
    返回 (confirmed, [窗口内 ETH 破位 (bar_idx, dir)])。"""
    lo = max(0, i - SMT_HALF_WINDOW)
    hi = min(len(eth_bos) - 1, i + SMT_HALF_WINDOW)
    hits = [(j, eth_bos[j]) for j in range(lo, hi + 1) if eth_bos[j] == direction]
    return (len(hits) > 0), hits


def main():
    print("盈利策略迭代 · 第二十一轮：SMT 笔记原文版（S2c + BTC/ETH ±3 根确认，全模拟）")
    print("基础信号 S2c-BTC，止损 1xATR / 止盈 2xATR；达标：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS_1H:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h[BTC][0]]
    assert [b["t"] for b in data1h[ETH][0]] == base_ts, "ETH 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS_1H:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15[BTC][0]]
    assert [b["t"] for b in data15[ETH][0]] == base_ts15, "ETH 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：BTC/ETH 各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    days_all_1h = set(group_days(data1h[BTC][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）。")

    btc_bars, btc_funding = data1h[BTC]
    eth_bars = data1h[ETH][0]
    atr_btc = atr_wilder(btc_bars)

    # ---- 原生 1h vs 15m 合成 1h（重叠窗口一致性校验）----
    bars1h_from15 = r11.synthesize(data15[BTC][0], 4, 3600)
    assert len(bars1h_from15) == 103 * 24, f"15m 合成 1h 应为 {103*24} 根"
    native_by_t = {b["t"]: b for b in btc_bars}
    max_diff = 0.0
    n_cmp = 0
    n_skip = 0
    for b in bars1h_from15:
        nb = native_by_t.get(b["t"])
        if nb is None:
            # 合成 1h 的尾部（2026-11-16 01:00 之后）超出原生 1h 缓存：
            # 原生 1h 最后一根是 2026-11-16 00:00 的零量 stub，完整日只到
            # 2026-11-15；15m 缓存的完整日到 2026-11-16。这是数据源
            # 边界差异，不是错误——只比较两者共有的时间戳。
            n_skip += 1
            continue
        for k in ("o", "h", "l", "c"):
            max_diff = max(max_diff, abs(b[k] - nb[k]))
            n_cmp += 1
    print(f"[一致性] 原生 1h vs 15m 合成 1h（共有 {len(bars1h_from15)-n_skip} 根，"
          f"跳过合成独有 {n_skip} 根）：OHLC 最大差 {max_diff:.6f}"
          f"（{'一致' if max_diff == 0 else '有差异，见报告'}）。")

    # ---- S2c 信号（第十一轮脚本原样，BTC，365d 1h）----
    sig_c1, st_c1 = r11.build_s2c_signals(btc_bars, atr_btc)
    print(f"[S2c-BTC 365d 1h] BOS {st_c1['bos']} 次 / 信号 {st_c1['signals']} 个 "
          f"（BOS 根须在 08:00–20:00 UTC）。")

    # ---- SMT-21 确认：对每个 S2c 信号做 ±3 根判定 ----
    eth_bos = eth_bos_series(eth_bars)
    n_eth_bos = sum(1 for v in eth_bos if v != 0)
    print(f"[ETH BOS] 365d 1h ETH 收盘破位共 {n_eth_bos} 次 "
          f"（多 {sum(1 for v in eth_bos if v == 1)} / 空 {sum(1 for v in eth_bos if v == -1)}）。")
    idx_of_t = {b["t"]: i for i, b in enumerate(btc_bars)}
    # sig_c1 key=入场根时间戳（BOS 根 +1）；反推 BOS 根下标
    sig_pass, sig_veto, sig_delayed = {}, {}, {}
    veto_detail = []  # (bos_idx, direction, confirmed, hits, entry_idx)
    n_tail = 0
    for entry_t, sig in sorted(sig_c1.items()):
        gi_entry = idx_of_t[entry_t]
        bos_i = gi_entry - 1
        if bos_i + 4 >= len(btc_bars):
            n_tail += 1
            continue
        confirmed, hits = smt21_confirmed(eth_bos, bos_i, sig["direction"])
        entry4_t = btc_bars[bos_i + 4]["t"]
        rec = {"direction": sig["direction"], "atr": sig["atr"], "tag": "BOS-SMT",
               "bos_idx": bos_i}
        veto_detail.append((bos_i, sig["direction"], confirmed, hits, bos_i + 4))
        if entry4_t not in sig_delayed:
            sig_delayed[entry4_t] = dict(rec)
        if confirmed:
            if entry4_t not in sig_pass:
                sig_pass[entry4_t] = dict(rec)
        else:
            if entry4_t not in sig_veto:
                sig_veto[entry4_t] = dict(rec)
    n_sig = len(veto_detail)
    n_conf = sum(1 for _, _, c, _, _ in veto_detail if c)
    n_veto = n_sig - n_conf
    print(f"[SMT-21] 判定信号 {n_sig} 个（尾部无法判定 i+4 越界 {n_tail} 个，只影响 MAIN/D/C1d，"
          f"C1 仍可交易）；确认 {n_conf} 个 / 否决 {n_veto} 个 / 否决率 {n_veto/n_sig:.1%}。")
    for half, lo_d, hi_d in [("前185d", datetime(2025, 11, 16, tzinfo=timezone.utc).date(),
                             SPLIT_1H.date()),
                            ("后180d", SPLIT_1H.date(),
                             datetime(2026, 11, 16, tzinfo=timezone.utc).date())]:
        sub = [v for v in veto_detail
               if lo_d <= datetime.fromtimestamp(btc_bars[v[0]]["t"], timezone.utc).date() < hi_d]
        vv = sum(1 for v in sub if not v[2])
        print(f"  {half}：信号 {len(sub)} 个，否决 {vv} 个，否决率 "
              f"{vv/len(sub):.1%}" if sub else f"  {half}：无信号")
    n_23 = sum(1 for _, _, _, _, e in veto_detail
               if datetime.fromtimestamp(btc_bars[e]["t"], timezone.utc).hour == 23)
    print(f"  注：SMT 臂入场根为 23:00（BOS 根 19:00，当天最后一根、入场即 EOD 平仓）的信号 "
          f"{n_23} 个，引擎原样处理，数量见报告。")

    # ---- 首信号人工核对材料 ----
    bos0, dir0, conf0, hits0, ent0 = veto_detail[0]
    print("\n[首信号核对 S2c-BTC + SMT-21] "
          f"BOS 根 {datetime.fromtimestamp(btc_bars[bos0]['t'], timezone.utc).isoformat()} "
          f"方向 {'LONG' if dir0 == 1 else 'SHORT'} "
          f"BTC 收 {btc_bars[bos0]['c']:.2f} / ATR {atr_btc[bos0]:.2f}")
    sh_l, _, sl_l, _ = r11.confirmed_levels(btc_bars, 2)
    print(f"  BTC 该根已确认摆动高 {sh_l[bos0]} / 摆动低 {sl_l[bos0]}；"
          f"前一根收 {btc_bars[bos0-1]['c']:.2f}")
    print(f"  窗口 [{bos0-3}, {bos0+3}] 内 ETH 收盘破位："
          + (", ".join(f"{datetime.fromtimestamp(eth_bars[j]['t'], timezone.utc).isoformat()} "
                       f"{'LONG' if d == 1 else 'SHORT'}" for j, d in hits0) or "无"))
    print(f"  SMT-21 判定：{'确认' if conf0 else '否决'}；"
          f"C1 入场 {datetime.fromtimestamp(btc_bars[bos0+1]['t'], timezone.utc).isoformat()} 开盘 "
          f"{btc_bars[bos0+1]['o']:.2f}；"
          f"SMT 臂入场 {datetime.fromtimestamp(btc_bars[ent0]['t'], timezone.utc).isoformat()} 开盘 "
          f"{btc_bars[ent0]['o']:.2f}（若通过）")
    # 第一个被否决的信号
    first_v = next(v for v in veto_detail if not v[2])
    bosv, dirv, _, hitsv, entv = first_v
    print("[首个被否决信号] "
          f"BOS 根 {datetime.fromtimestamp(btc_bars[bosv]['t'], timezone.utc).isoformat()} "
          f"方向 {'LONG' if dirv == 1 else 'SHORT'} "
          f"BTC 收 {btc_bars[bosv]['c']:.2f}；窗口内 ETH 同向破位："
          + ("无" if not hitsv else ", ".join(
              f"{datetime.fromtimestamp(eth_bars[j]['t'], timezone.utc).isoformat()}" for j, _ in hitsv))
          + f"；D 臂入场 {datetime.fromtimestamp(btc_bars[entv]['t'], timezone.utc).isoformat()} 开盘 "
            f"{btc_bars[entv]['o']:.2f}")

    all_results, all_trades = [], []

    def record(res, trades_full, family, variant, gran, split_fn, veto_info=None):
        res["family"] = family
        res["variant"] = variant
        res["tp_mult"] = TP_MULT
        res["granularity"] = gran
        if veto_info is not None:
            res["signals_seen"], res["signals_vetoed"], res["veto_rate"] = veto_info
        all_results.append(res)
        if trades_full is not None:
            for t in trades_full:
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["tp_mult"] = TP_MULT
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def line(label, res):
        def f(v, fmt):
            return ("--" if v is None else format(v, fmt))
        print(f"[{label} {res['symbol']} {res['split']}] n={res['trades']} 胜率={f(res['win_rate'], '.4f')} "
              f"盈亏比={f(res['profit_factor'], '.2f')} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={f(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={f(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    def split_fn_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    # ================= S2c 臂：C1 / MAIN / D / C1d =================
    print("\n=== S2c-BTC 臂（365d 1h）===")
    arms_s2c = [
        ("R21-S2c-C1-orig", "S2c", sig_c1, (n_sig, 0, 0.0)),
        ("R21-S2c-SMT-pass", "S2c-SMT", sig_pass, (n_sig, n_veto, round(n_veto / n_sig, 4))),
        ("R21-S2c-SMT-vetoed", "S2c-SMT-D", sig_veto, (n_sig, n_veto, round(n_veto / n_sig, 4))),
        ("R21-S2c-C1d-delayed", "S2c-delayed", sig_delayed, (n_sig, 0, 0.0)),
    ]
    for label, family, sigs, vi in arms_s2c:
        for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
            trades, curve, ndays = r11.simulate_generic(
                BTC, btc_bars, sigs, btc_funding, subset, 2, 8, label, 24)
            res = summarize(BTC, trades, curve, label, len(sigs))
            res["split"] = wname
            res["days"] = ndays
            record(res, trades if wname == "365d" else None, family, label, "1h",
                   split_fn_1h, vi if wname == "365d" else None)
            line(label, res)

    # ================= 对照 2：S3-BTC，第十九轮写法 =================
    print("\n=== 对照 2：S3-BTC，第十九轮写法（F1 在 BTC 上为 0 笔，见报告）===")
    print("[F1] F1 按定义只做 7 个山寨、BTC 是领涨源从不作为交易腿，"
          "故对照 2 在 BTC 上只有 S3 一臂。")
    btc_sw = r19.swing_points(btc_bars)
    eth_sw = r19.swing_points(eth_bars)

    def make_veto_c2(arm):
        counter = {"seen": 0, "vetoed": 0}

        def veto_fn(gi, sig):
            counter["seen"] += 1
            if arm == "C2a":
                return False
            conf = r19.smt_conflicts(btc_bars, eth_bars, gi, r19.SMT_WINDOW_1H, sig,
                                     btc_sw, eth_sw)
            if conf:
                counter["vetoed"] += 1
            return conf

        return veto_fn, counter

    for arm, label in [("C2a", "R21-S3-C2a-orig"), ("C2b", "R21-S3-C2b-R19SMT")]:
        full_counter = None
        for wname, subset in [("365d", None), ("前185d", front_1h), ("后180d", back_1h)]:
            veto_fn, counter = make_veto_c2(arm)
            if wname == "365d":
                full_counter = counter
            trades, curve, ndays = r19.run_s3_1h_veto(
                btc_bars, btc_funding, BTC, subset, TP_MULT, label, veto_fn)
            res = r19.summarize(BTC, trades, curve, label)
            res["split"] = wname
            res["days"] = ndays
            vi = (counter["seen"], counter["vetoed"],
                  round(counter["vetoed"] / counter["seen"], 4)) if counter["seen"] else (0, 0, None)
            record(res, trades if wname == "365d" else None, "S3", label, "1h",
                   split_fn_1h, vi if wname == "365d" else None)
            line(label, res)
        print(f"  [S3 {label} BTC] 全期引擎决策点信号 seen={full_counter['seen']} "
              f"vetoed={full_counter['vetoed']}")

    # ---- 汇总 ----
    print("\n=== 汇总（BTC 独立 10 万 USDT，1x，主口径 Taker）===")
    for variant in sorted({r["variant"] for r in all_results}):
        for wname in ["365d", "前185d", "后180d"]:
            rs = [r for r in all_results if r["variant"] == variant and r["split"] == wname]
            if not rs:
                continue
            r0 = rs[0]
            print(f"  {variant} {wname}：Taker {r0['taker_net_pct']*100:+.2f}% / "
                  f"M2 {r0['m2_net_pct']*100:+.2f}% | 毛利 {r0['gross_usdt']:+.0f} "
                  f"成本 {r0['taker_cost_sum']:+.0f} 笔数 {r0['trades']} "
                  f"每笔毛利 {r0['gross_per_trade_usdt']:+.2f} USDT")

    # ---- pooled t ----
    print("\n=== Pooled t 值（逐笔净收益占权益 %，全期明细）===")
    for variant in sorted({r["variant"] for r in all_results}):
        sub = [t for t in all_trades if t["variant"] == variant]
        for wname in ["365d", "前185d", "后180d"]:
            s2 = [t for t in sub if wname == "365d" or t["split"] == wname]
            vals = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
            vals_t = [t["pnl"] / START_EQUITY for t in s2]
            print(f"  {variant} {wname}：n={len(vals)} "
                  f"pooled t(M1)={t_value(vals)} pooled t(Taker)={t_value(vals_t)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker，候选臂：C1 / MAIN / C2a / C2b）===")
    for variant in ["R21-S2c-C1-orig", "R21-S2c-SMT-pass",
                    "R21-S3-C2a-orig", "R21-S3-C2b-R19SMT"]:
        row = {}
        for wname in ["前185d", "后180d", "365d"]:
            r0 = [r for r in all_results if r["variant"] == variant and r["split"] == wname][0]
            row[wname] = r0["taker_net_pct"]
        good = row["前185d"] > 0 and row["后180d"] > 0 and row["365d"] > 0.02
        print(f"  {variant} Taker：前 {row['前185d']*100:+.2f}% / "
              f"后 {row['后180d']*100:+.2f}% / 全 {row['365d']*100:+.2f}% → "
              f"{'达标' if good else '不达标'}")

    # ---- 复核 1：对照 1 的 103d 子窗口 vs 第十一轮 S2c-BTC 已发表数字 ----
    print("\n=== 复核 1：C1 的 103d 子窗口 vs 第十一轮 S2c-BTC 已发表数字（Taker，全期）===")
    atr_from15 = atr_wilder(bars1h_from15)
    sig_from15, st_from15 = r11.build_s2c_signals(bars1h_from15, atr_from15)
    funding15 = load_funding(BTC)
    days15 = set(group_days(bars1h_from15, 24).keys())
    front_15 = {d for d in days15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days15 if d >= SPLIT_15M.date()}

    def split_fn_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    checks1 = {  # (split, taker_net_pct, trades, gross)
        "103d": (-0.0285, 115, -7.81),
        "前51d": (-0.0084, 57, 577.39),
        "后52d": (-0.0203, 58, -590.16),
    }
    bad1 = 0
    res1 = {}
    for wname, subset in [("103d", None), ("前51d", front_15), ("后52d", back_15)]:
        trades, curve, ndays = r11.simulate_generic(
            BTC, bars1h_from15, sig_from15, funding15, subset, 2, 8, "R21-check-S2c103", 24)
        res = summarize(BTC, trades, curve, "R21-check-S2c103", len(sig_from15))
        res1[wname] = res
        exp_pct, exp_n, exp_g = checks1[wname]
        ok = abs(res["taker_net_pct"] - exp_pct) < 0.0005 and res["trades"] == exp_n
        bad1 += 0 if ok else 1
        print(f"  S2c-BTC {wname}（1h-from-15m）：本轮 {res['taker_net_pct']*100:+.2f}% "
              f"n={res['trades']} 毛利={res['gross_usdt']:+.2f} vs 第十一轮 "
              f"{exp_pct*100:+.2f}% n={exp_n} 毛利={exp_g:+.2f} → {'一致' if ok else '不一致！！'}")
    print(f"  复核 1 结果：{3-bad1}/3 一致" + ("（全部通过）" if bad1 == 0 else "（有出入，见报告）"))
    # 原生 1h 切 103d 窗口，与合成路径交叉核对（同一日集合：原生 1h 的
    # 完整日只到 2026-11-15，故交叉窗口为 102 天 2026-08-06~11-15；
    # 前/后半段按同一 SPLIT_15M 切分，含 2026-11-16 的那一天只在
    # 合成路径里，两边数字不直接比，只比共有窗口）
    days_103 = {d for d in days_all_1h
                if datetime(2026, 8, 6, tzinfo=timezone.utc).date() <= d
                <= datetime(2026, 11, 16, tzinfo=timezone.utc).date()}
    front_103 = {d for d in days_103 if d < SPLIT_15M.date()}
    back_103 = {d for d in days_103 if d >= SPLIT_15M.date()}
    for wname, subset in [("102d-native", days_103), ("前51d-x", front_103),
                          ("后51d-x", back_103)]:
        trades, curve, ndays = r11.simulate_generic(
            BTC, btc_bars, sig_c1, btc_funding, subset, 2, 8, "R21-check-S2c103n", 24)
        res = summarize(BTC, trades, curve, "R21-check-S2c103n", len(sig_c1))
        trades2, curve2, _ = r11.simulate_generic(
            BTC, bars1h_from15, sig_from15, funding15, subset, 2, 8,
            "R21-check-S2c103s", 24)
        res2 = summarize(BTC, trades2, curve2, "R21-check-S2c103s", len(sig_from15))
        print(f"  [交叉] S2c-BTC {wname}（{ndays} 天）：原生 1h "
              f"{res['taker_net_pct']*100:+.2f}% n={res['trades']} 毛利={res['gross_usdt']:+.2f} "
              f"vs 合成 1h {res2['taker_net_pct']*100:+.2f}% n={res2['trades']} "
              f"毛利={res2['gross_usdt']:+.2f}")

    # ---- 复核 2：对照 2 vs 第十九轮 S3-BTC 已发表数字 ----
    print("\n=== 复核 2：对照 2 vs 第十九轮 S3-BTC 已发表数字（Taker，全期 365d）===")
    checks2 = {"R21-S3-C2a-orig": (-0.0150, 32), "R21-S3-C2b-R19SMT": (-0.0141, 31)}
    bad2 = 0
    for variant, (exp_pct, exp_n) in checks2.items():
        r0 = [r for r in all_results if r["variant"] == variant and r["split"] == "365d"][0]
        ok = abs(r0["taker_net_pct"] - exp_pct) < 0.0005 and r0["trades"] == exp_n
        bad2 += 0 if ok else 1
        print(f"  {variant}：本轮 {r0['taker_net_pct']*100:+.2f}% n={r0['trades']} "
              f"毛利={r0['gross_usdt']:+.2f} vs 第十九轮 {exp_pct*100:+.2f}% n={exp_n} → "
              f"{'一致' if ok else '不一致！！'}")
    print(f"  复核 2 结果：{2-bad2}/2 一致" + ("（全部通过）" if bad2 == 0 else "（有出入，见报告）"))

    with open(os.path.join(DATA_DIR, "gate_iter_round21_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round21_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "exit_time_utc", "entry", "exit",
                    "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt", "price_pnl_usdt",
                    "cost_taker_usdt", "cost_maker_usdt", "funding_cost_usdt",
                    "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["family"], x["variant"], x["symbol"])):
            w.writerow([t["family"], t["variant"], t["tp_mult"], t["granularity"], t["split"],
                        t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t.get("liquidated", False), t["hold_min"]])
    print(f"\n汇总已写入：data/gate_iter_round21_summary.json ({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round21_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益.")


if __name__ == "__main__":
    main()
