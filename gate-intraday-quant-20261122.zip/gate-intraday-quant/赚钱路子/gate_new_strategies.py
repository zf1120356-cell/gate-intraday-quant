#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gate 新策略研究（全模拟，不下单、不开户、不碰真钱）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约。
前置结论（已读完三份报告，不再重复测）：
  ORB 突破、VWAP 均值回归、EMA 动量、ORB+VWAP+ATR 组合、
  止盈 3x、去 VWAP 出场、ORB 改窗口、成交量过滤、
  资金费率结算点套利（日内版）、亚盘突破 —— 180 天 72 个格子
  全部为负，毛利基本为零，亏损几乎全是成本。
  深化报告结论：再换方向策略的参数大概率是过拟合。

本次任务：发明 4 个真正不同家族的新策略，只改参数不算新。
每个策略的假设在写代码前就已定好（写在下面），不是看数据后挑的。
  S1 配对交易 BTC/ETH：赌价差日内均值回归，不赌市场方向，
     市场中性；前面全是单腿方向赌注，这是本质不同。
  S2 波动率扩张：平时空仓，只在波动突然放大且收盘有方向时才跟，
     用“少做”攻击成本问题；前面策略每天必做 1 笔。
  S3 RSI 极端反转：赌日内超买超卖到极值后回落，假设与动量策略
     完全相反（动量赌延续，反转赌回落）。
  S4 资金费率极值反转：费率极端正=多头拥挤，赌价格日内回落；
     与 N1 本质不同——N1 是持仓进结算点收资金费，S4 是赌价格
     反转、不以收资金费为目的。

口径（与前置一致，除非注明）：
  数据：data/gate_30m_180d_{BTC,ETH,SOL}_USDT.csv（各 8,641 根，
  2026-05-20~11-15，180 个完整 UTC 日），资金费率
  data/gate_funding_180d_{...}.json（各 537 条）。只用缓存，不重新取数。
  成本：一轮开平名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
  资金费按实际费率计。仓位：每笔保证金 10% 权益，1x 为主，
  2x 只在全 180 天做一次缩放对照。每天每币最多 2 笔（S1 每天最多 1 笔），
  当天最后一根 30m（23:30）收盘强制平仓、不过夜。
  执行：收盘价触发信号、下一根开盘价成交；止损/止盈用盘中高低价触发。
  窗口：前 90 天 2026-05-20~08-17 / 后 90 天 2026-08-18~11-15 /
  全 180 天，各重置 10 万 USDT 虚拟权益。
  没有网格寻优，每个策略只测一组事先定好的参数。

运行：python3 gate_new_strategies.py
输出：终端打印全部表 + data/gate_new_summary.json
      + data/gate_new_trades.csv
"""
import csv
import json
import math
import os
import statistics
from datetime import datetime, timezone, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005}
ROUNDTRIP_COST = 0.0025  # 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
START_DAY = datetime(2026, 5, 20, tzinfo=timezone.utc)
SPLIT_DAY = datetime(2026, 8, 18, tzinfo=timezone.utc)
ATR_PERIOD = 14


def load_bars(symbol):
    path = os.path.join(DATA_DIR, f"gate_30m_180d_{symbol}.csv")
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    path = os.path.join(DATA_DIR, f"gate_funding_180d_{symbol}.json")
    with open(path) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day=48):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def rsi_wilder(closes, period=14):
    rsi = [None] * len(closes)
    if len(closes) <= period:
        return rsi
    gains, losses = [], []
    for i in range(1, period + 1):
        ch = closes[i] - closes[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    avg_g = sum(gains) / period
    avg_l = sum(losses) / period
    rsi[period] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    for i in range(period + 1, len(closes)):
        ch = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(ch, 0.0)) / period
        avg_l = (avg_l * (period - 1) + max(-ch, 0.0)) / period
        rsi[i] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    return rsi


def summarize(equity, start, trades, label):
    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] <= 0]
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0.0
    avg_loss = abs(sum(t["pnl"] for t in losses) / len(losses)) if losses else 0.0
    return {"label": label, "trades": len(trades),
            "win_rate": round(len(wins) / len(trades), 4) if trades else None,
            "net_return": round((equity - start) / start, 4),
            "final_equity": round(equity, 2),
            "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
            "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
            "total_pnl": round(sum(t["pnl"] for t in trades), 2),
            "liquidations": sum(1 for t in trades if t.get("liquidated"))}


def add_mdd(result, curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    result["max_dd"] = round(mdd, 4)
    return result


def funding_cost_between(funding, symbol, day, entry_t, exit_t, notional, direction):
    """多头费率>0付钱、空头收钱；只计 08:00/16:00 结算点。"""
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


# ---------------------------------------------------------------- 通用单腿日内引擎
def run_single(bars, funding, symbol, days_subset, strategy, leverage=1,
               max_trades_day=2, label=""):
    """strategy in {"S2-vol", "S3-rsi", "S4-funding"}。
    共用：保证金 10% 权益、收盘触发下一根开盘成交、盘中高低价触发
    止损/止盈、23:30 强制平仓、单日 -2% 熔断、强平检查。"""
    atr = atr_wilder(bars)
    closes = [b["c"] for b in bars]
    rsi = rsi_wilder(closes) if strategy == "S3-rsi" else [None] * len(bars)
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 48)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / leverage - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    # S4 用的最新已知资金费率（按时间排序，取 <= 当前 bar 时间的最后一条）
    fund_times = sorted(funding.keys())

    def latest_funding(t):
        import bisect
        i = bisect.bisect_right(fund_times, t) - 1
        return funding[fund_times[i]] if i >= 0 else 0.0

    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        day_stopped = False
        pos = None
        trades_today = 0
        # 本日各 bar 的 range 中位数（S2 用，取当日已走完 bar 的中位数近似；
        # 为避免前视，改用前 20 根全局 bar 的 range 中位数，在循环内现算）
        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, symbol, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                if pos["direction"] == 1:
                    adv = (pos["entry"] - b["l"]) / pos["entry"]
                else:
                    adv = (b["h"] - pos["entry"]) / pos["entry"]
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                # 策略特有出场（只在收盘价上判断）
                if strategy == "S3-rsi":
                    r = rsi[gi]
                    if r is not None:
                        if pos["direction"] == 1 and r >= 50:
                            close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                        if pos["direction"] == -1 and r <= 50:
                            close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if strategy == "S4-funding" and pos is not None:
                    if (b["t"] - pos["entry_t"]) >= 4 * 3600:
                        close_trade(pos, b["t"], b["c"], "time_expiry"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_trades_day \
                    and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                sig, tp_mult = 0, 2.0
                if strategy == "S2-vol":
                    # 只在 08:00-16:00 UTC；信号 bar：range > 1.8x 前 20 根 range 中位数，
                    # 且收盘在 range 上/下 25% 内（有方向的收盘）。
                    if not (8.0 <= hour < 16.0):
                        continue
                    if gi < 20:
                        continue
                    ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                    med_range = ranges[len(ranges) // 2]
                    rng = b["h"] - b["l"]
                    if rng <= 1.8 * med_range or med_range == 0:
                        continue
                    frac = (b["c"] - b["l"]) / rng if rng else 0.5
                    if frac >= 0.75:
                        sig = 1
                    elif frac <= 0.25:
                        sig = -1
                    tp_mult = 2.0
                elif strategy == "S3-rsi":
                    if not (8.0 <= hour < 20.0):
                        continue
                    r = rsi[gi]
                    if r is None:
                        continue
                    # 极值 + 本根 range 大于前 20 根中位数（避开死市里的极值）
                    if gi < 20:
                        continue
                    ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                    med_range = ranges[len(ranges) // 2]
                    if (b["h"] - b["l"]) <= med_range:
                        continue
                    if r < 25:
                        sig = 1
                    elif r > 75:
                        sig = -1
                    tp_mult = 1.5
                elif strategy == "S4-funding":
                    if not (0.0 <= hour < 20.0):
                        continue
                    fr = latest_funding(b["t"])
                    if fr >= 0.00008:
                        sig = -1  # 费率极端正=多头拥挤，赌回落做空
                    elif fr <= -0.00008:
                        sig = 1
                    tp_mult = 1.0
                if sig == 0:
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * leverage
                worst = notional * (a / entry + ROUNDTRIP_COST)
                if worst / equity > 0.01:
                    continue
                stop = entry - a if sig == 1 else entry + a
                tp = entry + tp_mult * a if sig == 1 else entry - tp_mult * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "price_pnl": 0.0, "hold_min": None,
                       "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    res = summarize(equity, START_EQUITY, trades, label)
    res["symbol"] = symbol
    res["days"] = len(days)
    res["avg_hold_min"] = round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None
    add_mdd(res, curve)
    return res, trades


# ---------------------------------------------------------------- S1 配对交易 BTC/ETH
def run_pairs(bars_btc, bars_eth, fund_btc, fund_eth, days_subset, label="S1-pairs"):
    """价差 = ln(BTC) - ln(ETH)，滚动 480 根（10 天）均值/标准差，
    z = (spread - mean) / std（只用当前 bar 之前的数据，无前视）。
    |z|>2 开仓（z>0 做空价差：空 BTC + 多 ETH），|z|<0.5 平仓，
    |z|>=3.5 止损，23:30 强制平仓。每天最多 1 笔。
    每腿名义 5,000 USDT（合计 10,000，= 单腿策略的保证金口径），
    一轮成本 = 两腿名义合计 x 0.25% = 25 USDT。"""
    by_t_btc = {b["t"]: b for b in bars_btc}
    by_t_eth = {b["t"]: b for b in bars_eth}
    common_t = sorted(set(by_t_btc) & set(by_t_eth))
    closes_btc = [by_t_btc[t]["c"] for t in common_t]
    closes_eth = [by_t_eth[t]["c"] for t in common_t]
    spread = [math.log(cb) - math.log(ce) for cb, ce in zip(closes_btc, closes_eth)]
    # 滚动 z（只用过去 480 根，不含当前）
    z = [None] * len(spread)
    W = 480
    for i in range(W, len(spread)):
        window = spread[i - W:i]
        mu = statistics.mean(window)
        sd = statistics.pstdev(window)
        z[i] = (spread[i] - mu) / sd if sd > 0 else 0.0
    idx_of_t = {t: i for i, t in enumerate(common_t)}
    # 按日分组（用 BTC 的 bar）
    days = {}
    for b in bars_btc:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    days = {d: v for d, v in sorted(days.items()) if len(v) == 48}
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_pair(tr, exit_t, reason):
            nonlocal equity, day_pnl
            bi = idx_of_t[exit_t]
            pb = by_t_btc[exit_t]["c"]
            pe = by_t_eth[exit_t]["c"]
            tr["exit_t"] = exit_t
            tr["reason"] = reason
            tr["exit_btc"] = pb
            tr["exit_eth"] = pe
            # 每腿名义 5,000：多腿赚 (exit/entry-1)，空腿赚 -(exit/entry-1)
            pnl_btc = 5000 * (pb / tr["entry_btc"] - 1) * tr["dir_btc"]
            pnl_eth = 5000 * (pe / tr["entry_eth"] - 1) * tr["dir_eth"]
            tr["price_pnl"] = pnl_btc + pnl_eth
            tr["cost_usdt"] = 10000 * ROUNDTRIP_COST
            # 资金费：每腿在 08:00/16:00 结算点，多头付、空头收
            fc = 0.0
            ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
            for h in (8, 16):
                s = int((ds + timedelta(hours=h)).timestamp())
                if tr["entry_t"] < s <= exit_t:
                    if s in fund_btc:
                        fc += fund_btc[s] * 5000 * tr["dir_btc"]
                    if s in fund_eth:
                        fc += fund_eth[s] * 5000 * tr["dir_eth"]
            tr["funding_cost_usdt"] = fc
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - fc
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                zv = z[gi]
                exited = False
                if zv is not None and abs(zv) < 0.5:
                    close_pair(pos, b["t"], "z_revert"); exited = True
                elif zv is not None and abs(zv) >= 3.5:
                    close_pair(pos, b["t"], "z_stop"); exited = True
                if exited:
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_pair(pos, b["t"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 1 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                zv = z[gi]
                if zv is None:
                    continue
                if zv > 2.0:
                    dir_btc, dir_eth = -1, 1   # 做空价差
                elif zv < -2.0:
                    dir_btc, dir_eth = 1, -1   # 做多价差
                else:
                    continue
                nxt_t = day_bars[i + 1]["t"]
                pos = {"symbol": "BTC/ETH-pair", "variant": label,
                       "direction": dir_btc, "dir_btc": dir_btc, "dir_eth": dir_eth,
                       "entry_t": nxt_t,
                       "entry_btc": by_t_btc[nxt_t]["o"], "entry_eth": by_t_eth[nxt_t]["o"],
                       "entry": spread[idx_of_t[nxt_t]], "z_entry": zv,
                       "notional": 10000, "margin": 10000,
                       "exit_t": None, "pnl": 0.0, "liquidated": False, "reason": "",
                       "funding_cost_usdt": 0.0, "cost_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_pair(pos, day_bars[-1]["t"], "eod")
            pos = None
    res = summarize(equity, START_EQUITY, trades, label)
    res["symbol"] = "BTC/ETH-pair"
    res["days"] = len(days)
    res["avg_hold_min"] = round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None
    add_mdd(res, curve)
    return res, trades


# ---------------------------------------------------------------- 主流程
def main():
    print("Gate 新策略研究（30m、180 天、全模拟）")
    print(f"窗口：{START_DAY.date()}~2026-11-15，前 90 天 {START_DAY.date()}~2026-08-17，"
          f"后 90 天 2026-08-18~2026-11-15")
    data = {}
    for sym in SYMBOLS:
        bars = load_bars(sym)
        funding = load_funding(sym)
        data[sym] = (bars, funding)
        days = group_days(bars, 48)
        print(f"[{sym}] 完整交易日：{len(days)} 天，首日 {min(days)} 末日 {max(days)}，"
              f"资金费率 {len(funding)} 条")
    all_results = []
    all_trades = []

    def run_and_collect(fn, label, split_name, subset, collect_180d=True):
        res, trades = fn(subset)
        res["split"] = split_name
        all_results.append(res)
        if split_name == "180d" and collect_180d:
            for t in trades:
                t["variant"] = label
                t["split"] = "180d"
            all_trades.extend(trades)
        print(f"[{label} {res.get('symbol','')} {split_name}] 笔数={res['trades']} "
              f"胜率={res['win_rate']} 净收益={res['net_return']*100:+.2f}% "
              f"盈亏比={res['profit_factor']} 最大回撤={res['max_dd']*100:.2f}% "
              f"平均持仓={res['avg_hold_min']}分钟 爆仓={res['liquidations']}")
        return res

    singles = [("S2-vol", "S2-vol", 2), ("S3-rsi", "S3-rsi", 2), ("S4-funding", "S4-funding", 2)]
    for label, strat, max_td in singles:
        for sym in SYMBOLS:
            bars, funding = data[sym]
            days_all = set(group_days(bars, 48).keys())
            days_a = {d for d in days_all if d < SPLIT_DAY.date()}
            days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
            for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
                run_and_collect(
                    lambda s, _s=sym, _b=bars, _f=funding, _l=label, _m=max_td, _st=strat:
                        run_single(_b, _f, _s, s, _st, leverage=1, max_trades_day=_m, label=_l),
                    label, split_name, subset)
        # 2x 只做全 180 天缩放对照
        for sym in SYMBOLS:
            bars, funding = data[sym]
            res, trades = run_single(bars, funding, sym, None, strat, leverage=2,
                                     max_trades_day=max_td, label=label + "-2x")
            res["split"] = "180d-2x"
            all_results.append(res)
            print(f"[{label}-2x {sym} 180d] 笔数={res['trades']} 胜率={res['win_rate']} "
                  f"净收益={res['net_return']*100:+.2f}% 盈亏比={res['profit_factor']} "
                  f"最大回撤={res['max_dd']*100:.2f}% 爆仓={res['liquidations']}")

    # S1 配对交易（一个组合，不是按币拆）
    bars_btc, fund_btc = data["BTC_USDT"]
    bars_eth, fund_eth = data["ETH_USDT"]
    days_all = set(group_days(bars_btc, 48).keys())
    days_a = {d for d in days_all if d < SPLIT_DAY.date()}
    days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
    for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
        run_and_collect(
            lambda s: run_pairs(bars_btc, bars_eth, fund_btc, fund_eth, s, label="S1-pairs"),
            "S1-pairs", split_name, subset)

    # ---- 汇总：三币平均（单腿策略，1x）----
    print("\n=== 汇总：三币平均净收益 1x（各币独立 10 万 USDT；S1 为单一组合）===")
    for label in ["S2-vol", "S3-rsi", "S4-funding", "S1-pairs"]:
        for split_name in ["180d", "前90d", "后90d"]:
            rs = [r for r in all_results if r["label"] == label and r["split"] == split_name]
            if not rs:
                continue
            avg = sum(r["net_return"] for r in rs) / len(rs)
            tot = sum(r["trades"] for r in rs)
            wrs = [r["win_rate"] for r in rs if r["win_rate"] is not None]
            pfs = [r["profit_factor"] for r in rs if r["profit_factor"] is not None]
            mdds = [r["max_dd"] for r in rs]
            print(f"{label} {split_name}：平均净收益 {avg*100:+.2f}%  总笔数 {tot}  "
                  f"胜率 {min(wrs)*100:.1f}%~{max(wrs)*100:.1f}%  "
                  f"盈亏比 {min(pfs) if pfs else None}~{max(pfs) if pfs else None}  "
                  f"最大回撤 {min(mdds)*100:.2f}%~{max(mdds)*100:.2f}%")

    # ---- 成本拆解：每个策略全 180 天 1x，毛利 vs 成本 ----
    print("\n=== 成本拆解（全 180 天，1x）：毛利（扣资金费后）vs 成本拖累 ===")
    for t180 in all_trades:
        pass
    for label in ["S2-vol", "S3-rsi", "S4-funding"]:
        for sym in SYMBOLS:
            ts = [t for t in all_trades if t.get("variant") == label and t.get("symbol") == sym]
            if not ts:
                continue
            gross = sum(t.get("price_pnl", 0) - t.get("funding_cost_usdt", 0) for t in ts)
            cost = sum(t.get("cost_usdt", 0) for t in ts)
            print(f"[{label} {sym}] 笔数={len(ts)} 毛利={gross:+.0f} USDT "
                  f"成本=-{cost:.0f} USDT 净={gross-cost:+.0f} USDT")
    ts = [t for t in all_trades if t.get("variant") == "S1-pairs"]
    if ts:
        gross = sum(t.get("price_pnl", 0) - t.get("funding_cost_usdt", 0) for t in ts)
        cost = sum(t.get("cost_usdt", 0) for t in ts)
        print(f"[S1-pairs] 笔数={len(ts)} 毛利={gross:+.0f} USDT "
              f"成本=-{cost:.0f} USDT 净={gross-cost:+.0f} USDT")

    # ---- 落盘 ----
    with open(os.path.join(DATA_DIR, "gate_new_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_new_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "split", "symbol", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_usdt", "price_pnl_usdt",
                    "cost_usdt", "funding_cost_usdt", "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x.get("symbol", ""), x.get("variant", ""))):
            w.writerow([t.get("variant", ""), t.get("split", ""), t.get("symbol", ""),
                        "LONG" if t.get("direction") == 1 else ("SHORT" if t.get("direction") == -1 else t.get("variant", "")),
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t.get("entry"), t.get("exit"), t.get("notional"),
                        round(t["pnl"], 2), round(t.get("price_pnl", 0), 2),
                        round(t.get("cost_usdt", 0), 2), round(t.get("funding_cost_usdt", 0), 2),
                        t.get("reason", ""), t.get("liquidated", False), t.get("hold_min")])
    print("\n汇总已写入：data/gate_new_summary.json")
    print("明细已写入：data/gate_new_trades.csv")
    print("模拟结束：本脚本不下单、不开户、不碰真钱。")


if __name__ == "__main__":
    main()
