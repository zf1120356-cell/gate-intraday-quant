#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
迭代 A：S3 低换手版（全模拟，不下单、不开户、不碰真钱）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约。
原版 S3（见 Gate新策略研究.md / gate_new_strategies.py）：
  RSI(14,Wilder) 收盘 <25 做多、>75 做空；08:00-20:00 UTC；
  本根振幅 > 前 20 根中位数；每天每币最多 2 笔；
  出场 RSI 回 50 / 止损 1xATR / 止盈 1.5xATR / 当天 23:30 强制平仓。
  180 天 1x 平均 -1.61%，221 笔，毛利基本为零、亏损几乎全是成本。

本迭代只改换手，不改出场、不改止损止盈、不加杠杆。
候选（全部只用前 90 天 2026-05-20~08-17 决定，见 §选型）：
  (a) 每周只做 RSI 最极端的 2 天 / 3 天（按当日 max|RSI-50| 排序）
  (b) 只做 SOL 一个币
  (c) RSI 阈值收紧到 20/80
  以及组合 A2+C、A3+C、B+C。

锁定的规则（由前 90 天数字决定，写死在 SELECTED，不读后 90 天）：
  >>> SELECTED = (c) RSI 20/80，三币全做，其他 S3 规则原样 <<<
  选型依据（前 90 天，三币平均，各币独立 10 万 USDT）：
    BASE 25/75 : -0.66%  102 笔  毛利 +564   成本 2,540
    A2 top2    : -0.72%   80 笔  毛利 -158   成本 1,992  <- 砍掉的 22 笔毛利 +722，是赚钱的交易
    A3 top3    : -0.65%   94 笔  毛利 +387   成本 2,340  <- 基本等于原版，无收益
    C 20/80    : -0.05%   44 笔  毛利 +941   成本 1,100  <- 砍掉的 58 笔毛利 -377、净 -1,817，是亏钱的交易
    A2+C       : -0.17%   41 笔  毛利 +510   成本 1,024  <- 比单用 C 差
    A3+C       : -0.05%   44 笔  与 C 完全相同（每周 top3 约束在 20/80 下不生效）
    B SOL 原版 : -0.07%   25 笔；B+C SOL 20/80: +0.17% 14 笔（+170 USDT，14 笔样本，噪声范围内）
  结论：(a) 反向筛选——RSI 最极端的日子恰恰是延续/止损的日子，砍掉的是好交易；
  (c) 正向筛选——20/80 砍掉的 58 笔是净亏 1,817 USDT 的交易，且三币全部改善
  （BTC -0.75%->-0.28%、ETH -1.16%->-0.05%、SOL -0.07%->+0.17%），毛利不降反升
  （+564->+941），成本砍 57%。(b) 单币是事后挑币，无信号改善，不采纳；
  B+C 单格 +0.17% 只有 14 笔，选它就是挑小样本最优格，不采纳。
  附带：(a) 的周内排序是事后排序（周一交易时不知道周五是不是最极端），
  本身带前视、不可直接交易；(c) 无前视，可直接执行。这也是选 (c) 的理由之一。

口径（与原版 S3 完全一致）：
  数据：data/gate_30m_180d_{BTC,ETH,SOL}_USDT.csv（2026-05-20~11-15，180 天），
  资金费率 data/gate_funding_180d_{...}.json。只用缓存，不重新取数。
  成本：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；资金费按实际费率计，
  计入毛利（与原版报告“毛利（扣资金费后）”口径一致）。
  仓位：每笔保证金 10% 权益，1x；收盘触发、下一根开盘成交；
  止损/止盈用盘中高低价触发（同根同时碰到先判止损，原版同款约定）；
  当天 23:30（最后一根 30m）强制平仓、不过夜；单日 -2% 熔断；
  单笔最坏情况（ATR+成本）> 1% 权益则跳过（原版同款风控）。
  窗口：前 90 天 2026-05-20~08-17 / 后 90 天 2026-08-18~11-15 / 全 180 天，
  各窗口重置 10 万 USDT 虚拟权益。
  引擎已用原版参数复核：BASE 前 90 天 BTC -0.75%/37 笔、ETH -1.16%/40 笔、
  SOL -0.07%/25 笔，与 Gate新策略研究.md 完全一致。

运行：python3 gate_iter_A.py
输出：终端打印全部表 + data/gate_iter_A_summary.json + data/gate_iter_A_trades.csv
"""
import csv
import json
import os
from datetime import datetime, timezone, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005}
ROUNDTRIP_COST = 0.0025  # 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
SPLIT_DAY = datetime(2026, 8, 18, tzinfo=timezone.utc)
ATR_PERIOD = 14

# --- 锁定的规则：(c) RSI 20/80，三币全做，其他 S3 规则原样（见文件头选型依据）---
SELECTED_RSI_LO = 20
SELECTED_RSI_HI = 80


def load_bars(symbol):
    path = os.path.join(DATA_DIR, f"gate_30m_180d_{symbol}.csv")
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    path = os.path.join(DATA_DIR, f"gate_funding_180d_{symbol}.json")
    with open(path) as f:
        return {int(k): float(v) for k, v in json.load(f).items()}


def group_days(bars, bars_per_day=48):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def rsi_wilder(closes, period=14):
    rsi = [None] * len(closes)
    if len(closes) <= period:
        return rsi
    gains, losses = [], []
    for i in range(1, period + 1):
        ch = closes[i] - closes[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    avg_g = sum(gains) / period
    avg_l = sum(losses) / period
    rsi[period] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    for i in range(period + 1, len(closes)):
        ch = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(ch, 0.0)) / period
        avg_l = (avg_l * (period - 1) + max(-ch, 0.0)) / period
        rsi[i] = 100 - 100 / (1 + avg_g / avg_l) if avg_l > 0 else 100.0
    return rsi


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    """多头费率>0付钱、空头收钱；只计 08:00/16:00 结算点。"""
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def daily_extremes(bars):
    """仅用于选型审计：每币每天 max|RSI-50|（08:00-20:00、过振幅过滤的 bar）。"""
    rsi = rsi_wilder([b["c"] for b in bars])
    idx = {b["t"]: i for i, b in enumerate(bars)}
    ext = {}
    for day, db in group_days(bars, 48).items():
        m = 0.0
        for b in db:
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            if not (8.0 <= hour < 20.0):
                continue
            gi = idx[b["t"]]
            r = rsi[gi]
            if r is None or gi < 20:
                continue
            ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
            if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                continue
            m = max(m, abs(r - 50))
        ext[day] = m
    return ext


def weekly_allowed(ext, topk):
    """仅用于选型审计：周一为一周起点，每周按当日极值取前 topk 天。"""
    from collections import defaultdict
    weeks = defaultdict(list)
    for d, e in ext.items():
        monday = d - timedelta(days=d.weekday())
        weeks[monday].append((d, e))
    allowed = set()
    for monday, lst in weeks.items():
        lst.sort(key=lambda x: -x[1])
        for d, e in lst[:topk]:
            if e > 0:
                allowed.add(d)
    return allowed


def run_s3(bars, funding, symbol, days_subset, rsi_lo=25, rsi_hi=75,
           allowed_days=None, label=""):
    """S3 引擎（原版 gate_new_strategies.py run_single 的 S3 分支，一字不改的逻辑，
    只把 RSI 阈值和每周允许交易日做成参数）。"""
    atr = atr_wilder(bars)
    rsi = rsi_wilder([b["c"] for b in bars])
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 48)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / 1 - maint
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        if allowed_days is not None and day not in allowed_days:
            continue
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            gi = idx_of_t[b["t"]]
            a = atr[gi]
            if pos is not None:
                adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                       else (b["h"] - pos["entry"]) / pos["entry"])
                if adv >= liq_move:
                    close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                    pos = None
                    continue
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                r = rsi[gi]
                if r is not None:
                    if pos["direction"] == 1 and r >= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                    if pos["direction"] == -1 and r <= 50:
                        close_trade(pos, b["t"], b["c"], "rsi_mid"); pos = None; continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < 2 and i < len(day_bars) - 1:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                if a is None:
                    continue
                if not (8.0 <= hour < 20.0):
                    continue
                r = rsi[gi]
                if r is None or gi < 20:
                    continue
                ranges = sorted(bars[j]["h"] - bars[j]["l"] for j in range(gi - 20, gi))
                if (b["h"] - b["l"]) <= ranges[len(ranges) // 2]:
                    continue
                sig = 0
                if r < rsi_lo:
                    sig = 1
                elif r > rsi_hi:
                    sig = -1
                if sig == 0:
                    continue
                nxt = day_bars[i + 1]
                entry = nxt["o"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - a if sig == 1 else entry + a
                tp = entry + 1.5 * a if sig == 1 else entry - 1.5 * a
                pos = {"symbol": symbol, "variant": label, "direction": sig,
                       "entry_t": nxt["t"], "entry": entry, "stop": stop, "tp": tp,
                       "atr": a, "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "price_pnl": 0.0, "hold_min": None,
                       "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] <= 0]
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0.0
    avg_loss = abs(sum(t["pnl"] for t in losses) / len(losses)) if losses else 0.0
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    cost = sum(t["cost_usdt"] for t in trades)
    res = {"label": label, "symbol": symbol,
           "trades": len(trades),
           "win_rate": round(len(wins) / len(trades), 4) if trades else None,
           "net_return": round((equity - START_EQUITY) / START_EQUITY, 4),
           "final_equity": round(equity, 2),
           "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
           "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
           "total_pnl": round(sum(t["pnl"] for t in trades), 2),
           "gross_usdt": round(gross, 2), "cost_usdt": round(cost, 2),
           "max_dd": round(mdd, 4), "liquidations": sum(1 for t in trades if t.get("liquidated")),
           "days": len(days),
           "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None}
    return res, trades


def main():
    print("迭代 A：S3 低换手版（RSI 20/80，三币，1x，全模拟）")
    print("窗口：2026-05-20~11-15，前 90 天 05-20~08-17，后 90 天 08-18~11-15")
    data = {}
    for sym in SYMBOLS:
        bars = load_bars(sym)
        funding = load_funding(sym)
        data[sym] = (bars, funding)
        days = group_days(bars, 48)
        print(f"[{sym}] 完整交易日：{len(days)} 天，首日 {min(days)} 末日 {max(days)}")

    # ---- 选型审计：只用前 90 天（本表是锁定规则的依据，不读后 90 天）----
    print("\n=== 选型审计：前 90 天（2026-05-20~08-17），三币平均 ===")
    candidates = [
        ("BASE 25/75", dict(rsi_lo=25, rsi_hi=75)),
        ("A2 weekly-top2", dict(rsi_lo=25, rsi_hi=75, topk=2)),
        ("A3 weekly-top3", dict(rsi_lo=25, rsi_hi=75, topk=3)),
        ("C 20/80 [SELECTED]", dict(rsi_lo=20, rsi_hi=80)),
        ("A2+C", dict(rsi_lo=20, rsi_hi=80, topk=2)),
        ("A3+C", dict(rsi_lo=20, rsi_hi=80, topk=3)),
    ]
    for label, kw in candidates:
        tot_net = tot_tr = tot_gross = tot_cost = 0
        per = []
        for sym in SYMBOLS:
            bars, funding = data[sym]
            days_all = set(group_days(bars, 48).keys())
            days_a = {d for d in days_all if d < SPLIT_DAY.date()}
            allowed = weekly_allowed(daily_extremes(bars), kw["topk"]) if "topk" in kw else None
            res, _ = run_s3(bars, funding, sym, days_a, rsi_lo=kw["rsi_lo"],
                            rsi_hi=kw["rsi_hi"], allowed_days=allowed, label=label)
            per.append(f"{sym[:3]} {res['net_return']*100:+.2f}% n={res['trades']}")
            tot_net += res["net_return"]; tot_tr += res["trades"]
            tot_gross += res["gross_usdt"]; tot_cost += res["cost_usdt"]
        print(f"{label}: AVG {tot_net/3*100:+.2f}%  trades={tot_tr} "
              f"gross={tot_gross:+.0f} cost={tot_cost:.0f} net={tot_gross-tot_cost:+.0f}  "
              + " | ".join(per))

    # ---- 锁定规则：(c) 20/80，前 90 / 后 90 / 全 180 ----
    print("\n=== 锁定规则 (c) RSI 20/80：分窗口结果（各币独立 10 万 USDT，1x）===")
    all_results = []
    all_trades = []
    for sym in SYMBOLS:
        bars, funding = data[sym]
        days_all = set(group_days(bars, 48).keys())
        days_a = {d for d in days_all if d < SPLIT_DAY.date()}
        days_b = {d for d in days_all if d >= SPLIT_DAY.date()}
        for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
            res, trades = run_s3(bars, funding, sym, subset,
                                 rsi_lo=SELECTED_RSI_LO, rsi_hi=SELECTED_RSI_HI,
                                 label="A-S3-20/80")
            res["split"] = split_name
            all_results.append(res)
            if split_name == "180d":
                for t in trades:
                    t["variant"] = "A-S3-20/80"
                    t["split"] = "180d"
                all_trades.extend(trades)
            print(f"[A-S3-20/80 {sym} {split_name}] 笔数={res['trades']} "
                  f"胜率={res['win_rate']} 净收益={res['net_return']*100:+.2f}% "
                  f"盈亏比={res['profit_factor']} 最大回撤={res['max_dd']*100:.2f}% "
                  f"毛利={res['gross_usdt']:+.0f} 成本=-{res['cost_usdt']:.0f} "
                  f"平均持仓={res['avg_hold_min']}分钟 爆仓={res['liquidations']}")

    print("\n=== 汇总：三币平均净收益（锁定规则 20/80，1x）===")
    for split_name in ["180d", "前90d", "后90d"]:
        rs = [r for r in all_results if r["split"] == split_name]
        avg = sum(r["net_return"] for r in rs) / len(rs)
        tot = sum(r["trades"] for r in rs)
        gross = sum(r["gross_usdt"] for r in rs)
        cost = sum(r["cost_usdt"] for r in rs)
        print(f"A-S3-20/80 {split_name}：平均净收益 {avg*100:+.2f}%  总笔数 {tot}  "
              f"毛利={gross:+.0f} 成本=-{cost:.0f} 净={gross-cost:+.0f} USDT")

    # ---- 与原版 S3 对照（同口径，取自 gate_new_summary.json 的已发表数字）----
    print("\n=== 对照：原版 S3（25/75）三币平均 ===")
    print("原版 S3 前90d：-0.66%（102 笔）| 后90d：-0.96%（119 笔）| 全180d：-1.61%（221 笔）")

    with open(os.path.join(DATA_DIR, "gate_iter_A_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_A_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "split", "symbol", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_usdt", "price_pnl_usdt",
                    "cost_usdt", "funding_cost_usdt", "reason", "liquidated", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x.get("symbol", ""))):
            w.writerow([t.get("variant", ""), t.get("split", ""), t.get("symbol", ""),
                        "LONG" if t.get("direction") == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t.get("entry"), t.get("exit"), t.get("notional"),
                        round(t["pnl"], 2), round(t.get("price_pnl", 0), 2),
                        round(t.get("cost_usdt", 0), 2), round(t.get("funding_cost_usdt", 0), 2),
                        t.get("reason", ""), t.get("liquidated", False), t.get("hold_min")])
    print("\n汇总已写入：data/gate_iter_A_summary.json")
    print("明细已写入：data/gate_iter_A_trades.csv")
    print("模拟结束：本脚本不下单、不开户、不碰真钱。")


if __name__ == "__main__":
    main()
