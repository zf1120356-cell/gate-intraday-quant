#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十八轮：Breaker 回测（学习笔记方向 3）
=====================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（用户按顺序继续）：学习笔记方向 3。第十一、十二轮的 OB 逻辑
全是“OB 被回踩后继续走”，从来没测过“OB 被突破失效后反过来当
支撑/压力”的那一面。Breaker 赌的是角色反转，不是 OB 支撑。

定义出处（跑前定死，单组参数，不许用全样本挑）：
  教程：smc-ai-tutor skills/smc-learning/references/06-进阶概念与
  入场模型.md A1（Breaker Block）+ 学习笔记 §3 方向 3 原文。
  看涨 Breaker（做多，看跌版上下镜像）：
    1. L → H：已确认摆动低 L（N=3 分形，确认于 i+3 根收盘时），
       之后已确认摆动高 H（H > L）。
    2. 扫荡：随后一根 1h 收盘价跌破 L（影线刺破 + 收盘收回不算，
       必须实体收盘跌破 L），扫掉 L 下方流动性。
    3. MSS 两步确认（本轮的操作定义，跑前写死，与笔记原文的
       “CHoCH 之后新方向再出 BOS”对应）：
       第 1 步 CHoCH：扫荡后首次收盘回到 L 上方（收复被扫的摆动低）；
       第 2 步 BOS： 第 1 步之后首次收盘突破 H，且该根实体
       >= 0.5xATR（位移证据，照抄第十四轮 DISP_MIN_ATR=0.5）。
       两步须先后出现在不同根上；同一根不能同时完成两步。
       第 2 步完成的那根即 Breaker 形成根（BOS 根）。
    4. Breaker 区间 = H 处、下跌开始前那段上涨 K 线的实体（教程
       取前者的口径）：腿 L→H 内实体最大的那根看涨 K 线的实体
       [min(o,c), max(o,c)]；腿内无看涨 K 线则该 setup 作废。
    5. 失效：回踩前 1h 收盘穿过 Breaker 区间远端（做多：收盘 <
       zone_lo）则 Breaker 失效。
  Mitigation（下跌没能跌破 L 的失败摆动版）不做，只做有扫荡的
  Breaker，以便和 Mitigation 对照时分得清（笔记原文）。

  与笔记原文的出入（跑前写明，不事后改）：
    (a) 止损：笔记原文是结构止损（放在 L 之下）+ 止盈看对侧流动性；
        本轮按任务要求和用户定死的 1:2 口径，统一用固定 1xATR 止损 /
        2xATR 止盈（simulate_generic，与第十一轮 S2 对照同一出场口径，
        这样对照比较的只是“入场”本身）。结构止损的距离只作诊断：
        每笔记录入场价到 Breaker 区间远端的距离（xATR），见报告 §6；
        第十七轮已在同一批 QM 信号上测过结构止损（-0.32% 对固定 ATR
        -0.28%，结构止损距离中位数 2.23xATR），不再重复开臂。
    (b) 主臂 A 的确认：笔记原文是 15m CHoCH 确认；15m 数据只有
        103 天，主臂放 365d 必须去掉它，改用 1h 确认（触及根收盘守住
        区间下沿）；笔记原文版放在 D 诊断臂（103d，1h 结构 + 15m
        CHoCH），与第十七轮 A/D 分工完全一致。
    (c) 扫荡等待与 MSS 等待各设 48 根 1h 上限（笔记未写，跑前定死）：
        48 根内无扫荡则 pair 过期；扫荡后 48 根内 MSS 未完成则过期。

组合（4 个，全部跑前定死）：
  A 主臂 Breaker-1h-回测：1h 定结构 + 1h 回测入场。Breaker 形成后
    24 根 1h 内，价格首次回落触及 Breaker 实体区间（long：某根 low
    <= zone_hi），且该触及根收盘守住区间下沿（close >= zone_lo）
    才进，下一根 1h 开盘进；收盘穿过下沿则 Breaker 失效；24 根内
    未触及作废。固定 1xATR/2xATR。365d 1h，8 币。
  B 对照 1 S2 原版：第十一轮 S2 一字不变复用（1h BOS + OB/FVG
    回踩，15m 找入场，48 根窗口，08:00-20:00 UTC 信号窗口；注意：
    第十一轮的 1h 结构取自 15m 合成的 1h（103x24 根），不是 365d
    1h 缓存，本轮照抄这一点，否则 BOS 数对不上），用来
    判断“回测已失效翻转的 OB”相对“回测未失效的 OB”有没有增值。
    103d 15m，8 币。
  C 对照 2 直接追 Breaker 破位：Breaker 形成根（BOS 根）的下一根
    1h 开盘直接顺破位方向进，不等回测；固定 1xATR/2xATR。用来判断
    “回测入场本身”相对“追破位”有没有增值。365d 1h，8 币。
  D 诊断臂 Breaker-15m（笔记原文版）：1h 定 Breaker 结构，15m 找
    触发——形成后 96 根 15m 内，价格先触及 Breaker 实体区间（触及根
    收盘守住下沿），随后 15m 出现小级别 CHoCH（收盘破最近已确认
    15m 摆动高/低，N=3，且被破摆动点须在触及根或之后形成）才进，
    下一根 15m 开盘进；触及前或确认前 15m 收盘穿过区间远端则失效。
    固定 1xATR/2xATR（15m ATR）。103d，8 币。D 只是诊断臂，不与
    A/C 同口径比较全期数字；它的作用是回答“加了 15m CHoCH 确认
    之后数字变不变”。

  A/C vs 第十一轮 S2（B）：同为“回踩再进”，但 S2 回踩的是未失效的
    OB/FVG（破位后形成的订单区，价格没穿过它），本轮回踩的是已失效
    翻转的 OB（价格先收盘穿过它、再回来）；S2 的 OB 取 BOS 前 10 根
    内最后一根反向 K 线（全区间），本轮 Breaker 取腿内实体最大的
    看涨 K 线（只取实体）；S2 用 15m 入场、48 根窗口、08:00-20:00
    信号窗口，本轮 A 用 1h 入场、24 根窗口、无信号窗口（Killzone
    只作诊断）。
  A vs C：同一批 Breaker 形成事件，区别只在入场时点（回测确认进
    vs 破位当根追），直接回答“回测这一步值多少钱”。
  A vs D：同一套 1h Breaker 结构，区别只在触发层（1h 触及 + 收盘
    守住 vs 15m 触及 + CHoCH 确认）。
  A/C vs 第十二轮 S1/S2：十二轮回踩的也是 OB/FVG（未失效），且
    OB 取位移腿内最大实体同向 K 线（常是破位根本身）；本轮的
    Breaker 区间取的是破位前那段腿里的反向大实体 K 线，方向相反。
  A/C vs 第十四轮 B-T1/B-T2：十四轮赌诱导验证的 BOS + 三条件 OB +
    MSS，本轮不要求诱导、不要求 OB 三条件——Breaker 的结构链本身
    就是确认（扫荡 + 两步 MSS + 回测）；十四轮 MSS 是回踩触及后的
    确认，本轮 MSS 是 Breaker 形成时的确认，位置相反。
  A/C vs 第十七轮 QM：同为扫荡后反转 + 回测，但 QM 回测的是左肩
    QML（破位前就存在的结构位），本轮回测的是失效 OB 翻转成的
    Breaker（破位后才存在的反应区）；QM 用结构止损，本轮用固定
    1xATR/2xATR（见出入 (a)）。

通用口径（与前十七轮一致）：
  每笔保证金 10% 权益、1x；信号根收盘触发、下一根开盘成交；止损/
  止盈用盘中高低价触发（同根同时碰到先判止损）；单日 -2% 熔断；
  单笔最坏情况（止损距离 + 成本）> 1% 权益跳过；每天每币最多 2 笔；
  最多持 8 根 1h（A/B/C）/ 16 根 15m（B/D，B 沿用第十一轮口径）；
  当天收盘强制平仓，持仓不过夜；成本主口径 Taker（一轮名义 x 0.25%，
  taker 0.075% + 滑点 0.05%，双边）；资金费按实际费率计（08:00/
  16:00 结算点，前半段 2026-05-21 之前无数据按 0 计）。M1/M2 只做
  对照（第九轮同款）。
  Killzone 只作诊断、不作硬过滤（第十二轮教训：教程明说加密时段
  效应弱，只能参考；且第十二轮把它当硬过滤时它成了最狠的筛子）。

前视防控（写死在代码里）：
  - 摆动点、扫荡、MSS 两步、回踩触及、15m CHoCH 全部只用已收盘的根；
    摆动点须在确认根（bar i+3）收盘后才可用。
  - 入场永远是触发根的下一根开盘价。
  - D 的 15m 触发根须严格晚于 1h BOS 根收盘时刻；触及根与 CHoCH 根
    必须是不同根；被破的 15m 摆动点须在触及根或之后形成。

数据：
  1h：2025-11-16~2026-11-15，365 天，8 币各 8,761 根（与第十一至
    十七轮同一缓存，含末根 2026-11-16 00:00 半根，照抄前轮口径不
    特殊处理）；前半段 2025-11-16~2026-05-19（185 天）、后半段
    2026-05-20~2026-11-15（180 天）。
  15m：2026-08-06~2026-11-16，103 天，8 币各 9,888 根；前半段
    2026-08-06~09-25（51 天）、后半段 2026-09-26~11-16（52 天）。
  8 币：BTC / ETH / SOL / DOGE / LINK / XRP / BNB / ADA。
  全部复用本地缓存，不联网。各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

运行：python3 gate_iter_round18.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round18_summary.json
      + data/gate_iter_round18_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)

import gate_iter_round11 as r11

SYMBOLS = r11.SYMBOLS
START_EQUITY = r11.START_EQUITY
MARGIN_FRAC = r11.MARGIN_FRAC
ROUNDTRIP_COST = r11.ROUNDTRIP_COST
SPLIT_1H = r11.SPLIT_1H
SPLIT_15M = r11.SPLIT_15M
load_bars = r11.load_bars
load_funding = r11.load_funding
atr_wilder = r11.atr_wilder
confirmed_levels = r11.confirmed_levels
synthesize = r11.synthesize
group_days = r11.group_days
funding_cost_between = r11.funding_cost_between
maker_cost = r11.maker_cost
t_value = r11.t_value
max_dd = r11.max_dd
summarize = r11.summarize
build_s2_signals_full = r11.build_s2_signals_full
simulate_generic = r11.simulate_generic

# ---- 锁定的参数（跑前定死）----
SWING_N = 3            # 摆动点 N=3（抄识别程序默认，笔记方向 3 原文）
DISP_MIN_ATR = 0.5     # MSS 第 2 步位移证据：实体 >= 0.5xATR（照抄第十四轮）
SWEEP_WAIT = 48        # pair 形成后等扫荡的上限（1h 根数，跑前定死）
MSS_WAIT = 48          # 扫荡后等 MSS 完成的上限（1h 根数，跑前定死）
RETRACE_BARS_1H = 24   # Breaker 形成后回测窗口（1h 根数，照抄 QM）
RETRACE_BARS_15M = 96  # Breaker 形成后回测窗口（15m 根数，= 24h）
MAX_HOLD_1H = 8
MAX_HOLD_15M = 16
MAX_PER_DAY = 2
T15_START = datetime(2026, 8, 6, tzinfo=timezone.utc)
T15_END = datetime(2026, 11, 16, tzinfo=timezone.utc)


def in_killzone(t):
    dt = datetime.fromtimestamp(t, timezone.utc)
    h = dt.hour + dt.minute / 60.0
    return (8.0 <= h < 11.0) or (13.0 <= h < 16.0)


def breaker_zone(bars, i_from, i_to, direction):
    """腿 [i_from, i_to] 内实体最大的顺腿方向 K 线的实体区间。
    direction=+1（看涨 Breaker）：腿是上涨腿，取最大实体看涨 K 线；
    direction=-1：腿是下跌腿，取最大实体看跌 K 线。
    返回 (lo, hi, bar_idx)，无符合 K 线则 None。"""
    best = None
    best_body = -1.0
    for k in range(i_from, i_to + 1):
        b = bars[k]
        if direction == 1 and b["c"] > b["o"]:
            body = b["c"] - b["o"]
            if body > best_body:
                best_body = body
                best = (min(b["o"], b["c"]), max(b["o"], b["c"]), k)
        elif direction == -1 and b["c"] < b["o"]:
            body = b["o"] - b["c"]
            if body > best_body:
                best_body = body
                best = (min(b["o"], b["c"]), max(b["o"], b["c"]), k)
    return best


# ----------------------------------------------------------------------
# Breaker 形成检测（1h，N=3，全部只用已收盘根）
# direction=+1 看涨（做多）：L → H → 收盘跌破 L（扫荡）→ 收复 L（CHoCH）
#   → 收盘突破 H 且实体 >= 0.5xATR（BOS + 位移）→ Breaker 形成。
# direction=-1 看跌：镜像。
# ----------------------------------------------------------------------
def detect_breaker_events_dir(bars, atr, n, direction):
    """返回 (events, stats)。
    events 每项：{dir, zone_lo, zone_hi, zone_bar, L, H, sweep_ext,
                  bos_idx, bos_close_t, sweep_idx, step1_idx, atr_bos}。"""
    sh_level, sh_idx, sl_level, sl_idx = confirmed_levels(bars, n)
    closes = [b["c"] for b in bars]
    events = []
    stats = Counter()
    consumed = set()  # 已消费的 (L_bar, H_bar)，防同一对重复成 Breaker
    state = "idle"
    L = H = None
    iL = iH = -1
    zone = None
    sweep_ext = None
    sweep_j = -1
    step1_j = -1
    ob_failed_counted = False
    for j in range(1, len(bars)):
        b, c = bars[j], closes[j]
        sh, sl = sh_level[j], sl_level[j]
        shi, sli = sh_idx[j], sl_idx[j]
        if state == "idle":
            if direction == 1:
                ok = (sl is not None and sh is not None and shi > sli
                      and (sli, shi) not in consumed)
                if ok:
                    L, H, iL, iH = sl, sh, sli, shi
                    zone = breaker_zone(bars, iL, iH, direction)
                    if zone is None:
                        stats["pairs_no_zone"] += 1
                        consumed.add((sli, shi))
                        continue
                    state = "wait_sweep"
                    stats["pairs"] += 1
            else:
                ok = (sh is not None and sl is not None and sli > shi
                      and (shi, sli) not in consumed)
                if ok:
                    L, H, iL, iH = sh, sl, shi, sli
                    zone = breaker_zone(bars, iL, iH, direction)
                    if zone is None:
                        stats["pairs_no_zone"] += 1
                        consumed.add((shi, sli))
                        continue
                    state = "wait_sweep"
                    stats["pairs"] += 1
        elif state == "wait_sweep":
            # H 更新：等待期间出现更高的已确认摆动高，腿延长、区间重算
            if direction == 1:
                if sh is not None and shi > iH and sh > H:
                    H, iH = sh, shi
                    zone = breaker_zone(bars, iL, iH, direction)
                    stats["h_updated"] += 1
                swept = c < L
                broke_h = c > H
            else:
                if sl is not None and sli > iH and sl < H:
                    H, iH = sl, sli
                    zone = breaker_zone(bars, iL, iH, direction)
                    stats["h_updated"] += 1
                swept = c > L
                broke_h = c < H
            if swept:
                sweep_ext = b["l"] if direction == 1 else b["h"]
                sweep_j = j
                step1_j = -1
                ob_failed_counted = False
                state = "wait_mss"
                stats["sweeps"] += 1
            elif broke_h:
                consumed.add((iL, iH))
                state = "idle"
                stats["invalid_bos_first"] += 1
            elif j - iH > SWEEP_WAIT:
                consumed.add((iL, iH))
                state = "idle"
                stats["expired_no_sweep"] += 1
        elif state == "wait_mss":
            # 扫荡极值可加深（只更新极值，不改 L/H/区间）
            if direction == 1:
                sweep_ext = min(sweep_ext, b["l"])
                reclaim = c > L
                bos = c > H
            else:
                sweep_ext = max(sweep_ext, b["h"])
                reclaim = c < L
                bos = c < H
            if step1_j < 0:
                if reclaim:
                    step1_j = j
                    stats["step1_done"] += 1
                # 同一根不判第 2 步（两步须在不同根上）
            else:
                if bos and not ob_failed_counted:
                    stats["ob_failed"] += 1
                    ob_failed_counted = True
                if bos:
                    body = abs(b["c"] - b["o"])
                    if atr[j] is not None and body >= DISP_MIN_ATR * atr[j]:
                        events.append({
                            "dir": direction,
                            "zone_lo": zone[0], "zone_hi": zone[1],
                            "zone_bar": zone[2],
                            "L": L, "H": H, "sweep_ext": sweep_ext,
                            "bos_idx": j, "bos_close_t": b["t"] + 3600,
                            "sweep_idx": sweep_j, "step1_idx": step1_j,
                            "atr_bos": atr[j]})
                        consumed.add((iL, iH))
                        state = "idle"
                        stats["breaker_formed"] += 1
                    else:
                        stats["step2_no_disp"] += 1
            if state == "wait_mss" and j - sweep_j > MSS_WAIT:
                consumed.add((iL, iH))
                state = "idle"
                stats["expired_no_mss"] += 1
    return events, stats


def detect_breaker_events(bars, atr, n=SWING_N):
    """双向 Breaker 事件（看涨 + 看跌），按 bos_idx 时间顺序合并。"""
    ev_l, st_l = detect_breaker_events_dir(bars, atr, n, +1)
    ev_s, st_s = detect_breaker_events_dir(bars, atr, n, -1)
    events = sorted(ev_l + ev_s, key=lambda e: e["bos_idx"])
    stats = Counter()
    for k in set(list(st_l.keys()) + list(st_s.keys())):
        stats[k + "_long"] = st_l.get(k, 0)
        stats[k + "_short"] = st_s.get(k, 0)
        stats[k] = st_l.get(k, 0) + st_s.get(k, 0)
    stats["breaker_formed_long"] = len(ev_l)
    stats["breaker_formed_short"] = len(ev_s)
    return events, stats


# ----------------------------------------------------------------------
# A 主臂回测入场（1h）：形成后 24 根内首次回落触及区间 + 收盘守住
# ----------------------------------------------------------------------
def build_breaker_signals_1h(bars, atr, events):
    """返回 (signals, stats)。
    signals key=入场根 t，value={direction, atr, tag, zone_lo, zone_hi,
    zone_width_atr, sweep_depth_atr, bos_idx}。"""
    sigs = {}
    stats = Counter()
    for ev in events:
        d = ev["dir"]
        bos = ev["bos_idx"]
        zone_lo, zone_hi = ev["zone_lo"], ev["zone_hi"]
        stats["events"] += 1
        outcome = None
        for j in range(bos + 1, min(bos + RETRACE_BARS_1H + 1, len(bars) - 1)):
            b = bars[j]
            c = b["c"]
            # 先判失效：收盘穿过区间远端
            if (d == 1 and c < zone_lo) or (d == -1 and c > zone_hi):
                stats["invalidated"] += 1
                outcome = "invalidated"
                break
            touched = (b["l"] <= zone_hi) if d == 1 else (b["h"] >= zone_lo)
            if not touched:
                continue
            stats["touched"] += 1
            # 确认：触及根收盘守住区间下沿（long: close >= zone_lo）
            held = (c >= zone_lo) if d == 1 else (c <= zone_hi)
            if not held:
                stats["invalidated"] += 1
                outcome = "invalidated"
                break
            if atr[j] is None:
                outcome = "no_atr"
                break
            entry_t = bars[j + 1]["t"]
            if entry_t in sigs:
                stats["dup_entry"] += 1
                outcome = "dup"
                break
            zw = zone_hi - zone_lo
            sd = (abs(ev["L"] - ev["sweep_ext"]) / atr[j]
                  if atr[j] else None)
            sigs[entry_t] = {"direction": d, "atr": atr[j],
                             "tag": f"BRK{'+' if d == 1 else '-'}",
                             "zone_lo": zone_lo, "zone_hi": zone_hi,
                             "zone_width_atr": round(zw / atr[j], 2),
                             "sweep_depth_atr": (round(sd, 2)
                                                 if sd is not None else None),
                             "bos_idx": bos}
            stats["signals"] += 1
            outcome = "signal"
            break
        if outcome is None:
            stats["expired"] += 1
    return sigs, stats


# ----------------------------------------------------------------------
# D 诊断臂回测入场（15m，笔记原文版）：形成后 96 根 15m 内先触及区间
# （触及根收盘守住下沿），随后 15m 出现小级别 CHoCH 才进。
# ----------------------------------------------------------------------
def build_breaker_signals_15m(bars1h, bars15, atr15, events):
    sh15, sh15_idx, sl15, sl15_idx = confirmed_levels(bars15, SWING_N)
    idx15_of_t = {b["t"]: i for i, b in enumerate(bars15)}
    sigs = {}
    stats = Counter()
    for ev in events:
        if not (int(T15_START.timestamp()) <= ev["bos_close_t"]
                < int(T15_END.timestamp())):
            continue
        stats["events_in_window"] += 1
        start = idx15_of_t.get(ev["bos_close_t"])
        if start is None:
            stats["no_start15"] += 1
            continue
        d = ev["dir"]
        zone_lo, zone_hi = ev["zone_lo"], ev["zone_hi"]
        touched = False
        touch_k = -1
        outcome = None
        for k in range(start, min(start + RETRACE_BARS_15M, len(bars15) - 1)):
            b = bars15[k]
            c = b["c"]
            # 先判失效：收盘穿过区间远端
            if (d == 1 and c < zone_lo) or (d == -1 and c > zone_hi):
                stats["invalidated"] += 1
                outcome = "invalidated"
                break
            if not touched:
                hit = (b["l"] <= zone_hi) if d == 1 else (b["h"] >= zone_lo)
                if not hit:
                    continue
                held = (c >= zone_lo) if d == 1 else (c <= zone_hi)
                if not held:
                    stats["invalidated"] += 1
                    outcome = "invalidated"
                    break
                touched = True
                touch_k = k
                stats["touched"] += 1
                continue
            # 已触及：等 15m CHoCH（收盘破最近已确认摆动高/低，且该摆动点
            # 须在触及根或之后形成）
            if d == 1:
                sh = sh15[k]
                choch = (sh is not None and sh15_idx[k] >= touch_k
                         and bars15[k - 1]["c"] <= sh < c)
            else:
                sl = sl15[k]
                choch = (sl is not None and sl15_idx[k] >= touch_k
                         and bars15[k - 1]["c"] >= sl > c)
            if not choch:
                continue
            stats["triggered"] += 1
            if atr15[k] is None:
                outcome = "no_atr"
                break
            zw = zone_hi - zone_lo
            entry_t = bars15[k + 1]["t"]
            if entry_t in sigs:
                stats["dup_entry"] += 1
                outcome = "dup"
                break
            sigs[entry_t] = {"direction": d, "atr": atr15[k],
                             "tag": f"BRK15{'+' if d == 1 else '-'}",
                             "zone_lo": zone_lo, "zone_hi": zone_hi,
                             "zone_width_atr": round(zw / atr15[k], 2),
                             "sweep_depth_atr": None,
                             "bos_idx": ev["bos_idx"]}
            stats["signals"] += 1
            outcome = "signal"
            break
        if outcome is None:
            stats["expired"] += 1
    return sigs, stats


# ----------------------------------------------------------------------
# C 对照 2：直接追 Breaker 破位（不回测）
# ----------------------------------------------------------------------
def build_breaker_chase_signals(bars, atr, events):
    """返回 (signals, stats)。入场 = BOS 根下一根 1h 开盘。"""
    sigs = {}
    stats = Counter()
    for ev in events:
        d = ev["dir"]
        bos = ev["bos_idx"]
        stats["events"] += 1
        if bos + 1 >= len(bars):
            stats["no_next_bar"] += 1
            continue
        if atr[bos] is None:
            stats["no_atr"] += 1
            continue
        entry_t = bars[bos + 1]["t"]
        if entry_t in sigs:
            stats["dup_entry"] += 1
            continue
        zw = ev["zone_hi"] - ev["zone_lo"]
        sigs[entry_t] = {"direction": d, "atr": atr[bos],
                         "tag": f"BRKchase{'+' if d == 1 else '-'}",
                         "zone_lo": ev["zone_lo"], "zone_hi": ev["zone_hi"],
                         "zone_width_atr": round(zw / atr[bos], 2),
                         "sweep_depth_atr": None,
                         "bos_idx": bos}
        stats["signals"] += 1
    return sigs, stats


def main():
    print("盈利策略迭代 · 第十八轮：Breaker 回测（学习笔记方向 3，全模拟）")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；"
          "时间戳对齐、零缺口。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    all_results, all_trades = [], []
    pooled = {}

    def record(res, trades_full, family, variant, gran, split_fn, setup_stats=None,
               extra=None):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        if setup_stats is not None:
            res["setup_stats"] = {k: (dict(v) if isinstance(v, Counter) else v)
                                  for k, v in setup_stats.items()}
        if extra:
            res.update(extra)
        all_results.append(res)
        if trades_full is not None:
            pooled.setdefault(family, [])
            for t in trades_full:
                pooled[family].append(t["pnl"] / START_EQUITY)
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def split_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def _f(v, fmt):
        return "None" if v is None else format(v, fmt)

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={_f(res['win_rate'], '.4f')} "
              f"盈亏比={_f(res['profit_factor'], '.2f')} 平均赢={res['avg_win_usdt']:+.0f} "
              f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={_f(res['t_taker'], '.2f')}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={_f(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={_f(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    def run_family(family, label, bars_by_sym, signals_by_sym, funding_by_sym,
                   subsets, max_per_day, max_hold, bars_per_day, split_fn, gran,
                   setup_stats_by_sym=None, sig_zone_by_sym=None):
        for sym in SYMBOLS:
            bars = bars_by_sym[sym]
            funding = funding_by_sym[sym]
            for wname, subset in subsets:
                trades, curve, ndays = simulate_generic(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    max_per_day, max_hold, label, bars_per_day)
                res = summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                if trades:
                    kz = [t for t in trades if in_killzone(t["entry_t"])]
                    res["killzone_trades"] = len(kz)
                    res["killzone_taker_net_pct"] = round(
                        sum(t["pnl"] for t in kz) / START_EQUITY, 4)
                    # 诊断：结构止损距离（入场价到 Breaker 区间远端，xATR）
                    if sig_zone_by_sym is not None:
                        zmap = sig_zone_by_sym[sym]
                        dists = []
                        for t in trades:
                            z = zmap.get(t["entry_t"])
                            if z is None or not t.get("atr"):
                                continue
                            far = z["zone_lo"] if t["direction"] == 1 else z["zone_hi"]
                            dists.append(abs(t["entry"] - far) / t["atr"])
                        if dists:
                            dists.sort()
                            res["median_struct_stop_dist_atr"] = round(
                                dists[len(dists) // 2], 2)
                            res["struct_stop_dist_atr_range"] = [
                                round(dists[0], 2), round(dists[-1], 2)]
                record(res, trades if subset is None else None, family, label,
                       gran, split_fn,
                       setup_stats_by_sym.get(sym) if setup_stats_by_sym else None)
                show(res, sym, wname)

    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}

    # ================= Breaker 形成检测（1h，N=3）=================
    print("\n=== Breaker 形成检测（1h，N=3，8 币）===")
    brk_events, brk_stats = {}, {}
    for sym in SYMBOLS:
        brk_events[sym], brk_stats[sym] = detect_breaker_events(
            data1h[sym][0], atr1h[sym])
    tot = Counter()
    for v in brk_stats.values():
        tot.update(v)
    print(f"[Breaker 形成] 8 币合计：OB 候选 pairs={tot['pairs']}（无区间 "
          f"{tot['pairs_no_zone']}）/ 扫荡 sweeps={tot['sweeps']} / 第 1 步 "
          f"step1_done={tot['step1_done']} / OB 失效 ob_failed={tot['ob_failed']} / "
          f"Breaker 形成 breaker_formed={tot['breaker_formed']} "
          f"（多 {tot['breaker_formed_long']} / 空 {tot['breaker_formed_short']}）/ "
          f"作废：先破 H {tot['invalid_bos_first']} / 无扫荡过期 "
          f"{tot['expired_no_sweep']} / MSS 未完成过期 {tot['expired_no_mss']} / "
          f"第 2 步无位移 {tot['step2_no_disp']} / H 更新 {tot['h_updated']}")

    # ================= A 主臂：Breaker-1h-回测 =================
    print("\n=== A 主臂：Breaker-1h-回测（365d 1h，8 币）===")
    sig_a, st_a = {}, {}
    for sym in SYMBOLS:
        sig_a[sym], st_a[sym] = build_breaker_signals_1h(
            data1h[sym][0], atr1h[sym], brk_events[sym])
    tot_a = Counter()
    for v in st_a.values():
        tot_a.update(v)
    print(f"[A] 回测漏斗（8 币合计）：Breaker 事件 {tot_a['events']} / 触及 "
          f"{tot_a['touched']} / 信号 {tot_a['signals']} / 作废：失效 "
          f"{tot_a['invalidated']} / 过期 {tot_a['expired']} / 重复入场 "
          f"{tot_a['dup_entry']}")
    run_family("BRK-A", "R18-BRK-A", {s: data1h[s][0] for s in SYMBOLS}, sig_a,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               MAX_PER_DAY, MAX_HOLD_1H, 24, split_1h, "1h",
               setup_stats_by_sym=st_a, sig_zone_by_sym=sig_a)

    # ================= C 对照 2：直接追 Breaker 破位 =================
    print("\n=== C 对照 2：直接追 Breaker 破位（365d 1h，8 币）===")
    sig_c, st_c = {}, {}
    for sym in SYMBOLS:
        sig_c[sym], st_c[sym] = build_breaker_chase_signals(
            data1h[sym][0], atr1h[sym], brk_events[sym])
    tot_c = Counter()
    for v in st_c.values():
        tot_c.update(v)
    print(f"[C] 追破位漏斗（8 币合计）：Breaker 事件 {tot_c['events']} / 信号 "
          f"{tot_c['signals']} / 重复入场 {tot_c['dup_entry']}")
    run_family("BRK-C", "R18-BRK-C", {s: data1h[s][0] for s in SYMBOLS}, sig_c,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               MAX_PER_DAY, MAX_HOLD_1H, 24, split_1h, "1h",
               setup_stats_by_sym=st_c, sig_zone_by_sym=sig_c)

    # ================= B 对照 1：S2 原版（一字不变复用）=================
    print("\n=== B 对照 1：S2 原版（第十一轮一字不变，103d 15m，8 币）===")
    sig_b, st_b = {}, {}
    bars1h_from15 = {}
    for sym in SYMBOLS:
        bars15 = data15[sym][0]
        bars1h = synthesize(bars15, 4, 3600)
        assert len(bars1h) == 103 * 24, f"{sym} 15m 合成 1h 应为 {103*24} 根，实际 {len(bars1h)}"
        bars1h_from15[sym] = bars1h
        sig_b[sym], st_b[sym] = build_s2_signals_full(bars15, bars1h, atr15[sym])
    print(f"[B/S2] setup 统计（8 币合计）：BOS "
          f"{sum(v['bos'] for v in st_b.values())} 次 / OB setup "
          f"{sum(v['setups_ob'] for v in st_b.values())} 个 / FVG setup "
          f"{sum(v['setups_fvg'] for v in st_b.values())} 个 / 无区 "
          f"{sum(v['setups_none'] for v in st_b.values())} 个 / 触发 "
          f"{sum(v['triggered'] for v in st_b.values())} 次 / 信号 "
          f"{sum(v['signals'] for v in st_b.values())} 个 "
          f"（作废：失效 {sum(v['invalidated'] for v in st_b.values())} / "
          f"过期 {sum(v['expired'] for v in st_b.values())}）")
    for sym in SYMBOLS:
        bars = data15[sym][0]
        funding = data15[sym][1]
        for wname, subset in [("103d", None), ("前51d", front_15),
                              ("后52d", back_15)]:
            trades, curve, ndays = simulate_generic(
                sym, bars, sig_b[sym], funding, subset,
                MAX_PER_DAY, MAX_HOLD_15M, "R18-S2", 96)
            res = summarize(sym, trades, curve, "R18-S2", len(sig_b[sym]))
            res["split"] = wname
            res["days"] = ndays
            if trades:
                kz = [t for t in trades if in_killzone(t["entry_t"])]
                res["killzone_trades"] = len(kz)
                res["killzone_taker_net_pct"] = round(
                    sum(t["pnl"] for t in kz) / START_EQUITY, 4)
            record(res, trades if subset is None else None, "S2-B", "R18-S2",
                   "15m", split_15, st_b[sym])
            show(res, sym, wname)

    # ================= D 诊断臂：Breaker-15m（笔记原文版）=================
    print("\n=== D 诊断臂：Breaker-15m（1h 结构 + 15m CHoCH 确认，103d，8 币）===")
    sig_d, st_d = {}, {}
    for sym in SYMBOLS:
        sig_d[sym], st_d[sym] = build_breaker_signals_15m(
            data1h[sym][0], data15[sym][0], atr15[sym], brk_events[sym])
    tot_d = Counter()
    for v in st_d.values():
        tot_d.update(v)
    print(f"[D] 15m 触发漏斗（8 币合计）：窗口内 Breaker 事件 "
          f"{tot_d['events_in_window']} / 触及 {tot_d['touched']} / CHoCH 触发 "
          f"{tot_d['triggered']} / 信号 {tot_d['signals']} / 作废：失效 "
          f"{tot_d['invalidated']} / 过期 {tot_d['expired']} / 重复入场 "
          f"{tot_d['dup_entry']}")
    run_family("BRK-D", "R18-BRK-D", {s: data15[s][0] for s in SYMBOLS}, sig_d,
               {s: data15[s][1] for s in SYMBOLS},
               [("103d", None), ("前51d", front_15), ("后52d", back_15)],
               MAX_PER_DAY, MAX_HOLD_15M, 96, split_15, "15m",
               setup_stats_by_sym=st_d, sig_zone_by_sym=sig_d)

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, wnames) in [
            ("BRK-A", "1h", ["365d", "前185d", "后180d"]),
            ("BRK-C", "1h", ["365d", "前185d", "后180d"]),
            ("S2-B", "15m", ["103d", "前51d", "后52d"]),
            ("BRK-D", "15m", ["103d", "前51d", "后52d"])]:
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["split"] == wname]
            n_tr = sum(r["trades"] for r in rs)
            avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
            avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
            avg_g = sum(r["gross_usdt"] for r in rs)
            avg_c = sum(r["taker_cost_sum"] for r in rs)
            print(f"[{fam} {gran} {wname}] 币均 Taker {avg_t*100:+.2f}% | "
                  f"M2 {avg_m2*100:+.2f}% | 笔数 {n_tr} | "
                  f"毛利合计 {avg_g:+.0f} | 成本合计 {avg_c:+.0f}")

    # ---- pooled t（全期逐笔，Taker）----
    print("\n=== Pooled t（全期逐笔，Taker，1x）===")
    for fam in ["BRK-A", "BRK-C", "S2-B", "BRK-D"]:
        pnls = pooled.get(fam, [])
        print(f"[{fam}] n={len(pnls)} pooled t={t_value(pnls)}")

    # ---- 写文件 ----
    out_sum = os.path.join(DATA_DIR, "gate_iter_round18_summary.json")
    out_tr = os.path.join(DATA_DIR, "gate_iter_round18_trades.csv")
    with open(out_sum, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    if all_trades:
        keys = []
        for t in all_trades:
            for k in t.keys():
                if k not in keys:
                    keys.append(k)
        with open(out_tr, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(all_trades)
    print(f"\n写出：{out_sum}（{len(all_results)} 条）")
    print(f"写出：{out_tr}（{len(all_trades)} 笔）")


if __name__ == "__main__":
    main()
