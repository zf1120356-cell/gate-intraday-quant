#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十九轮：判断清单校准——信号特征 × 跟进测量轮（分系统 SUB-SMC）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

预注册（跑前写死，不可改；来源：盈利策略迭代-分系统回测挖掘.md §2.2；
任务书：第三十九轮）：
  测什么：35 轮三模板（A 扫荡反转做多 / B FVG 回踩做多 / C 供给拒绝做空）
  的信号特征，与逐笔跟进结果连接，算 P(到 2xATR | 到 1xATR) 与每笔毛利。
  给每时段判断层的强度阈值提供数字依据（不是拍脑袋）。
  目的不是找 edge，是校准“强度”这一维到底分不分档。
  定位：测量轮，不是验证轮——同一批数据、同一批信号，只加特征切面；
  量出来的分档效应不能当作 edge。通过的分档要进判断层，须先在
  2026-11-16 之后的实盘纸面数据上看（12 月 18 日月度复核时判），
  不得直接改判断层规则；且按用户 2026-11-21 硬性要求，后续任何
  回测验证一律用未回测过的币种（已回测过的币从回测池退掉），R2
  全新宇宙检验只一次。
  预期（跑前写死）：按挖掘报告，0.5x 确认本身不在已有数据可测范围；
  分档大概率不全过。预期是不通过或只过个别档。

  两个宇宙（跨币检验）：
    A 旧宇宙：35 轮 8 币 BTC/ETH/SOL/DOGE/LINK/XRP/BNB/ADA，
      103 天 2026-08-06~11-16；前 46 天 08-06~09-20 / 后 57 天 09-21~11-16。
    B 新宇宙：37 轮 8 币 MMT/WLD/PIEVERSE/AVAX/PAXG/ARB/FIL/TAO，
      100 天 2026-08-09~11-16；前 43 天 08-09~09-20 / 后 57 天 09-21~11-16。
    两半切点同 35/37 轮：2026-09-21。
  执行口径（两宇宙一字相同，35 轮主臂 / 37 轮全量臂）：
    去 Killzone、全天触发（只保留北京时间 01:00–07:00 不开新单，
    即 UTC 17:00–23:00）；取消 23:00 强制平仓；跟踪止盈（初始止损
    1xATR(15m,14)，有利浮动 ≥2xATR 激活，激活后止损 = 极值 ∓1xATR）；
    最多持 16 根（4h）；每天每币最多 2 笔；单币单日 -2000 熔断；
    每笔名义 10,000、1 倍；主口径 Taker（双边固定 25 USDT/笔）；
    资金费只计 08:00/16:00 结算点。信号定义与 R15 builders 一字不改，
    本轮只给每个信号加特征输出列。
  信号层面：两个宇宙的信号都要含被每天 2 笔上限拦掉的与持仓中跳过
    的（信号层面，不只执行笔）；分组/分档时写清执行笔与信号的区别。

  信号特征（定义跑前写死；ATR 倍数统一用执行口径的 15m ATR14，
  即入场根前一根收盘的 Wilder ATR——与止损/跟踪激活的 1x/2x
  同一把尺；1h ATR 归一化的值也输出作诊断列，不参与分档）：
    决策时可知（只用写触发决策时刻已收盘的 K 线；触及/收回根之前
    的根；确认根不参与特征）——可进判断层作加权（若通过）：
    (1) 探针倍数 probe_x15 = 探针价差 ÷ 15m ATR：
        A：扫荡根影线 = 48h 滚动最低 L − 扫荡根最低价；
        B：触及根探入 FVG 的深度 = FVG 上沿 − 触及根最低价；
        C-FVG：触及根探入供给区深度 = 触及根最高价 − 供给区下沿；
        C-eqhigh：触及根刺破带顶的影线 = 触及根最高价 − 带顶。
    (2) FVG/区宽度 width_x15 =（上沿 − 下沿）÷ 15m ATR：
        B 为看涨 FVG 宽度；C 为供给区宽度（FVG 或等高位带）。
        A 无 FVG，该列为空，不参与分档。
    (3) 位子测试次数 tests（整数）：
        A：扫荡根之前最后一个已收盘 1h 根对应的 48 根 1h 窗口里，
        最低价 ≤ L + 0.1xATR(1h) 的 1h 根数（含形成 L 的那根；
        探针根不计入——窗口只取扫荡根之前已收盘的 1h 根）。
        B/C：同一供给区/FVG 在本次信号之前（含本次）的触及回合数
        （触及后过期/作废再触及，重新计数；以（kind, lo, hi, 形成时刻）
        为区标识）。
    (4) 扫荡深度 depth_x15 = 扫荡价差 ÷ 15m ATR：
        A：L −（扫荡根至收回根之间各根最低价的最小值）；
        B/C 无扫荡段，depth ≡ probe（报告里写清，不另作分档）。
    事后才知道（决策后才知道的量，只能作结果分析，不许进权重）：
    (5) 确认根跟进幅度 confirm_x15 = 确认根收盘超出触发位的幅度 ÷ 15m ATR：
        A：确认根收盘 − CHOCH 触发位 H；B：确认根收盘 − FVG 上沿；
        C：供给区下沿 − 确认根收盘。
        分类理由（写死）：实盘判断层写补充触发时，确认根是触发条件
        里的未来一步（“随后一根确认”），写触发的那一刻确认根还没
        有；回测里信号在确认根收盘后才发出，只是执行口径，不代表
        决策时可知。故 confirm 一律不进判断层权重，只作结果分析。

  分档（跑前写死，不事后换）：
    探针 probe_x15：<1x / 1–1.5x / ≥1.5x；基准档 <1x。
    宽度 width_x15：<0.5x / 0.5–1x / ≥1x；基准档 <0.5x。
    测试次数 tests：1 / 2 / ≥3；基准档 1。
    depth 与 confirm 只作诊断分档（同探针的三档作对照表），不参与
    通过/证伪判定。
  每档报：n_signals（信号数，含被上限拦掉的）、n_exec（执行笔数）、
    n_reach_1x、n_reach_2x、P(到 2x | 到 1x)、每笔毛利（执行笔），
    前后两半分开报，两个宇宙分开报。

  通过标准（跑前写死，不放宽）：
    某档（探针/宽度/测试三类分档之一）同时满足——在旧宇宙前半、
    旧宇宙后半、新宇宙前半、新宇宙后半四个切片里，每一切片都满足：
    (i) P(到 2x|到 1x）比同一切片里同模板的基准档高 10 个百分点以上，
    (ii) 每笔毛利 > 25 USDT——才进判断层作加权。
    任一切片里 P 无定义（n_reach_1x = 0）或 n_exec = 0，该档在该
    切片判不达标。样本量 n_exec 如实报出；名义通过但任一切片
    n_exec < 10 的档，报告里单列“样本不足、不可采信”，不进判断层。
  证伪：没有一档四切片同时达标，则强度分档证伪，判断层不按强度
    加权，只保留现有的 0.5x 确认规则。

  无未来数据（用户硬性要求，执行前自查，写死在代码里）：
    - 信号只用已收盘 K 线：R15 builders 一字不改（本轮只复制并加
      特征输出，信号判定逻辑逐行相同）；入场一律是确认根的下一根
      15m 开盘价。
    - 特征只用决策时已知：探针/深度/宽度/测试次数全部只用触及根
      与收回根之前（含触及/收回根本身）的已收盘根；确认根不参与
      任何决策时特征（确认根跟进幅度单列事后分析）。
    - 模拟不用未来数据：复用 gate_iter_round35.simulate_stream，
      一字不改；资金费只计 08:00/16:00 结算点。
    - 15m ATR 取入场根前一根收盘的 Wilder ATR（与 35/37 轮同口径）；
      入场落在窗口最初 14 根内、ATR 未预热的信号跳过并计数（37 轮
      同处理，不编数）。
    - 数据绝对不能做假：算不出就写算不出（33 轮缺 atr 列即是先例；
      本轮 warmup 跳过的信号与 n=0 的档如实报）。

  保真校验（跑后必须通过，否则先修脚本再出报告）：
    (a) 特征版 builders 与原版 R15 builders 在同一数据上信号一字
        相同：信号键集合相同，每信号 direction/atr/tag 相同（只多
        特征列）。
    (b) 旧宇宙主臂模拟复现 35 轮 MAIN：每模板笔数/毛利/净与
        data/gate_iter_round35_trades.csv 的 MAIN 行逐项相等。
    (c) 新宇宙全量臂模拟复现 37 轮 FULL：每模板笔数/毛利/净与
        data/gate_iter_round37_trades.csv 的 FULL 行逐项相等。
    (d) 跑两遍，三个输出文件的 md5 完全一致。

运行：python3 gate_iter_round39.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round39_signals.csv
      + data/gate_iter_round39_cells.json + data/gate_iter_round39_summary.json
复现：跑两遍，三个文件的 md5 应完全一致。
"""

import bisect
import csv
import hashlib
import json
import math
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round15 as R15  # 原版 builders（保真对照）与 1h 合成
import gate_iter_round35 as R35  # 复用 35 轮引擎：load / atr / simulate_stream
import gate_iter_round37 as R37  # 复用 37 轮新宇宙 1h 合并函数

DATA_DIR = os.path.join(SCRIPT_DIR, "data")

OLD_SYMBOLS = R15.SYMBOLS  # BTC/ETH/SOL/DOGE/LINK/XRP/BNB/ADA
NEW_SYMBOLS = R37.NEW_SYMBOLS  # MMT/WLD/PIEVERSE/AVAX/PAXG/ARB/FIL/TAO
SPLIT = R35.SPLIT_R35  # 2026-09-21；旧宇宙前 46d / 后 57d；新宇宙前 43d / 后 57d
START_EQUITY = R35.START_EQUITY
NOTIONAL = R35.NOTIONAL
MAX_PER_DAY = R35.MAX_PER_DAY

# 分档（跑前写死）
PROBE_BUCKETS = [("<1", lambda x: x < 1.0),
                 ("1-1.5", lambda x: 1.0 <= x < 1.5),
                 (">=1.5", lambda x: x >= 1.5)]
WIDTH_BUCKETS = [("<0.5", lambda x: x < 0.5),
                 ("0.5-1", lambda x: 0.5 <= x < 1.0),
                 (">=1", lambda x: x >= 1.0)]
TESTS_BUCKETS = [("1", lambda t: t == 1),
                 ("2", lambda t: t == 2),
                 (">=3", lambda t: t >= 3)]
BASELINE = {"probe": "<1", "width": "<0.5", "tests": "1"}


# ----------------------------------------------------------------------
# 特征版构建器：R15 build_A/B/C 的逐行复制，只加特征输出列。
# 信号判定逻辑（状态机、条件、窗口、失效规则）与 R15 一字相同；
# 唯一改动：信号字典多出 feat_* 键；另加位子触及回合计数。
# Killzone 在本轮恒关（只测 MAIN/FULL 执行臂），故 kz_ok 恒真。
# ----------------------------------------------------------------------
def kz_ok(t):
    return True


# R15  helpers（纯函数，原样复用，不复制）：fvgs_1h / swing_highs_n3 /
# eqhigh_zones / roll_low_48h / atr1h_at；常量 FVG_MIN_ATR / SEQ_WINDOW /
# CONFIRM_WINDOW / ZONE_VALID_HOURS / EQH_VALID_HOURS / EQH_TOL_ATR /
# ROLL_LOW_HOURS 全部取 R15 的值。
def build_A_feat(bars15, bars1h, atr1h):
    n = len(bars15)
    low48 = R15.roll_low_48h(bars1h)
    close_ts_1h = [b["t"] + 3600 for b in bars1h]

    def level_at(t):
        k = bisect.bisect_right(close_ts_1h, t) - 1
        if k < 0:
            return None
        return low48[k]

    signals = {}
    fun = Counter()
    state = "idle"
    lvl = sweep_i = rec_j = H = deadline = None
    for i in range(n):
        b = bars15[i]
        t = b["t"]
        if state != "idle" and i > deadline:
            fun["expired"] += 1
            state = "idle"
            lvl = sweep_i = rec_j = H = deadline = None
        if state == "idle":
            L = level_at(t)
            if L is not None and b["l"] < L:
                state, lvl, sweep_i = "swept", L, i
                deadline = i + R15.SEQ_WINDOW
                fun["sweeps"] += 1
        elif state == "swept":
            if b["c"] > lvl:
                state, rec_j = "reclaimed", i
                H = max(x["h"] for x in bars15[sweep_i:i + 1])
                fun["reclaims"] += 1
        elif state == "reclaimed":
            if b["c"] > H:
                fun["choch"] += 1
                if i + 1 < n:
                    et = bars15[i + 1]["t"]
                    if kz_ok(et):
                        a = R15.atr1h_at(bars1h, atr1h, et)
                        if a is not None:
                            # ---- 特征（只用触及/收回根之前已收盘的根）----
                            t_sweep = bars15[sweep_i]["t"]
                            k_s = bisect.bisect_right(close_ts_1h, t_sweep) - 1
                            win = bars1h[max(0, k_s - R15.ROLL_LOW_HOURS):k_s]
                            tests = sum(1 for x in win
                                        if x["l"] <= lvl + R15.EQH_TOL_ATR * a)
                            probe_price = lvl - bars15[sweep_i]["l"]
                            depth_price = lvl - min(x["l"] for x in bars15[sweep_i:rec_j + 1])
                            confirm_follow_price = b["c"] - H
                            signals[et] = {
                                "direction": 1, "atr": a, "tag": "R15-A",
                                "feat_kind": "sweep",
                                "feat_probe_price": probe_price,
                                "feat_depth_price": depth_price,
                                "feat_width_price": None,
                                "feat_tests": tests,
                                "feat_confirm_follow_price": confirm_follow_price,
                            }
                            fun["signals"] += 1
                        else:
                            fun["signal_no_atr"] += 1
                    else:
                        fun["killzone_skipped"] += 1
                else:
                    fun["signal_no_entry_bar"] += 1
                state = "idle"
                lvl = sweep_i = rec_j = H = deadline = None
    return signals, fun


def build_B_feat(bars15, bars1h, atr1h):
    n = len(bars15)
    fvg_list = R15.fvgs_1h(bars1h, atr1h, +1)
    fun = Counter({"fvgs_formed": len(fvg_list)})
    signals = {}
    fvg_by_t = sorted(fvg_list, key=lambda z: z["formed_close_t"])
    active = []
    fi = 0
    state = "idle"
    cur = None
    touch_i = None
    deadline = None
    touch_n = {}  # (lo, hi, formed_close_t) -> 触及回合数（含本次）
    for i in range(n):
        b = bars15[i]
        t = b["t"]
        while fi < len(fvg_by_t) and fvg_by_t[fi]["formed_close_t"] <= t:
            active.append(dict(fvg_by_t[fi]))
            fi += 1
        active = [z for z in active if t < z["formed_close_t"] + R15.ZONE_VALID_HOURS * 3600]
        if (t + 900) % 3600 == 0:
            still = []
            for z in active:
                if b["c"] < z["lo"]:
                    fun["voided_1h_close"] += 1
                    if state == "touched" and cur is z:
                        state, cur, touch_i, deadline = "idle", None, None, None
                        fun["voided_while_touched"] += 1
                else:
                    still.append(z)
            active = still
        prev_c = bars15[i - 1]["c"] if i > 0 else None
        if state == "touched" and not any(cur is z for z in active):
            fun["expired_zone_gone"] += 1
            state, cur, touch_i, deadline = "idle", None, None, None
        if state == "idle":
            cands = [z for z in active
                     if z["hi"] <= prev_c or (z["lo"] <= prev_c <= z["hi"])] \
                if prev_c is not None else []
            if not cands:
                continue
            cur = max(cands, key=lambda z: (z["hi"], z["formed_close_t"]))
            if b["l"] <= cur["hi"] and b["c"] >= cur["lo"]:
                key = (cur["lo"], cur["hi"], cur["formed_close_t"])
                touch_n[key] = touch_n.get(key, 0) + 1
                state, touch_i = "touched", i
                deadline = i + R15.CONFIRM_WINDOW
                fun["touches"] += 1
            else:
                cur = None
        elif state == "touched":
            if i > deadline:
                fun["expired_no_confirm"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] < cur["lo"]:
                fun["voided_seq_close_below"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] > cur["hi"]:
                fun["confirms"] += 1
                if i + 1 < n:
                    et = bars15[i + 1]["t"]
                    if kz_ok(et):
                        a = R15.atr1h_at(bars1h, atr1h, et)
                        if a is not None:
                            # ---- 特征（只用触及根已收盘的信息）----
                            key = (cur["lo"], cur["hi"], cur["formed_close_t"])
                            probe_price = cur["hi"] - bars15[touch_i]["l"]
                            signals[et] = {
                                "direction": 1, "atr": a, "tag": "R15-B",
                                "feat_kind": "fvg",
                                "feat_probe_price": probe_price,
                                "feat_depth_price": probe_price,  # B 无扫荡段，depth ≡ probe
                                "feat_width_price": cur["hi"] - cur["lo"],
                                "feat_tests": touch_n.get(key, 0),
                                "feat_confirm_follow_price": b["c"] - cur["hi"],
                            }
                            fun["signals"] += 1
                        else:
                            fun["signal_no_atr"] += 1
                    else:
                        fun["killzone_skipped"] += 1
                else:
                    fun["signal_no_entry_bar"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
    return signals, fun


def build_C_feat(bars15, bars1h, atr1h):
    n = len(bars15)
    fvg_list = R15.fvgs_1h(bars1h, atr1h, -1)
    eq_list = R15.eqhigh_zones(bars1h, atr1h)
    zones_all = []
    for z in fvg_list:
        zones_all.append({"lo": z["lo"], "hi": z["hi"], "kind": "fvg",
                          "avail_t": z["formed_close_t"],
                          "expire_t": z["formed_close_t"] + R15.ZONE_VALID_HOURS * 3600})
    for z in eq_list:
        zones_all.append({"lo": z["lo"], "hi": z["hi"], "kind": "eqhigh",
                          "avail_t": z["avail_t"],
                          "expire_t": z["last_conf_t"] + R15.EQH_VALID_HOURS * 3600})
    zones_all.sort(key=lambda z: z["avail_t"])
    fun = Counter({"zones_formed_fvg": len(fvg_list),
                   "zones_formed_eqhigh": len(eq_list)})
    signals = {}
    active = []
    zi = 0
    state = "idle"
    cur = None
    touch_i = None
    deadline = None
    touch_n = {}  # (kind, lo, hi, avail_t) -> 触及回合数（含本次）
    for i in range(n):
        b = bars15[i]
        t = b["t"]
        while zi < len(zones_all) and zones_all[zi]["avail_t"] <= t:
            active.append(dict(zones_all[zi]))
            zi += 1
        active = [z for z in active if t < z["expire_t"]]
        if (t + 900) % 3600 == 0:
            still = []
            for z in active:
                if b["c"] > z["hi"]:
                    fun["voided_1h_close"] += 1
                    if state == "touched" and cur is z:
                        state, cur, touch_i, deadline = "idle", None, None, None
                        fun["voided_while_touched"] += 1
                else:
                    still.append(z)
            active = still
        prev_c = bars15[i - 1]["c"] if i > 0 else None
        if state == "touched" and not any(cur is z for z in active):
            fun["expired_zone_gone"] += 1
            state, cur, touch_i, deadline = "idle", None, None, None
        if state == "idle":
            cands = [z for z in active
                     if z["lo"] >= prev_c or (z["lo"] <= prev_c <= z["hi"])] \
                if prev_c is not None else []
            if not cands:
                continue
            cur = min(cands, key=lambda z: (z["lo"], -z["avail_t"]))
            touched = False
            if cur["kind"] == "fvg":
                touched = b["h"] >= cur["lo"] and b["l"] <= cur["hi"] and b["c"] <= cur["hi"]
            else:  # eqhigh：影线刺破带顶且收盘未收穿
                touched = b["h"] > cur["hi"] and b["c"] <= cur["hi"]
            if touched:
                key = (cur["kind"], cur["lo"], cur["hi"], cur["avail_t"])
                touch_n[key] = touch_n.get(key, 0) + 1
                state, touch_i = "touched", i
                deadline = i + R15.CONFIRM_WINDOW
                fun["touches"] += 1
                fun[f"touches_{cur['kind']}"] += 1
            else:
                cur = None
        elif state == "touched":
            if i > deadline:
                fun["expired_no_confirm"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] > cur["hi"]:
                fun["voided_seq_close_above"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
                continue
            if b["c"] < cur["lo"]:
                fun["confirms"] += 1
                fun[f"confirms_{cur['kind']}"] += 1
                if i + 1 < n:
                    et = bars15[i + 1]["t"]
                    if kz_ok(et):
                        a = R15.atr1h_at(bars1h, atr1h, et)
                        if a is not None:
                            # ---- 特征（只用触及根已收盘的信息）----
                            key = (cur["kind"], cur["lo"], cur["hi"], cur["avail_t"])
                            if cur["kind"] == "fvg":
                                probe_price = bars15[touch_i]["h"] - cur["lo"]
                            else:  # eqhigh：刺破带顶的影线
                                probe_price = bars15[touch_i]["h"] - cur["hi"]
                            signals[et] = {
                                "direction": -1, "atr": a, "tag": "R15-C",
                                "feat_kind": cur["kind"],
                                "feat_probe_price": probe_price,
                                "feat_depth_price": probe_price,  # C 无扫荡段，depth ≡ probe
                                "feat_width_price": cur["hi"] - cur["lo"],
                                "feat_tests": touch_n.get(key, 0),
                                "feat_confirm_follow_price": cur["lo"] - b["c"],
                            }
                            fun["signals"] += 1
                        else:
                            fun["signal_no_atr"] += 1
                    else:
                        fun["killzone_skipped"] += 1
                else:
                    fun["signal_no_entry_bar"] += 1
                state, cur, touch_i, deadline = "idle", None, None, None
    return signals, fun


# ----------------------------------------------------------------------
# 工具
# ----------------------------------------------------------------------
def fav_atr(t):
    """峰值有利浮动（ATR 倍数），与 35/36/37 轮诊断同口径。"""
    if not t.get("atr"):
        return 0.0
    return (t.get("max_favour_usdt", 0.0) / NOTIONAL) / (t["atr"] / t["entry"])


def split_of(et):
    return ("front" if datetime.fromtimestamp(et, timezone.utc).date()
            < SPLIT.date() else "back")


def bucket_name(value, buckets):
    if value is None:
        return None
    for name, pred in buckets:
        if pred(value):
            return name
    return None


def load_universe(symbols, days_expected, bars_per_day, build_1h_fn, label):
    """加载 15m + 资金费，校验，合成 1h。返回 (data15, data1h)。"""
    data15 = {}
    for sym in symbols:
        bars = R35.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R35.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R35.group_days(bars, bars_per_day)
        assert len(days) == days_expected, \
            f"{sym} 15m 完整日应为 {days_expected} 天，实际 {len(days)}"
        assert len(bars) == days_expected * bars_per_day, \
            f"{sym} 15m 应为 {days_expected * bars_per_day} 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data15[symbols[0]][0]]
    for sym in symbols:
        assert [b["t"] for b in data15[sym][0]] == base_ts, \
            f"{sym} 15m 时间戳与 {symbols[0]} 不对齐"
    print(f"[{label}] 数据校验通过：{len(symbols)} 币各 {len(base_ts)} 根 15m / "
          f"{days_expected} 天；时间戳对齐、零缺口。")
    data1h = build_1h_fn(symbols) if build_1h_fn is not None else R15.build_1h_combined()
    return data15, data1h


def build_signals_both(symbols, data15, data1h, label):
    """原版 R15 builders 与特征版 builders 各跑一遍，逐项比对保真。
    返回特征版信号 {fam: {sym: {et: sig}}}。"""
    R15.in_killzone = lambda t: True  # 去 Killzone（与 35/37 轮主臂同）
    templates_orig = [("A", R15.build_A), ("B", R15.build_B), ("C", R15.build_C)]
    templates_feat = [("A", build_A_feat), ("B", build_B_feat), ("C", build_C_feat)]
    feat_sig = {}
    for (fam, builder_orig), (_, builder_feat) in zip(templates_orig, templates_feat):
        sig_o, sig_f = {}, {}
        for sym in symbols:
            bars1h, a1h = data1h[sym]
            so, fo = builder_orig(data15[sym][0], bars1h, a1h)
            sf, ff = builder_feat(data15[sym][0], bars1h, a1h)
            sig_o[sym], sig_f[sym] = so, sf
            assert set(so.keys()) == set(sf.keys()), \
                f"保真失败：{label} {fam} {sym} 信号键集合不一致（原版 {len(so)} vs 特征版 {len(sf)}）"
            for et, s in so.items():
                t = sf[et]
                assert s["direction"] == t["direction"] and s["atr"] == t["atr"] \
                    and s["tag"] == t["tag"], \
                    f"保真失败：{label} {fam} {sym} {et} 信号内容不一致"
            assert fo == ff, \
                f"保真失败：{label} {fam} {sym} 漏斗计数不一致（原版 {dict(fo)} vs 特征版 {dict(ff)}）"
        feat_sig[fam] = sig_f
        tot = sum(len(v) for v in sig_f.values())
        print(f"[{label} 信号 {fam}] 特征版与原版一字相同：8 币合计 {tot} 个信号；"
              + "、".join(f"{s.replace('_USDT', '')} {len(sig_f[s])}" for s in symbols))
    return feat_sig


def to_exec_signals(feat_sig, data15, label):
    """夜禁过滤 + 15m ATR 挂接（与 35/37 轮一字相同）。
    返回 (exec_sig, night_blocked, warmup_blocked)。
    exec_sig[fam][sym][et] = 原信号 + atr_15m（warmup 缺失时为 None，但保留信号）。"""
    atr15 = {s: R35.atr_wilder(data15[s][0]) for s in data15}
    idx_of_t = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in data15}
    exec_sig, night_blocked, warmup_blocked = {}, {}, {}
    for fam, sig_by_sym in feat_sig.items():
        ms, nb, wb = {}, {}, {}
        for sym, sig in sig_by_sym.items():
            ms[sym], nb[sym], wb[sym] = {}, 0, 0
            for et, s in sig.items():
                if R35._entry_in_no_new_window(et):
                    nb[sym] += 1
                    continue
                gi = idx_of_t[sym][et]
                a15 = atr15[sym][gi - 1] if gi - 1 >= 0 else None
                if a15 is None:
                    wb[sym] += 1
                s2 = dict(s)
                s2["atr_15m"] = a15
                ms[sym][et] = s2
        exec_sig[fam] = ms
        night_blocked[fam] = nb
        warmup_blocked[fam] = wb
        print(f"[{label} 执行信号 {fam}] 夜禁拦掉 {sum(nb.values())} 个；"
              f"ATR 未预热 {sum(wb.values())} 个（保留信号、15m 归一化列为空）；"
              f"入场信号 {sum(len(v) for v in ms.values())} 个。")
    return exec_sig, night_blocked, warmup_blocked


def run_simulation(label, symbols, data15, exec_sig):
    """复用 R35.simulate_stream 跑 MAIN/FULL 执行臂。
    返回 {(fam, sym): trades}。"""
    out = {}
    for fam in ("A", "B", "C"):
        for sym in symbols:
            bars, funding = data15[sym]
            trades, curve, stats = R35.simulate_stream(
                sym, bars, {et: {"direction": s["direction"], "atr": s["atr_15m"],
                                 "atr_basis": "15m", "tag": s.get("tag", "")}
                            for et, s in exec_sig[fam][sym].items()
                            if s["atr_15m"] is not None},
                funding, MAX_PER_DAY, f"R39-{label}-{fam}")
            out[(fam, sym)] = trades
        n = sum(len(out[(fam, s)]) for s in symbols)
        print(f"[{label} 模拟 {fam}] 执行笔数 {n}（8 币合计）")
    return out


def join_signals_trades(label, symbols, exec_sig, sim_trades):
    """信号 × 执行笔连接。返回信号记录表（每信号一行，含特征与结果）。"""
    recs = []
    for fam in ("A", "B", "C"):
        for sym in symbols:
            tmap = {t["entry_t"]: t for t in sim_trades[(fam, sym)]}
            assert len(tmap) == len(sim_trades[(fam, sym)]), \
                f"连接失败：{label} {fam} {sym} 同一入场时刻出现两笔成交"
            for et, s in sorted(exec_sig[fam][sym].items()):
                a15, a1h = s["atr_15m"], s["atr"]
                rec = {
                    "universe": label, "family": fam, "symbol": sym,
                    "entry_t": et, "direction": s["direction"],
                    "atr_1h": a1h, "atr_15m": a15,
                    "kind": s.get("feat_kind"),
                    "tests": s.get("feat_tests"),
                    "executed": et in tmap,
                    "reason": None, "gross": None, "pnl": None,
                    "reached_1x": None, "reached_2x": None, "fav_atr": None,
                }
                for col, price in (("probe", s.get("feat_probe_price")),
                                   ("depth", s.get("feat_depth_price")),
                                   ("width", s.get("feat_width_price")),
                                   ("confirm", s.get("feat_confirm_follow_price"))):
                    if price is None:
                        rec[f"{col}_x15"] = None
                        rec[f"{col}_x1h"] = None
                    else:
                        rec[f"{col}_x15"] = (price / a15) if a15 else None
                        rec[f"{col}_x1h"] = (price / a1h) if a1h else None
                if et in tmap:
                    t = tmap[et]
                    fa = fav_atr(t)
                    rec.update({
                        "reason": t["reason"],
                        "gross": t["price_pnl"] - t["funding_cost_usdt"],
                        "pnl": t["pnl"],
                        "reached_1x": fa >= 1.0 - 1e-9,
                        "reached_2x": fa >= 2.0 - 1e-9,
                        "fav_atr": fa,
                    })
                recs.append(rec)
    return recs


def check_reproduce(label, sim_trades, ref_csv, ref_arm):
    """保真校验 (b)/(c)：每模板笔数/毛利/净与历史 trades CSV 的指定臂逐项相等
    （CSV 数字四舍五入到 2 位小数，容差按笔数计）。"""
    ref = defaultdict(list)
    with open(ref_csv, newline="") as f:
        for r in csv.DictReader(f):
            if r["arm"] == ref_arm:
                ref[r["family"]].append(r)
    ok = True
    for fam in ("A", "B", "C"):
        mine = [t for (ff, _), ts in sim_trades.items() if ff == fam for t in ts]
        rn = len(ref[fam])
        rg = sum(float(r["price_pnl_usdt"]) - float(r["funding_cost_usdt"]) for r in ref[fam])
        rnet = sum(float(r["pnl_taker_usdt"]) for r in ref[fam])
        mg = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in mine)
        mn = sum(t["pnl"] for t in mine)
        tol = 0.01 * max(len(mine), rn) + 0.1
        good = (len(mine) == rn and abs(mg - rg) <= tol and abs(mn - rnet) <= tol)
        ok = ok and good
        print(f"  [复现 {label} {fam}] 本轮 n={len(mine)} 毛利 {mg:+.2f} 净 {mn:+.2f} vs "
              f"历史 {ref_arm} n={rn} 毛利 {rg:+.2f} 净 {rnet:+.2f} → {'✓' if good else '✗ 不一致'}")
    assert ok, f"复现校验失败：{label} 与历史 {ref_arm} 不一致，停止出报告！"
    print(f"  [复现 {label}] 与历史 {ref_arm} 逐项一致 ✓")


# ----------------------------------------------------------------------
# 分档统计
# ----------------------------------------------------------------------
FEATURES = [
    # (key, x15 列, 分档表, 参与判定)
    ("probe", "probe_x15", PROBE_BUCKETS, True),
    ("width", "width_x15", WIDTH_BUCKETS, True),
    ("tests", "tests", TESTS_BUCKETS, True),
    ("depth", "depth_x15", PROBE_BUCKETS, False),    # 诊断，不参与判定
    ("confirm", "confirm_x15", WIDTH_BUCKETS, False),  # 诊断（事后量），不参与判定
]


def cell_metrics(recs):
    """一批执行笔的指标：n_exec、n1、n2、P(2x|1x)、毛利、每笔毛利。"""
    n = len(recs)
    n1 = sum(1 for r in recs if r["reached_1x"])
    n2 = sum(1 for r in recs if r["reached_2x"])
    gross = sum(r["gross"] for r in recs)
    return {
        "n_exec": n,
        "n_reach_1x": n1,
        "n_reach_2x": n2,
        "p_reach_2x_given_1x": (n2 / n1) if n1 else None,
        "gross": round(gross, 2),
        "gross_per_trade": round(gross / n, 2) if n else None,
    }


def analyze(all_recs):
    """分档统计 + 通过判定。返回 (cells, verdicts)。"""
    cells, verdicts = [], []
    for feature, col, buckets, judged in FEATURES:
        for fam in ("A", "B", "C"):
            if feature == "width" and fam == "A":
                continue  # A 无 FVG，宽度列为空
            # 每（宇宙，切片）先算基准档 P，供通过判定用（诊断档无基准档）
            base_p = {}
            if judged:
                for uni in ("旧宇宙", "新宇宙"):
                    for half in ("front", "back"):
                        brecs = [r for r in all_recs
                                 if r["universe"] == uni and r["family"] == fam
                                 and split_of(r["entry_t"]) == half
                                 and r["executed"]
                                 and bucket_name(r[col], buckets) == BASELINE[feature]]
                        m = cell_metrics(brecs)
                        base_p[(uni, half)] = m["p_reach_2x_given_1x"]
            for bname, _pred in buckets:
                if judged and bname == BASELINE[feature]:
                    continue
                slice_pass, slice_detail = {}, {}
                for uni in ("旧宇宙", "新宇宙"):
                    for half in ("front", "back"):
                        sigs = [r for r in all_recs
                                if r["universe"] == uni and r["family"] == fam
                                and split_of(r["entry_t"]) == half
                                and bucket_name(r[col], buckets) == bname]
                        execs = [r for r in sigs if r["executed"]]
                        m = cell_metrics(execs)
                        bp = base_p.get((uni, half))
                        p_ok = (judged and m["p_reach_2x_given_1x"] is not None and bp is not None
                                and m["p_reach_2x_given_1x"] - bp > 0.10)
                        g_ok = (judged and m["gross_per_trade"] is not None and m["gross_per_trade"] > 25)
                        small_n = m["n_exec"] < 10
                        slice_pass[(uni, half)] = bool(p_ok and g_ok and not small_n)
                        slice_detail[(uni, half)] = {
                            "n_signals": len(sigs), **m,
                            "baseline_p": bp,
                            "p_margin_pp": (round((m["p_reach_2x_given_1x"] - bp) * 100, 1)
                                           if m["p_reach_2x_given_1x"] is not None and bp is not None
                                           else None),
                            "pass_p": bool(p_ok), "pass_gross": bool(g_ok),
                            "small_n": small_n,
                            "pass_slice": bool(p_ok and g_ok and not small_n),
                        }
                        cells.append({
                            "feature": feature, "family": fam, "bucket": bname,
                            "universe": uni, "half": half, "judged": judged,
                            "baseline_bucket": BASELINE.get(feature),
                            **slice_detail[(uni, half)],
                        })
                if judged:
                    verdicts.append({
                        "feature": feature, "family": fam, "bucket": bname,
                        "pass_all_4_slices": all(slice_pass.values()),
                        "slices": {f"{u}-{h}": slice_pass[(u, h)]
                                   for (u, h) in slice_pass},
                        "small_n_anywhere": any(
                            slice_detail[k]["small_n"] for k in slice_detail),
                    })
    return cells, verdicts


def main():
    print("盈利策略迭代 · 第三十九轮：判断清单校准——信号特征 × 跟进测量轮（分系统）")
    print("目的：给每时段判断层的强度阈值提供数字依据；测量轮，不是验证轮。")
    print("通过标准：某档在旧前/旧后/新前/新后四个切片里，每一切片都满足"
          "P(2x|1x）比基准档高 10pp 以上且每笔毛利 > 25 USDT，才进判断层作加权。")

    # ---- 旧宇宙 ----
    data15_old, data1h_old = load_universe(
        OLD_SYMBOLS, 103, 96, None, "旧宇宙")
    feat_old = build_signals_both(OLD_SYMBOLS, data15_old, data1h_old, "旧宇宙")
    exec_old, nb_old, wb_old = to_exec_signals(feat_old, data15_old, "旧宇宙")
    sim_old = run_simulation("旧宇宙", OLD_SYMBOLS, data15_old, exec_old)
    print("\n=== 保真校验 (b)：旧宇宙主臂 vs 35 轮 MAIN ===")
    check_reproduce("旧宇宙", sim_old,
                    os.path.join(DATA_DIR, "gate_iter_round35_trades.csv"), "MAIN")
    recs_old = join_signals_trades("旧宇宙", OLD_SYMBOLS, exec_old, sim_old)

    # ---- 新宇宙 ----
    data15_new, data1h_new = load_universe(
        NEW_SYMBOLS, 100, 96,
        lambda syms: R37.build_1h_combined_new(syms), "新宇宙")
    feat_new = build_signals_both(NEW_SYMBOLS, data15_new, data1h_new, "新宇宙")
    exec_new, nb_new, wb_new = to_exec_signals(feat_new, data15_new, "新宇宙")
    sim_new = run_simulation("新宇宙", NEW_SYMBOLS, data15_new, exec_new)
    print("\n=== 保真校验 (c)：新宇宙全量臂 vs 37 轮 FULL ===")
    check_reproduce("新宇宙", sim_new,
                    os.path.join(DATA_DIR, "gate_iter_round37_trades.csv"), "FULL")
    recs_new = join_signals_trades("新宇宙", NEW_SYMBOLS, exec_new, sim_new)

    all_recs = recs_old + recs_new
    print(f"\n信号记录总数：{len(all_recs)}（旧宇宙 {len(recs_old)} / 新宇宙 {len(recs_new)}）;"
          f"执行 {sum(1 for r in all_recs if r['executed'])} 笔，"
          f"未执行 {sum(1 for r in all_recs if not r['executed'])} 个信号"
          f"（被 2 笔上限/持仓中/熔断拦掉）。")

    # ---- 分档统计 ----
    cells, verdicts = analyze(all_recs)

    # ---- 打印分档表 ----
    print("\n=== 分档表（执行笔；P = P(到 2x | 到 1x)；毛利 = 每笔毛利 USDT）===")
    for feature, col, buckets, judged in FEATURES:
        for fam in ("A", "B", "C"):
            if feature == "width" and fam == "A":
                continue
            print(f"\n-- {fam} · {feature}"
                  f"{'（判定档）' if judged else '（诊断，不参与判定）'} --")
            for bname, _ in buckets:
                line = []
                for uni in ("旧宇宙", "新宇宙"):
                    for half in ("front", "back"):
                        sigs = [r for r in all_recs
                                if r["universe"] == uni and r["family"] == fam
                                and split_of(r["entry_t"]) == half
                                and bucket_name(r[col], buckets) == bname]
                        execs = [r for r in sigs if r["executed"]]
                        m = cell_metrics(execs)
                        p = m["p_reach_2x_given_1x"]
                        if judged and bname == BASELINE[feature]:
                            line.append(f"{uni}-{half} 基准 n_sig={len(sigs)} n={m['n_exec']} "
                                        f"P={p if p is None else round(p, 3)} "
                                        f"毛利/笔={m['gross_per_trade']}")
                        elif judged:
                            cc = [c for c in cells if c["feature"] == feature
                                  and c["family"] == fam and c["bucket"] == bname
                                  and c["universe"] == uni and c["half"] == half][0]
                            line.append(f"{uni}-{half} n_sig={cc['n_signals']} n={cc['n_exec']} "
                                        f"P={p if p is None else round(p, 3)} "
                                        f"(基线 {cc['baseline_p'] if cc['baseline_p'] is None else round(cc['baseline_p'], 3)}, "
                                        f"Δ{cc['p_margin_pp']}pp) "
                                        f"毛利/笔={cc['gross_per_trade']} "
                                        f"{'✓' if cc['pass_slice'] else '✗'}")
                        else:
                            line.append(f"{uni}-{half} n_sig={len(sigs)} n={m['n_exec']} "
                                        f"P={p if p is None else round(p, 3)} "
                                        f"毛利/笔={m['gross_per_trade']}")
                print(f"  [{bname}] " + " | ".join(line))

    # ---- 通过 / 证伪判定 ----
    print("\n=== 判定（四切片同时达标才通过）===")
    passed = [v for v in verdicts if v["pass_all_4_slices"]]
    for v in verdicts:
        print(f"  {v['family']}–{v['feature']}–{v['bucket']}："
              f"{'通过' if v['pass_all_4_slices'] else '不通过'} "
              f"{v['slices']}"
              f"{'（有切片 n_exec < 10，样本不足）' if v['small_n_anywhere'] else ''}")
    if not passed:
        print("  没有一档四切片同时达标 → 强度分档证伪：判断层不按强度加权，"
              "只保留现有的 0.5x 确认规则。")
    else:
        print(f"  {len(passed)} 档通过 → 仍只是测量通过：进判断层前须先在 "
              "2026-11-16 之后的实盘纸面数据上验证（12 月 18 日月度复核时判），"
              "不得直接改判断层规则。")

    # ---- 诊断：C 模板 kind 拆分 ----
    print("\n=== 诊断：C 模板按 kind 拆分（fvg vs eqhigh；只作参考）===")
    for kind in ("fvg", "eqhigh"):
        for uni in ("旧宇宙", "新宇宙"):
            rs = [r for r in all_recs if r["family"] == "C" and r["kind"] == kind
                  and r["universe"] == uni and r["executed"]]
            m = cell_metrics(rs)
            print(f"  C-{kind} {uni}：信号 {sum(1 for r in all_recs if r['family'] == 'C' and r['kind'] == kind and r['universe'] == uni)} 个，"
                  f"执行 {m['n_exec']} 笔，P(2x|1x)={m['p_reach_2x_given_1x']}，"
                  f"每笔毛利={m['gross_per_trade']}")

    # ---- 写文件 ----
    sig_fields = ["universe", "family", "symbol", "entry_t", "direction",
                  "kind", "tests", "atr_1h", "atr_15m",
                  "probe_x15", "probe_x1h", "depth_x15", "depth_x1h",
                  "width_x15", "width_x1h", "confirm_x15", "confirm_x1h",
                  "executed", "reason", "gross", "pnl",
                  "reached_1x", "reached_2x", "fav_atr"]
    with open(os.path.join(DATA_DIR, "gate_iter_round39_signals.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=sig_fields)
        w.writeheader()
        for r in sorted(all_recs, key=lambda x: (x["universe"], x["family"], x["entry_t"], x["symbol"])):
            row = {k: ("" if r.get(k) is None else
                       (datetime.fromtimestamp(r[k], timezone.utc).isoformat() if k == "entry_t"
                        else r[k])) for k in sig_fields}
            w.writerow(row)
    with open(os.path.join(DATA_DIR, "gate_iter_round39_cells.json"), "w") as f:
        json.dump({"cells": cells, "verdicts": verdicts}, f, indent=2, ensure_ascii=False)
    summary = {
        "round": 39,
        "n_signals": len(all_recs),
        "n_signals_old": len(recs_old),
        "n_signals_new": len(recs_new),
        "n_exec": sum(1 for r in all_recs if r["executed"]),
        "n_exec_old": sum(1 for r in recs_old if r["executed"]),
        "n_exec_new": sum(1 for r in recs_new if r["executed"]),
        "verdicts": verdicts,
        "passed_buckets": [f"{v['family']}-{v['feature']}-{v['bucket']}" for v in passed],
        "falsified": len(passed) == 0,
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round39_summary.json"), "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"\n信号已写入：data/gate_iter_round39_signals.csv ({len(all_recs)} 行)")
    print(f"分档已写入：data/gate_iter_round39_cells.json ({len(cells)} 个格子）")
    print(f"汇总已写入：data/gate_iter_round39_summary.json")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
