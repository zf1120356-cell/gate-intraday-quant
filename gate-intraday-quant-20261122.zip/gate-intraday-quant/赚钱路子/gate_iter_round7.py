#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第七轮：4 个真正新的合约日内家族（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
用户指示：只做合约就行，策略市场那么多，不合适就自己研究——
不要停在纸面观察，继续发明新的合约策略。本轮即执行该指示。

已测过、不再做的家族（见 盈利策略迭代.md / 第二~六轮）：
  ORB、VWAP、EMA、ORB+VWAP+ATR 及 6 个变体、配对 BTC/ETH、波动率扩张、
  RSI 反转（S3 原版及 20/80 低换手版）、资金费率极值反转、资金费率结算点
  套利、亚盘突破、高波动日门控（及前 10% 收紧版）、跨币种轮动、
  资金费率+价格背离、截面日内多空（08:00/12:00 排序）、纯永续资金费价差、
  S3 低换手 + Maker 混合现实（A+B 组合）。

本轮 4 个新家族（规则全部写死在文件头，先定再跑；每家族只测一组
事先定好的参数，无网格寻优、无全样本挑参；因此不存在“用后半段选型”
的问题——选型这一步根本没有发生）：
  F1 BTC 领涨-山寨跟随（跨币领先滞后，lead-lag）：
    赌：BTC 的 2h 涨跌会领先山寨约 1 根 K 线，且山寨还没跟上时才有肉。
    与已测家族的区别：第四轮截面多空是每天固定时刻按当日收益排序、
    4 条腿市场中性持有到收盘；C2 轮动是每天挑 |4h| 最大的 1 个币顺做。
    F1 是事件驱动：只在 BTC 出现 2h 大波动那一刻、且山寨尚未跟上时才
    进场，单腿、短持（≤4h）。BTC 本身不做（BTC 带自己 = 普通动量，
    已测过），只做 7 个山寨。
    规则：信号根 i（UTC 08:00~19:00 收盘）：BTC 2h 收益
      rBTC = c[i]/c[i-2]-1，|rBTC| >= 0.5%；且山寨自身 2h 收益
      |rALT| < 0.5*|rBTC|（还没跟上，否则跳过）。方向 = sign(rBTC)。
      下一根开盘进场；止损 1xATR、止盈 1.5xATR（ATR(14,1h)，信号根），
      最多持 4 根 K 线；每天每币最多 2 笔；当天 23:00 收盘强制平仓。
  F2 波动率状态切换（高波做趋势、低波做反转）：
    赌：波动率状态决定当日方向信号的符号——高波日上午的涨跌会延续，
    低波日上午的涨跌会回吐。C1 高波动日门控只做了半边（高波日才做、
    只做趋势、低波日空仓）；F2 两边都做，且方向随状态翻转。
    规则：每天 08:00（07:00 根收盘后）决策。上午收益
      m = c[07:00]/o[00:00]-1；ATR 状态 = 当日 07:00 根 ATR(14)
      / 过去 20 个交易日同一时刻 ATR 的中位数；>= 1.15 为高波日，
      否则低波日。|m| < 0.2% 则跳过（上午太平，无方向可赌）。
      高波日方向 = sign(m)，低波日方向 = -sign(m)。
      08:00 根开盘进场；止损 1xATR、止盈 1.5xATR；持有到止损/止盈/
      当天 23:00 收盘；每天每币最多 1 笔。前 20 天热身，无交易。
  F3 插针 / 长影线反转（清算扫单后的反转，stop-hunt fade）：
    赌：日内出现长下影线 = 空头扫止损后被接回，价格短线反弹；
    长上影线反向对称。信号来自 K 线形态（影线/实体比），不是 RSI、
    不是突破、不是波动率——此前 13 个家族没有一个用过影线形态。
    规则：信号根 i（UTC 08:00~19:00 收盘）：做多：下影线
      wick_lo = min(o,c)-l >= 2*|o-c|（实体），且 wick_lo >= 0.5xATR，
      且区间 h-l >= 0.5xATR，且收盘 c >= l + 0.6*(h-l)（收在区间上部）。
      做空对称：上影线 wick_hi = h-max(o,c) >= 2*|o-c| 且 >= 0.5xATR，
      且 h-l >= 0.5xATR，且 c <= l + 0.4*(h-l)。
      下一根开盘进场；止损 1xATR、止盈 1xATR（反转是短命的，不贪）；
      最多持 4 根 K 线；每天每币最多 2 笔；当天 23:00 收盘强制平仓。
  F4 资金费率变化驱动（费率的一阶差分，不是水平）：
    赌：费率本身极端（S4/C3/R6 都测过水平）不等于价格马上反转，
    但费率“加速变拥挤”（一期之内跳升）是新的信息：多头在一期之内
    快速加拥挤，短线有回吐压力。反向对称。信号只在结算点出现。
    规则：只看 08:00 与 16:00 UTC 两个结算点（00:00 点排除：入场
      会跨 UTC 日，同第六轮约定）。dR = 当期已结算费率 - 上一期费率。
      dR >= +0.006% 做空，dR <= -0.006% 做多；结算后 1 小时那根开盘
      进场（08:00 点 -> 09:00 开盘，16:00 点 -> 17:00 开盘，无前视）；
      止损 1xATR、止盈 1xATR（ATR(14,1h)，入场前一根）；最多持 4 根；
      每天每币最多 2 笔；当天 23:00 收盘强制平仓。
    窗口限制：Gate 资金费率接口只能回溯约 180 天，F4 只能跑
      2026-05-21~11-15（179 天），分半为 2026-05-21~08-18（90 天）
      与 2026-08-19~11-15（89 天），报告里单独说明，不假装是 365 天。

持仓量（OI）方向核查（本轮跑之前已做，结论写死）：
  2026-11-17 实测 Gate API v4：GET /futures/usdt/open_interest
  返回 MISSING_REQUIRED_HEADER（需要签名，是私有端点，非公开）；
  公开的 /futures/usdt/tickers 只给当前快照 total_size（当前持仓量），
  没有历史序列接口。因此“持仓量变化驱动”在 Gate 公开数据上无法
  回测 365 天，本轮不做该方向，不假装有数据。待 Gate 开放历史 OI
  公开接口后再议（见报告第 6 节）。

统一口径（与前几轮一致，除非另有说明）：
  数据：本地缓存 data/gate_1h_365d_{SYM}_USDT.csv（各 8,761 根 1h，
    2025-11-16~2026-11-15，365 个完整 UTC 日，零缺口，8 币时间戳
    完全对齐，脚本内 assert）；资金费 data/gate_funding_365d_{SYM}.json
    （各 537 条，2026-05-21 起；F1/F2/F3 前半段资金费按 0 计——
    第三轮已验证后半段 8 币资金费合计只有 -6.15 USDT，可忽略）。
  粒度：1h（Gate 30m 接口最多取约 10,000 根，365 天取不到）。
  成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）。
  Maker 只做上限对照 M1（入场 -0.01%，止盈出场 -0.01%，止损/EOD/到
  期出场市价 0.125%/边）与混合现实 M2（沿用第三轮公式与 B 实测成交率/
  逆向惩罚，新币种用 SOL 保守代理）。每笔保证金 10% 权益、1x 为主；
  当天 23:00（23:00 那根收盘）强制平仓、不过夜；单日 -2% 熔断
  （与第三轮同款）；同根 K 线同时碰止损和止盈时先判止损（前置同款约定）。
  1x 下维持保证金对应的爆仓幅度约 99%，日内不可能触发，清算逻辑省略
  （注明，不假装测过）。
  窗口：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~2026-05-19
    （185 天）；后半段 2026-05-20~2026-11-15（180 天）。
    F4 例外：全 179 天 2026-05-21~11-15，前 90 天 / 后 89 天。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。
  达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
    否则诚实写不达标。F1 看 7 个山寨平均（BTC 不参与），F2/F3 看
    三币平均与八币平均，F4 看八币平均（179 天窗口）。

运行：python3 gate_iter_round7.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round7_summary.json
      + data/gate_iter_round7_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
import statistics
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
ALTS = [s for s in SYMBOLS if s != "BTC_USDT"]
MEME = {"DOGE_USDT"}  # 单独标注 Meme 币风险

START_DAY = datetime(2025, 11, 16, tzinfo=timezone.utc)
END_DAY = datetime(2026, 11, 16, tzinfo=timezone.utc)
SPLIT_DAY = datetime(2026, 5, 20, tzinfo=timezone.utc)  # 前半段止于 05-19
FUNDING_START = datetime(2026, 5, 21, tzinfo=timezone.utc)
F4_SPLIT = datetime(2026, 8, 19, tzinfo=timezone.utc)  # F4 前半止于 08-18

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(symbol):
    with open(os.path.join(DATA_DIR, f"gate_1h_365d_{symbol}.csv"), newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day=24):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason in ("stop_loss", "eod", "max_hold"):
        exit_rate = TAKER_EXIT
    elif reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def simulate(symbol, signals, funding, days_subset, max_per_day, label):
    """通用日内引擎。
    signals: dict entry_t -> {"direction": +/-1, "atr": float,
              "sl_mult": float, "tp_mult": float, "max_hold": int(根数)}。
    入场价 = 入场根开盘价；止损/止盈按入场价与信号根 ATR 现算；
    同根同时碰到先判止损；持满 max_hold 根在该根收盘平仓；当天
    23:00 根收盘强制平仓；单日 -2% 熔断后不再开新仓。
    返回 (trades, curve, n_days)。trades 为 Taker 口径明细。"""
    bars = simulate.BARS[symbol]
    atr = simulate.ATR[symbol]
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, 24)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= pos["max_hold"] - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": sig["max_hold"]}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


# ----------------------------------------------------------------------
# 信号生成器（每个只返回 {entry_t: signal}；生成时只用信号根及之前的数据）
# ----------------------------------------------------------------------

def build_f1_signals(alt_bars, btc_bars, alt_atr, btc_atr):
    """F1：BTC 2h 大波动 + 山寨没跟上 -> 顺 BTC 方向做山寨。"""
    sigs = {}
    idx = {b["t"]: i for i, b in enumerate(alt_bars)}
    for i in range(2, len(alt_bars)):
        b = alt_bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour <= 19):
            continue
        if alt_atr[i] is None:
            continue
        r_btc = btc_bars[i]["c"] / btc_bars[i - 2]["c"] - 1
        if abs(r_btc) < 0.005:
            continue
        r_alt = alt_bars[i]["c"] / alt_bars[i - 2]["c"] - 1
        if abs(r_alt) >= 0.5 * abs(r_btc):
            continue  # 山寨已经跟上了，没有滞后可吃
        entry_t = alt_bars[i + 1]["t"]  # 下一根开盘进场
        sigs[entry_t] = {"direction": 1 if r_btc > 0 else -1,
                         "atr": alt_atr[i], "sl_mult": 1.0, "tp_mult": 1.5,
                         "max_hold": 4}
    return sigs


def build_f2_signals(bars, atr):
    """F2：每天 08:00 决策；高波顺上午方向、低波反做。返回 {entry_t: signal}。"""
    sigs = {}
    days = group_days(bars, 24)
    dlist = sorted(days)
    atr_0700 = []  # 每天 07:00 根收盘时的 ATR（与 entry 前一根同一时刻）
    for d in dlist:
        db = days[d]
        # 07:00 根是当天第 8 根（00:00 为第 1 根）
        atr_0700.append(atr[[b["t"] for b in bars].index(db[7]["t"])])
    t_of = {b["t"]: i for i, b in enumerate(bars)}
    for k, d in enumerate(dlist):
        if k < 20:
            continue  # 热身：需要过去 20 天 ATR 中位数
        db = days[d]
        a_now = atr_0700[k]
        if a_now is None:
            continue
        hist = [x for x in atr_0700[k - 20:k] if x is not None]
        if len(hist) < 20:
            continue
        med = statistics.median(hist)
        morning = db[7]["c"] / db[0]["o"] - 1  # 00:00 开 -> 07:00 收
        if abs(morning) < 0.002:
            continue
        high_vol = a_now >= 1.15 * med
        direction = (1 if morning > 0 else -1) if high_vol else (-1 if morning > 0 else 1)
        entry_t = db[8]["t"]  # 08:00 根开盘进场
        sigs[entry_t] = {"direction": direction, "atr": a_now,
                         "sl_mult": 1.0, "tp_mult": 1.5, "max_hold": 24}
    return sigs


def build_f3_signals(bars, atr):
    """F3：长影线反转（插针 fade）。"""
    sigs = {}
    for i in range(1, len(bars) - 1):
        b = bars[i]
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if not (8 <= dt.hour <= 19):
            continue
        a = atr[i]
        if a is None:
            continue
        o, h, l, c = b["o"], b["h"], b["l"], b["c"]
        body = abs(o - c)
        rng = h - l
        if body <= 0 or rng < 0.5 * a:
            continue
        direction = 0
        wick_lo = min(o, c) - l
        wick_hi = h - max(o, c)
        if wick_lo >= 2 * body and wick_lo >= 0.5 * a and c >= l + 0.6 * rng:
            direction = 1
        elif wick_hi >= 2 * body and wick_hi >= 0.5 * a and c <= l + 0.4 * rng:
            direction = -1
        if direction == 0:
            continue
        entry_t = bars[i + 1]["t"]
        sigs[entry_t] = {"direction": direction, "atr": a,
                         "sl_mult": 1.0, "tp_mult": 1.0, "max_hold": 4}
    return sigs


def build_f4_signals(bars, atr, funding):
    """F4：资金费率一阶差分。只看 08:00/16:00 结算点，结算后 1h 进场。"""
    sigs = {}
    t_of = {b["t"]: i for i, b in enumerate(bars)}
    for t in sorted(funding):
        dt = datetime.fromtimestamp(t, timezone.utc)
        if dt.hour not in (8, 16):
            continue
        prev_t = t - 8 * 3600
        if prev_t not in funding:
            continue
        d_r = funding[t] - funding[prev_t]
        if abs(d_r) < 0.00006:  # 0.006%
            continue
        entry_t = t + 3600  # 结算后 1 小时那根开盘（09:00 / 17:00）
        if entry_t not in t_of:
            continue
        gi = t_of[entry_t]
        a = atr[gi - 1] if gi >= 1 else None
        if a is None:
            continue
        direction = -1 if d_r > 0 else 1  # 费率加速变拥挤 -> 反向 fade
        sigs[entry_t] = {"direction": direction, "atr": a,
                         "sl_mult": 1.0, "tp_mult": 1.0, "max_hold": 4}
    return sigs


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def summarize_window(sym, trades, curve, label, n_signals):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins += 1 if pnl_m1 > 0 else 0
    peak, mdd = m1_curve[0], 0.0
    for v in m1_curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n, "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins / n, 4) if n else None,
        "m1_max_dd": round(mdd, 4),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
    }


def main():
    print("盈利策略迭代 · 第七轮：4 个新合约日内家族（全模拟）")
    print("F1 BTC领涨-山寨跟随 / F2 波动率状态切换 / F3 插针反转 / F4 资金费率变化驱动")
    print("达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    data = {}
    for sym in SYMBOLS:
        bars = load_bars(sym)
        funding = load_funding(sym)
        data[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data[sym][0]] == base_ts, f"{sym} 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h、365 个完整 UTC 日、时间戳完全对齐、零缺口。")
    print("持仓量核查：Gate /futures/usdt/open_interest 需签名（私有端点），无公开历史"
          " OI 序列——OI 方向本轮不做，见报告。")

    simulate.BARS = {s: data[s][0] for s in SYMBOLS}
    simulate.ATR = {s: atr_wilder(data[s][0]) for s in SYMBOLS}

    days_all = set(group_days(data["BTC_USDT"][0], 24).keys())
    days_front = {d for d in days_all if d < SPLIT_DAY.date()}
    days_back = {d for d in days_all if d >= SPLIT_DAY.date()}
    f4_days_all = {d for d in days_all if d >= FUNDING_START.date()}
    f4_front = {d for d in f4_days_all if d < F4_SPLIT.date()}
    f4_back = {d for d in f4_days_all if d >= F4_SPLIT.date()}
    print(f"窗口：全 365d（{len(days_all)} 天）前 {len(days_front)} 天 / 后 {len(days_back)} 天；"
          f"F4 窗口 179 天（前 {len(f4_front)} 天 / 后 {len(f4_back)} 天）。")

    # ---- 生成全部信号（只用信号根及之前的数据，无前视）----
    signals = {}  # (family, symbol) -> {entry_t: signal}
    btc_bars = data["BTC_USDT"][0]
    for sym in ALTS:
        signals[("F1", sym)] = build_f1_signals(
            data[sym][0], btc_bars, simulate.ATR[sym], simulate.ATR["BTC_USDT"])
    for sym in SYMBOLS:
        signals[("F2", sym)] = build_f2_signals(data[sym][0], simulate.ATR[sym])
        signals[("F3", sym)] = build_f3_signals(data[sym][0], simulate.ATR[sym])
        signals[("F4", sym)] = build_f4_signals(data[sym][0], simulate.ATR[sym], data[sym][1])
    for fam in ["F1", "F2", "F3", "F4"]:
        tot = sum(len(signals[(fam, s)]) for s in SYMBOLS if (fam, s) in signals)
        print(f"[{fam}] 全窗口信号数合计：{tot}（生成后才跑回测，不做信号筛选）")

    FAMS = [("F1", "F1-BTC-lead-lag", ALTS, 2,
             [("365d", None), ("前185d", days_front), ("后180d", days_back)]),
            ("F2", "F2-vol-regime-switch", SYMBOLS, 1,
             [("365d", None), ("前185d", days_front), ("后180d", days_back)]),
            ("F3", "F3-wick-reversal", SYMBOLS, 2,
             [("365d", None), ("前185d", days_front), ("后180d", days_back)]),
            ("F4", "F4-funding-delta", SYMBOLS, 2,
             [("179d", f4_days_all), ("前90d", f4_front), ("后89d", f4_back)])]

    all_results, all_trades = [], []
    for fam, label, syms, max_per_day, windows in FAMS:
        print(f"\n=== {fam} {label} ===")
        for sym in syms:
            bars, funding = data[sym]
            sigs = signals[(fam, sym)]
            for wname, subset in windows:
                trades, curve, ndays = simulate(sym, sigs, funding, subset, max_per_day, label)
                res = summarize_window(sym, trades, curve, label, len(sigs))
                res["split"] = wname
                res["days"] = ndays
                all_results.append(res)
                if wname in ("365d", "179d"):
                    for t in trades:
                        t2 = dict(t)
                        t2["variant"] = label
                        t2["family"] = fam
                        if fam == "F4":
                            t2["split"] = ("前90d" if datetime.fromtimestamp(
                                t["entry_t"], timezone.utc).date() < F4_SPLIT.date() else "后89d")
                        else:
                            t2["split"] = ("前185d" if datetime.fromtimestamp(
                                t["entry_t"], timezone.utc).date() < SPLIT_DAY.date() else "后180d")
                        all_trades.append(t2)
                print(f"[{fam} {sym} {wname}] n={res['trades']} 信号={res['signals']} "
                      f"胜率={res['win_rate']} 盈亏比={res['profit_factor']} "
                      f"Taker {res['taker_net_pct']*100:+.2f}% | M1 {res['m1_net_pct']*100:+.2f}% "
                      f"(t={res['m1_t']}, MDD {res['m1_max_dd']*100:.2f}%) | "
                      f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
                      f"成本={res['taker_cost_sum']:+.0f} 平均持仓={res['avg_hold_min']}分钟")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker；M2 括号内）===")
    for fam, label, syms, _, windows in FAMS:
        for wname, _ in windows:
            rs = [r for r in all_results if r["label"] == label and r["split"] == wname]
            for key in ("taker_net_pct", "m2_net_pct"):
                avg = sum(r[key] for r in rs) / len(rs)
                print(f"  {fam} {wname} {key} 平均 {avg*100:+.2f}%  "
                      f"（{' / '.join(f'{r['symbol'][:4]} {r[key]*100:+.2f}%' for r in rs)}）")
            for scope, ss in ([("三币", CORE3), ("八币", SYMBOLS)] if fam in ("F2", "F3") else
                              ([("七山寨", ALTS)] if fam == "F1" else [("八币", SYMBOLS)])):
                sub = [r for r in rs if r["symbol"] in ss]
                if sub:
                    print(f"    {fam} {wname} {scope} Taker 平均 "
                          f"{sum(r['taker_net_pct'] for r in sub)/len(sub)*100:+.2f}% / "
                          f"M2 平均 {sum(r['m2_net_pct'] for r in sub)/len(sub)*100:+.2f}%")

    # ---- pooled t（全期明细，M1 逐笔）----
    print("\n=== Pooled t 值（M1 逐笔净收益占权益 %，全期明细）===")
    for fam, label, _, _, _ in FAMS:
        sub = [t for t in all_trades if t["family"] == fam]
        for wname in (["365d", "前185d", "后180d"] if fam != "F4" else ["179d", "前90d", "后89d"]):
            s2 = [t for t in sub if wname in ("365d", "179d") or t["split"] == wname]
            vals = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
            print(f"  {fam} {wname}：n={len(vals)} pooled t={t_value(vals)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker；M2 同时列出）===")
    for fam, label, syms, _, windows in FAMS:
        wnames = [w for w, _ in windows]
        row_t, row_m2 = {}, {}
        for wname in wnames:
            rs = [r for r in all_results if r["label"] == label and r["split"] == wname]
            row_t[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            row_m2[wname] = sum(r["m2_net_pct"] for r in rs) / len(rs)
        good_t = row_t[wnames[1]] > 0 and row_t[wnames[2]] > 0 and row_t[wnames[0]] > 0.02
        good_m2 = row_m2[wnames[1]] > 0 and row_m2[wnames[2]] > 0 and row_m2[wnames[0]] > 0.02
        print(f"  {fam} Taker：前 {row_t[wnames[1]]*100:+.2f}% / 后 {row_t[wnames[2]]*100:+.2f}% / "
              f"全 {row_t[wnames[0]]*100:+.2f}% → {'达标' if good_t else '不达标'}；"
              f"M2：前 {row_m2[wnames[1]]*100:+.2f}% / 后 {row_m2[wnames[2]]*100:+.2f}% / "
              f"全 {row_m2[wnames[0]]*100:+.2f}% → {'达标' if good_m2 else '不达标'}")
        # 单币检查：两半都为正的币
        for sym in syms:
            rf = [r for r in all_results if r["label"] == label and r["symbol"] == sym
                  and r["split"] == wnames[1]][0]
            rb = [r for r in all_results if r["label"] == label and r["symbol"] == sym
                  and r["split"] == wnames[2]][0]
            r365 = [r for r in all_results if r["label"] == label and r["symbol"] == sym
                    and r["split"] == wnames[0]][0]
            flag = "★ 两半都为正" if (rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0) else ""
            print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / 后 {rb['taker_net_pct']*100:+.2f}% / "
                  f"全 {r365['taker_net_pct']*100:+.2f}% (n={r365['trades']}, t={r365['m1_t']}) {flag}")

    with open(os.path.join(DATA_DIR, "gate_iter_round7_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round7_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "variant", "split", "symbol", "direction", "entry_time_utc",
                    "exit_time_utc", "entry", "exit", "notional", "pnl_taker_usdt",
                    "pnl_maker_m1_usdt", "price_pnl_usdt", "cost_taker_usdt",
                    "cost_maker_usdt", "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["family"], x["symbol"])):
            w.writerow([t["family"], t["variant"], t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round7_summary.json")
    print("明细已写入：data/gate_iter_round7_trades.csv")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
