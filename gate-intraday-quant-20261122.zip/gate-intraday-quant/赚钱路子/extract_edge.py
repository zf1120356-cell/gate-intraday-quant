#!/usr/bin/env python3
"""盈利优势提取 · 汇总脚本（SMC 之后范围）

范围：第十一、十二、十四、十五、十六轮 + SMC 定义审计。
不含：第 1-10 轮通用策略、第五轮资金费率套利、第十三轮（通用出场调优，
仅在与 SMC 零件叠加时才收——本范围内的 SMC 组合均未用 SL0.5，故不收）。

读 data/gate_iter_round{11,12,14,15,16}_summary.json 与 trades.csv、
data/smc_definition_audit.json，输出总表数字。
口径：每币独立 10 万 USDT、1x；主口径 Taker（双边约 25 USDT/笔）；
M1 = Maker 100% 成交上界，M2 = Maker 混合现实口径；
币均 % = 各币净 USDT 之和 / (币数 × 100,000)；
毛利 = 价差盈亏 - 资金费（不扣交易成本）；毛利/成本 = 毛利 / Taker 成本合计；
盈亏平衡线约每笔毛利 +25 USDT。
用法：python3 extract_edge.py
"""
import csv
import glob
import json
import math
import os
import statistics
from collections import defaultdict

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
ROUNDS = {
    11: "gate_iter_round11_summary.json",
    12: "gate_iter_round12_summary.json",
    14: "gate_iter_round14_summary.json",
    15: "gate_iter_round15_summary.json",
    16: "gate_iter_round16_summary.json",
}
EQUITY_PER_COIN = 100_000.0


def is_full(split):
    s = str(split or "")
    return bool(s) and "前" not in s and "后" not in s


def gross_pt(r):
    if r.get("gross_per_trade_usdt") is not None:
        return r["gross_per_trade_usdt"]
    if r.get("gross_usdt") is not None and r.get("trades"):
        return r["gross_usdt"] / r["trades"]
    return None


def load_summary(fname):
    with open(os.path.join(BASE, fname), encoding="utf-8") as f:
        return json.load(f)


def pooled_taker_t(trades_file, variant_col="variant"):
    """从 trades.csv 按 variant 算逐笔 Taker PnL 的 t 值（mean/(sd/sqrt(n))）。
    有 family 列时按 (family, variant) 分组，避免把不同信号源混在一起。"""
    path = os.path.join(BASE, trades_file)
    if not os.path.exists(path):
        return {}
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    if not rows:
        return {}
    pnl_col = None
    for cand in ("pnl_taker_usdt", "pnl"):
        if cand in rows[0]:
            pnl_col = cand
            break
    if pnl_col is None:
        return {}
    by_var = defaultdict(list)
    for r in rows:
        try:
            key = (r.get("family"), r.get(variant_col, "")) if "family" in rows[0] else r.get(variant_col, "")
            by_var[key].append(float(r[pnl_col]))
        except (TypeError, ValueError):
            continue
    out = {}
    for v, vals in by_var.items():
        if len(vals) >= 2:
            sd = statistics.stdev(vals)
            out[v] = statistics.mean(vals) / (sd / math.sqrt(len(vals))) if sd else None
        else:
            out[v] = None
    return out


def main():
    print("# 盈利优势提取 · 脚本复现总表（SMC 之后范围：11/12/14/15/16 轮）")
    print("# 币均% = 合计净 USDT / (币数 x 100000)；毛利/成本 = 毛利合计 / Taker 成本合计")
    print()
    all_full_rows = []
    for rnd, fname in sorted(ROUNDS.items()):
        d = load_summary(fname)
        full = [r for r in d if is_full(r.get("split"))]
        all_full_rows.extend(full)
        print(f"== 第{rnd}轮 {fname}：全期行 {len(full)}")
        # 组合级 pooled
        groups = defaultdict(list)
        for r in full:
            groups[r.get("label")].append(r)
        for lab, rs in sorted(groups.items()):
            n = sum(r.get("trades", 0) or 0 for r in rs)
            gross = sum(r.get("gross_usdt", 0) or 0 for r in rs)
            tc = sum(r.get("taker_cost_sum", 0) or 0 for r in rs)
            tak = sum(r.get("taker_net_usdt", 0) or 0 for r in rs)
            m1 = sum(r.get("m1_net_usdt", 0) or 0 for r in rs)
            m2 = sum(r.get("m2_net_usdt", 0) or 0 for r in rs)
            ncoins = len({r.get("symbol") for r in rs})
            denom = ncoins * EQUITY_PER_COIN
            print(
                f"  [组合] {lab}: n={n} 毛利={gross:.0f} 每笔毛利={gross / n if n else 0:.2f} "
                f"毛利/成本={gross / tc if tc else float('nan'):.3f} "
                f"Taker币均={tak / denom * 100:.2f}% M1币均={m1 / denom * 100:.2f}% "
                f"M2币均={m2 / denom * 100:.2f}%"
            )
        # 单币全期 Taker 为正（n>=1 列出，n<5 另标）
        print("  [单币全期 Taker>0]")
        for r in sorted(full, key=lambda x: -(x.get("taker_net_pct") or 0)):
            if (r.get("taker_net_pct") or 0) > 0:
                print(
                    f"    {r.get('label')} {r.get('symbol')} n={r.get('trades')} "
                    f"Taker={r['taker_net_pct'] * 100:.2f}% t_taker={r.get('t_taker')} "
                    f"M1={ (r.get('m1_net_pct') or 0) * 100:.2f}% m1_t={r.get('m1_t')} "
                    f"毛利/笔={gross_pt(r)} 毛利/成本={(r.get('gross_usdt') or 0) / (r.get('taker_cost_sum') or 1):.3f}"
                )
        # 单币全期 M1>0 且 n>=20（Maker 上界正值）
        print("  [单币全期 M1>0 且 n>=20]")
        for r in sorted(full, key=lambda x: -(x.get("m1_net_pct") or 0)):
            if (r.get("m1_net_pct") or 0) > 0 and (r.get("trades") or 0) >= 20:
                print(
                    f"    {r.get('label')} {r.get('symbol')} n={r.get('trades')} "
                    f"M1={r['m1_net_pct'] * 100:.2f}% m1_t={r.get('m1_t')} "
                    f"Taker={r.get('taker_net_pct') * 100:.2f}% 毛利/笔={gross_pt(r)}"
                )
        # 前后两半都为正（Taker / M1 / M2 分别列）
        groups2 = defaultdict(dict)
        for r in d:
            groups2[(r.get("label"), r.get("symbol"))][str(r.get("split"))] = r
        print("  [前后两半都为正的币x组合格子]")
        for (lab, sym), mp in sorted(groups2.items()):
            pre = [v for k, v in mp.items() if "前" in k]
            post = [v for k, v in mp.items() if "后" in k]
            if not pre or not post:
                continue
            for field in ("taker_net_pct", "m1_net_pct", "m2_net_pct"):
                pv, qv = pre[0].get(field), post[0].get(field)
                if pv is not None and qv is not None and pv > 0 and qv > 0:
                    print(
                        f"    {lab} {sym} {field} 前 n={pre[0].get('trades')} "
                        f"{pv * 100:.2f}% / 后 n={post[0].get('trades')} {qv * 100:.2f}%"
                    )
        print()

    # 全范围计数：Taker 为正的全期单币行 / 全期行总数
    n_pos_taker = sum(1 for r in all_full_rows if (r.get("taker_net_pct") or 0) > 0)
    print(f"全范围全期行总数={len(all_full_rows)}，其中 Taker 为正的单币行={n_pos_taker}")
    print()
    # pooled taker t（trades.csv 重算，与各轮报告的 pooled t 对照）
    print("== pooled Taker t（由 trades.csv 逐笔 Taker PnL 重算；报告值见各轮报告正文）")
    for rnd, tf in [(11, "gate_iter_round11_trades.csv"),
                    (12, "gate_iter_round12_trades.csv"),
                    (14, "gate_iter_round14_trades.csv"),
                    (15, "gate_iter_round15_trades.csv"),
                    (16, "gate_iter_round16_trades.csv")]:
        for v, t in sorted(pooled_taker_t(tf).items()):
            if v:
                print(f"  第{rnd}轮 {v}: pooled t(Taker)={t if t is None else round(t, 2)}")
    print()
    # SMC 定义审计
    print("== SMC 定义审计（smc_definition_audit.json；只数数，不涉及盈亏）")
    a = json.load(open(os.path.join(BASE, "smc_definition_audit.json"), encoding="utf-8"))
    tot = a["total"]
    print(f"  第十二轮 S1 破位总数={tot['breaks']}，有教程版 OB={tot['has_ob']} "
          f"({tot['has_ob'] / tot['breaks'] * 100:.2f}%)，同侧清扫 N=3={tot['has_sweep_n3']} "
          f"({tot['has_sweep_n3'] / tot['breaks'] * 100:.2f}%)，有同向 FVG={tot['has_fvg']} "
          f"({tot['has_fvg'] / tot['breaks'] * 100:.2f}%)，严格 FVG={tot['has_fvg_strict']} "
          f"({tot['has_fvg_strict'] / tot['breaks'] * 100:.2f}%)")
    print(f"  三条件全满足={tot['three_conditions']} ({tot['three_conditions'] / tot['breaks'] * 100:.2f}%)，"
          f"严格口径={tot['three_conditions_strict']} "
          f"({tot['three_conditions_strict'] / tot['breaks'] * 100:.2f}%)")
    print(f"  诱导 N=5={tot['has_inducement_n5']} ({tot['has_inducement_n5'] / tot['breaks'] * 100:.2f}%)，"
          f"诱导 N=3={tot['has_inducement_n3']}，根本无内部回撤点 N=5={tot['no_internal_n5']} "
          f"({tot['no_internal_n5'] / tot['breaks'] * 100:.2f}%)")
    print("  （检测器口径另见 SMC定义审计.md §1：4,865 次事件中有效 OB 886 个 = 19.44%，其中强的 116 个）")
    print()
    # R16 事后时段切分（F1，family+variant+入场小时；仅作附记，不计入优势）
    print("== 附记：R16 trades.csv 事后入场小时切分（family+variant+UTC 小时，n>=20 且毛利/笔>20）")
    rows = list(csv.DictReader(open(os.path.join(BASE, "gate_iter_round16_trades.csv"), encoding="utf-8")))
    g = defaultdict(list)
    for r in rows:
        g[(r.get("family"), r.get("variant"), int(r["entry_time_utc"][11:13]))].append(float(r["price_pnl_usdt"]))
    for k, v in sorted(g.items(), key=lambda kv: -(sum(kv[1]) / len(kv[1]))):
        if len(v) >= 20 and sum(v) / len(v) > 20:
            print(f"  {k} n={len(v)} 毛利/笔={sum(v) / len(v):.2f} 毛利合计={sum(v):.0f} "
                  f"（事后切分，Taker 净/笔约 {sum(v) / len(v) - 25:.2f}，见报告 §2 E23）")


if __name__ == "__main__":
    main()
