#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第四十一轮：SQZ 波动率挤压突破（分系统 SUB-SMC，新信号第一次测）
================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

预注册（跑前写死，不可改；来源：分系统下一代信号设计.md §1 SQZ + §4 测试计划）：
  测什么：SQZ 波动率挤压突破——ATR(14) 处于 20 根最低且 8 根区间
  <1.5xATR 时压缩，第一根收盘突破区间且振幅 >=1xATR 就顺方向入场，
  止损放在区间另一边（结构止损，构造上约 0.5xATR），吃波动率均值回归后
  状态切换的第一段。
  信号定义（设计 §1.1，参数一字不改；判定时点按裁定 (2) 的唯一自洽读法；
  全部用已收盘 15m K 线，入场一律下一根 15m 开盘；多空对称）：
    - 压缩（在扩张根前一根 j=i-1 收盘时判定）：15m ATR(14)（Wilder）
      处于过去 20 根的最低值；且过去 8 根（bars[j-7..j]，含信号根 j）
      的最高-最低 < 1.5xATR(14)。
    - 扩张：第一根收盘价站上同一 8 根区间上沿（做多）或跌破下沿
      （做空）的 15m K 线，且该根振幅（最高-最低）>= 1.0xATR(14)。
      只认第一根突破根；已在区间外的后续根不再发信号。
    - 入场：扩张根收盘后的下一根 15m 开盘，顺扩张方向。
    - 止损（结构止损）：做多 -> 8 根区间下沿 - 0.1xATR；做空 -> 8 根区间
      上沿 + 0.1xATR（ATR 取扩张根收盘时的最新值）。构造上止损距离
      约 0.5-1.0xATR，目标均值 <=0.6xATR。
    - 止盈/出场：沿用 SUB 现行标准（v1.2）：无固定止盈；有利 >=2xATR 时
      跟踪止盈激活，止损上移至峰值 -/+1xATR；无 23:00 强平。
  口径裁定（设计文档本身有两处出入，跑前写死裁定，见报告 §0）：
    (1) 持满上限：§1.1 写主臂“不设持满上限、诊断臂保留 16 根”，§4.3 写
        主臂 16 根、诊断臂去掉上限——两者正好相反。任务书明确主臂与
        35/40 轮一字相同（16 根持满上限），故执行 §4.3：主臂 16 根，
        诊断臂去掉上限（只报告、不参与四项标准）。
    (2) 压缩判定时点（§1.1 用“信号根”“扩张根”两个词，字面有歧义；
        本轮按唯一自洽的读法执行，证明如下，见报告 §0）：
        若压缩在扩张根 i 收盘时判定（ATR[i] 为过去 20 根最低 且
        bars[i-7..i] 区间 <1.5xATR[i] 且扩张根振幅 >=1.0xATR[i]），
        三者联立无解——振幅要求 TR[i] >= 振幅 >= ATR[i]，ATR 最低
        要求 TR[i] <= ATR[i-1]（否则 ATR[i] > ATR[i-1] 不是最低），
        两式推出 TR[i] = ATR[i-1] 且振幅 = TR[i] = ATR[i] 精确成立，
        即扩张根的真实波幅须与前一根 ATR 分毫不差——连续价格下
        测度为零的刀锋事件。字面读法下 SQZ 几乎永不发信号，与设计
        §5.1“真实样本、期望 +20~+27/笔”的预期自相矛盾。
        故执行唯一自洽的读法：压缩在扩张根前一根 j=i-1 收盘时判定
        （ATR[j] 为过去 20 根最低；8 根区间 = bars[j-7..j] <1.5xATR[j]），
        扩张根 i 收盘突破同一 8 根区间且振幅 >=1.0xATR[i]，
        入场为扩张根下一根开盘。此时“8 根区间”在压缩句与扩张句里
        是同一区间，“第一根突破根”仍有意义（前一根收盘价若已突破
        它自己的 8 根区间，则扩张根不是第一根）。字面口径的信号数
        只作一条诊断计数（预期 ~0），不参与判定。
    (3) R1 的对照臂：设计 §1.4(iv) 写“R1 省成本占比 <=80%（对照臂
        §4.3）”，但 §4.3 是执行口径、对照臂在 §4.2。SQZ 是新信号、
        没有“未过滤版”可作 R1 基准，故裁定：基准 = 同宇宙同窗口的
        A/B/C 三模板全量臂的合并（分系统现行系统 = 三模板合池）；
        R1 = SQZ 相对该合池的净改善里省成本的占比。另报 SQZ 相对每
        个单模板的 R1 作诊断。判定以合池为准。
  数据：新宇宙 8 币 BCH/PUMP/APT/ICP/AAVE/ONDO/JCT/PIPPIN（设计 §4.1，
  排除 32 个已回测币；见 data/gate_iter_round41_selection.json），
  窗口 2026-08-09~11-16（100 天，9,600 根 15m），半段切分 2026-09-21
  （前 43 天 / 后 57 天，与 37/40 轮同）。1h 2025-11-16~2026-11-16
  （8,761 根，仅对照臂用）；资金费 2026-08-01 起（7 天 chunk 重取后
  8 币均为 321 条、零缺口——首轮 30 天 chunk 被 limit=100 截断，
  PUMP/ONDO/JCT/PIPPIN 各缺 121 个结算点，已修好重取，见选择文件）。
  执行口径（设计 §4.3，与 35/40 轮主臂一字相同）：名义 10,000/笔，1 倍；
  每币每天最多 2 笔；北京 01:00-07:00（UTC 17:00-23:00）不开新单；
  单币单日 -2000 熔断；成本模型 = 现行真实口径（Taker 主口径）。
  主臂：16 根持满上限。诊断臂：去掉持满上限（实盘 SUB v1.1 规则），
  只报告、不参与四项标准（其资金费按 35 轮口径只计入场日与入场日+1
  的 08:00/16:00 点，持仓 >2 天的笔会漏计资金费，报告里单独算差额）。
  对照臂（设计 §4.2，每轮必做）：同宇宙、同窗口、不加新信号的 A/B/C
  全量臂（37 轮 FULL 口径，15m ATR，2 笔/天，16 根持满，跟踪 2xATR
  激活；35 轮 builders 一字不改）。作用：判断新宇宙本身是难是易。
  第一关（设计 §4.2，跑全量回测之前）：信号率与联合样本量——目标
  >=100 笔；<50 笔则该信号不可测，测试停止并如实报告，不放宽条件凑数。
  报什么：SQZ 主臂：信号数、笔数、全期 Taker 净（币均）、前/后半段
  Taker 净、每笔毛利、毛利/成本、P(到 1xATR)、P(到 2x|到 1x)、R1 三项
  分解；逐币表；§4.4 诊断（止损距离分布、P(1x)/P(2x|1x) vs 0.51/0.60
  基准、每币 1xATR 的 USDT 值与每币毛利、时段拆分、信号率与跳过原因拆分）。
  通过标准（设计 §1.4，四项全过才算）：(i) 全期 1 倍 Taker 净 > +2%
  （币均），(ii) 前后两半都为正，(iii) 每笔毛利 > 25 USDT 且两半都
  > 25，(iv) R1 省成本占比 <= 80%（基准 = A/B/C 合池，见上裁定 (3)）。
  证伪：四项任一不过，则 SQZ 证伪，下一轮按设计顺序测 FBO（不许调 SQZ
  的阈值重测、不许换批币重测 SQZ）。
  定位：验证轮（新信号、新宇宙第一次测），计 1 个方向；若通过，它仍只
  是在一个新宇宙上的一次通过，后续验证须在 2026-11-16 之后的实盘纸面
  数据上看（12 月 18 日月度复核时判）。
  预期（设计 §5.1，跑前写死）：期望约在 +20~+27/笔之间（上限 +27.1，
  紧止损截赢笔后下修），刚好卡在 25 线上下；四项标准里最可能不过的是
  (iii) 每笔毛利两半 >25。若败，最可能的败因是 P(走到 1x) 被紧止损
  打下来（<0.45）或止损均值 >0.6xATR。

无未来数据（用户 2026-11-21 硬性要求，执行前自查，写死在代码里）：
  - SQZ 信号只用已收盘 15m K 线：压缩判定用扩张根 i（含）之前的已收盘根，
    ATR 用扩张根收盘时的 Wilder ATR(14)；扩张判定用扩张根收盘价；
    入场一律是扩张根的下一根 15m 开盘价（信号字典的键就是入场根时刻）。
    “第一根突破根”判定只用扩张根及其前一根的收盘价与各自的 8 根区间，
    不读任何未来根。
  - 对照臂复用 R15 builders 与 R35.simulate_stream 一字不改（合规性见
    37 轮脚本说明）；模拟每根只用当根高低收与已持仓状态；资金费只计
    入场日与入场日+1 的 08:00/16:00 结算点（35 轮口径）。
  数据绝对不能做假：算不出就写算不出（33 轮缺 atr 列即是先例）。

运行：python3 gate_iter_round41.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round41_summary.json
      + data/gate_iter_round41_cells.json + data/gate_iter_round41_trades.csv
复现：跑两遍，三个文件的 md5 应完全一致。
"""

import bisect
import csv
import json
import math
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round15 as R15  # 三个 SMC 模板 builders（原样恢复）
import gate_iter_round35 as R35  # 复用 35 轮引擎：load / atr / simulate_stream / summarize
import gate_iter_round37 as R37  # 复用 37 轮新宇宙 1h 合并函数、格子统计口径、时段划分

DATA_DIR = os.path.join(SCRIPT_DIR, "data")

# ---- 新宇宙（跑前定死；设计 §4.1 + data/gate_iter_round41_selection.json）----
SYMBOLS = ["BCH_USDT", "PUMP_USDT", "APT_USDT", "ICP_USDT",
           "AAVE_USDT", "ONDO_USDT", "JCT_USDT", "PIPPIN_USDT"]
# R35.summarize 用 FILL/PENALTY（Maker 混合诊断 M2）且只在原 8 币上有值。
# 沿用 R35 自身的规则（gate_iter_round35.py：无实测成交率的币一律取 SOL 的值，
# 37 轮同法）：新宇宙 8 币同样取 SOL 的 FILL/PENALTY。M2 只是诊断量
# （R4：执行口径只认混合现实，M1/M0 作诊断）；本轮四项通过标准只用
# Taker 净与毛利，M2 默认值不影响证伪/通过结论。
for _sym in SYMBOLS:
    if _sym not in R35.FILL:
        R35.FILL[_sym] = R35.FILL["SOL_USDT"]
        R35.PENALTY[_sym] = R35.PENALTY["SOL_USDT"]
SPLIT_R35 = R35.SPLIT_R35  # 2026-09-21；前半段 08-09~09-20（43 天）/ 后 57 天
START_EQUITY = R35.START_EQUITY
NOTIONAL = R35.NOTIONAL
MAX_PER_DAY = R35.MAX_PER_DAY
MAX_HOLD_MAIN = R35.MAX_HOLD_MAIN  # 主臂 16 根（与 35/40 轮一致，见裁定 (1)）

# SQZ 参数（设计 §1.1，跑前写死，不许改）
SQZ_ATR_PERIOD = 14
SQZ_ATR_LOW_LOOKBACK = 20   # ATR 处于过去 20 根的最低值
SQZ_RANGE_BARS = 8          # 8 根区间
SQZ_RANGE_MULT = 1.5        # 8 根区间 < 1.5xATR
SQZ_AMP_MULT = 1.0          # 扩张根振幅 >= 1.0xATR
SQZ_STOP_PAD_MULT = 0.1     # 止损在区间边之外 0.1xATR
SQZ_FIRST_GATE_MIN_TRADES = 50   # 第一关：<50 笔不可测
SQZ_FIRST_GATE_TARGET_TRADES = 100

TEMPLATES = [("A", "R15-A 扫荡反转做多", R15.build_A),
             ("B", "R15-B FVG 回踩做多", R15.build_B),
             ("C", "R15-C 供给拒绝做空", R15.build_C)]


def split_of(et):
    return ("前43d" if datetime.fromtimestamp(et, timezone.utc).date()
            < SPLIT_R35.date() else "后57d")


def session_of(entry_t):
    return R37.session_of(entry_t)


def fav_atr(t):
    """峰值有利浮动（ATR 倍数）。与 35/36/37 轮诊断同口径：
    max_favour_usdt / (10,000 x ATR / 入场价)。"""
    if not t.get("atr"):
        return 0.0
    return (t.get("max_favour_usdt", 0.0) / NOTIONAL) / (t["atr"] / t["entry"])


# ----------------------------------------------------------------------
# SQZ 信号 builder（设计 §1.1，判定时点按裁定 (2) 的唯一自洽读法）
#   扩张根 i（信号在 i 收盘时生成，入场 = bars[i+1] 的开盘）：
#     压缩（在 j=i-1 收盘时判定）：atr[j] 为过去 20 根最低；
#       bars[j-7..j] 的最高-最低 < 1.5xATR[j]
#     扩张：c[i] > max(h[j-7..j])（做多）或 c[i] < min(l[j-7..j])（做空），
#       且 h[i]-l[i] >= 1.0xATR[i]
#     第一根：前一根（即 j）的收盘价未站上/跌破它自己的 8 根区间
#       （bars[j-8..j-1]，同向）——否则扩张根不是第一根
#     止损：做多 -> min(l[j-7..j]) - 0.1xATR[i]；
#           做空 -> max(h[j-7..j]) + 0.1xATR[i]
#   字面口径诊断：压缩在扩张根 i 收盘时判定（ATR[i] 为 20 根最低 且
#   bars[i-7..i] 区间 <1.5xATR[i]）的信号数——按裁定 (2) 的证明应 ~0，
#   只计数、不参与判定。
# ----------------------------------------------------------------------
def build_sqz(bars, atr):
    """返回 (signals, funnel)：
    signals: {entry_t: {direction, atr, stop, range_hi, range_lo, tag}}
    funnel: 逐阶段漏斗计数（每阶段 = 通过之前全部阶段 + 本阶段的根数）。"""
    n = len(bars)
    signals = {}
    funnel = Counter()
    funnel["bars_eval"] = 0
    funnel["atr_low"] = 0
    funnel["range_tight"] = 0
    funnel["breakout"] = 0
    funnel["amplitude"] = 0
    funnel["first_breakout"] = 0
    funnel["signals"] = 0
    funnel["literal_reading_signals"] = 0  # 字面口径诊断：压缩在扩张根判定的信号数
    funnel["warmup_bars"] = 0
    # ATR(14) 首个有效值在下标 13；压缩根 j 的 20 根最低值窗口需 j-19 >= 13，
    # 即 j >= 32、扩张根 i = j+1 >= 33；i+1 须存在（入场根）。
    for i in range(33, n - 1):
        funnel["bars_eval"] += 1
        j = i - 1
        a_sig = atr[j]
        a_exp = atr[i]
        if a_sig is None or a_sig <= 0 or a_exp is None or a_exp <= 0:
            continue
        # 字面口径诊断（与主流程无关）：压缩在扩张根 i 收盘时判定
        if a_exp == min(atr[i - 19:i + 1]):
            hi_lit = max(b["h"] for b in bars[i - 7:i + 1])
            lo_lit = min(b["l"] for b in bars[i - 7:i + 1])
            if hi_lit - lo_lit < SQZ_RANGE_MULT * a_exp:
                hi8_lit = max(b["h"] for b in bars[i - 8:i])
                lo8_lit = min(b["l"] for b in bars[i - 8:i])
                c_lit = bars[i]["c"]
                d_lit = 1 if c_lit > hi8_lit else (-1 if c_lit < lo8_lit else 0)
                if d_lit != 0 and bars[i]["h"] - bars[i]["l"] >= SQZ_AMP_MULT * a_exp:
                    hi8p = max(b["h"] for b in bars[i - 9:i - 1])
                    lo8p = min(b["l"] for b in bars[i - 9:i - 1])
                    c_prev = bars[i - 1]["c"]
                    if not ((d_lit == 1 and c_prev > hi8p) or
                            (d_lit == -1 and c_prev < lo8p)):
                        funnel["literal_reading_signals"] += 1
        # 阶段 1：压缩根 j 的 ATR 为过去 20 根最低
        w20 = atr[j - 19:j + 1]
        if any(x is None for x in w20):
            continue
        if a_sig != min(w20):
            continue
        funnel["atr_low"] += 1
        # 阶段 2：过去 8 根（bars[j-7..j]）区间 < 1.5xATR[j]
        hi8 = max(b["h"] for b in bars[j - 7:j + 1])
        lo8 = min(b["l"] for b in bars[j - 7:j + 1])
        if hi8 - lo8 >= SQZ_RANGE_MULT * a_sig:
            continue
        funnel["range_tight"] += 1
        # 阶段 3：扩张根收盘突破同一 8 根区间
        c = bars[i]["c"]
        direction = 0
        if c > hi8:
            direction = 1
        elif c < lo8:
            direction = -1
        else:
            continue
        funnel["breakout"] += 1
        # 阶段 4：扩张根振幅 >= 1.0xATR[i]
        if bars[i]["h"] - bars[i]["l"] < SQZ_AMP_MULT * a_exp:
            continue
        funnel["amplitude"] += 1
        # 阶段 5：第一根突破根——前一根（压缩根 j）的收盘价未突破它自己的
        # 8 根区间（bars[j-8..j-1]，同向）；否则扩张根不是第一根
        hi8_prev = max(b["h"] for b in bars[j - 8:j])
        lo8_prev = min(b["l"] for b in bars[j - 8:j])
        c_prev = bars[j]["c"]
        if direction == 1 and c_prev > hi8_prev:
            continue
        if direction == -1 and c_prev < lo8_prev:
            continue
        funnel["first_breakout"] += 1
        entry_t = bars[i + 1]["t"]
        stop = lo8 - SQZ_STOP_PAD_MULT * a_exp if direction == 1 else hi8 + SQZ_STOP_PAD_MULT * a_exp
        signals[entry_t] = {
            "direction": direction, "atr": a_exp, "atr_basis": "15m",
            "stop": stop, "range_hi": hi8, "range_lo": lo8,
            "expand_t": bars[i]["t"],
            "tag": f"SQZ-{'L' if direction == 1 else 'S'}",
        }
        funnel["signals"] += 1
    funnel["warmup_bars"] = 33  # i=0..32 不能作扩张根（压缩根 j 的 ATR 窗口未预热）
    return signals, funnel


def _selftest_sqz():
    """SQZ builder 自测（合成数据，不读任何真实数据）。
    构造 60 根 15m：前 40 根横盘（o=100.0, h=100.1, l=99.9, c=100.0，
    ATR 恒定 0.2）；第 41 根（下标 40）为扩张根：o=100.1, h=101.5,
    l=100.0, c=101.4，振幅 1.5；第 42 根（下标 41）继续在区间外。
    预期：下标 40 应发做多信号（压缩根 = 下标 39：ATR 0.2 为 20 根最低，
    8 根区间 0.2 < 1.5x0.2；扩张根收盘 101.4 > 区间上沿 100.1，振幅
    1.5 >= ATR[40]；前一根收盘 100.0 未突破它自己的区间），入场根 =
    下标 41 的开盘时刻，止损 = 区间下沿 99.9 - 0.1xATR[40]；
    下标 41 不发信号（压缩根 = 下标 40 的 ATR 不是 20 根最低）；
    下标 40 之前无信号；字面口径信号数 = 0（ATR[40] 不是最低）。
    另：把第 41 根振幅改小（o=100.15, h=100.25, l=100.12, c=100.22，
    振幅 0.13 < ATR[40]）应无信号（振幅关）。"""
    base_t = 1760000000 - (1760000000 % 900)
    bars = []
    for i in range(60):
        t = base_t + i * 900
        bars.append({"t": t, "o": 100.0, "h": 100.1, "l": 99.9, "c": 100.0,
                     "v": 10.0, "sum": 1000.0})
    # 第 41 根（下标 40）：扩张根
    bars[40] = {"t": base_t + 40 * 900, "o": 100.1, "h": 101.5, "l": 100.0,
                "c": 101.4, "v": 50.0, "sum": 5000.0}
    # 第 42 根（下标 41）：继续在区间外
    bars[41] = {"t": base_t + 41 * 900, "o": 101.4, "h": 102.0, "l": 101.2,
                "c": 101.8, "v": 40.0, "sum": 4000.0}
    atr = R35.atr_wilder(bars)
    sig, fun = build_sqz(bars, atr)
    assert len(sig) == 1, f"自测失败：应恰好 1 个信号，实际 {len(sig)}"
    et = bars[41]["t"]
    assert et in sig, "自测失败：信号入场根应为扩张根的下一根"
    s = sig[et]
    assert s["direction"] == 1, f"自测失败：方向应为做多，实际 {s['direction']}"
    assert s["range_hi"] == 100.1 and s["range_lo"] == 99.9, \
        f"自测失败：区间应为前 8 根的 [99.9, 100.1]，实际 [{s['range_lo']}, {s['range_hi']}]"
    assert abs(s["stop"] - (99.9 - 0.1 * s["atr"])) < 1e-9, \
        f"自测失败：止损应为区间下沿 - 0.1xATR[扩张根]，实际 {s['stop']}"
    assert fun["signals"] == 1 and fun["first_breakout"] == 1, \
        f"自测失败：漏斗 signals/first_breakout 应为 1，实际 {fun}"
    assert fun["literal_reading_signals"] == 0, \
        f"自测失败：字面口径信号数应为 0，实际 {fun['literal_reading_signals']}"
    # 振幅关：把扩张根振幅改小
    bars2 = [dict(b) for b in bars]
    bars2[40] = {"t": base_t + 40 * 900, "o": 100.15, "h": 100.25, "l": 100.12,
                 "c": 100.22, "v": 50.0, "sum": 5000.0}
    atr2 = R35.atr_wilder(bars2)
    sig2, _ = build_sqz(bars2, atr2)
    assert len(sig2) == 0, f"自测失败：振幅不足时应 0 信号，实际 {len(sig2)}"
    print("[SQZ builder 自测 ✓] 扩张根发信号、止损=区间下沿-0.1xATR[扩张根]、"
          "区间外后续根不发信号、振幅不足不发信号、字面口径信号数为 0 均正确")


# ----------------------------------------------------------------------
# 流式模拟：SQZ 版（R35.simulate_stream 的推广，一字不改其余逻辑）
#   差别只有两处：(a) 止损优先用 sig["stop"]（结构止损，绝对价），
#   无 "stop" 键时退回 entry -/+ 1xATR（与 R35 一字相同，用于等价自测）；
#   (b) max_hold 参数化（16 = 主臂；None = 诊断臂去掉上限）。
#   其余：每根处理顺序、出场原因、资金费、成本、熔断、每日 2 笔上限、
#   跳空止损跳过、当根收盘平仓后不再开新仓、data_end 收尾，全部与 R35 一致。
#   另计：n_skip_gap（入场开盘价已穿止损而跳过）、每笔止损距离
#   （stop_dist_atr / stop_dist_usdt，按实际入场价计）。
# ----------------------------------------------------------------------
def simulate_sqz(symbol, bars, signals, funding, max_per_day, label,
                 activate_mult=R35.TRAIL_ACTIVATE_MULT, max_hold=MAX_HOLD_MAIN):
    trades = []
    curve = [START_EQUITY]
    equity = START_EQUITY
    trades_by_entry_date = {}
    day_pnl = {}
    pos = None
    n_skip_open = 0
    n_skip_cap = 0
    n_skip_breaker = 0
    n_skip_gap = 0

    def close_trade(tr, exit_t, exit_price, reason):
        nonlocal equity
        tr["exit_t"], tr["exit"] = exit_t, exit_price
        tr["reason"] = reason
        tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
        tr["funding_cost_usdt"] = R35.funding_cost_between(
            funding, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
        tr["cost_usdt"] = tr["notional"] * R35.ROUNDTRIP_COST
        tr["cost_maker_usdt"] = R35.maker_cost(tr["notional"], reason)
        move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
        tr["price_pnl"] = tr["notional"] * move
        tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
        tr["pnl_pct_equity"] = tr["pnl"] / START_EQUITY
        tr["peak"] = tr.get("peak")
        tr["trail_active"] = tr.get("trail_active", False)
        tr["max_favour_usdt"] = (((tr["peak"] - tr["entry"]) / tr["entry"]) * tr["direction"]
                                 * tr["notional"]) if tr.get("peak") is not None else 0.0
        equity += tr["pnl"]
        exit_date = datetime.fromtimestamp(exit_t, timezone.utc).date()
        day_pnl[exit_date] = day_pnl.get(exit_date, 0.0) + tr["pnl"]
        trades.append(tr)
        curve.append(equity)

    for gi, b in enumerate(bars):
        if pos is not None and b["t"] in signals:
            n_skip_open += 1
        just_closed = False
        if pos is not None:
            d = pos["direction"]
            exited = False
            if d == 1:
                if b["l"] <= pos["stop"]:
                    reason = "trailing_stop" if pos["trail_active"] else "stop_loss"
                    close_trade(pos, b["t"], pos["stop"], reason)
                    exited = True
            else:
                if b["h"] >= pos["stop"]:
                    reason = "trailing_stop" if pos["trail_active"] else "stop_loss"
                    close_trade(pos, b["t"], pos["stop"], reason)
                    exited = True
            if exited:
                pos = None
                just_closed = True
            elif max_hold is not None and gi - pos["entry_gi"] >= max_hold - 1:
                close_trade(pos, b["t"], b["c"], "max_hold")
                pos = None
                just_closed = True
            else:
                a = pos["atr"]
                if d == 1:
                    if b["h"] > pos["peak"]:
                        pos["peak"] = b["h"]
                else:
                    if b["l"] < pos["peak"]:
                        pos["peak"] = b["l"]
                if not pos["trail_active"]:
                    favour = (pos["peak"] - pos["entry"]) * d
                    if favour >= activate_mult * a:
                        pos["trail_active"] = True
                if pos["trail_active"]:
                    cand = (pos["peak"] - R35.TRAIL_ATR_MULT * a if d == 1
                            else pos["peak"] + R35.TRAIL_ATR_MULT * a)
                    if d == 1:
                        if cand > pos["stop"]:
                            pos["stop"] = cand
                    else:
                        if cand < pos["stop"]:
                            pos["stop"] = cand
        if pos is None and not just_closed:
            sig = signals.get(b["t"])
            if sig is None:
                continue
            entry_date = datetime.fromtimestamp(b["t"], timezone.utc).date()
            if trades_by_entry_date.get(entry_date, 0) >= max_per_day:
                n_skip_cap += 1
                continue
            if day_pnl.get(entry_date, 0.0) <= R35.DAILY_HALT:
                n_skip_breaker += 1
                continue
            entry = b["o"]
            a = sig["atr"]
            if "stop" in sig:
                stop = sig["stop"]
            else:
                stop = entry - R35.SL_MULT * a if sig["direction"] == 1 else entry + R35.SL_MULT * a
            if (sig["direction"] == 1 and entry <= stop) or (sig["direction"] == -1 and entry >= stop):
                n_skip_gap += 1
                continue
            pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                   "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                   "stop": stop, "tp": None, "atr": a,
                   "peak": entry, "trail_active": False,
                   "notional": NOTIONAL, "margin": 0.10 * NOTIONAL,
                   "exit_t": None, "exit": None, "pnl": 0.0,
                   "reason": "", "funding_cost_usdt": 0.0,
                   "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                   "hold_min": None, "pnl_pct_equity": 0.0,
                   "max_hold": max_hold,
                   "atr_basis": sig.get("atr_basis", ""), "tag": sig.get("tag", ""),
                   "stop_dist_atr": abs(entry - stop) / a if a else None,
                   "stop_dist_usdt": abs(entry - stop) / entry * NOTIONAL,
                   "range_hi": sig.get("range_hi"), "range_lo": sig.get("range_lo"),
                   "expand_t": sig.get("expand_t")}
            trades_by_entry_date[entry_date] = trades_by_entry_date.get(entry_date, 0) + 1
    if pos is not None:
        close_trade(pos, bars[-1]["t"], bars[-1]["c"], "data_end")
        pos = None
    stats = {"skip_open": n_skip_open, "skip_cap": n_skip_cap,
             "skip_breaker": n_skip_breaker, "skip_gap": n_skip_gap}
    return trades, curve, stats


def _selftest_sim_equivalence():
    """simulate_sqz 与 R35.simulate_stream 等价自测：同一组信号
    （不带 "stop" 键，止损退回 entry -/+ 1xATR）、同一 max_hold=16，
    两引擎的逐笔结果必须一字相同（entry_t/exit_t/exit/reason/pnl）。
    用 BCH 的 A 模板信号（真实数据）跑——若我的复制改动了任何逻辑，
    这里就会露出来。"""
    bars = R35.load_bars(os.path.join(DATA_DIR, "gate_15m_103d_BCH_USDT.csv"))
    funding = R35.load_funding("BCH_USDT")
    data1h = R37.build_1h_combined_new(["BCH_USDT"])
    bars1h, a1h = data1h["BCH_USDT"]
    R15.in_killzone = lambda t: True
    sig_raw, _ = R15.build_A(bars, bars1h, a1h)
    atr15 = R35.atr_wilder(bars)
    idx = {b["t"]: i for i, b in enumerate(bars)}
    sig = {}
    for et, s in sig_raw.items():
        if R35._entry_in_no_new_window(et):
            continue
        gi = idx[et]
        a15 = atr15[gi - 1] if gi - 1 >= 0 else None
        if a15 is None:
            continue
        sig[et] = {"direction": s["direction"], "atr": a15, "atr_basis": "15m"}
    t1, _, _ = R35.simulate_stream("BCH_USDT", bars, sig, funding, MAX_PER_DAY, "EQ-TEST")
    t2, _, _ = simulate_sqz("BCH_USDT", bars, sig, funding, MAX_PER_DAY, "EQ-TEST",
                            max_hold=MAX_HOLD_MAIN)
    assert len(t1) == len(t2), f"等价自测失败：笔数 {len(t1)} vs {len(t2)}"
    for x, y in zip(t1, t2):
        for k in ("entry_t", "exit_t", "exit", "reason"):
            assert x[k] == y[k], f"等价自测失败：{k} {x[k]} vs {y[k]}"
        assert abs(x["pnl"] - y["pnl"]) < 1e-9, f"等价自测失败：pnl {x['pnl']} vs {y['pnl']}"
    print(f"[引擎等价自测 ✓] simulate_sqz（无 stop 键、16 根上限）与 "
          f"R35.simulate_stream 在 BCH/A 信号上逐笔一字相同（{len(t1)} 笔）")


def funding_cost_full(funding, entry_t, exit_t, notional, direction):
    """诊断用：全部 08:00/16:00 结算点（不限入场日与入场日+1）。
    只用于诊断臂持仓 >2 天的资金费漏计差额；不参与任何一笔的 pnl。"""
    if not funding:
        return 0.0
    cost = 0.0
    day = datetime.fromtimestamp(entry_t, timezone.utc).date()
    d = day
    while d <= datetime.fromtimestamp(exit_t, timezone.utc).date():
        ds = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
        for h in (8, 16):
            s = int((ds + timedelta(hours=h)).timestamp())
            if entry_t < s <= exit_t and s in funding:
                cost += funding[s] * notional * (1 if direction == 1 else -1)
        d += timedelta(days=1)
    return cost


def cell_stats_r41(fam, group, trades, bench, symbols):
    """一个格子的全部上报数字（数学与 R37.cell_stats 一字相同，只把
    SYMBOLS 与切分函数参数化——R37 的版本硬编码旧宇宙币种与 09-21 切分）。
    bench = 对照基准的 USDT 合计（净/毛利/成本），用于 R1 三项分解。
    四项标准：(i) 全期币均 Taker 净 > +2%；(ii) 两半都正；
    (iii) 每笔毛利 > 25 且两半都 > 25；(iv) R1 省成本占比 <= 80%
    （要求 d_net > 0）。"""
    n = len(trades)
    gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    cost = sum(t["cost_usdt"] for t in trades)
    net = sum(t["pnl"] for t in trades)
    per_coin_pct = {}
    for sym in symbols:
        st = [t for t in trades if t["symbol"] == sym]
        per_coin_pct[sym] = sum(t["pnl"] for t in st) / START_EQUITY
    coin_mean_pct = sum(per_coin_pct.values()) / len(symbols)
    half = {}
    for w in ("前43d", "后57d"):
        wt = [t for t in trades if split_of(t["entry_t"]) == w]
        wg = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in wt)
        wpc = {}
        for sym in symbols:
            st = [t for t in wt if t["symbol"] == sym]
            wpc[sym] = sum(t["pnl"] for t in st) / START_EQUITY
        half[w] = {
            "n": len(wt),
            "gross": wg,
            "gross_per_trade": (wg / len(wt)) if wt else None,
            "coin_mean_pct": sum(wpc.values()) / len(symbols),
            "net_usdt": sum(t["pnl"] for t in wt),
        }
    n1 = sum(1 for t in trades if fav_atr(t) >= 1.0 - 1e-9)
    n2 = sum(1 for t in trades if fav_atr(t) >= 2.0 - 1e-9)
    p1 = (n1 / n) if n else None
    p2_given_1 = (n2 / n1) if n1 else None
    d_net = net - bench["net"]
    d_gross = gross - bench["gross"]
    saved_cost = bench["cost"] - cost
    if abs(d_net - (d_gross + saved_cost)) > 0.01:
        raise AssertionError(f"R1 账目不对：{fam} {group} Δ净 {d_net} ≠ Δ毛利 {d_gross} + 省成本 {saved_cost}")
    saved_share = (saved_cost / d_net) if d_net > 0 else None
    c1 = coin_mean_pct > 0.02
    c2 = half["前43d"]["coin_mean_pct"] > 0 and half["后57d"]["coin_mean_pct"] > 0
    gpt = (gross / n) if n else None
    c3 = (gpt is not None and gpt > 25
          and half["前43d"]["gross_per_trade"] is not None and half["前43d"]["gross_per_trade"] > 25
          and half["后57d"]["gross_per_trade"] is not None and half["后57d"]["gross_per_trade"] > 25)
    c4 = (d_net > 0 and saved_share is not None and saved_share <= 0.80)
    return {
        "family": fam, "group": group, "n": n,
        "gross_usdt": round(gross, 2), "cost_usdt": round(cost, 2),
        "net_usdt": round(net, 2),
        "gross_per_trade": round(gpt, 2) if gpt is not None else None,
        "gross_cost_ratio": round(gross / cost, 4) if cost else None,
        "coin_mean_pct_full": round(coin_mean_pct, 4),
        "coin_mean_pct_front": round(half["前43d"]["coin_mean_pct"], 4),
        "coin_mean_pct_back": round(half["后57d"]["coin_mean_pct"], 4),
        "gross_per_trade_front": (round(half["前43d"]["gross_per_trade"], 2)
                                  if half["前43d"]["gross_per_trade"] is not None else None),
        "gross_per_trade_back": (round(half["后57d"]["gross_per_trade"], 2)
                                 if half["后57d"]["gross_per_trade"] is not None else None),
        "n_front": half["前43d"]["n"], "n_back": half["后57d"]["n"],
        "p_reach_1x": round(p1, 4) if p1 is not None else None,
        "p_reach_2x_given_1x": round(p2_given_1, 4) if p2_given_1 is not None else None,
        "n_reach_1x": n1, "n_reach_2x": n2,
        "r1_d_net": round(d_net, 2), "r1_d_gross": round(d_gross, 2),
        "r1_saved_cost": round(saved_cost, 2),
        "r1_saved_share": round(saved_share, 4) if saved_share is not None else None,
        "pass_c1_net_gt_2pct": c1, "pass_c2_both_halves_pos": c2,
        "pass_c3_gross_per_trade_gt_25": c3, "pass_c4_r1_le_80pct": c4,
        "pass_all": bool(c1 and c2 and c3 and c4),
    }


def _selftest_cell_stats():
    """cell_stats_r41 自测：用 37 轮 FULL A 臂的真实逐笔（trades.csv）
    与 37 轮报告公布的基准（A：229 笔、净 -4,297.32）核对——
    bench 取自身时 d_net=0、saved_share=None；n 与净须与报告一字相同
    （CSV 逐笔 pnl 保留 2 位小数，容差 0.05）。"""
    rows = []
    with open(os.path.join(DATA_DIR, "gate_iter_round37_trades.csv"), newline="") as f:
        for r in csv.DictReader(f):
            if r["family"] == "A" and r["arm"] == "FULL":
                rows.append({"symbol": r["symbol"],
                             "entry_t": int(datetime.fromisoformat(r["entry_time_utc"]).timestamp()),
                             "price_pnl": float(r["price_pnl_usdt"]),
                             "funding_cost_usdt": float(r["funding_cost_usdt"]),
                             "cost_usdt": float(r["cost_taker_usdt"]),
                             "pnl": float(r["pnl_taker_usdt"]),
                             "max_favour_usdt": float(r["max_favour_usdt"]),
                             "atr": float(r["atr"]) if r["atr"] else None,
                             "entry": float(r["entry"])})
    bench = {"net": sum(t["pnl"] for t in rows),
             "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in rows),
             "cost": sum(t["cost_usdt"] for t in rows)}
    c = cell_stats_r41("A", "FULL", rows, bench,
                       ["MMT_USDT", "WLD_USDT", "PIEVERSE_USDT", "AVAX_USDT",
                        "PAXG_USDT", "ARB_USDT", "FIL_USDT", "TAO_USDT"])
    assert c["n"] == 229, f"格子自测失败：A FULL 笔数 {c['n']} ≠ 229"
    assert abs(c["net_usdt"] - (-4297.32)) <= 0.05, \
        f"格子自测失败：A FULL 净 {c['net_usdt']} ≠ -4297.32"
    assert c["r1_d_net"] == 0.0 and c["r1_saved_share"] is None, \
        f"格子自测失败：自身作基准时 R1 应为 0/None，实际 {c['r1_d_net']}/{c['r1_saved_share']}"
    print(f"[格子统计自测 ✓] 37 轮 FULL A 臂复算：n={c['n']} 净 {c['net_usdt']:+.2f} "
          f"与 37 轮报告一字相同；R1 自身基准为 0/None ✓")


def main():
    _selftest_sqz()
    _selftest_sim_equivalence()
    _selftest_cell_stats()
    sel = json.load(open(os.path.join(DATA_DIR, "gate_iter_round41_selection.json")))
    assert sel["selected_symbols"] == SYMBOLS, "选择文件宇宙与本脚本不一致"
    assert sel["start_15m"] == "2026-08-09", \
        f"15m 窗口起点不是 2026-08-09（实际 {sel['start_15m']}），切分点与本脚本假设不符，停止"
    print("盈利策略迭代 · 第四十一轮：SQZ 波动率挤压突破（分系统 SUB-SMC，新信号第一次测）")
    print(f"新宇宙：{', '.join(s.replace('_USDT', '') for s in SYMBOLS)}")
    print("信号（设计 §1.1）：ATR(14) 过去 20 根最低 + 过去 8 根（含扩张根）区间 <1.5xATR"
          " + 第一根收盘突破 8 根区间且振幅 >=1xATR，下一根开盘顺方向入场；"
          "止损 = 区间另一边 -/+ 0.1xATR；出场跟踪止盈 2xATR 激活、主臂 16 根持满上限。")
    print("通过标准（四项全过才算）：(i) 全期币均 Taker 净 > +2%，(ii) 前后两半都为正，"
          "(iii) 每笔毛利 > 25 USDT 且两半都 > 25，(iv) R1 省成本占比 ≤ 80%"
          "（基准 = A/B/C 三模板全量臂合池，见报告 §0 裁定 (3)）。")

    # ---- 数据校验（与 37/40 轮同口径，窗口 2026-08-09~11-16，100 天）----
    data15 = {}
    for sym in SYMBOLS:
        bars = R35.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R35.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R35.group_days(bars, 96)
        assert len(days) == 100, f"{sym} 15m 完整日应为 100 天，实际 {len(days)}"
        assert len(bars) == 100 * 96, f"{sym} 15m 应为 {100*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15[SYMBOLS[0]][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 {SYMBOLS[0]} 不对齐"
    print("数据校验通过：8 币各 9,600 根 15m / 100 天；时间戳对齐、零缺口。")
    # 资金费完整性：8 币均为 321 条（2026-08-01~11-15，零缺口）
    for sym in SYMBOLS:
        f = data15[sym][1]
        assert len(f) == 321, f"{sym} 资金费应为 321 条，实际 {len(f)}"
    print("资金费校验通过：8 币各 321 条（2026-08-01~11-15），零缺口（7 天 chunk 重取后）。")

    data1h = R37.build_1h_combined_new(SYMBOLS)
    days_all_15 = set(R35.group_days(data15[SYMBOLS[0]][0], 96).keys())
    front_43 = {d for d in days_all_15 if d < SPLIT_R35.date()}
    back_57 = {d for d in days_all_15 if d >= SPLIT_R35.date()}
    print(f"窗口：全 100d（前 {len(front_43)} 天 2026-08-09~09-20 / "
          f"后 {len(back_57)} 天 2026-09-21~11-16）。")

    windows = [("100d", None), ("前43d", front_43), ("后57d", back_57)]
    atr15 = {s: R35.atr_wilder(data15[s][0]) for s in SYMBOLS}

    # ---- SQZ 信号 ----
    sqz_sig_raw, funnel_tot = {}, Counter()
    for sym in SYMBOLS:
        sig, fun = build_sqz(data15[sym][0], atr15[sym])
        sqz_sig_raw[sym] = sig
        funnel_tot.update(fun)
        print(f"[SQZ 信号 {sym.replace('_USDT', '')}] 扩张信号 {len(sig)} 个；"
              f"漏斗：ATR最低 {fun['atr_low']} → 区间紧 {fun['range_tight']} → "
              f"突破 {fun['breakout']} → 振幅 {fun['amplitude']} → 首根 {fun['first_breakout']} → "
              f"信号 {fun['signals']}（替代口径信号 {fun['alt_range_tight_signals']}）")
    print(f"[SQZ 信号合计] 8 币合计 {sum(len(v) for v in sqz_sig_raw.values())} 个信号；"
          f"评估根数 {funnel_tot['bars_eval']}；ATR 预热期 {funnel_tot['warmup_bars']} 根无信号；"
          f"字面口径（压缩在扩张根判定）信号 {funnel_tot['literal_reading_signals']} 个（仅诊断，预期 ~0）。")

    # 夜间禁单过滤
    sqz_sig, night_blocked = {}, {}
    for sym in SYMBOLS:
        sqz_sig[sym], night_blocked[sym] = {}, 0
        for et, s in sqz_sig_raw[sym].items():
            if R35._entry_in_no_new_window(et):
                night_blocked[sym] += 1
                continue
            sqz_sig[sym][et] = s
    n_sig = sum(len(v) for v in sqz_sig.values())
    print(f"[SQZ 信号] 夜间禁单时段拦掉 {sum(night_blocked.values())} 个信号；"
          f"入场信号 {n_sig} 个。")

    # ---- 第一关（设计 §4.2）：信号样本量 ----
    print(f"\n=== 第一关（定义审计）：SQZ 信号 {n_sig} 个（目标 >=100 笔，<50 笔不可测）===")
    gate_ok = n_sig >= SQZ_FIRST_GATE_MIN_TRADES
    if not gate_ok:
        print(f"  第一关不通过：信号仅 {n_sig} 个 < 50，SQZ 不可测，测试停止并如实报告。")
        with open(os.path.join(DATA_DIR, "gate_iter_round41_summary.json"), "w") as f:
            json.dump([{"family": "SQZ", "group": "MAIN", "verdict": "UNMEASURABLE",
                        "signals": n_sig,
                        "funnel": dict(funnel_tot),
                        "night_blocked": dict(night_blocked)}], f, indent=2, ensure_ascii=False)
        print("已写入 data/gate_iter_round41_summary.json（仅第一关结果）。")
        return
    print(f"  第一关通过：信号 {n_sig} 个（{'达到' if n_sig >= SQZ_FIRST_GATE_TARGET_TRADES else '未达到'}"
          f" 100 笔目标），继续全量回测。")

    # ---- 对照臂信号：35 轮三模板（去 Killzone → 夜禁过滤 → 15m ATR），与 37 轮一字相同 ----
    R15.in_killzone = lambda t: True
    idx_of_t = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in SYMBOLS}
    ctrl_sig, ctrl_night, ctrl_warmup = {}, {}, {}
    for fam, label, builder in TEMPLATES:
        ms, nb, wb = {}, {}, {}
        for sym in SYMBOLS:
            bars1h, a1h = data1h[sym]
            raw, _fun = builder(data15[sym][0], bars1h, a1h)
            ms[sym], nb[sym], wb[sym] = {}, 0, 0
            for et, s in raw.items():
                if R35._entry_in_no_new_window(et):
                    nb[sym] += 1
                    continue
                gi = idx_of_t[sym][et]
                a15 = atr15[sym][gi - 1] if gi - 1 >= 0 else None
                if a15 is None:
                    wb[sym] += 1
                    continue
                ms[sym][et] = {"direction": s["direction"], "atr": a15,
                               "atr_basis": "15m", "tag": s.get("tag", "")}
        ctrl_sig[fam] = ms
        ctrl_night[fam] = nb
        ctrl_warmup[fam] = wb
        print(f"[对照信号 {fam}] 夜间禁单拦掉 {sum(nb.values())} 个；ATR 未预热跳过 "
              f"{sum(wb.values())} 个；入场信号 {sum(len(v) for v in ms.values())} 个。")

    # ---- 模拟：SQZ 主臂（16 根上限）+ 诊断臂（无上限）+ 对照臂 ----
    all_results, all_trades = [], []
    arm_trades = {}

    def run_sqz_arm(arm, max_hold):
        fam_trades = []
        skip_tot = Counter()
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            trades, curve, stats = simulate_sqz(
                sym, bars, sqz_sig[sym], funding, MAX_PER_DAY,
                f"R41-SQZ-{arm}", max_hold=max_hold)
            fam_trades.extend(trades)
            skip_tot.update(stats)
        fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
        arm_trades[("SQZ", arm)] = fam_trades
        print(f"[SQZ-{arm}] 全期 n={len(fam_trades)}；跳过信号：持仓中 {skip_tot['skip_open']} / "
              f"满2笔 {skip_tot['skip_cap']} / 熔断 {skip_tot['skip_breaker']} / "
              f"入场穿止损 {skip_tot['skip_gap']}")
        for sym in SYMBOLS:
            st = [t for t in fam_trades if t["symbol"] == sym]
            for wname, _ in windows:
                wt = [t for t in st if wname == "100d" or split_of(t["entry_t"]) == wname]
                wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                eq = START_EQUITY
                wcurve = [eq]
                for t in wt_sorted:
                    eq += t["pnl"]
                    wcurve.append(eq)
                res = R35.summarize(sym, wt_sorted, wcurve,
                                    f"R41-SQZ-{arm}", len(sqz_sig[sym]))
                res["arm"] = f"SQZ-{arm}"
                res["family"] = "SQZ"
                res["template"] = "SQZ"
                res["variant"] = f"R41-SQZ-{arm}"
                res["granularity"] = "15m"
                res["atr_basis"] = "15m"
                res["split"] = wname
                res["days"] = 100 if wname == "100d" else (43 if wname == "前43d" else 57)
                res["signals_total"] = len(sqz_sig[sym])
                res["signals_blocked_night"] = night_blocked[sym]
                res["group"] = "SQZ"
                all_results.append(res)
        for t in fam_trades:
            t2 = dict(t)
            t2["arm"] = f"SQZ-{arm}"
            t2["family"] = "SQZ"
            t2["template"] = "SQZ"
            t2["variant"] = f"R41-SQZ-{arm}"
            t2["granularity"] = "15m"
            t2["atr_basis"] = "15m"
            t2["split"] = split_of(t["entry_t"])
            t2["entry_hour_utc"] = R35.entry_hour_utc(t["entry_t"])
            t2["session"] = session_of(t["entry_t"])
            t2["group"] = "SQZ"
            all_trades.append(t2)
        return fam_trades

    print("\n=== SQZ 主臂（16 根持满上限）===")
    sqz_main = run_sqz_arm("MAIN", MAX_HOLD_MAIN)
    print("\n=== SQZ 诊断臂（去掉持满上限，仅报告）===")
    sqz_diag = run_sqz_arm("DIAG", None)

    # 第一关的第二层：执行笔数 <50 同样不可测
    if len(sqz_main) < SQZ_FIRST_GATE_MIN_TRADES:
        print(f"\n[第一关] SQZ 主臂执行仅 {len(sqz_main)} 笔 < 50，信号不可测，"
              "四项标准不作判定（样本不足）。")
    print("\n=== 对照臂：A/B/C 全量（= 35 轮主臂口径，新宇宙复算）===")
    ctrl_trades = {}
    for fam, label, builder in TEMPLATES:
        fam_trades = []
        skip_tot = Counter()
        for sym in SYMBOLS:
            bars, funding = data15[sym]
            trades, curve, stats = R35.simulate_stream(
                sym, bars, ctrl_sig[fam][sym], funding, MAX_PER_DAY,
                f"R41-CTRL-{fam}")
            fam_trades.extend(trades)
            skip_tot.update(stats)
        fam_trades.sort(key=lambda t: (t["entry_t"], t["symbol"]))
        ctrl_trades[fam] = fam_trades
        print(f"[CTRL {fam}] 全期 n={len(fam_trades)}；跳过信号：持仓中 {skip_tot['skip_open']} / "
              f"满2笔 {skip_tot['skip_cap']} / 熔断 {skip_tot['skip_breaker']}")
        for sym in SYMBOLS:
            st = [t for t in fam_trades if t["symbol"] == sym]
            for wname, _ in windows:
                wt = [t for t in st if wname == "100d" or split_of(t["entry_t"]) == wname]
                wt_sorted = sorted(wt, key=lambda t: t["exit_t"])
                eq = START_EQUITY
                wcurve = [eq]
                for t in wt_sorted:
                    eq += t["pnl"]
                    wcurve.append(eq)
                res = R35.summarize(sym, wt_sorted, wcurve,
                                    f"R41-CTRL-{fam}", len(ctrl_sig[fam][sym]))
                res["arm"] = "CTRL"
                res["family"] = fam
                res["template"] = fam
                res["variant"] = f"R41-CTRL-{fam}"
                res["granularity"] = "15m"
                res["atr_basis"] = "15m"
                res["split"] = wname
                res["days"] = 100 if wname == "100d" else (43 if wname == "前43d" else 57)
                res["signals_total"] = len(ctrl_sig[fam][sym])
                res["signals_blocked_night"] = ctrl_night[fam][sym]
                res["signals_blocked_warmup"] = ctrl_warmup[fam][sym]
                res["group"] = "FULL"
                all_results.append(res)
        for t in fam_trades:
            t2 = dict(t)
            t2["arm"] = "CTRL"
            t2["family"] = fam
            t2["template"] = fam
            t2["variant"] = f"R41-CTRL-{fam}"
            t2["granularity"] = "15m"
            t2["atr_basis"] = "15m"
            t2["split"] = split_of(t["entry_t"])
            t2["entry_hour_utc"] = R35.entry_hour_utc(t["entry_t"])
            t2["session"] = session_of(t["entry_t"])
            t2["group"] = "FULL"
            all_trades.append(t2)

    # ---- 格子统计：SQZ 主臂（基准 = A/B/C 合池）+ 诊断臂（基准 = SQZ 主臂）----
    print("\n=== 格子统计 ===")
    bench_pool = {"net": 0.0, "gross": 0.0, "cost": 0.0}
    for fam in ("A", "B", "C"):
        ftr = ctrl_trades[fam]
        bench_pool["net"] += sum(t["pnl"] for t in ftr)
        bench_pool["gross"] += sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ftr)
        bench_pool["cost"] += sum(t["cost_usdt"] for t in ftr)
        print(f"  [对照 CTRL {fam}] n={len(ftr)} 毛利 "
              f"{sum(t['price_pnl'] - t['funding_cost_usdt'] for t in ftr):+.2f} "
              f"成本 {sum(t['cost_usdt'] for t in ftr):.2f} 净 {sum(t['pnl'] for t in ftr):+.2f} "
              f"每笔毛利 {sum(t['price_pnl'] - t['funding_cost_usdt'] for t in ftr)/len(ftr) if ftr else 0:+.2f}")
    print(f"  [基准合池 A+B+C] n={sum(len(ctrl_trades[f]) for f in ('A','B','C'))} "
          f"毛利 {bench_pool['gross']:+.2f} 成本 {bench_pool['cost']:.2f} 净 {bench_pool['net']:+.2f}")
    cells = []
    c_main = cell_stats_r41("SQZ", "MAIN", sqz_main, bench_pool, SYMBOLS)
    cells.append(c_main)
    print(f"  [SQZ MAIN] n={c_main['n']}（前 {c_main['n_front']} / 后 {c_main['n_back']}）"
          f"币均 Taker 全 {c_main['coin_mean_pct_full']*100:+.2f}% / 前 {c_main['coin_mean_pct_front']*100:+.2f}% / "
          f"后 {c_main['coin_mean_pct_back']*100:+.2f}% | 每笔毛利 {c_main['gross_per_trade']} "
          f"（前 {c_main['gross_per_trade_front']} / 后 {c_main['gross_per_trade_back']}）"
          f"毛利/成本 {c_main['gross_cost_ratio']} | P(1x)={c_main['p_reach_1x']} "
          f"P(2x|1x)={c_main['p_reach_2x_given_1x']} | R1 Δ净 {c_main['r1_d_net']:+.0f} "
          f"Δ毛利 {c_main['r1_d_gross']:+.0f} 省成本 {c_main['r1_saved_cost']:+.0f} "
          f"占比 {c_main['r1_saved_share'] if c_main['r1_saved_share'] is not None else '—'} | "
          f"四项 {'✓ 全过' if c_main['pass_all'] else '✗ 不过'} "
          f"(i){'✓' if c_main['pass_c1_net_gt_2pct'] else '✗'} "
          f"(ii){'✓' if c_main['pass_c2_both_halves_pos'] else '✗'} "
          f"(iii){'✓' if c_main['pass_c3_gross_per_trade_gt_25'] else '✗'} "
          f"(iv){'✓' if c_main['pass_c4_r1_le_80pct'] else '✗'}")
    bench_main = {"net": sum(t["pnl"] for t in sqz_main),
                  "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in sqz_main),
                  "cost": sum(t["cost_usdt"] for t in sqz_main)}
    c_diag = cell_stats_r41("SQZ", "DIAG", sqz_diag, bench_main, SYMBOLS)
    cells.append(c_diag)
    print(f"  [SQZ DIAG（仅报告）] n={c_diag['n']} 币均 Taker 全 {c_diag['coin_mean_pct_full']*100:+.2f}% "
          f"每笔毛利 {c_diag['gross_per_trade']}（前 {c_diag['gross_per_trade_front']} / "
          f"后 {c_diag['gross_per_trade_back']}）P(1x)={c_diag['p_reach_1x']} "
          f"P(2x|1x)={c_diag['p_reach_2x_given_1x']} | 相对主臂 R1 Δ净 {c_diag['r1_d_net']:+.0f} "
          f"Δ毛利 {c_diag['r1_d_gross']:+.0f} 省成本 {c_diag['r1_saved_cost']:+.0f}")
    # 诊断：SQZ 相对每个单模板的 R1
    for fam in ("A", "B", "C"):
        ftr = ctrl_trades[fam]
        bench1 = {"net": sum(t["pnl"] for t in ftr),
                  "gross": sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ftr),
                  "cost": sum(t["cost_usdt"] for t in ftr)}
        c1 = cell_stats_r41("SQZ", f"vs-{fam}", sqz_main, bench1, SYMBOLS)
        cells.append(c1)
        print(f"  [SQZ vs 单模板 {fam}（诊断）] Δ净 {c1['r1_d_net']:+.0f} Δ毛利 {c1['r1_d_gross']:+.0f} "
              f"省成本 {c1['r1_saved_cost']:+.0f} 占比 "
              f"{c1['r1_saved_share'] if c1['r1_saved_share'] is not None else '—'}")

    # ---- 诊断 §4.4 ----
    print("\n=== 诊断 §4.4（机制是否成立）===")
    # (1) 止损距离分布
    sd_atr = sorted(t["stop_dist_atr"] for t in sqz_main if t.get("stop_dist_atr") is not None)
    sd_usdt = sorted(t["stop_dist_usdt"] for t in sqz_main if t.get("stop_dist_usdt") is not None)
    if sd_atr:
        n_sd = len(sd_atr)
        med_atr = sd_atr[n_sd // 2] if n_sd % 2 == 1 else (sd_atr[n_sd // 2 - 1] + sd_atr[n_sd // 2]) / 2
        mean_atr = sum(sd_atr) / n_sd
        med_usdt = sd_usdt[n_sd // 2] if n_sd % 2 == 1 else (sd_usdt[n_sd // 2 - 1] + sd_usdt[n_sd // 2]) / 2
        mean_usdt = sum(sd_usdt) / n_sd
        print(f"  (1) 止损距离（主臂 {n_sd} 笔）：中位数 {med_atr:.3f}xATR / {med_usdt:.2f} USDT；"
              f"均值 {mean_atr:.3f}xATR / {mean_usdt:.2f} USDT；"
              f"机制要求中位数 <=0.7xATR：{'✓' if med_atr <= 0.7 else '✗'}")
    else:
        print("  (1) 止损距离：主臂 0 笔，算不出")
    # (2) P(1x) / P(2x|1x) vs 0.51 / 0.60 基准
    print(f"  (2) P(走到 1x)={c_main['p_reach_1x']}（基准 0.51）| "
          f"P(2x|1x)={c_main['p_reach_2x_given_1x']}（基准 0.60）| "
          f"走到 1x 笔数 {c_main['n_reach_1x']}/{c_main['n']}，走到 2x 笔数 {c_main['n_reach_2x']}")
    # (3) 每币 1xATR 的 USDT 值与每币毛利（双口径）
    print("  (3) 逐币：")
    for sym in SYMBOLS:
        st = [t for t in sqz_main if t["symbol"] == sym]
        if not st:
            print(f"    {sym.replace('_USDT', '')}：0 笔")
            continue
        atr_usdt = sum(t["atr"] / t["entry"] * NOTIONAL for t in st) / len(st)
        g = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in st)
        g_atr = sum((t["price_pnl"] - t["funding_cost_usdt"]) / (t["atr"] / t["entry"] * NOTIONAL)
                    for t in st) / len(st)
        f_wt = [t for t in st if split_of(t["entry_t"]) == "前43d"]
        b_wt = [t for t in st if split_of(t["entry_t"]) == "后57d"]
        print(f"    {sym.replace('_USDT', '')}：n={len(st)}（前 {len(f_wt)} / 后 {len(b_wt)}）"
              f" 1xATR 均值 {atr_usdt:.2f} USDT | 毛利 {g:+.2f} USDT（{g_atr:+.2f}xATR/笔）| "
              f"每笔毛利 {g/len(st):+.2f} USDT | 净 {sum(t['pnl'] for t in st):+.2f} "
              f"（币均 {sum(t['pnl'] for t in st)/START_EQUITY*100:+.2f}%）")
    # (4) 时段拆分（诊断，不作规则）
    print("  (4) 时段拆分（诊断）：")
    for ses in ("ASIA", "EURO", "US"):
        st = [t for t in sqz_main if session_of(t["entry_t"]) == ses]
        if not st:
            print(f"    {ses}：0 笔")
            continue
        g = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in st)
        print(f"    {ses}：n={len(st)} 毛利 {g:+.2f} 每笔毛利 {g/len(st):+.2f} "
              f"净 {sum(t['pnl'] for t in st):+.2f} P(1x)="
              f"{sum(1 for t in st if fav_atr(t) >= 1.0 - 1e-9)/len(st):.3f}")
    # (5) 信号率与跳过原因拆分
    print("  (5) 信号率与跳过原因：")
    print(f"    信号 {n_sig} 个 → 执行 {len(sqz_main)} 笔（执行率 "
          f"{len(sqz_main)/n_sig*100:.1f}%）；跳过：夜禁 {sum(night_blocked.values())} / "
          f"持仓中/满2笔/熔断/入场穿止损见主臂统计。")
    # 出场原因、跨夜、激活
    for arm_name, at in [("SQZ-MAIN", sqz_main), ("SQZ-DIAG", sqz_diag)]:
        rc = Counter(t["reason"] for t in at)
        ovn = [t for t in at
               if datetime.fromtimestamp(t["exit_t"], timezone.utc).date()
               > datetime.fromtimestamp(t["entry_t"], timezone.utc).date()]
        act = [t for t in at if t.get("trail_active")]
        long_holds = [t for t in at if t["hold_min"] is not None and t["hold_min"] > 2 * 24 * 60]
        print(f"  [{arm_name}] 出场：{dict(sorted(rc.items()))}（共 {len(at)} 笔）；"
              f"激活 {len(act)}/{len(at)}（{len(act)/len(at)*100:.1f}%）" if at else
              f"  [{arm_name}] 0 笔")
        if at:
            print(f"    跨夜 {len(ovn)} 笔净 {sum(t['pnl'] for t in ovn):+.0f}；"
                  f"资金费（引擎口径）{sum(t['funding_cost_usdt'] for t in at):+.2f}；"
                  f"持仓 >2 天 {len(long_holds)} 笔")
    # 诊断臂资金费漏计差额（引擎口径只计入场日与入场日+1 的结算点）
    if sqz_diag:
        diff_tot = 0.0
        n_long = 0
        for t in sqz_diag:
            full = funding_cost_full(data15[t["symbol"]][1], t["entry_t"], t["exit_t"],
                                     t["notional"], t["direction"])
            diff = full - t["funding_cost_usdt"]
            if abs(diff) > 1e-9:
                n_long += 1
            diff_tot += diff
        print(f"  [SQZ-DIAG 资金费差额] 全口径资金费 − 引擎口径资金费 = {diff_tot:+.2f} USDT"
              f"（{n_long} 笔有差额，即持仓跨过入场日+1 之后的结算点；"
              f"诊断臂净若按全口径计为 "
              f"{sum(t['pnl'] for t in sqz_diag) - diff_tot:+.2f}，仅供参考，不参与判定）")
    # 多空拆分
    for arm_name, at in [("SQZ-MAIN", sqz_main), ("SQZ-DIAG", sqz_diag)]:
        lo = [t for t in at if t["direction"] == 1]
        sh = [t for t in at if t["direction"] == -1]
        if at:
            print(f"  [{arm_name} 多空] LONG n={len(lo)} 净 {sum(t['pnl'] for t in lo):+.0f} "
                  f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in lo)/len(lo) if lo else 0:+.2f}；"
                  f"SHORT n={len(sh)} 净 {sum(t['pnl'] for t in sh):+.0f} "
                  f"每笔毛利 {sum(t['price_pnl']-t['funding_cost_usdt'] for t in sh)/len(sh) if sh else 0:+.2f}")

    # ---- 首笔人工核对（SQZ 主臂首笔：触发链与原始 K 线逐项核对）----
    print("\n=== 首笔人工核对（SQZ 主臂首笔）===")
    if sqz_main:
        t = sorted(sqz_main, key=lambda x: x["entry_t"])[0]
        bars = data15[t["symbol"]][0]
        idx = {b["t"]: i for i, b in enumerate(bars)}
        ei = idx[t["entry_t"]]
        exp_i = ei - 1  # 扩张根
        eb = bars[exp_i]
        hi8 = max(b["h"] for b in bars[exp_i - 8:exp_i])
        lo8 = min(b["l"] for b in bars[exp_i - 8:exp_i])
        a = atr15[t["symbol"]][exp_i]
        print(f"  首笔 {t['symbol']} {'做多' if t['direction'] == 1 else '做空'} "
              f"扩张根 {datetime.fromtimestamp(eb['t'], timezone.utc).isoformat()} "
              f"o={eb['o']} h={eb['h']} l={eb['l']} c={eb['c']} 振幅 {eb['h']-eb['l']:.4g} "
              f"ATR {a:.4g}（振幅/ATR {(eb['h']-eb['l'])/a:.2f}，须 >=1.0）")
        print(f"    前 8 根区间 [{lo8}, {hi8}]（信号止损 {'区间下沿' if t['direction'] == 1 else '区间上沿'} "
              f"{'-' if t['direction'] == 1 else '+'} 0.1xATR = {t['stop']:.4g}）；"
              f"信号记录止损 {t.get('stop')} 区间 [{t.get('range_lo')}, {t.get('range_hi')}]；"
              f"入场 {datetime.fromtimestamp(t['entry_t'], timezone.utc).isoformat()} 价 {t['entry']} "
              f"止损距离 {t.get('stop_dist_atr')}xATR / {t.get('stop_dist_usdt')} USDT；"
              f"出场 {datetime.fromtimestamp(t['exit_t'], timezone.utc).isoformat()} 价 {t['exit']} "
              f"原因 {t['reason']} 净 {t['pnl']:+.2f}")

    # ---- 账目核对 ----
    print("\n=== 账目核对 ===")
    for arm_name, at in [("SQZ-MAIN", sqz_main), ("SQZ-DIAG", sqz_diag),
                         ("CTRL-A", ctrl_trades["A"]), ("CTRL-B", ctrl_trades["B"]),
                         ("CTRL-C", ctrl_trades["C"])]:
        cost = sum(t["cost_usdt"] for t in at)
        gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in at)
        net = sum(t["pnl"] for t in at)
        assert abs(cost - len(at) * 25.0) < 0.01, f"账目不对：{arm_name} 成本 {cost} ≠ 笔数x25"
        assert abs(gross - cost - net) < 0.01, f"账目不对：{arm_name} 毛利-成本≠净"
        print(f"  [{arm_name}] 笔数 {len(at)} x 25 = {len(at)*25:.0f} = 成本合计 {cost:.2f} ✓；"
              f"毛利 {gross:+.2f} − 成本 {cost:.2f} = 净 {net:+.2f} ✓")

    # ---- 写文件 ----
    with open(os.path.join(DATA_DIR, "gate_iter_round41_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round41_cells.json"), "w") as f:
        json.dump(cells, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round41_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "template", "variant", "atr_basis", "granularity", "split", "symbol",
                    "direction", "entry_time_utc", "entry_hour_utc", "session", "group", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min", "peak", "trail_active",
                    "max_favour_usdt", "atr", "stop", "stop_dist_atr", "stop_dist_usdt",
                    "range_hi", "range_lo", "expand_time_utc"])
        for t in sorted(all_trades, key=lambda x: (x["arm"], x["family"], x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["template"], t["variant"], t.get("atr_basis", ""),
                        t["granularity"], t["split"], t["symbol"],
                        "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"], t["session"], t["group"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"], t.get("peak"), t.get("trail_active"),
                        round(t.get("max_favour_usdt", 0.0), 2), t.get("atr"),
                        t.get("stop", ""), t.get("stop_dist_atr", ""), t.get("stop_dist_usdt", ""),
                        t.get("range_hi", ""), t.get("range_lo", ""),
                        datetime.fromtimestamp(t["expand_t"], timezone.utc).isoformat()
                        if t.get("expand_t") else ""])
    print(f"\n汇总已写入：data/gate_iter_round41_summary.json ({len(all_results)} 条)")
    print(f"格子已写入：data/gate_iter_round41_cells.json ({len(cells)} 个格子)")
    print(f"明细已写入：data/gate_iter_round41_trades.csv ({len(all_trades)} 笔)")

    print("\n=== 最终判定（SQZ，四项全过才算）===")
    print(f"  SQZ–MAIN：{'通过' if c_main['pass_all'] else '不通过'}"
          f"（币均 Taker {c_main['coin_mean_pct_full']*100:+.2f}%，"
          f"每笔毛利 {c_main['gross_per_trade']}，R1 省成本占比 "
          f"{c_main['r1_saved_share'] if c_main['r1_saved_share'] is not None else '—'}）")
    if len(sqz_main) < SQZ_FIRST_GATE_MIN_TRADES:
        print("  执行笔数 < 50：SQZ 不可测，四项标准不作判定。")
    elif c_main["pass_all"]:
        print("  SQZ 四项全过 → 仍只是在一个新宇宙上的一次通过：按 R2 不得换另一批"
              "新币重验同一发现，后续验证须在 2026-11-16 之后的实盘纸面数据上看"
              "（12 月 18 日月度复核时判）。")
    else:
        print("  SQZ 证伪：下一轮按设计顺序测 FBO（不许调 SQZ 的阈值重测、"
              "不许换批币重测 SQZ）。")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
