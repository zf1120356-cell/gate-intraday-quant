#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十四轮：诱导验证的 BOS + 教程版 OB（只做合约、只做日内、只做 Gate）
============================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

背景：第十一轮 SMC 宽松形式化三家族全亏；第十二轮严格形式化两组合
-1.31%/-0.39%，S1 有 4,191 次破位且 100% 有 OB。学习笔记方向 1
（SMC-AI-Tutor学习笔记.md §3）要求测“诱导验证的 BOS + 教程版 OB”。
定义审计（SMC定义审计.md）发现方向 1 原文的诱导条件是退化的：
N=5 诱导仅 5 次（0.12%）、N=3 仅 19 次（0.45%）；96.54% 的破位在
推动起点之后根本没有内部回撤点，主因是腿太短（中位数仅 7 根），
不是确认条件太严。学习笔记 §5 第 2 步事先写过：如果诱导比例接近
0% 或 100%，这条条件没有方差、方向 1 里的诱导条件要换写法。审计
结果 0.12% 触发了这条预注册的换写法条款。所以本轮分两臂，两臂的
规则都在跑之前定死，跑完不许回头改：

  A 臂（原文版，仅 1h，365 天）：方向 1 原文照测，只为如实记录
    原文版的样本量，不指望它有结论。
  B 臂（改写版）：诱导按检测器条件①改写——破位根之前（推动起点
    之后）发生过一次同侧清扫（N=3 摆动点的清扫定义）。由于教程版
    三条件 OB 本来就包含这一条清扫条件，B 臂等价于“教程版三条件
    OB（严格 FVG）+ MSS 两步确认入场”。两个组合（同为 B 臂，只差
    确认粒度，与第十二轮 S1/S2 的架构对应）：
      B-T1：结构 1h、确认 1h，窗口 365 天 1h，回踩窗口破位后 24 根。
      B-T2：结构 1h（由 15m 合成，4 根合 1 根，与第十二轮 S2 同款）、
        确认 15m，窗口 103 天 15m，回踩窗口破位后 48 根 15m（12h）。
        15m 触及/确认根须严格晚于 1h 破位根收盘时刻。

锁定的通用规则（两臂共用，跑前定死）：
  摆动点 N=3 分形（抄检测器默认）：bar i 为摆动高当且仅当 h[i]
    严格大于左 3 根、不低于右 3 根；摆动低镜像。摆动点在 bar i+3
    收盘时确认。只用已收盘的根。
  摆动点可用时点（与检测器 detect() 循环顺序一致，写死）：bar k
    收盘时确认的摆动点，从 bar k+1 起才可用（即确认下标 < 当前根
    下标）。这与审计第二部分用的 R11 口径（确认根当根可用）差一根，
    只影响恰好落在确认根当根的破位/清扫；交叉验证以检测器为准。
  结构破位：收盘价上破最近一个已确认摆动高 = 看涨破位，下破最近
    一个已确认摆动低 = 看跌破位。BOS/CHOCH 不区分，方向即破位方向。
    破位扫描抄检测器 detect() 的跟踪方式：维护最近已确认摆动高/低
    引用（ref），新摆动点确认后替换 ref（即使未被破、即使更不极端），
    每个摆动点只记一次破位；某根收盘价严格越过 ref 价位即破位（不
    要求前根收盘价在价位另一侧）；同一根可同时产生两个方向的破位
    （先算看涨、后算看跌，与检测器顺序一致）。
  推动起点（origin）：被破摆动点之后、破位根之前的极值点（看涨取
    最低点、看跌取最高点，并列取靠后一根），区间为 (s, k) 不含两端；
    区间为空则无起点、无 setup。
  教程版 OB：从推动起点起，若起点那根是反向 K 线（看涨破位则为阴线）
    就顺延连续反向 K 线到最后一根（不超过破位根前一根）；若起点不是
    反向 K 线，就往前找最近的反向 K 线（不早于被破摆动点之后一根）；
    找不到则无 OB。OB 区间只取该根实体 [min(o,c), max(o,c)]。OB 根
    必须早于破位根。同一（方向、OB 根）只算一次（保留最早一次破位）。
  FVG：连续三根 A、B、C，看涨要求 C 最低 > A 最高，区间 [A 最高,
    C 最低]，看跌镜像。有效 FVG 必须宽度 >= 0.3xATR（Wilder ATR14，
    取形成根的 ATR；形成根 = C 根，与 11/12 轮同一口径；不用检测器
    的 TR 简单平均 ATR），且 C 根必须在破位根收盘时或之前收盘
    （B 根 <= 破位根 - 1，严格口径，杜绝前视；检测器那种 B 根 =
    破位根的边界情形不算）。
  三条件 OB：① 破位前有同侧清扫（A 臂的①由诱导条件本身满足；B 臂
    的①见下）；② OB 根之后、破位根之前（含破位根，即 FVG 的 B 根
    <= 破位根 - 1）存在同向有效 FVG；③ 结构破位本身。缺一条只算
    POI、不做。
  止损 1xATR、止盈 2xATR（用户要求的 1:2，ATR 用确认周期 ATR14）；
    每笔保证金 10% 权益、1x；成本主口径 Taker（一轮名义 x0.25%，
    taker 0.075% + 滑点 0.05%，双边）；资金费按实际费率计（08:00/
    16:00 结算点，前半段 2026-05-21 之前无数据按 0 计）；单日 -2%
    熔断；单笔最坏情况 (ATR+成本) > 1% 权益跳过；最多持 8 根（1h）/
    16 根（15m）；每天每币最多 2 笔；当天 23:00（1h）/ 23:45（15m）
    收盘强制平仓；同根同时碰止损和止盈先判止损；入场根本身不判出场
    （沿用 11/12 轮引擎约定）。
  Killzone 不作硬过滤（本轮不设 Killzone；只在诊断里按 UTC 小时分组
    汇报触发分布，不用于筛信号）。
  不重叠约定：同一币同一方向已有 setup 在等回踩/确认时，新的破位
    不生成新 setup，直到旧 setup 触发、作废或过期。判定写死：旧
    setup 的待定状态持续到其结果根（触及后完成第 2 步的根 / 作废根 /
    窗口末根）的收盘时刻（含该根）；新破位的破位根收盘时刻 <= 该时刻
    则跳过。B-T2 按时间戳比较（新破位 1h 收盘时刻 vs 旧 setup 结果
    15m 根收盘时刻）。

A 臂（原文版，仅 1h，365 天）：诱导验证的 BOS + 教程版 OB
  BOS 有效当且仅当：(a) 收盘破最近已确认摆动点；且 (b) 诱导：破位根
    之前、最近一次内部回撤的流动性已被扫。操作定义（抄学习笔记方向
    1 原文）：回撤低点 = 推动起点之后、破位根之前最近的已确认摆动低
    （看涨；看跌镜像为摆动高），须在破位根收盘前已确认（确认下标
    < 破位根下标）；该低点被某根 K 线影线刺破且收盘收回（或收盘跌破
    后下一根收回），且该扫荡的根严格在破位根之前、推动起点之后。
    扫荡根 w 的确认要求：被扫摆动点在 w 收盘时已可用（确认下标 < w）。
    收盘越过形式的扫荡，要求收回根 w+1 <= 破位根（收回须在破位收盘
    时或之前已观测到）。若推动起点之后、破位根之前根本没有内部回撤
    低点，则诱导不可能存在、该破位无效。
  OB 按通用规则的教程版 OB 定义；三条件里条件①由上述诱导本身满足
    （扫荡即诱导那一次），条件②③按通用规则。
  入场（与 B 臂相同的 MSS 确认），确认周期 1h，回踩窗口为破位后 24 根 1h。

B 臂（改写版）：三条件 OB + MSS 两步确认入场
  BOS 有效只需收盘破最近已确认摆动点（不再要求原文诱导）；OB 必须
    满足三条件，其中条件①为：推动起点之后、破位根收盘时或之前
    （扫荡根 <= 破位根），发生过一次同侧清扫（N=3 摆动点定义：影线
    越过某已确认摆动点且收盘收回，或收盘越过后下一根收回；看涨只计
    扫摆动低，看跌只计扫摆动高）。被扫摆动点在扫荡根收盘时已可用
    （确认下标 < 扫荡根）；收盘越过形式的扫荡，要求收回根 <= 破位根。
  入场确认（MSS 两步，写死）：破位后窗口内，价格首次回踩进 OB 实体
    区间（看涨：某根 l <= OB 上沿且 c >= OB 下沿；看跌镜像）即开始
    确认计时；回踩前若收盘穿过 OB 远端（看涨 c < OB 下沿）则 setup
    作废；窗口内未触及则过期。触及后，确认周期上必须依次完成两步
    才入场，缺一步都不进：
      第 1 步 CHoCH：确认周期上出现一根收盘价上破（看涨）最近一个
        已确认摆动高（看跌则下破最近已确认摆动低）的 K 线，且该摆动
        点的根严格晚于触及根（回踩过程中形成的小级别结构，不是破位
        前旧结构）。
      第 2 步 BOS：完成第 1 步之后，再出现一根收盘价上破（看涨）
        下一个最近已确认摆动高（看跌镜像）的 K 线，且该根须带位移
        证据——实体 >= 0.5xATR（确认周期 ATR14）或用实体完全吞没
        前一根反向 K 线实体。两步的摆动点均用 N=3、只用已确认的。
      入场为第 2 步完成根的下一根开盘价。两步都必须在回踩窗口内
        完成；窗口内未完成则过期；第 2 步完成前若收盘穿过 OB 远端
        则作废。
    实现歧义的写死判定（跑前定死，报告里原样写明）：
      (i) 第 1 步后新的摆动高跟踪：沿用与破位扫描同一套检测器式
        ref 跟踪（最近已确认摆动高，确认后替换、每点只记一次破位）；
        第 2 步 = 第 1 步完成根之后第一次同向收盘破位。第 2 步的
        摆动点无需另行要求晚于触及根——它必然晚于触及根（见下）。
      (ii) 无位移的破位不完成第 2 步、也不作废：继续等下一个同向
        破位根，直到出现带位移证据的破位根或窗口结束/作废。
      (iii) 吞没的定义：前一根必须是反向 K 线（看涨 setup 则前一根
        为阴线 c<o，看跌则为阳线 c>o）；第 2 步根的实体区间须完全
        覆盖前一根的实体区间（看涨：o2 <= c1 且 c2 >= o1；看跌镜像）。
      (iv) 每根监测根先判作废（收盘穿过 OB 远端）再判触及/第 1 步/
        第 2 步；同一根既作废又满足步骤条件时按作废计。触及根当根
        不判第 1 步（第 1 步的摆动点根须严格晚于触及根，触及根当根
        不可能满足），从触及根下一根起才判步骤。
      (v) 回踩窗口：B-T1/A 为破位根之后 24 根确认根（含第 24 根），
        即下标 k+1..k+24；B-T2 为破位根收盘时刻起 48 根 15m 根
        （含第 48 根）。触及、第 1 步、第 2 步都须落在窗口内。
      (vi) 信号冲突：两个 setup（不同方向）若在同一根确认根完成
        第 2 步、入场根时间戳相同，只保留先处理的 setup 的信号
        （信号字典 key=入场根时间戳，沿用 11/12 轮引擎约定），
        冲突次数单独计数汇报。
    为什么第 2 步摆动点必然晚于触及根：摆动点根 > 触及根才能被第 1
      步用；第 1 步完成根 >= 该摆动点根 + 4（确认需 3 根、可用又晚
      1 根）；第 2 步的摆动点在第 1 步完成之后才确认（ref 跟踪），
      其根 > 第 1 步完成根 - 3 >= 触及根 + 1。

窗口：
  A / B-T1：365 天 1h，2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  B-T2：103 天 15m，2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

前视防控（写死在代码里）：
  - 摆动点、破位、诱导/清扫、OB、FVG、MSS 两步全部只用已收盘的根；
    摆动点须确认后（确认下标 < 当前根下标）才可用。
  - 诱导/清扫的收回根须在破位根收盘时或之前；FVG 的 C 根须在破位根
    收盘时或之前（B 根 <= 破位根 - 1）。
  - 入场永远是第 2 步完成根的下一根开盘价。
  - B-T2 的 15m 触及/确认根须严格晚于 1h 破位根收盘时刻。

引擎复用：通用模拟、成本、资金费、汇总函数复用 gate_iter_round11.py
  的已验证函数（simulate_generic、summarize、atr_wilder、synthesize、
  load_bars、load_funding、group_days、t_value），口径零漂移；新信号
  逻辑（N=3 摆动点、诱导、教程版 OB、严格 FVG、MSS 两步确认）写在本
  脚本里。摆动点定义抄检测器（与 R11 的 swing_points 定义不同：
  R11 要求 h == 窗口最大值且 h > h[i-1]；检测器要求严格大于左 3 根、
  不低于右 3 根），故本轮不用 R11.confirmed_levels。

运行：python3 gate_iter_round14.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round14_summary.json
      + data/gate_iter_round14_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import os
import sys
from collections import Counter
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round11 as R11  # 复用第十一轮已验证的通用引擎与成本口径

DATA_DIR = os.path.join(SCRIPT_DIR, "data")
SYMBOLS = R11.SYMBOLS
START_EQUITY = R11.START_EQUITY
SPLIT_1H = R11.SPLIT_1H
SPLIT_15M = R11.SPLIT_15M

# ---- 锁定的参数：止损 1xATR，止盈 2xATR（用户要求 1:2）----
SL_MULT = 1.0
TP_MULT = 2.0
SWING_N = 3            # 摆动点 N=3（检测器默认）
FVG_MIN_ATR = 0.3      # 有效 FVG 最小尺寸 0.3xATR（教程“强”标准）
DISP_MIN_ATR = 0.5     # MSS 第 2 步位移证据：实体 >= 0.5xATR
RETRACE_BARS_1H = 24   # 1h 回踩窗口 24 根
RETRACE_BARS_15M = 48  # 15m 回踩窗口 12h = 48 根
MAX_HOLD_1H = 8
MAX_HOLD_15M = 16


# ----------------------------------------------------------------------
# N=3 摆动点（检测器定义）与检测器式结构破位扫描
# ----------------------------------------------------------------------
def swing_points_n3(bars, n=SWING_N):
    """返回 [(bar_idx, kind, level, confirmed_idx)]：
    kind 'H' 摆动高 / 'L' 摆动低；confirmed_idx = bar_idx + n。
    检测器定义：h[i] 严格大于左 n 根、不低于右 n 根；低点镜像。"""
    out = []
    H = [b["h"] for b in bars]
    L = [b["l"] for b in bars]
    for i in range(n, len(bars) - n):
        if all(H[i] > H[j] for j in range(i - n, i)) and \
                all(H[i] >= H[j] for j in range(i + 1, i + n + 1)):
            out.append((i, "H", H[i], i + n))
        if all(L[i] < L[j] for j in range(i - n, i)) and \
                all(L[i] <= L[j] for j in range(i + 1, i + n + 1)):
            out.append((i, "L", L[i], i + n))
    return out


def detector_events(bars, n=SWING_N):
    """抄检测器 detect() 的结构扫描（只含摆动点与破位两部分）：
    按根推进；每根先判破位（用当时已可用的最近已确认摆动点引用），
    再把本根收盘时确认的摆动点并入引用（即确认下标 < 当前根下标的
    摆动点才可用）。返回 (events, swings)：
      events: [{bar, dir, swing_bar, level, type}]，bar 为破位根下标；
      swings: swing_points_n3 的结果。
    与审计第一部分检测器事件数逐币对得上（交叉验证用）。"""
    swings = swing_points_n3(bars, n)
    by_conf = {}
    for s in swings:
        by_conf.setdefault(s[3], []).append(s)
    closes = [b["c"] for b in bars]
    events = []
    ref = {"H": None, "L": None}  # {bar, level, broken}
    trend = 0
    for k in range(len(bars)):
        rh, rl = ref["H"], ref["L"]
        if rh is not None and not rh["broken"] and closes[k] > rh["level"]:
            events.append({"bar": k, "dir": 1, "swing_bar": rh["bar"],
                           "level": rh["level"],
                           "type": "CHoCH" if trend == -1 else "BOS"})
            rh["broken"] = True
            trend = 1
        if rl is not None and not rl["broken"] and closes[k] < rl["level"]:
            events.append({"bar": k, "dir": -1, "swing_bar": rl["bar"],
                           "level": rl["level"],
                           "type": "CHoCH" if trend == 1 else "BOS"})
            rl["broken"] = True
            trend = -1
        for (i, kind, level, _c) in by_conf.get(k, []):
            ref[kind] = {"bar": i, "level": level, "broken": False}
    return events, swings


def events_by_bar(events):
    d = {}
    for e in events:
        d.setdefault(e["bar"], []).append(e)
    return d


# ----------------------------------------------------------------------
# 推动起点、教程版 OB、同侧清扫、原文诱导、严格 FVG
# ----------------------------------------------------------------------
def find_origin(bars, s, k, direction):
    """被破摆动点之后、破位根之前的极值点，区间 (s, k) 不含两端；
    看涨取 l 最小、看跌取 h 最大，并列取靠后一根；区间为空返回 None。"""
    if k - 1 < s + 1:
        return None
    m = s + 1
    for j in range(s + 2, k):
        if direction == 1:
            if bars[j]["l"] <= bars[m]["l"]:
                m = j
        else:
            if bars[j]["h"] >= bars[m]["h"]:
                m = j
    return m


def _is_opp(bar, direction):
    """反向 K 线：看涨破位取阴线，看跌破位取阳线；十字星两边都不算。"""
    if direction == 1:
        return bar["c"] < bar["o"]
    return bar["c"] > bar["o"]


def find_tutorial_ob(bars, s, m, k, direction):
    """教程版 OB：从推动起点 m 起，起点是反向 K 线就顺延连续反向 K 线
    到最后一根（不超过破位根前一根）；不是反向就往前找最近的反向 K 线
    （不早于 s+1）。返回 (ob_bar, ob_lo, ob_hi)，区间只取实体；无则 None。"""
    if _is_opp(bars[m], direction):
        j = m
        while j + 1 < k and _is_opp(bars[j + 1], direction):
            j += 1
    else:
        j = m - 1
        while j > s and not _is_opp(bars[j], direction):
            j -= 1
        if j <= s:
            return None
    if j >= k:
        return None
    lo = min(bars[j]["o"], bars[j]["c"])
    hi = max(bars[j]["o"], bars[j]["c"])
    return (j, lo, hi)


def _sweeps_level(bars, level, w, direction, k):
    """单根 w 是否扫了给定的同侧摆动点价位 level：
    影线越过且收盘收回，或收盘越过后下一根收回（收回根 <= k）。
    看涨只扫摆动低（l < level），看跌只扫摆动高（h > level）。"""
    if direction == 1:
        if bars[w]["l"] >= level:
            return False
        if bars[w]["c"] >= level:
            return True
        # 收盘越过：下一根收回
        return w + 1 <= k and w + 1 < len(bars) and bars[w + 1]["c"] >= level
    else:
        if bars[w]["h"] <= level:
            return False
        if bars[w]["c"] <= level:
            return True
        return w + 1 <= k and w + 1 < len(bars) and bars[w + 1]["c"] <= level


def _index_swings(swings):
    """摆动点表的两种索引（供清扫/诱导快速查询）：
    by_conf: {kind: [(confirmed_idx, level)]} 按确认下标排序；
    by_bar: {kind: [(bar_idx, level, confirmed_idx)]} 按根下标排序。"""
    by_conf = {"H": [], "L": []}
    by_bar = {"H": [], "L": []}
    for (i, kind, level, conf) in swings:
        by_conf[kind].append((conf, level))
        by_bar[kind].append((i, level, conf))
    for kind in ("H", "L"):
        by_conf[kind].sort()
        by_bar[kind].sort()
    return by_conf, by_bar


def sweep_exists(bars, swings_by_conf, m, k, direction, end_inclusive):
    """B 臂条件①：推动起点之后、破位根收盘时或之前，发生过一次同侧清扫。
    扫荡根 w 的范围：end_inclusive 为真时 w in (m, k]，否则 w in (m, k)。
    被扫摆动点须在 w 收盘时已可用（确认下标 < w）。
    判定等价于区间存在性：看涨影线式 level ∈ (l[w], c[w]]，收盘越过式
    level ∈ (c[w], c[w+1]]（须 w+1 <= k）；看跌镜像。
    返回 (是否, 扫荡根)。"""
    import bisect
    kind = "L" if direction == 1 else "H"
    lst = swings_by_conf[kind]  # 按确认下标排序
    w_hi = k if end_inclusive else k - 1
    levels = []  # 已可用摆动点的价位排序表
    p = 0
    for w in range(m + 1, w_hi + 1):
        if w < 0 or w >= len(bars):
            continue
        while p < len(lst) and lst[p][0] < w:
            bisect.insort(levels, lst[p][1])
            p += 1
        if not levels:
            continue
        if direction == 1:
            lo_w, c_w = bars[w]["l"], bars[w]["c"]
            i = bisect.bisect_right(levels, lo_w)
            if i < len(levels) and levels[i] <= c_w:
                return True, w
            if w + 1 <= k and w + 1 < len(bars):
                j = bisect.bisect_right(levels, c_w)
                if j < len(levels) and levels[j] <= bars[w + 1]["c"]:
                    return True, w
        else:
            h_w, c_w = bars[w]["h"], bars[w]["c"]
            i = bisect.bisect_left(levels, c_w)
            if i < len(levels) and levels[i] < h_w:
                return True, w
            if w + 1 <= k and w + 1 < len(bars):
                j = bisect.bisect_left(levels, bars[w + 1]["c"])
                if j < len(levels) and levels[j] < c_w:
                    return True, w
    return False, None


def inducement_check(bars, swings_by_bar, m, k, direction):
    """A 臂原文诱导：推动起点之后、破位根之前最近的已确认摆动低/高
    （看涨取摆动低，看跌取摆动高；须在破位根收盘前已确认，即确认下标
    < k），被某根扫荡根 w（m < w < k，w 晚于该摆动点本身）扫掉。
    返回 (是否, 原因, 内部点下标, 扫荡根)。"""
    import bisect
    kind = "L" if direction == 1 else "H"
    lst = swings_by_bar[kind]  # 按根下标排序
    bars_only = [x[0] for x in lst]
    internal = None
    lo = bisect.bisect_right(bars_only, m)
    hi = bisect.bisect_left(bars_only, k)
    for idx in range(hi - 1, lo - 1, -1):
        i, level, conf = lst[idx]
        if conf < k:
            internal = (i, level)
            break
    if internal is None:
        return False, "no_internal", None, None
    ii, level = internal
    for w in range(max(m + 1, ii + 1), k):
        if _sweeps_level(bars, level, w, direction, k):
            return True, "ok", ii, w
    return False, "internal_not_swept", ii, None


def strict_fvg_exists(bars, atr, ob_bar, k, direction):
    """严格 FVG：OB 根之后、破位根之前（含破位根）存在同向有效 FVG。
    即 FVG 的 B 根 b in (ob_bar, k-1]；宽度 >= 0.3xATR（Wilder ATR14，
    取形成根 C 根的 ATR）；C 根 = b+1 <= k，收盘时或之前已形成。
    返回 (是否, B 根下标, lo, hi)。"""
    for b in range(ob_bar + 1, k):
        c_idx = b + 1
        if c_idx >= len(bars) or atr[c_idx] is None:
            continue
        if direction == 1:
            if bars[c_idx]["l"] > bars[b - 1]["h"]:
                lo, hi = bars[b - 1]["h"], bars[c_idx]["l"]
                if hi - lo >= FVG_MIN_ATR * atr[c_idx]:
                    return True, b, lo, hi
        else:
            if bars[c_idx]["h"] < bars[b - 1]["l"]:
                lo, hi = bars[c_idx]["h"], bars[b - 1]["l"]
                if hi - lo >= FVG_MIN_ATR * atr[c_idx]:
                    return True, b, lo, hi
    return False, None, None, None


def has_displacement(bars, atr, m, direction):
    """MSS 第 2 步位移证据：根 m 的实体 >= 0.5xATR（确认周期 ATR14），
    或实体完全吞没前一根反向 K 线实体。"""
    if m <= 0 or m >= len(bars):
        return False
    body = abs(bars[m]["c"] - bars[m]["o"])
    if atr[m] is not None and body >= DISP_MIN_ATR * atr[m]:
        return True
    prev = bars[m - 1]
    if direction == 1 and prev["c"] < prev["o"]:
        return bars[m]["o"] <= prev["c"] and bars[m]["c"] >= prev["o"]
    if direction == -1 and prev["c"] > prev["o"]:
        return bars[m]["o"] >= prev["c"] and bars[m]["c"] <= prev["o"]
    return False


# ----------------------------------------------------------------------
# MSS 两步确认（回踩触及 + CHoCH + BOS + 位移证据）
# ----------------------------------------------------------------------
def run_mss(mon_bars, atr_mon, mon_events_by_bar, ob_lo, ob_hi, direction,
            start_idx, end_idx):
    """在确认根（mon_bars[start_idx..end_idx]，含两端）上推进一个 setup。
    返回 dict：outcome ∈ {signal, void, expired}，以及 touch_bar /
    step1_bar / step2_bar / void_reason / expire_reason。
    判定顺序（写死）：每根先判作废（收盘穿过 OB 远端），再判触及，
    触及根当根不判步骤；触及后按顺序判第 1 步、第 2 步。
    第 2 步无位移的破位不完成、不作废，继续等下一个同向破位根。"""
    touch = None
    step1 = None
    step2 = None
    void_reason = None
    for m in range(start_idx, end_idx + 1):
        if m < 0 or m >= len(mon_bars):
            break
        b = mon_bars[m]
        if direction == 1:
            if b["c"] < ob_lo:
                return {"outcome": "void", "touch_bar": touch,
                        "step1_bar": step1, "step2_bar": None,
                        "void_reason": "ob_far_side", "void_bar": m}
            if touch is None:
                if b["l"] <= ob_hi and b["c"] >= ob_lo:
                    touch = m
                continue
        else:
            if b["c"] > ob_hi:
                return {"outcome": "void", "touch_bar": touch,
                        "step1_bar": step1, "step2_bar": None,
                        "void_reason": "ob_far_side", "void_bar": m}
            if touch is None:
                if b["h"] >= ob_lo and b["c"] <= ob_hi:
                    touch = m
                continue
        # 触及根当根不判步骤（m == touch 时上面 continue 已跳过，此处 m > touch）
        if step1 is None:
            for e in mon_events_by_bar.get(m, []):
                if e["dir"] == direction and e["swing_bar"] > touch:
                    step1 = m
                    break
        elif step2 is None:
            for e in mon_events_by_bar.get(m, []):
                if e["dir"] == direction:
                    if has_displacement(mon_bars, atr_mon, m, direction):
                        step2 = m
                    break
            if step2 is not None:
                return {"outcome": "signal", "touch_bar": touch,
                        "step1_bar": step1, "step2_bar": step2,
                        "void_reason": None, "void_bar": None}
    if touch is None:
        return {"outcome": "expired", "touch_bar": None, "step1_bar": None,
                "step2_bar": None, "void_reason": None, "void_bar": None,
                "expire_reason": "no_touch"}
    if step1 is None:
        return {"outcome": "expired", "touch_bar": touch, "step1_bar": None,
                "step2_bar": None, "void_reason": None, "void_bar": None,
                "expire_reason": "no_step1"}
    return {"outcome": "expired", "touch_bar": touch, "step1_bar": step1,
            "step2_bar": None, "void_reason": None, "void_bar": None,
            "expire_reason": "no_step2"}


def build_setups(bars, atr, events, swings, arm,
                 mon_bars, atr_mon, mon_events_by_bar,
                 mon_start_of_break, horizon):
    """按时间顺序扫描结构破位，生成 setup 并跑 MSS 确认。
    arm: 'A'（原文诱导）或 'B'（改写清扫条件①）。
    mon_start_of_break: 函数 break_idx -> 确认序列起始根下标（None 表示
      无监测根）；horizon: 回踩窗口根数。
    返回 (signals, funnel)，signals key=入场根时间戳。
    funnel 计数均为 8 币外层累加前的单币计数。"""
    funnel = Counter()
    funnel["breaks"] = len(events)
    signals = {}
    seen_ob = set()          # (direction, ob_bar) 去重
    pending_until = {}       # direction -> 待定截止收盘时间戳（秒，含该根）
    collisions = 0
    swings_by_conf, swings_by_bar = _index_swings(swings)
    for e in events:
        k = e["bar"]
        d = e["dir"]
        s = e["swing_bar"]
        # 破位根收盘时刻：结构根时长由 bars 相邻时间戳差决定
        step_secs = bars[1]["t"] - bars[0]["t"] if len(bars) > 1 else 3600
        bos_close_t = bars[k]["t"] + step_secs
        if d in pending_until and bos_close_t <= pending_until[d]:
            funnel["overlap_skipped"] += 1
            continue
        m = find_origin(bars, s, k, d)
        if m is None:
            funnel["no_origin"] += 1
            continue
        # ---- 条件①：A 臂原文诱导 / B 臂改写清扫 ----
        if arm == "A":
            ok1, why1, ii, w = inducement_check(bars, swings_by_bar, m, k, d)
            funnel["cond1_checked"] += 1
            if not ok1:
                funnel["cond1_fail_" + why1] += 1
                continue
            funnel["cond1_ok"] += 1
        else:
            ok1, w = sweep_exists(bars, swings_by_conf, m, k, d, end_inclusive=True)
            funnel["cond1_checked"] += 1
            if not ok1:
                funnel["cond1_fail_no_sweep"] += 1
                continue
            funnel["cond1_ok"] += 1
        # ---- 教程版 OB ----
        ob = find_tutorial_ob(bars, s, m, k, d)
        if ob is None:
            funnel["no_ob"] += 1
            continue
        funnel["has_ob"] += 1
        ob_bar, ob_lo, ob_hi = ob
        # ---- 条件②：严格 FVG ----
        ok2, fvg_b, fvg_lo, fvg_hi = strict_fvg_exists(bars, atr, ob_bar, k, d)
        if not ok2:
            funnel["no_fvg"] += 1
            continue
        funnel["three_cond"] += 1
        # ---- 去重（方向、OB 根）----
        if (d, ob_bar) in seen_ob:
            funnel["dedup_skipped"] += 1
            continue
        seen_ob.add((d, ob_bar))
        funnel["setups_active"] += 1
        # ---- MSS 确认 ----
        start = mon_start_of_break(k)
        if start is None or start >= len(mon_bars) - 1:
            funnel["mss_no_monitor"] += 1
            pending_until[d] = bos_close_t
            continue
        end = min(start + horizon - 1, len(mon_bars) - 1)
        res = run_mss(mon_bars, atr_mon, mon_events_by_bar,
                      ob_lo, ob_hi, d, start, end)
        mon_step = mon_bars[1]["t"] - mon_bars[0]["t"] if len(mon_bars) > 1 else 900
        if res["outcome"] == "signal":
            funnel["touched"] += 1
            funnel["mss_complete"] += 1
            s2 = res["step2_bar"]
            pending_until[d] = mon_bars[s2]["t"] + mon_step
            if s2 + 1 >= len(mon_bars):
                funnel["signal_no_entry_bar"] += 1
                continue
            entry_t = mon_bars[s2 + 1]["t"]
            if atr_mon[s2] is None:
                funnel["signal_no_atr"] += 1
                continue
            if entry_t in signals:
                collisions += 1
                continue
            tag = ("A" if arm == "A" else "B") + (
                " OB[%.6g,%.6g]@%d FVG[%.6g,%.6g]@%d BOS@%d touch@%d "
                "s1@%d s2@%d" % (ob_lo, ob_hi, ob_bar, fvg_lo, fvg_hi, fvg_b,
                                 k, res["touch_bar"], res["step1_bar"], s2))
            signals[entry_t] = {"direction": d, "atr": atr_mon[s2], "tag": tag,
                                "ob_lo": ob_lo, "ob_hi": ob_hi,
                                "fvg_lo": fvg_lo, "fvg_hi": fvg_hi,
                                "bos_t": bars[k]["t"], "bos_idx": k,
                                "touch_bar": res["touch_bar"],
                                "step1_bar": res["step1_bar"],
                                "step2_bar": s2}
            funnel["signals"] += 1
        elif res["outcome"] == "void":
            funnel["void_" + res["void_reason"]] += 1
            if res["touch_bar"] is not None:
                funnel["touched"] += 1
            pending_until[d] = mon_bars[res["void_bar"]]["t"] + mon_step
        else:
            funnel["expired_" + res["expire_reason"]] += 1
            if res["touch_bar"] is not None:
                funnel["touched"] += 1
            pending_until[d] = mon_bars[end]["t"] + mon_step
    funnel["signal_collisions"] = collisions
    return signals, funnel


# ----------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------
def main():
    print("盈利策略迭代 · 第十四轮：诱导验证的 BOS + 教程版 OB（止损 1xATR / 止盈 2xATR，全模拟）")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    print("A 臂：方向 1 原文诱导版（仅 1h）；B 臂：三条件 OB（严格 FVG）+ MSS 两步确认；"
          "B-T1 全 1h，B-T2 为 1h 结构 + 15m 确认。Killzone 不作硬过滤。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = R11.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = R11.load_funding(sym)
        data1h[sym] = (bars, funding)
        days = R11.group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = R11.load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = R11.load_funding(sym)
        data15[sym] = (bars, funding)
        days = R11.group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    assert data1h["BTC_USDT"][0][0]["t"] % 14400 == 0, "1h 起始时间戳不在 4h 边界"
    assert data15["BTC_USDT"][0][0]["t"] % 3600 == 0, "15m 起始时间戳不在整点边界"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；"
          "时间戳对齐、零缺口。")

    days_all_1h = set(R11.group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(R11.group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- 交叉验证：B-T1 的 N=3 破位总数按币 vs 审计第一部分检测器事件数 ----
    print("\n=== 交叉验证：N=3 破位（检测器式扫描）vs 审计第一部分检测器事件数 ===")
    detector_counts = {}
    for sym in SYMBOLS:
        short = sym.replace("_USDT", "")
        with open(os.path.join(DATA_DIR, "smc_detect_audit", f"{short}_1h_365d.json")) as f:
            dj = json.load(f)
        detector_counts[sym] = len(dj["detect"]["events"])
    atr1h = {s: R11.atr_wilder(data1h[s][0]) for s in SYMBOLS}
    ev1h, sw1h = {}, {}
    cross_ok = True
    for sym in SYMBOLS:
        ev1h[sym], sw1h[sym] = detector_events(data1h[sym][0])
        mine, ref = len(ev1h[sym]), detector_counts[sym]
        err = (mine - ref) / ref if ref else 0.0
        flag = "" if abs(err) <= 0.01 else "  <-- 误差超过 1%，需排查！"
        if abs(err) > 0.01:
            cross_ok = False
        print(f"[{sym}] 本轮破位 {mine} 次 vs 检测器 {ref} 次，误差 {err*100:+.2f}%{flag}")
    tot_mine = sum(len(v) for v in ev1h.values())
    tot_ref = sum(detector_counts.values())
    print(f"[合计] 本轮破位 {tot_mine} 次 vs 检测器 {tot_ref} 次，"
          f"误差 {(tot_mine-tot_ref)/tot_ref*100:+.2f}%"
          + ("" if cross_ok else "  <-- 误差超过 1%，需排查后再报数！"))

    # ---- 15m 确认序列的检测器式事件（B-T2 的 MSS 用）----
    atr15 = {s: R11.atr_wilder(data15[s][0]) for s in SYMBOLS}
    ev15, sw15 = {}, {}
    for sym in SYMBOLS:
        ev15[sym], sw15[sym] = detector_events(data15[sym][0])

    all_results, all_trades = [], []
    pooled = {}
    funnels = {}  # (family) -> {sym: funnel Counter}

    def record(res, trades_full, family, variant, gran, split_fn, funnel_by_sym=None):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        if funnel_by_sym is not None:
            res["setup_stats"] = {s: dict(c) for s, c in funnel_by_sym.items()}
        all_results.append(res)
        if trades_full is not None:
            pooled.setdefault(family, [])
            for t in trades_full:
                pooled[family].append(t["pnl"] / START_EQUITY)
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def split_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def _fmt(x, spec):
        return "—" if x is None else format(x, spec)

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={_fmt(res['win_rate'], '.4f')} "
              f"盈亏比={_fmt(res['profit_factor'], '.2f')} 平均赢={_fmt(res['avg_win_usdt'], '+.0f')} "
              f"平均亏={_fmt(res['avg_loss_usdt'], '.0f')} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={_fmt(res['t_taker'], '.2f')}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={_fmt(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={_fmt(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    def show_funnel(label, funnel_by_sym):
        tot = Counter()
        for c in funnel_by_sym.values():
            tot.update(c)
        print(f"[{label}] 漏斗（8 币合计）：破位 {tot['breaks']} / 无起点 "
              f"{tot['no_origin']} / 条件①通过 {tot['cond1_ok']}（失败："
              f"无内部点 {tot['cond1_fail_no_internal']} / 内部点未被扫 "
              f"{tot['cond1_fail_internal_not_swept']} / 无清扫 "
              f"{tot['cond1_fail_no_sweep']}）/ 有 OB {tot['has_ob']} / 无 OB "
              f"{tot['no_ob']} / 三条件全满足 {tot['three_cond']} / 无 FVG "
              f"{tot['no_fvg']} / 去重跳过 {tot['dedup_skipped']} / 不重叠跳过 "
              f"{tot['overlap_skipped']} / setup {tot['setups_active']} / 回踩触及 "
              f"{tot['touched']} / MSS 完成 {tot['mss_complete']} / 信号 "
              f"{tot['signals']} 个（无入场根 {tot['signal_no_entry_bar']} / "
              f"无 ATR {tot['signal_no_atr']} / 信号冲突 {tot['signal_collisions']}）/ "
              f"作废 {tot['void_ob_far_side']} / 过期（未触及 "
              f"{tot['expired_no_touch']} / 未完成第 1 步 {tot['expired_no_step1']} / "
              f"未完成第 2 步 {tot['expired_no_step2']}）/ 无监测根 "
              f"{tot['mss_no_monitor']}")
        per_sym = " / ".join(
            f"{s.replace('_USDT','')}:破位{c['breaks']}/①{c['cond1_ok']}/"
            f"OB{c['has_ob']}/三条件{c['three_cond']}/信号{c['signals']}"
            for s, c in funnel_by_sym.items())
        print(f"[{label}] 分币（破位/条件①/有OB/三条件/信号）：{per_sym}")
        return tot

    def run_family(family, label, bars_by_sym, signals_by_sym, funding_by_sym,
                   subsets, max_per_day, max_hold, bars_per_day, split_fn, gran,
                   funnel_by_sym):
        for sym in SYMBOLS:
            bars = bars_by_sym[sym]
            funding = funding_by_sym[sym]
            for wname, subset in subsets:
                trades, curve, ndays = R11.simulate_generic(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    max_per_day, max_hold, label, bars_per_day)
                for t in trades:
                    sig = signals_by_sym[sym].get(t["entry_t"])
                    if sig is not None:
                        t["ob_lo"] = sig.get("ob_lo")
                        t["ob_hi"] = sig.get("ob_hi")
                        t["fvg_lo"] = sig.get("fvg_lo")
                        t["fvg_hi"] = sig.get("fvg_hi")
                        t["bos_t"] = sig.get("bos_t")
                res = R11.summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if subset is None else None, family, label,
                       gran, split_fn,
                       funnel_by_sym={sym: funnel_by_sym[sym]} if subset is None else None)
                show(res, sym, wname)

    # ================= A 臂：原文诱导版（全 1h，365d）=================
    print("\n=== A 臂：原文诱导的 BOS + 教程版 OB（全 1h，365d，8 币）===")
    sig_a, fun_a = {}, {}
    for sym in SYMBOLS:
        bars = data1h[sym][0]
        evb = events_by_bar(ev1h[sym])
        sig_a[sym], fun_a[sym] = build_setups(
            bars, atr1h[sym], ev1h[sym], sw1h[sym], "A",
            bars, atr1h[sym], evb,
            lambda k, _b=bars: k + 1, RETRACE_BARS_1H)
    show_funnel("A", fun_a)
    run_family("A", "R14-A", {s: data1h[s][0] for s in SYMBOLS}, sig_a,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               2, MAX_HOLD_1H, 24, split_1h, "1h", fun_a)

    # ================= B-T1：三条件 OB + MSS（全 1h，365d）=================
    print("\n=== B-T1：三条件 OB + MSS 两步确认（全 1h，365d，8 币）===")
    sig_b1, fun_b1 = {}, {}
    for sym in SYMBOLS:
        bars = data1h[sym][0]
        evb = events_by_bar(ev1h[sym])
        sig_b1[sym], fun_b1[sym] = build_setups(
            bars, atr1h[sym], ev1h[sym], sw1h[sym], "B",
            bars, atr1h[sym], evb,
            lambda k, _b=bars: k + 1, RETRACE_BARS_1H)
    show_funnel("B-T1", fun_b1)
    run_family("B-T1", "R14-B-T1", {s: data1h[s][0] for s in SYMBOLS}, sig_b1,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               2, MAX_HOLD_1H, 24, split_1h, "1h", fun_b1)

    # ================= B-T2：1h 结构、15m 确认（103d）=================
    print("\n=== B-T2：三条件 OB + MSS 两步确认（1h 结构、15m 确认，103d，8 币）===")
    sig_b2, fun_b2 = {}, {}
    bars1h_from15 = {}
    for sym in SYMBOLS:
        bars15 = data15[sym][0]
        bars1h = R11.synthesize(bars15, 4, 3600)
        assert len(bars1h) == 103 * 24, f"{sym} 15m 合成 1h 应为 {103*24} 根，实际 {len(bars1h)}"
        bars1h_from15[sym] = bars1h
        atr1h15 = R11.atr_wilder(bars1h)
        ev1h15, sw1h15 = detector_events(bars1h)
        evb15 = events_by_bar(ev15[sym])
        idx15_of_t = {b["t"]: i for i, b in enumerate(bars15)}

        def _start(k, _b1=bars1h, _idx=idx15_of_t):
            return _idx.get(_b1[k]["t"] + 3600)

        sig_b2[sym], fun_b2[sym] = build_setups(
            bars1h, atr1h15, ev1h15, sw1h15, "B",
            bars15, atr15[sym], evb15, _start, RETRACE_BARS_15M)
    show_funnel("B-T2", fun_b2)
    run_family("B-T2", "R14-B-T2", {s: data15[s][0] for s in SYMBOLS}, sig_b2,
               {s: data15[s][1] for s in SYMBOLS},
               [("103d", None), ("前51d", front_15), ("后52d", back_15)],
               2, MAX_HOLD_15M, 96, split_15, "15m", fun_b2)

    # ---- Killzone 诊断：信号触发根（第 2 步完成根）的 UTC 小时分布 ----
    print("\n=== 诊断：信号触发根（MSS 第 2 步完成根）的 UTC 小时分布（Killzone 不作过滤）===")
    for label, sigs in [("A", sig_a), ("B-T1", sig_b1), ("B-T2", sig_b2)]:
        hours = Counter()
        for sym in SYMBOLS:
            for entry_t, sig in sigs[sym].items():
                s2 = sig["step2_bar"]
                mon = data1h[sym][0] if label in ("A", "B-T1") else data15[sym][0]
                t = mon[s2]["t"]
                hours[datetime.fromtimestamp(t, timezone.utc).hour] += 1
        dist = " ".join(f"{h:02d}h:{hours.get(h, 0)}" for h in range(24))
        print(f"[{label}] {dist}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, wnames) in [
            ("A", "1h", ["365d", "前185d", "后180d"]),
            ("B-T1", "1h", ["365d", "前185d", "后180d"]),
            ("B-T2", "15m", ["103d", "前51d", "后52d"])]:
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["split"] == wname]
            n_tr = sum(r["trades"] for r in rs)
            avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
            avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
            avg_g = sum(r["gross_usdt"] for r in rs)
            avg_c = sum(r["taker_cost_sum"] for r in rs)
            n_pos = sum(1 for r in rs if r["taker_net_pct"] > 0)
            print(f"[{fam} {gran} {wname}] 币均 Taker {avg_t*100:+.2f}% | "
                  f"M2 {avg_m2*100:+.2f}% | 笔数 {n_tr} | 为正币数 {n_pos}/8 | "
                  f"毛利合计 {avg_g:+.0f} | 成本合计 {avg_c:+.0f}")

    # ---- 前后两半都为正的币数 ----
    print("\n=== 前后两半都为正的币数 ===")
    for (fam, gran, wfront, wback) in [
            ("A", "1h", "前185d", "后180d"),
            ("B-T1", "1h", "前185d", "后180d"),
            ("B-T2", "15m", "前51d", "后52d")]:
        both = 0
        for sym in SYMBOLS:
            rf = [r for r in all_results if r["family"] == fam and r["symbol"] == sym
                  and r["split"] == wfront]
            rb = [r for r in all_results if r["family"] == fam and r["symbol"] == sym
                  and r["split"] == wback]
            if rf and rb and rf[0]["taker_net_pct"] > 0 and rb[0]["taker_net_pct"] > 0:
                both += 1
        print(f"[{fam}] 前后两半都为正的币数：{both}/8")

    # ---- pooled t（全期逐笔，Taker）----
    print("\n=== Pooled t（全期逐笔，Taker，1x）===")
    for fam in ["A", "B-T1", "B-T2"]:
        pnls = pooled.get(fam, [])
        print(f"[{fam}] n={len(pnls)} pooled t={R11.t_value(pnls)}")

    # ---- 写文件 ----
    out_sum = os.path.join(DATA_DIR, "gate_iter_round14_summary.json")
    out_tr = os.path.join(DATA_DIR, "gate_iter_round14_trades.csv")
    with open(out_sum, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    if all_trades:
        keys = list(all_trades[0].keys())
        with open(out_tr, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(all_trades)
    else:
        with open(out_tr, "w", newline="") as f:
            f.write("")
    print(f"\n写出：{out_sum}（{len(all_results)} 条）")
    print(f"写出：{out_tr}（{len(all_trades)} 笔）")


if __name__ == "__main__":
    main()
