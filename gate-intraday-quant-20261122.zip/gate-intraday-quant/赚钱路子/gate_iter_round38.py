#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第三十八轮：候选 S1（BTC 强动量做多 2%–5% 带）在全新币种宇宙上的验证（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

来源：回测经验挖掘.md §1.3 的预注册方案一字不改（只改两处执行前提，跑前写死在报告 §0）：
  (1) 轮次编号：原指派“第三十六轮”，36 已由分系统完成、37 已由分系统启动，
      本轮为第三十八轮，36/37 的文件一字未动。
  (2) 粒度：原计划 15m，但 2026-11-21 01:32 UTC 实测 Gate 15m 只允许最近
      10,000 根回溯（自 2026-08-06 起报 400 "Candlestick too long ago"），
      15m × 365 天窗口不存在；故取 1h（S1 定义本身写“下一根 15m/1h 开盘做多”，
      1h 在定义内）。1h 发现子集 +24.30（n=1,054）低于成本线，本轮是更严的检验。

信号 S1（单臂，无对照）：
  只做多；BTC 过去 2h 上涨 2%–5%（1h 收盘价，close[i]/close[i-2]-1）时，
  宇宙里每个币下一根 1h 开盘做多；SL 1xATR(14,1h)、TP 2xATR(14,1h)；
  每币每天最多 1 笔、无持仓才进、彼此独立；BTC 只触发、不交易；
  日内 23:00 UTC 强制平仓（22:00 根收盘）；每日 -2% 熔断；
  同根同时碰 SL 与 TP 先判 SL；无持满上限。
  无未来函数：信号只用已收盘的 1h K 线（BTC close[i]、close[i-2]、ATR 只用
  信号根及之前），入场一律下一根开盘（bars[i+1] 的 open）。

成本与口径：Taker 一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）；
  计分口径为混合现实 M1（入场 maker -0.01%、止盈出场 maker -0.01%、
  止损/其他出场 taker 0.125%）；M0（零成本毛利）只作诊断；Taker 净同时披露。
  资金费按实际费率计（08:00/16:00 结算点；2026-05-25 之前无数据按 0 计——
  接口 180 天保留期边界，2026-11-21 实测；05-25 在边界上不稳定，取数脚本
  遇 180 天报错时自动顺延，实际覆盖以资金费文件为准）。

窗口：1h 全 365 天 2025-11-16~2026-11-16（8,761 根，含末尾平值占位根，
  与第 24 轮 1h 臂同一约定）；前半段 2025-11-16~2026-05-19（185 天）；
  后半段 2026-05-20~2026-11-15（180 天）。各币独立 10 万 USDT 虚拟权益。

通过标准（三条同时满足，缺一即证伪；口径见报告 §0.6）：
  (1) 全期 1x M1 净 > +2%（12 币平均）；(2) 前后两半 M1 都为正；
  (3) 每笔毛利 > 25 USDT（价差毛利扣资金费、不扣交易成本，全部交易汇合）。
  市况 artifact 条款：只在上涨月成立、下跌月为负，同样丢弃。
  任一不满足即丢弃 S1，不调阈值、不换带宽、不拆粒度、不换币重测。

引擎：辅助函数（load_bars、load_funding、group_days、atr_wilder、
funding_cost_between、maker_cost、t_value、max_dd）照抄第二十四轮；
simulate 改自第二十四轮 simulate_f1：去掉 max_hold 分支（本轮无持满上限）、
去掉做空分支（只做多）、每天每币最多 1 笔（原 2 笔）、交易日为 00:00–22:00
的 23 根 1h（23:00 根不交易，信号仍可用全天 24 根收盘价生成）。
入场根自身的高/低不触发 SL/TP（第二十四轮同一约定：入场后首根检查为下一根）。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) 数据校验：12 币各 8,761 根 1h / 365 个完整日（23 根/日）、时间戳与 BTC 对齐。
  (b) 脚本跑两遍，summary 与 trades 的 md5 两次运行完全一致。
  (c) 首笔交易人工核对触发链（信号根、入场根、rBTC、ATR、SL/TP、出场根、PnL）。
  (d) 账目核对：笔数 × 25 = 成本合计、毛利 − 成本 = 净，误差 < 0.01。

运行：python3 gate_iter_round38.py（回测本身不联网，只读本地缓存；
      缓存由 gate_iter_round38_fetch.py 预先拉取）
输出：终端打印全部表 + data/gate_iter_round38_summary.json
      + data/gate_iter_round38_trades.csv
复现：跑两遍，summary 与 trades 两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

# ---- 币种（跑前写死，见报告 §0.3 与 data/gate_iter_round38_selection.json）----
NEW_SYMBOLS = ["MMT_USDT", "WLD_USDT", "PIEVERSE_USDT", "AVAX_USDT",
               "KERNEL_USDT", "PAXG_USDT", "ARB_USDT", "FIL_USDT",
               "CYBER_USDT", "TAO_USDT", "ENA_USDT", "INJ_USDT"]

TP_MULT = 2.0            # 止盈 2xATR（用户要求的 1:2）
SL_MULT = 1.0            # 止损 1xATR
SPLIT = datetime(2026, 5, 20, tzinfo=timezone.utc)  # 前半段止于 05-19

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# S1 触发带（跑前写死，含端点）
S1_LO = 0.02
S1_HI = 0.05
LOOKBACK = 2  # 1h 粒度下 2 根 = 2h


# ---- 辅助函数：照抄第二十四轮 ----
def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    # 本轮读 _r38 专属资金费文件（见取数脚本注释：共享文件名正由分系统三十七轮同时写入）
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}_r38.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def entry_hour_utc(entry_t):
    return datetime.fromtimestamp(entry_t, timezone.utc).hour


# ---- S1 信号：只用已收盘 K 线，入场下一根开盘 ----
def build_s1_signals(alt_bars, btc_bars, alt_atr):
    sigs = {}
    for i in range(LOOKBACK, len(alt_bars)):
        if alt_atr[i] is None:
            continue
        r_btc = btc_bars[i]["c"] / btc_bars[i - LOOKBACK]["c"] - 1
        if not (S1_LO <= r_btc <= S1_HI):
            continue
        if i + 1 >= len(alt_bars):
            continue
        entry_t = alt_bars[i + 1]["t"]
        # 无未来函数审计：入场时间戳必须严格晚于信号根时间戳
        assert entry_t > alt_bars[i]["t"]
        sigs[entry_t] = {"direction": 1, "atr": alt_atr[i],
                         "r_btc": r_btc, "signal_t": alt_bars[i]["t"]}
    return sigs


def simulate_s1(symbol, bars, signals, funding, days_subset, max_per_day, label):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    # 交易日只取 00:00–22:00 的 23 根 1h；23:00 根不交易（但信号生成可用它）
    trade_bars = [b for b in bars if entry_hour_utc(b["t"]) < 23]
    days = group_days(trade_bars, 23)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if b["l"] <= pos["stop"]:
                    close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                elif b["h"] >= pos["tp"]:
                    close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - SL_MULT * a
                tp = entry + TP_MULT * a
                pos = {"symbol": symbol, "variant": label, "direction": 1,
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "r_btc": sig["r_btc"], "signal_t": sig["signal_t"]}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    # M0：零成本毛利（价差毛利扣资金费、不扣任何交易成本），只作诊断
    m0_net = gross_sum
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "gross_above_25_share": round(sum(1 for t in trades if (t["price_pnl"] - t["funding_cost_usdt"]) > 25) / n, 4) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m0_net_usdt": round(m0_net, 2),
        "m0_net_pct": round(m0_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def month_table(trades, label):
    """逐月诊断：每笔毛利、M1 净、Taker 净；月份涨跌用 BTC 月收益另算。"""
    rows = []
    months = sorted({datetime.fromtimestamp(t["entry_t"], timezone.utc).strftime("%Y-%m") for t in trades})
    for m in months:
        sub = [t for t in trades if datetime.fromtimestamp(t["entry_t"], timezone.utc).strftime("%Y-%m") == m]
        n = len(sub)
        gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in sub)
        m1 = sum(t["pnl_maker_m1"] for t in sub)
        taker = sum(t["pnl"] for t in sub)
        rows.append({"month": m, "trades": n,
                     "gross_per_trade_usdt": round(gross / n, 2),
                     "m1_net_usdt": round(m1, 2),
                     "taker_net_usdt": round(taker, 2),
                     "win_rate_m1": round(sum(1 for t in sub if t["pnl_maker_m1"] > 0) / n, 4)})
    print(f"\n--- {label}：逐月诊断 ---")
    print(f"  {'月份':>7} {'笔数':>5} {'每笔毛利':>9} {'M1净':>10} {'Taker净':>10} {'M1胜率':>7}")
    for r in rows:
        print(f"  {r['month']:>7} {r['trades']:>5} {r['gross_per_trade_usdt']:+9.2f} "
              f"{r['m1_net_usdt']:+10.2f} {r['taker_net_usdt']:+10.2f} {r['win_rate_m1']:>7.3f}")
    return rows


def hour_table(trades, label):
    rows = []
    for h in range(24):
        sub = [t for t in trades
               if datetime.fromtimestamp(t["entry_t"], timezone.utc).hour == h]
        n = len(sub)
        if n == 0:
            rows.append({"hour_utc": h, "trades": 0, "gross_usdt": 0.0,
                         "gross_per_trade_usdt": None, "gross_t": None,
                         "taker_net_usdt": 0.0, "taker_net_per_trade_usdt": None,
                         "taker_t": None, "win_rate": None})
            continue
        gross = [t["price_pnl"] - t["funding_cost_usdt"] for t in sub]
        taker = [t["pnl"] for t in sub]
        rows.append({
            "hour_utc": h, "trades": n,
            "gross_usdt": round(sum(gross), 2),
            "gross_per_trade_usdt": round(sum(gross) / n, 2),
            "gross_t": t_value([g / START_EQUITY for g in gross]),
            "taker_net_usdt": round(sum(taker), 2),
            "taker_net_per_trade_usdt": round(sum(taker) / n, 2),
            "taker_t": t_value([p / START_EQUITY for p in taker]),
            "win_rate": round(sum(1 for p in taker if p > 0) / n, 4),
        })
    print(f"\n--- {label}：24 小时诊断（入场 UTC 小时）---")
    print(f"  {'小时':>4} {'笔数':>5} {'每笔毛利':>9} {'毛利t':>7} "
          f"{'每笔Taker净':>11} {'Taker t':>8} {'胜率':>6}")
    for r in rows:
        gp = f"{r['gross_per_trade_usdt']:+.2f}" if r["gross_per_trade_usdt"] is not None else "—"
        gt = f"{r['gross_t']:+.2f}" if r["gross_t"] is not None else "—"
        tp = f"{r['taker_net_per_trade_usdt']:+.2f}" if r["taker_net_per_trade_usdt"] is not None else "—"
        tt = f"{r['taker_t']:+.2f}" if r["taker_t"] is not None else "—"
        wr = f"{r['win_rate']:.3f}" if r["win_rate"] is not None else "—"
        print(f"  {r['hour_utc']:>4} {r['trades']:>5} {gp:>9} {gt:>7} {tp:>11} {tt:>8} {wr:>6}")
    return rows


def main():
    print("盈利策略迭代 · 第三十八轮：候选 S1（BTC 强动量做多 2%–5% 带）在全新币种宇宙上的验证（全模拟）")
    print("信号：BTC 2h +2%~+5% → 下一根 1h 开盘做多；SL 1xATR / TP 2xATR；每币每天 1 笔；23:00 UTC 强平；每日 -2% 熔断。")
    print("计分口径 M1（混合现实），M0 只作诊断，Taker 净同时披露；通过标准：M1 全期 >2%、前后两半 M1 都为正、每笔毛利 >25 USDT。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data = {}
    for sym in NEW_SYMBOLS + ["BTC_USDT"]:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        # 归一化：剔除 2026-11-16 00:00 的平值占位根（o=h=l=c、v=0，接口边界产物，
        # 非真实成交根；第 24 轮缓存里有它，本轮取数脚本的 <end 过滤把它排除了）。
        # 剔除后全部为真实根：2025-11-16 00:00 ~ 2026-11-15 23:00，共 8,760 根。
        bars = [b for b in bars if b["t"] < 1794787200]
        funding = load_funding(sym) if sym != "BTC_USDT" else {}
        data[sym] = (bars, funding)
        trade_bars = [b for b in bars if entry_hour_utc(b["t"]) < 23]
        days = group_days(trade_bars, 23)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8760, f"{sym} 1h 应为 8760 根（真实根），实际 {len(bars)}"
        if sym != "BTC_USDT":
            print(f"  {sym}: 1h 8761 根 / 365 天；资金费 {len(funding)} 条，"
                  f"覆盖 {datetime.fromtimestamp(min(funding), timezone.utc).date()} ~ "
                  f"{datetime.fromtimestamp(max(funding), timezone.utc).date()}" if funding else
                  f"  {sym}: 1h 8761 根 / 365 天；资金费 0 条（算不出，见报告）")
    base_ts = [b["t"] for b in data["BTC_USDT"][0]]
    for sym in NEW_SYMBOLS:
        assert [b["t"] for b in data[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    print("数据校验通过：12 币 + BTC 各 8,760 根 1h 真实根 / 365 天；时间戳对齐、零缺口。")
    print("资金费自 2026-05-25 起（接口 180 天保留期边界；05-25 之前按 0 计）。")

    days_all = set(group_days([b for b in data["BTC_USDT"][0] if entry_hour_utc(b["t"]) < 23], 23).keys())
    front = {d for d in days_all if d < SPLIT.date()}
    back = {d for d in days_all if d >= SPLIT.date()}
    print(f"窗口：1h 全 365d（前 {len(front)} 天 / 后 {len(back)} 天）；切分点 2026-05-20。")

    # ---- S1 信号：每个币只生成一次 ----
    atr = {s: atr_wilder(data[s][0]) for s in NEW_SYMBOLS}
    sigs = {}
    for sym in NEW_SYMBOLS:
        sigs[sym] = build_s1_signals(data[sym][0], data["BTC_USDT"][0], atr[sym])
    print(f"[S1] 信号数：合计 {sum(len(v) for v in sigs.values())} "
          f"（各币：{', '.join(f'{s} {len(v)}' for s, v in sigs.items())}）。")
    # 无未来函数审计：全部信号的 entry_t > signal_t（build 时已断言；此处再全量核对）
    assert all(v["signal_t"] < k for s in sigs.values() for k, v in s.items()), "信号时间审计失败"
    print("无未来函数审计通过：全部信号 entry_t > signal_t。")

    windows = [("365d", None), ("前185d", front), ("后180d", back)]
    all_results, all_trades = [], []
    for sym in NEW_SYMBOLS:
        bars, funding = data[sym]
        for wname, subset in windows:
            trades, curve, ndays = simulate_s1(
                sym, bars, sigs[sym], funding, subset, 1, "S1-1h")
            res = summarize(sym, trades, curve, "S1-1h", len(sigs[sym]))
            res["family"] = "S1"
            res["variant"] = "S1-1h"
            res["granularity"] = "1h"
            res["split"] = wname
            res["days"] = ndays
            all_results.append(res)
            if wname == "365d":
                for t in trades:
                    t2 = dict(t)
                    t2["family"] = "S1"
                    t2["variant"] = "S1-1h"
                    t2["granularity"] = "1h"
                    t2["split"] = "前185d" if datetime.fromtimestamp(t["entry_t"], timezone.utc).date() < SPLIT.date() else "后180d"
                    t2["entry_hour_utc"] = entry_hour_utc(t["entry_t"])
                    all_trades.append(t2)
            print(f"[S1-1h {sym} {wname}] n={res['trades']} 信号 {len(sigs[sym])} "
                  f"胜率={res['win_rate']} 盈亏比={res['profit_factor']} "
                  f"M1 {res['m1_net_pct']*100:+.2f}% (t={res['m1_t']}, MDD {res['m1_max_dd']*100:.2f}%) | "
                  f"Taker {res['taker_net_pct']*100:+.2f}% | M0 {res['m0_net_pct']*100:+.2f}% | "
                  f"毛利={res['gross_usdt']:+.0f} 每笔毛利={res['gross_per_trade_usdt']:+.2f} "
                  f"成本={res['taker_cost_sum']:+.0f} 持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均（12 币独立 10 万 USDT，1x）----
    print("\n=== 汇总：平均净收益（12 币独立 10 万 USDT，1x）===")
    agg = {}
    for wname, _ in windows:
        rs = [r for r in all_results if r["split"] == wname]
        gt = sum(r["gross_usdt"] for r in rs)
        ct = sum(r["taker_cost_sum"] for r in rs)
        nt = sum(r["trades"] for r in rs)
        wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
        agg[wname] = {
            "m1_pct": sum(r["m1_net_pct"] for r in rs) / len(rs),
            "taker_pct": sum(r["taker_net_pct"] for r in rs) / len(rs),
            "m0_pct": sum(r["m0_net_pct"] for r in rs) / len(rs),
            "gross": gt, "cost": ct, "n": nt,
            "gross_per_trade": gt / nt if nt else None,
            "win_rate": wr,
        }
        print(f"  S1-1h {wname}（12 币）：M1 平均 {agg[wname]['m1_pct']*100:+.2f}% / "
              f"Taker 平均 {agg[wname]['taker_pct']*100:+.2f}% / M0 平均 {agg[wname]['m0_pct']*100:+.2f}% | "
              f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
              f"每笔毛利 {gt/nt:+.2f} USDT 胜率 {wr:.3f}" if wr is not None else
              f"  S1-1h {wname}（12 币）：M1 平均 {agg[wname]['m1_pct']*100:+.2f}% / "
              f"Taker 平均 {agg[wname]['taker_pct']*100:+.2f}% / M0 平均 {agg[wname]['m0_pct']*100:+.2f}% | "
              f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} 每笔毛利 — 胜率 —")

    # ---- Pooled t（全期明细，Taker 与 M1）----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for wname, _ in windows:
        s2 = [t for t in all_trades if wname == "365d" or t["split"] == wname]
        vt = [t["pnl"] / START_EQUITY for t in s2]
        vm = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
        print(f"  S1-1h {wname}：n={len(s2)} "
              f"pooled t(Taker)={t_value(vt)} pooled t(M1)={t_value(vm)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（计分口径 M1；三条同时满足）===")
    c1 = agg["365d"]["m1_pct"] > 0.02
    c2 = agg["前185d"]["m1_pct"] > 0 and agg["后180d"]["m1_pct"] > 0
    c3 = agg["365d"]["gross_per_trade"] is not None and agg["365d"]["gross_per_trade"] > 25
    print(f"  (1) 全期 M1 净 {agg['365d']['m1_pct']*100:+.2f}% > +2% → {'通过' if c1 else '不通过'}"
          f"（Taker {agg['365d']['taker_pct']*100:+.2f}% 同时披露）")
    print(f"  (2) 前半 M1 {agg['前185d']['m1_pct']*100:+.2f}% / 后半 M1 {agg['后180d']['m1_pct']*100:+.2f}% "
          f"都为正 → {'通过' if c2 else '不通过'}"
          f"（Taker 前 {agg['前185d']['taker_pct']*100:+.2f}% / 后 {agg['后180d']['taker_pct']*100:+.2f}%）")
    print(f"  (3) 每笔毛利 {agg['365d']['gross_per_trade']:+.2f} USDT > 25 → {'通过' if c3 else '不通过'}")
    verdict = c1 and c2 and c3
    print(f"  整轮判定：{'通过' if verdict else '不通过'} → {'S1 进入下一阶段（30–60 天实时纸面观察）' if verdict else 'S1 证伪，丢弃，不复活'}")

    # ---- 逐币两半（M1）----
    print("\n=== 逐币两半（M1 净）===")
    for sym in NEW_SYMBOLS:
        rf = [r for r in all_results if r["symbol"] == sym and r["split"] == "前185d"][0]
        rb = [r for r in all_results if r["symbol"] == sym and r["split"] == "后180d"][0]
        both = rf["m1_net_pct"] > 0 and rb["m1_net_pct"] > 0
        print(f"  {sym}: 前 {rf['m1_net_pct']*100:+.2f}% / 后 {rb['m1_net_pct']*100:+.2f}% "
              f"→ {'★ 两半都为正' if both else ''}")

    # ---- 敏感性：剔除 PAXG（11 币）----
    print("\n=== 敏感性：剔除 PAXG（11 币；PAXG 为黄金背书代币）===")
    for wname, _ in windows:
        rs = [r for r in all_results if r["split"] == wname and r["symbol"] != "PAXG_USDT"]
        gt = sum(r["gross_usdt"] for r in rs)
        nt = sum(r["trades"] for r in rs)
        print(f"  S1-1h(除 PAXG) {wname}：M1 平均 {sum(r['m1_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
              f"Taker 平均 {sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
              f"每笔毛利 {gt/nt:+.2f} USDT（n={nt}）")

    # ---- 逐月诊断 + BTC 月收益（市况 artifact 检查）----
    btc_bars = data["BTC_USDT"][0]
    btc_monthly = {}
    months_sorted = sorted({datetime.fromtimestamp(b["t"], timezone.utc).strftime("%Y-%m") for b in btc_bars})
    for m in months_sorted:
        mb = [b for b in btc_bars if datetime.fromtimestamp(b["t"], timezone.utc).strftime("%Y-%m") == m]
        btc_monthly[m] = mb[-1]["c"] / mb[0]["o"] - 1
    month_rows = month_table(all_trades, "S1-1h 全期")
    print("\n--- 市况 artifact 检查：逐月 M1 净 vs BTC 当月收益 ---")
    up_pos = down_pos = 0
    for r in month_rows:
        br = btc_monthly[r["month"]]
        tag = "上涨月" if br >= 0 else "下跌月"
        if br >= 0 and r["m1_net_usdt"] > 0:
            up_pos += 1
        if br < 0 and r["m1_net_usdt"] > 0:
            down_pos += 1
        print(f"  {r['month']} BTC {br*100:+.2f}%（{tag}）→ S1 M1 净 {r['m1_net_usdt']:+.2f} USDT（n={r['trades']}）")
    print(f"  上涨月为正：{up_pos} 个月；下跌月为正：{down_pos} 个月。"
          + ("（只在上涨月成立、下跌月为负 → 市况 artifact，丢弃）" if down_pos == 0 and up_pos > 0 else ""))

    # ---- 24 小时诊断 ----
    hour_rows = hour_table(all_trades, "S1-1h 全期")

    # ---- 首笔交易（人工核对触发链）----
    first_trades = sorted(all_trades, key=lambda x: x["entry_t"])
    if first_trades:
        t0 = first_trades[0]
        print("\n=== 首笔交易（人工核对触发链）===")
        print(f"  {t0['symbol']} LONG 信号 "
              f"{datetime.fromtimestamp(t0['signal_t'], timezone.utc).isoformat()} "
              f"rBTC={t0['r_btc']*100:+.2f}% ATR={t0['atr']:.4f} → 入场 "
              f"{datetime.fromtimestamp(t0['entry_t'], timezone.utc).isoformat()} "
              f"@ {t0['entry']}（SL {t0['stop']:.4f} / TP {t0['tp']:.4f}）→ 出场 "
              f"{datetime.fromtimestamp(t0['exit_t'], timezone.utc).isoformat()} "
              f"@ {t0['exit']} 原因 {t0['reason']} 持仓 {t0['hold_min']} 分钟 "
              f"价差 PnL {t0['price_pnl']:+.2f} Taker 净 {t0['pnl']:+.2f} M1 净 {t0['pnl_maker_m1']:+.2f}")

    # ---- 账目核对 ----
    print("\n=== 账目核对 ===")
    for wname, _ in windows:
        rs = [r for r in all_results if r["split"] == wname]
        gt = sum(r["gross_usdt"] for r in rs)
        ct = sum(r["taker_cost_sum"] for r in rs)
        nt = sum(r["taker_net_usdt"] for r in rs)
        print(f"  {wname}：毛利 {gt:+.2f} − 成本 {ct:+.2f} = {gt-ct:+.2f}；"
              f"Taker 净合计 {nt:+.2f}；误差 {abs((gt-ct)-nt):.4f}（<0.01 为通过）")

    with open(os.path.join(DATA_DIR, "gate_iter_round38_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round38_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "variant", "granularity", "split", "symbol",
                    "direction", "signal_time_utc", "entry_time_utc", "entry_hour_utc",
                    "exit_time_utc", "entry", "exit", "r_btc_pct", "atr",
                    "stop", "tp", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["symbol"])):
            w.writerow([t["family"], t["variant"], t["granularity"],
                        t["split"], t["symbol"], "LONG",
                        datetime.fromtimestamp(t["signal_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["entry"], t["exit"], round(t["r_btc"] * 100, 4), t["atr"],
                        t["stop"], t["tp"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round38_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round38_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")

    diag = {
        "month_rows": month_rows,
        "btc_monthly": {m: round(v, 4) for m, v in btc_monthly.items()},
        "hour_rows": hour_rows,
        "verdict": {"c1_m1_full_gt_2pct": c1, "c2_both_halves_m1_positive": c2,
                    "c3_gross_per_trade_gt_25": c3, "pass": verdict},
        "agg": {k: {kk: (round(vv, 4) if isinstance(vv, float) else vv) for kk, vv in v.items()}
                for k, v in agg.items()},
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round38_diag.json"), "w") as f:
        json.dump(diag, f, indent=2, ensure_ascii=False)
    print("诊断已写入：data/gate_iter_round38_diag.json")


if __name__ == "__main__":
    main()
