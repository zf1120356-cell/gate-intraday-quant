#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回测经验挖掘 Part 4：第二节止盈止损 / 第三节机械规则（描述性，只读现有文件）。
不重算出场、不换出场重跑、不调参。
"""
import csv, glob, json, math, os, pickle, statistics, sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.expanduser('~/workspace/赚钱路子'))
from mine_experience import dist_stats, tstat, load_trades, parse_dt

DATA = os.path.expanduser('~/workspace/赚钱路子/data')
COST_LINE = 25.0
OUT = {}

def welch(a, b):
    import math as _m
    ma, mb = statistics.mean(a), statistics.mean(b)
    va, vb = statistics.variance(a), statistics.variance(b)
    na, nb = len(a), len(b)
    se = _m.sqrt(va / na + vb / nb)
    return (ma - mb) / se if se > 0 else 0.0

ded = pickle.load(open('/tmp/mine2_pool.pkl', 'rb'))
disc = [t for t in ded if t['symbol'] != 'ZEC' and t['entry_hour'] != 17]
pool = [t for t in disc if t.get('feat')]
print(f"deduped={len(ded)} discovery={len(disc)}")

def show(name, rows):
    print(f"\n=== {name} ===")
    for r in rows:
        print(r)

# ================= 第二节：止盈止损 =================
print("\n########## SECTION 2: EXITS (TP/SL) ##########")
# 2.1 出场原因构成（去重池）
g = defaultdict(list)
hold = defaultdict(list)
for t in ded:
    r = t['reason'] or '?'
    g[r].append(t['gross'])
    hold[r].append(t['hold_min'])
tot = sum(len(v) for v in g.values())
rows = []
for r, v in sorted(g.items(), key=lambda kv: -len(kv[1])):
    d = dist_stats(v)
    rows.append(dict(reason=r, n=d['n'], share=round(d['n'] / tot, 3), mean=round(d['mean'], 2),
                     median=round(d['median'], 2), frac_gt25=round(d['frac_gt25'], 2),
                     mean_hold_min=round(statistics.mean(hold[r]), 1)))
    print(f"{r:16s} n={d['n']:6d} share={d['n']/tot:.3f} mean={d['mean']:7.2f} med={d['median']:7.2f} >25%={d['frac_gt25']:.2f} hold={statistics.mean(hold[r]):6.1f}min")
OUT['reason_mix'] = rows
# 2.2 主要家族的 TP/SL 比
fam_g = defaultdict(lambda: defaultdict(int))
fam_n = Counter()
for t in ded:
    fam_g[t['famkey']][t['reason'] or '?'] += 1
    fam_n[t['famkey']] += 1
print("\n--- TP/SL ratio by major family (n>=500) ---")
for f, n in fam_n.most_common(14):
    r = fam_g[f]
    tp, sl = r.get('take_profit', 0), r.get('stop_loss', 0)
    print(f"{f:36s} n={n:6d} TP={tp:5d} SL={sl:5d} TP/SL={tp/max(sl,1):.2f} max_hold={r.get('max_hold',0)} eod={r.get('eod',0)}")
# 2.3 毛利集中度（发现池）
gs = sorted((t['gross'] for t in pool), reverse=True)
total = sum(gs)
for q in (0.01, 0.05, 0.10):
    k = int(len(gs) * q)
    print(f"top {int(q*100)}% trades ({k}) share of total gross: {sum(gs[:k])/total:.3f}")
# 多少笔构成总毛利的 50%
c = 0; acc = 0
for v in gs:
    acc += v; c += 1
    if acc >= total * 0.5:
        break
print(f"trades for 50% of total gross: {c} / {len(gs)} ({c/len(gs):.3f})")
# TP 交易内部的集中度
tp_gs = sorted((t['gross'] for t in pool if t['reason'] == 'take_profit'), reverse=True)
tp_tot = sum(tp_gs)
for q in (0.05, 0.10):
    k = int(len(tp_gs) * q)
    print(f"TP trades top {int(q*100)}% share of TP gross: {sum(tp_gs[:k])/tp_tot:.3f}")
OUT['concentration'] = dict(top1=round(sum(gs[:int(len(gs)*0.01)])/total, 3),
                            top5=round(sum(gs[:int(len(gs)*0.05)])/total, 3),
                            top10=round(sum(gs[:int(len(gs)*0.10)])/total, 3),
                            n_for_50pct=c)
# 2.4 MFE：R33/34/35 的 max_favour_usdt（实测列，非重算）
print("\n--- MFE (max_favour_usdt, R33/34/35 only; file atr where present, else 1h feat ATR) ---")
feat_atr = {}
for t in ded:
    if t['feat'].get('atr') == t['feat'].get('atr') and t['entry_price']:
        feat_atr[(t['symbol'], t['entry_dt'], t['direction'])] = (t['feat']['atr'], float(t['entry_price']))
for rnd in (33, 34, 35):
    f = os.path.join(DATA, f'gate_iter_round{rnd}_trades.csv')
    rows = list(csv.DictReader(open(f, newline='', encoding='utf-8')))
    print(f"\nRound {rnd}: n={len(rows)}")
    by_reason = defaultdict(list)
    for row in rows:
        try:
            mf = float(row['max_favour_usdt'])
            entry = float(row['entry'])
            atr = float(row['atr']) if row.get('atr') not in (None, '') else None
            if atr is None:
                fa = feat_atr.get((row['symbol'].replace('_USDT', ''), parse_dt(row['entry_time_utc']),
                                   1 if row['direction'] in ('1', 'LONG') else -1))
                atr = fa[0] if fa else None
            if atr is None or atr <= 0:
                continue
            atr_usd = atr * 10000.0 / entry
            by_reason[row['reason']].append((mf, mf / atr_usd, float(row['price_pnl_usdt']) - float(row['funding_cost_usdt'] or 0)))
        except Exception:
            continue
    for reason, v in sorted(by_reason.items(), key=lambda kv: -len(kv[1])):
        mfs = [x[0] for x in v]; rs = [x[1] for x in v]
        print(f"  {reason:16s} n={len(v):5d} max_favour mean={statistics.mean(mfs):7.2f} USDT "
              f"({statistics.mean(rs):5.2f} ATR) med={statistics.median(rs):5.2f} ATR | "
              f"frac>=0.5R={sum(1 for x in rs if x>=0.5)/len(rs):.2f} >=1R={sum(1 for x in rs if x>=1)/len(rs):.2f} >=1.5R={sum(1 for x in rs if x>=1.5)/len(rs):.2f}")
    sl = by_reason.get('stop_loss', [])
    if sl:
        gb = [(mf_r - (g / (10000.0 / 1))) for mf_r, g in []]  # placeholder, computed below properly
        # 回吐：max_favour(R) - realized gross(R)，gross(R)= price pnl / atr_usd；需 atr_usd，上面已折算在 rs 里？rs 是 mf/atr；gross 的 R = gross_usdt/atr_usd，未存。重算：
        pass
    OUT[f'mfe_r{rnd}'] = {r: dict(n=len(v), mf_mean_usdt=round(statistics.mean([x[0] for x in v]), 2),
                                 mf_mean_R=round(statistics.mean([x[1] for x in v]), 2),
                                 frac_ge1R=round(sum(1 for x in v if x[1] >= 1) / len(v), 3))
                         for r, v in by_reason.items()}
    # 全部交易里到过 +1R 的比例 vs 最终止盈比例
    allv = [x for v in by_reason.values() for x in v]
    print(f"  ALL n={len(allv)} frac reached >=1R at any point: {sum(1 for x in allv if x[1]>=1)/len(allv):.3f}; "
          f"ended take_profit: {len(by_reason.get('take_profit', []))/len(allv):.3f}")

# 2.4b 回吐量（SL 交易：max_favour_R - realized_R），R33/34/35
print("\n--- give-back for stop_loss trades (max_favour_R minus realized_R) ---")
for rnd in (33, 34, 35):
    f = os.path.join(DATA, f'gate_iter_round{rnd}_trades.csv')
    rows = list(csv.DictReader(open(f, newline='', encoding='utf-8')))
    gb = []
    for row in rows:
        if row['reason'] != 'stop_loss':
            continue
        try:
            mf = float(row['max_favour_usdt']); entry = float(row['entry'])
            atr = float(row['atr']) if row.get('atr') not in (None, '') else None
            if atr is None:
                fa = feat_atr.get((row['symbol'].replace('_USDT', ''), parse_dt(row['entry_time_utc']),
                                   1 if row['direction'] in ('1', 'LONG') else -1))
                atr = fa[0] if fa else None
            if atr is None or atr <= 0:
                continue
            atr_usd = atr * 10000.0 / entry
            gross = float(row['price_pnl_usdt']) - float(row['funding_cost_usdt'] or 0)
            gb.append(mf / atr_usd - gross / atr_usd)
        except Exception:
            continue
    if gb:
        print(f"Round {rnd} SL n={len(gb)} give-back mean={statistics.mean(gb):.2f}R med={statistics.median(gb):.2f}R "
              f"frac give-back>=1R: {sum(1 for x in gb if x>=1)/len(gb):.2f}")
        OUT[f'giveback_r{rnd}'] = dict(n=len(gb), mean=round(statistics.mean(gb), 2),
                                       median=round(statistics.median(gb), 2),
                                       frac_ge1R=round(sum(1 for x in gb if x >= 1) / len(gb), 3))

# ================= 第三节：机械规则 =================
print("\n########## SECTION 3: MECHANICAL RULES ##########")
# 3.1 确认过滤器方差：MAIN（过滤后）vs CTRL1 被滤掉的部分（同轮同信号）
raw = load_trades()
print("\n--- confirmation filter: MAIN (kept) vs CTRL1-minus-MAIN (filtered out), per-trade gross ---")
for rnd in (20, 24, 26, 30):
    rt = [t for t in raw if t['round'] == rnd]
    arms = defaultdict(list)
    for t in rt:
        arms[t['arm']].append(t)
    if 'MAIN' not in arms or 'CTRL1' not in arms:
        print(f"Round {rnd}: arms {sorted(arms)} — skip")
        continue
    main_keys = {(t['symbol'], t['entry_dt'], t['direction'], round(t['gross'], 2)) for t in arms['MAIN']}
    kept = [t['gross'] for t in arms['MAIN']]
    out = [t['gross'] for t in arms['CTRL1'] if (t['symbol'], t['entry_dt'], t['direction'], round(t['gross'], 2)) not in main_keys]
    dm, do = dist_stats(kept), dist_stats(out)
    tt = welch(kept, out)
    print(f"Round {rnd}: MAIN n={dm['n']} mean={dm['mean']:.2f} | filtered-out n={do['n']} mean={do['mean']:.2f} | "
          f"delta={dm['mean']-do['mean']:+.2f} Welch t={tt:.2f}")
    OUT[f'filter_r{rnd}'] = dict(main_n=dm['n'], main_mean=round(dm['mean'], 2),
                                 out_n=do['n'], out_mean=round(do['mean'], 2),
                                 delta=round(dm['mean'] - do['mean'], 2), t=round(tt, 2))
# 3.2 Killzone 方差：R15（有限制）vs R35（同模板、无 Killzone/无 23:00 平仓）
print("\n--- Killzone: R15 (with Killzone+23:00 close) vs R35 (same templates, no Killzone/no close) ---")
for rnd in (15, 35):
    s = json.load(open(os.path.join(DATA, f'gate_iter_round{rnd}_summary.json')))
    by = defaultdict(list)
    for e in s:
        by[(e.get('template') or e.get('variant') or '?', e.get('granularity'))].append(e)
    for k, es in sorted(by.items(), key=str):
        tot_n = sum(e.get('n_trades', 0) or 0 for e in es)
        gp = [e.get('gross_per_trade_usdt') for e in es if e.get('gross_per_trade_usdt') is not None]
        tk = [e.get('taker_net_pct') for e in es if e.get('taker_net_pct') is not None]
        print(f"R{rnd} {k}: n={tot_n} gross/trade={statistics.mean(gp):.2f}" if gp else f"R{rnd} {k}: n={tot_n} gross/trade=n/a",
              f"taker_net={statistics.mean(tk):+.2f}%" if tk else "")
# 3.3 强度阈值方差：引用 Part 1 桶 H（withBTC 梯度）与桶 B
p1 = json.load(open('/tmp/mine3_part1.json'))
print("\n--- strength threshold variance (from Part 1 buckets H/B, discovery pool) ---")
for d in p1['H']:
    print(f"  H {d['bucket']}: n={d['n']} mean={d['mean']:.2f} t={d['t']:.2f}")
# 3.4 确认强度方差：引用 Part 1 桶 F/G
print("\n--- confirmation-strength variance (Part 1 buckets F/G) ---")
for d in p1['F']:
    print(f"  F {d['bucket']}: n={d['n']} mean={d['mean']:.2f} t={d['t']:.2f}")
# 3.5 TP 倍数方差：R9 摘要（TP 1x/2x/3x 臂）
print("\n--- TP multiple variance (R9 summary) ---")
s9 = json.load(open(os.path.join(DATA, 'gate_iter_round9_summary.json')))
seen9 = {}
for e in s9:
    k = (e.get('variant'), e.get('tp_mult'), e.get('granularity'))
    seen9.setdefault(k, []).append(e)
for k in sorted(seen9, key=str):
    es = seen9[k]
    gp = [e.get('gross_per_trade_usdt') for e in es if e.get('gross_per_trade_usdt') is not None]
    tk = [e.get('taker_net_pct') for e in es if e.get('taker_net_pct') is not None]
    n = sum(e.get('n_trades', 0) or 0 for e in es)
    print(f"  {k}: n={n} gross/trade={statistics.mean(gp):.2f}" if gp else f"  {k}: n={n} gross/trade=n/a",
          f"taker={statistics.mean(tk):+.2f}%" if tk else "")

json.dump(OUT, open('/tmp/mine3_part2.json', 'w', encoding='utf-8'), ensure_ascii=False, default=str)
print("\nsaved /tmp/mine3_part2.json")
