#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SMC 定义审计 · 第二部分：三条件 OB 审计（只数数，不开回测，不碰真钱）
================================================================================
在第十二轮 S1 的 4,191 次 1h 结构破位（N=5 摆动点，365 天，8 币）上统计：

  (1) 有没有教程版 OB（smc_detect.py 的 OB 定义：推动起点 = 被破摆动点
      之后、破位根之前的极值点；起点那根是反向 K 线就顺延连续反向 K 线
      到最后一根，不是反向就往前找最近的反向 K 线；只取实体；OB 根早于破位根）
  (2) 条件①同侧清扫（N=3 摆动点；窗口 = 推动起点之后、破位根之前；
      影线越过已确认摆动点且收盘收回，或收盘越过后下一根收回；
      看涨只计扫摆动低，看跌只计扫摆动高）+ N=5 敏感性
  (3) 条件② FVG（OB 根之后、破位根之前含破位根形成的同向 FVG，
      B 根下标 in (OB 根, 破位根]，宽度 >= 0.3 x ATR，教程“强”标准）
  (4) 三条件同时满足（(1) 且 (2) 且 (3)）
  (5) 诱导式（推动起点之后、破位根之前最近的已确认摆动低/高被扫；
      另计根本没有内部回撤低/高点的破位）

复用第 11/12 轮已验证的函数（gate_iter_round11.load_bars /
confirmed_levels / swing_points），不复制第二份引擎；破位清单的复现
逻辑与 gate_iter_round12.build_strict_setups 的破位扫描逐行一致，
并用 gate_iter_round12_summary.json 的 setup_stats 逐币校验总数。

ATR 口径：FVG 宽度用的 ATR 是教程程序 smc_detect.py 的定义——真实
波幅 TR 的 14 根简单平均，取 FVG 的 B 根前一根的 ATR（pre(b)=atr[b-1]）；
与第 11/12 轮的 Wilder ATR 不同，特此注明。

前视防控（写死）：
  - 只用已收盘的根；摆动点须在确认根（bar i+N）收盘后才可用。
  - 清扫的“收盘越过后下一根收回”要求收回根严格早于破位根（w+1 < k），
    即扫荡与收回在破位收盘之前已全部观测到。
  - FVG 按教程程序的口径以 B 根（中间根）下标定位：b in (OB 根, 破位根]。
    边界情形 b == 破位根时，C 根是破位根后一根——这是教程程序自身的
    口径（detect() 里 has_fvg 用 j+1 <= f['b'] <= k），本审计如实沿用，
    并单独计数有多少 (3) 阳性依赖 b == 破位根这一边界情形。

运行：python3 smc_definition_audit.py（不联网，只读本地缓存）
输出：终端打印汇总表 + data/smc_definition_audit.json
复现：跑两遍，JSON 的 md5 应完全一致。
"""
import json
import os
import sys
from collections import Counter

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round11 as R11  # 复用已验证的通用函数

DATA_DIR = os.path.join(SCRIPT_DIR, "data")
OUT_JSON = os.path.join(DATA_DIR, "smc_definition_audit.json")
SUMMARY12 = os.path.join(DATA_DIR, "gate_iter_round12_summary.json")
SYMBOLS = R11.SYMBOLS
SWING_N_BREAK = 5      # 第十二轮 S1 的摆动点 N=5
SWING_N_SWEEP = 3      # 教程程序默认 N=3（条件①主口径）
FVG_MIN_ATR = 0.3      # 教程“强”FVG 标准（smc_detect.py fvg_weak_atr）


def detector_atr(bars):
    """教程程序 smc_detect.py 的 ATR：TR 的 14 根简单平均（含当根）。

    tr[0] = H-L；tr[i] = max(H-L, |H-C[i-1]|, |L-C[i-1]|)；
    atr[i] = mean(tr[max(0, i-13) .. i])。
    """
    n = len(bars)
    tr = []
    for i in range(n):
        if i == 0:
            tr.append(bars[i]["h"] - bars[i]["l"])
        else:
            tr.append(max(bars[i]["h"] - bars[i]["l"],
                          abs(bars[i]["h"] - bars[i - 1]["c"]),
                          abs(bars[i]["l"] - bars[i - 1]["c"])))
    atr = []
    for i in range(n):
        lo = max(0, i - 13)
        atr.append(sum(tr[lo:i + 1]) / (i + 1 - lo))
    return atr


def is_bear(b):
    return b["c"] < b["o"]


def is_bull(b):
    return b["c"] > b["o"]


def find_tutorial_ob(bars, s, k, d):
    """教程版 OB（smc_detect.py 的 OB 找根逻辑，逐行复现）。

    s = 被破摆动点 bar 下标，k = 破位根下标，d = +1 看涨 / -1 看跌。
    推动起点 m = (s, k) 内极值点（看涨取最低点、看跌取最高点，并列取靠后一根）。
    返回 (has_ob, origin_m, ob_bar_or_None)。
    """
    if d == 1:
        m = s + 1
        for j in range(s + 1, k):
            if bars[j]["l"] <= bars[m]["l"]:
                m = j
        opp = is_bear
    else:
        m = s + 1
        for j in range(s + 1, k):
            if bars[j]["h"] >= bars[m]["h"]:
                m = j
        opp = is_bull
    if opp(bars[m]):
        j = m
        while j + 1 < k and opp(bars[j + 1]):
            j += 1
    else:
        j = m - 1
        while j > s and not opp(bars[j]):
            j -= 1
        if j <= s:
            return False, m, None
    if j >= k:
        return False, m, None
    return True, m, j


def sweep_in_window(bars, swings, m, k, d):
    """窗口 (m, k) 内有没有同侧清扫。

    swings = [(bar_idx, kind, level, confirmed_idx)]（某 N 的摆动点表）。
    看涨 d=+1 只计扫摆动低（kind 'L'），看跌只计扫摆动高（kind 'H'）。
    某根 w（m < w < k）：影线越过某已确认摆动点（confirmed <= w）且
    收盘收回；或收盘越过后下一根（w+1 < k）收回。
    """
    kind = "L" if d == 1 else "H"
    levels = [(i, lv, cf) for (i, kd, lv, cf) in swings if kd == kind]
    for w in range(m + 1, k):
        bw, bn = bars[w], bars[w + 1] if w + 1 < k else None
        for (i, lv, cf) in levels:
            if cf > w or i >= w:
                continue
            if d == 1:
                if bw["l"] < lv and (bw["c"] >= lv or
                                     (bw["c"] < lv and bn is not None and bn["c"] >= lv)):
                    return True
            else:
                if bw["h"] > lv and (bw["c"] <= lv or
                                     (bw["c"] > lv and bn is not None and bn["c"] <= lv)):
                    return True
    return False


def fvg_in_range(bars, atr, ob_bar, k, d):
    """OB 根之后、破位根之前（含破位根）有没有同向 FVG（B 根下标 in (ob_bar, k]）。

    FVG 定义（smc_detect.py）：连续三根 A/B/C，B 为中间根；看涨 C 最低 >
    A 最高，宽度 = C 最低 - A 最高；看跌反过来。宽度 >= 0.3 x ATR，
    ATR 取 B 根前一根的教程程序 ATR（pre(b) = atr[b-1]）。
    返回 (has_fvg, relies_on_b_eq_k)：后者指阳性是否依赖 b == k 的边界情形。
    """
    for b in range(ob_bar + 1, k + 1):
        if b + 1 >= len(bars):
            continue
        a, c = b - 1, b + 1
        if d == 1:
            if bars[c]["l"] > bars[a]["h"]:
                width = bars[c]["l"] - bars[a]["h"]
            else:
                continue
        else:
            if bars[c]["h"] < bars[a]["l"]:
                width = bars[a]["l"] - bars[c]["h"]
            else:
                continue
        a_atr = atr[b - 1] if b > 0 else atr[0]
        if width >= FVG_MIN_ATR * a_atr:
            return True, (b == k)
    return False, False


def inducement_check(bars, swings, m, k, d):
    """诱导式检查（学习笔记方向 1 的写法）。

    最近一次内部回撤低/高点 = (m, k) 内最近的已确认摆动低（看涨）/
    摆动高（看跌），须在破位根收盘前已确认（confirmed <= k-1）。
    该点在 (m, k) 内被扫：影线刺破且收盘收回，或收盘跌破后下一根
    （w+1 < k）收回。扫荡根须晚于该摆动点本身（w > i）。
    返回 (has_inducement, has_internal_point)。
    """
    kind = "L" if d == 1 else "H"
    cands = [(i, lv, cf) for (i, kd, lv, cf) in swings
             if kd == kind and m < i < k and cf <= k - 1]
    if not cands:
        return False, False
    i, lv, cf = max(cands, key=lambda x: x[0])
    for w in range(i + 1, k):
        bw = bars[w]
        bn = bars[w + 1] if w + 1 < k else None
        if cf > w:
            continue
        if d == 1:
            if bw["l"] < lv and (bw["c"] >= lv or
                                 (bw["c"] < lv and bn is not None and bn["c"] >= lv)):
                return True, True
        else:
            if bw["h"] > lv and (bw["c"] <= lv or
                                 (bw["c"] > lv and bn is not None and bn["c"] <= lv)):
                return True, True
    return False, True


def audit_symbol(sym):
    bars = R11.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
    atr_det = detector_atr(bars)
    sh_level, sh_idx, sl_level, sl_idx = R11.confirmed_levels(bars, n=SWING_N_BREAK)
    swings3 = R11.swing_points(bars, n=SWING_N_SWEEP)
    swings5 = R11.swing_points(bars, n=SWING_N_BREAK)
    closes = [b["c"] for b in bars]
    breaks = []
    stats = Counter()
    for j in range(1, len(bars)):
        bos_dir = 0
        sh, sl = sh_level[j], sl_level[j]
        pc, c = closes[j - 1], closes[j]
        if sh is not None and pc <= sh < c:
            bos_dir = 1
        elif sl is not None and pc >= sl > c:
            bos_dir = -1
        if bos_dir == 0:
            continue
        d = bos_dir
        s = sh_idx[j] if d == 1 else sl_idx[j]
        stats["breaks"] += 1
        if d == 1:
            stats["breaks_up"] += 1
        else:
            stats["breaks_dn"] += 1
        has_ob, m, ob_bar = find_tutorial_ob(bars, s, j, d)
        if has_ob:
            stats["has_ob"] += 1
        sw3 = sweep_in_window(bars, swings3, m, j, d)
        if sw3:
            stats["has_sweep_n3"] += 1
        sw5 = sweep_in_window(bars, swings5, m, j, d)
        if sw5:
            stats["has_sweep_n5"] += 1
        if has_ob:
            has_fvg, b_eq_k = fvg_in_range(bars, atr_det, ob_bar, j, d)
            # 严格口径（诊断用）：FVG 的 C 根须在破位根收盘前已形成，即 B 根 <= k-1
            has_fvg_strict, _ = fvg_in_range(bars, atr_det, ob_bar, j - 1, d)
        else:
            has_fvg, b_eq_k = False, False
            has_fvg_strict = False
        if has_fvg:
            stats["has_fvg"] += 1
            if b_eq_k:
                stats["has_fvg_b_eq_k"] += 1
        if has_fvg_strict:
            stats["has_fvg_strict"] += 1
        # 辅助诊断：不依赖 OB 根、只看窗口 (m, k] 内有没有同向大 FVG
        has_fvg_any = False
        for b in range(m + 1, j + 1):
            if b + 1 >= len(bars):
                continue
            a, cc = b - 1, b + 1
            if d == 1 and bars[cc]["l"] > bars[a]["h"]:
                wdt = bars[cc]["l"] - bars[a]["h"]
            elif d == -1 and bars[cc]["h"] < bars[a]["l"]:
                wdt = bars[a]["l"] - bars[cc]["h"]
            else:
                continue
            a_atr = atr_det[b - 1] if b > 0 else atr_det[0]
            if wdt >= FVG_MIN_ATR * a_atr:
                has_fvg_any = True
                break
        if has_fvg_any:
            stats["has_fvg_any_window"] += 1
        if has_ob and sw3 and has_fvg:
            stats["three_conditions"] += 1
        if has_ob and sw3 and has_fvg_strict:
            stats["three_conditions_strict"] += 1
        if has_ob and sw5 and has_fvg:
            stats["three_conditions_n5sweep"] += 1
        ind5, internal5 = inducement_check(bars, swings5, m, j, d)
        if ind5:
            stats["has_inducement_n5"] += 1
        if not internal5:
            stats["no_internal_n5"] += 1
        ind3, internal3 = inducement_check(bars, swings3, m, j, d)
        if ind3:
            stats["has_inducement_n3"] += 1
        if not internal3:
            stats["no_internal_n3"] += 1
        breaks.append({"sym": sym, "j": j, "t": bars[j]["t"], "dir": d,
                       "broken_swing": s, "origin": m, "ob_bar": ob_bar,
                       "has_ob": has_ob, "sweep_n3": sw3, "sweep_n5": sw5,
                       "fvg": has_fvg, "three": bool(has_ob and sw3 and has_fvg),
                       "ind_n5": ind5, "internal_n5": internal5,
                       "ind_n3": ind3, "internal_n3": internal3})
    return stats, breaks


def main():
    # ---- 校验：复现的破位总数必须与第十二轮报告一致 ----
    with open(SUMMARY12) as f:
        s12 = json.load(f)
    expected = {}
    for r in s12:
        if r["split"] == "365d" and r["family"] == "S1":
            expected[r["symbol"]] = r["setup_stats"]["breaks"]
    all_stats, all_breaks = {}, []
    ok = True
    for sym in SYMBOLS:
        stats, breaks = audit_symbol(sym)
        all_stats[sym] = dict(stats)
        all_breaks.extend(breaks)
        exp = expected.get(sym)
        mark = "OK" if stats["breaks"] == exp else "MISMATCH"
        if stats["breaks"] != exp:
            ok = False
        print(f"[{mark}] {sym}: 复现破位 {stats['breaks']} 次（第十二轮报告 {exp} 次）")
    total = Counter()
    for sym in SYMBOLS:
        total.update(all_stats[sym])
    print(f"\n复现破位合计 {total['breaks']} 次（第十二轮 S1：4,191 次）"
          f"—— {'一致' if ok and total['breaks'] == 4191 else '不一致，先排查'}")
    tot = total["breaks"]

    def pct(x):
        return f"{x} ({100.0 * x / tot:.2f}%)" if tot else f"{x} (-%)"

    print("\n=== 第二部分汇总（8 币合计，1h，365 天，分母 = 4,191 次破位）===")
    print(f"破位总数：{tot}（看涨 {total['breaks_up']} / 看跌 {total['breaks_dn']}）")
    print(f"(1) 有教程版 OB：{pct(total['has_ob'])}")
    print(f"(2) 有同侧清扫（N=3）：{pct(total['has_sweep_n3'])}；"
          f"（N=5 敏感性）：{pct(total['has_sweep_n5'])}")
    print(f"(3) 有同向大 FVG（>=0.3xATR，OB 根之后）：{pct(total['has_fvg'])}"
          f"（其中依赖 b==破位根边界情形 {total['has_fvg_b_eq_k']} 次；"
          f"严格口径 C 根须在破位前形成：{pct(total['has_fvg_strict'])}）；"
          f"窗口内有大 FVG（不依赖 OB 根，辅助诊断）：{pct(total['has_fvg_any_window'])}")
    print(f"(4) 三条件同时满足（OB+清扫 N=3+FVG）：{pct(total['three_conditions'])}；"
          f"（严格 FVG 口径）：{pct(total['three_conditions_strict'])}；"
          f"（清扫用 N=5）：{pct(total['three_conditions_n5sweep'])}")
    print(f"(5) 有诱导（N=5 内部摆动点被扫）：{pct(total['has_inducement_n5'])}；"
          f"根本无内部回撤点（N=5）：{pct(total['no_internal_n5'])}")
    print(f"    有诱导（N=3 敏感性）：{pct(total['has_inducement_n3'])}；"
          f"根本无内部回撤点（N=3）：{pct(total['no_internal_n3'])}")
    out = {"method": {
        "breaks": "第十二轮 S1 破位复现：R11.confirmed_levels(n=5)，收盘破最近已确认摆动点，"
                  "与 gate_iter_round12.build_strict_setups 破位扫描逐行一致",
        "origin": "推动起点 m = (被破摆动点, 破位根) 内极值点，看涨取最低点、看跌取最高点，并列取靠后一根",
        "ob": "教程版 OB（smc_detect.py）：起点那根是反向 K 线（c<o 看涨 / c>o 看跌）就顺延连续反向 K 线到最后一根，"
              "不是反向就往前找最近的反向 K 线；只取实体；OB 根须早于破位根（j<k）",
        "sweep": "同侧清扫：窗口 (m, k) 内某根影线越过某已确认摆动点且收盘收回，或收盘越过后下一根（w+1<k）收回；"
                 "看涨只计扫摆动低，看跌只计扫摆动高；主口径 N=3，敏感性 N=5",
        "fvg": "同向 FVG：B 根下标 in (OB 根, 破位根]，三根 A/B/C，C 最低>A 最高为看涨；"
               "宽度 >= 0.3xATR，ATR 为 smc_detect.py 的 TR 14 根简单平均、取 B 根前一根；"
               "b==破位根时 C 根为破位根后一根（教程程序自身口径，单独计数）",
        "inducement": "最近一次内部回撤低/高点 = (m, k) 内最近的已确认摆动低（看涨）/摆动高（看跌），"
                      "须在破位根收盘前已确认；该点在 (m, k) 内被扫（影线刺破收盘收回，或收盘跌破后下一根收回）；"
                      "主口径 N=5（与破位同尺度），敏感性 N=3（学习笔记方向 1 的写法）",
        "atr_note": "FVG 宽度用的 ATR 是教程程序定义（TR 简单平均），不是第 11/12 轮的 Wilder ATR"},
        "per_symbol": all_stats,
        "total": dict(total),
        "n_breaks": tot,
        "verification": {"expected_breaks_per_symbol": expected,
                         "reproduced_total": tot, "match": bool(ok and tot == 4191)}}
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(f"\n汇总 JSON 已写入 {OUT_JSON}")
    print("复现提示：再跑一遍本脚本，JSON 的 md5 应不变。")


if __name__ == "__main__":
    main()
