#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十七轮：QM（卡西莫多）左肩 QML 回测（学习笔记方向 2）
=====================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（用户按顺序继续）：学习笔记方向 2。第十一轮 S1 只走到 QM 的
前半段（扫荡 + CHOCH 当根入场），QM 真正的入场是回测左肩 QML，
本轮第一次测“回到 QML 再做”这一步；同时第一次用结构止损。

定义出处（跑前定死，单组参数，不许用全样本挑）：
  教程：smc-ai-tutor skills/smc-learning/references/06-进阶概念与
  入场模型.md B1（QM 基础形态）+ 学习笔记 §3 方向 2 原文。
  看跌 QM：H → L → HH → LL。
    H：左肩 = 最近已确认摆动高（N=3 分形，确认于 i+3 根收盘时）。
    L：H 之后最近已确认摆动低。
    HH：扫高后回落——影线刺破 H 且收盘收回 H 下方（HH = 刺破极值），
        或收盘上破 H 后 8 根内收盘收回 H 下方（HH = 这段上破的最高价，
        8 根是本轮跑前定死的单组参数，照抄 S1 的 8 根窗口；8 根内不
        收回则视为真突破、该 QM 作废）。HH 必须是“扫高后回落”。
    LL：实体收盘跌破 L（= CHoCH），形成于 LL 收盘根。
    QML = 左肩 H 的水平线；入场区 = [QML, HH]，不要只盯一条线。
    回测：LL 出现后 24 根 1h 内，价格首次回到入场区（某根高点进入
    区间且收盘未穿过区间上沿）才进，方向做空；看涨版上下镜像。
    失效：回测前 1h 收盘穿过 HH（看跌）则 QM 失效；24 根内未回测
    作废；HH 到 QML 的距离 < 1xATR（触发根 ATR）则放弃（盈亏比不够）。
    24 根窗口、1xATR 宽度门槛均为跑前定死的单组参数（照抄笔记原文）。
  止损第一次用结构止损：止损放在 HH 上方（看跌）/ LL 极值下方（看涨）
    + 0.25xATR 缓冲（缓冲是本轮跑前定死的单组参数）；止盈 = 入场价
    ∓ 2×止损距离（用户要求的 1:2）。结构止损与固定 ATR 止损的区别
    见报告 §6：固定 ATR 止损只看波动幅度，结构止损看“分析被证伪的
    价位”（价格到了那里，QM 结构本身不成立）。
  Killzone 只作诊断、不作硬过滤（第十二轮教训：教程明说加密时段
  效应弱，只能参考；且第十二轮把它当硬过滤时它成了最狠的筛子）。

组合（4 个，全部跑前定死）：
  A 主臂 QM-1h-结构止损：1h 定结构 + 1h 回测入场（首次触及入场区，
    下一根 1h 开盘进），结构止损 + 0.25xATR 缓冲，止盈 2×止损距离。
    365d 1h，8 币。
  B 对照 1 S1 原版：第十一轮 S1 一字不变复用（N=2 摆动点、扫荡后
    8 根内 CHOCH 当根入场、固定 1xATR 止损 / 2xATR 止盈），用来判断
    “QML 回测入场本身”有没有增值。365d 1h，8 币。
  C 对照 2 QM-1h-固定 ATR：与 A 同一套 QM 信号（同一批回测触发），
    止损仍用固定 1xATR、止盈 2xATR，用来判断“结构止损本身”有没有
    增值。365d 1h，8 币。
  D 诊断臂 QM-15m-结构止损（笔记方向 2 原文版）：1h 定 QM 结构，
    15m 找触发——LL 之后 96 根 15m 内，价格先触及入场区、随后 15m
    出现小级别 CHoCH（收盘破最近已确认 15m 摆动低/高，N=3）才进，
    下一根 15m 开盘进；结构止损（15m ATR 的 0.25x 缓冲）。103d，
    8 币。15m 数据只有 103 天，所以 D 只是诊断臂，不与 A/C 同口径
    比较全期数字；它的作用是回答“加了 15m 确认之后数字变不变”。

与之前轮次的异同（先写在代码头，报告 §7 再展开）：
  A/C vs 第十一轮 S1：同为扫荡后反转，但 S1 在 CHOCH 当根入场（赌
    反转的起点），本轮等反转走完、价格回到左肩再入场（赌反转的回测）
    ——时点完全相反；S1 用 N=2 摆动点、固定 ATR 出场，本轮用 N=3
    摆动点、结构止损。S1 的信号 566 个里有多少能走到 QML 回测，
    本轮漏斗会直接数出来。
  A/C vs 第十二轮 S1/S2：同为“回踩再进”，但十二轮回踩的是 OB/FVG
    区间（破位后形成的订单区），本轮回踩的是左肩 QML（破位前就存在
    的结构位）；十二轮止损固定 1xATR，本轮第一次用结构止损。
  A/C vs 第十四轮 B-T1/B-T2：十四轮赌的是诱导验证的 BOS + 三条件
    OB + MSS 两步确认，本轮不要求诱导、不要求 OB、不要求 MSS——
    QM 的结构链本身就是确认（扫荡 + CHoCH + 回测三步走完才进）。
    两轮的共同点是“等确认再进”，不同点是确认的定义。
  A vs D：同一套 1h QM 结构，区别只在触发层（1h 首次触及即进 vs
    15m 触及 + CHoCH 确认）。D 是笔记原文版，A 是去掉 15m 确认的
    简化版（因为 15m 数据只有 103 天，主臂放 365d 必须去掉它）；
    两臂的差异直接回答“15m 确认”这个零件值多少钱。
  B2 快速回测 vs 延迟回测：只作事后分组诊断，不用于挑参数。快速 =
    回测前未出现更深的新摆动点（价格直接反弹回 QML）；延迟 = 回测
    前先出现更深的新摆动低/高（低位先横盘/下探一段才回来）。

通用口径（与前十六轮一致）：
  每笔保证金 10% 权益、1x；信号根收盘触发、下一根开盘成交；止损/
  止盈用盘中高低价触发（同根同时碰到先判止损）；单日 -2% 熔断；
  单笔最坏情况（止损距离 + 成本）> 1% 权益跳过；每天每币最多 2 笔；
  最多持 8 根 1h（A/B/C）/ 16 根 15m（D，= 4h，照抄第十二轮 S2）；
  当天收盘强制平仓，持仓不过夜；成本主口径 Taker（一轮名义 x 0.25%，
  taker 0.075% + 滑点 0.05%，双边）；资金费按实际费率计（08:00/
  16:00 结算点，前半段 2026-05-21 之前无数据按 0 计）。M1/M2 只做
  对照（第九轮同款）。
  入场价已越过结构止损（下一根开盘价跳过止损位）时跳过该笔——
  结构止损下这是必然会出现的情况，计入 skipped_gap。

前视防控（写死在代码里）：
  - 摆动点、扫荡、LL、回测触及、15m CHoCH 全部只用已收盘的根；
    摆动点须在确认根（bar i+3）收盘后才可用。
  - 入场永远是触发根的下一根开盘价。
  - D 的 15m 触发根须严格晚于 1h LL 收盘时刻（start t >= LL 收盘
    时刻），同收盘时刻的 15m 根不用；触及根与 CHoCH 根必须是不同根。

数据：
  1h：2025-11-16~2026-11-15，365 天，8 币各 8,761 根（与第十一至
    十六轮同一缓存，含末根 2026-11-16 00:00 半根，照抄前轮口径不
    特殊处理）；前半段 2025-11-16~2026-05-19（185 天）、后半段
    2026-05-20~2026-11-15（180 天）。
  15m：2026-08-06~2026-11-16，103 天，8 币各 9,888 根；前半段
    2026-08-06~09-25（51 天）、后半段 2026-09-26~11-16（52 天）。
  8 币：BTC / ETH / SOL / DOGE / LINK / XRP / BNB / ADA。
  全部复用本地缓存，不联网。各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

运行：python3 gate_iter_round17.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round17_summary.json
      + data/gate_iter_round17_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)

import gate_iter_round11 as r11

SYMBOLS = r11.SYMBOLS
START_EQUITY = r11.START_EQUITY
MARGIN_FRAC = r11.MARGIN_FRAC
ROUNDTRIP_COST = r11.ROUNDTRIP_COST
SPLIT_1H = r11.SPLIT_1H
SPLIT_15M = r11.SPLIT_15M
load_bars = r11.load_bars
load_funding = r11.load_funding
atr_wilder = r11.atr_wilder
confirmed_levels = r11.confirmed_levels
synthesize = r11.synthesize
group_days = r11.group_days
funding_cost_between = r11.funding_cost_between
maker_cost = r11.maker_cost
t_value = r11.t_value
max_dd = r11.max_dd
summarize = r11.summarize
build_s1_signals = r11.build_s1_signals
simulate_generic = r11.simulate_generic

# ---- 锁定的参数（跑前定死）----
SWING_N = 3            # 摆动点 N=3（抄识别程序默认，笔记方向 2 原文）
RETRACE_BARS = 24      # LL 后回测窗口（1h 根数，笔记原文）
EXCURSION_BARS = 8     # 收盘上破 shoulder 后收回的等待窗口（照抄 S1 的 8 根）
SL_BUFFER_ATR = 0.25   # 结构止损缓冲（xATR）
TP_MULT_STRUCT = 2.0   # 结构止损下止盈 = 2x 止损距离（用户要求 1:2）
MAX_HOLD_1H = 8
MAX_HOLD_15M = 16
MAX_PER_DAY = 2
T15_START = datetime(2026, 8, 6, tzinfo=timezone.utc)
T15_END = datetime(2026, 11, 16, tzinfo=timezone.utc)


def in_killzone(t):
    dt = datetime.fromtimestamp(t, timezone.utc)
    h = dt.hour + dt.minute / 60.0
    return (8.0 <= h < 11.0) or (13.0 <= h < 16.0)


# ----------------------------------------------------------------------
# QM 结构检测（1h，N=3，全部只用已收盘根）
# direction=-1 看跌：H(左肩) → L → HH(扫高后回落) → LL(收盘跌破 L)
# direction=+1 看涨：镜像（L → H → LL(扫低后回落) → HH(收盘上破 H)）
# ----------------------------------------------------------------------
def detect_qm_events_dir(bars, atr, n, direction):
    """返回 (events, stats)。
    events 每项：{dir, qml, extreme, ll_idx, ll_close_t, zone_lo, zone_hi,
                  anchor, atr_ll}。qml = 左肩水平线；extreme = 扫荡极值
    （HH 或 LL）；zone = [qml, extreme] 之间的入场区；anchor = 被破的
    摆动点（L 或 H）；ll_idx = LL/CHoCH 收盘根下标。"""
    sh_level, sh_idx, sl_level, sl_idx = confirmed_levels(bars, n)
    closes = [b["c"] for b in bars]
    events = []
    stats = Counter()
    consumed = set()  # 已消费的 (shoulder_bar, anchor_bar)，防同一对重复成 QM
    state = "idle"
    S = A = None
    s_bar = a_bar = -1
    EXT = None
    exc_ext = None
    exc_deadline = -1
    for j in range(1, len(bars)):
        b, c = bars[j], closes[j]
        sh, sl = sh_level[j], sl_level[j]
        shi, sli = sh_idx[j], sl_idx[j]
        if direction == -1:
            sh_lvl, sh_b, an_lvl, an_b = sh, shi, sl, sli
            pair_ok = (sh is not None and sl is not None and sli > shi)
        else:
            sh_lvl, sh_b, an_lvl, an_b = sl, sli, sh, shi
            pair_ok = (sh is not None and sl is not None and shi > sli)
        if state == "idle":
            if pair_ok and (sh_b, an_b) not in consumed:
                S, A, s_bar, a_bar = sh_lvl, an_lvl, sh_b, an_b
                state = "wait_sweep"
                stats["pairs"] += 1
        elif state == "wait_sweep":
            # anchor 加深：新确认的摆动点比原 anchor 更极端，更新锚点
            if an_lvl is not None and an_b > a_bar and (
                    (direction == -1 and an_lvl < A) or
                    (direction == 1 and an_lvl > A)):
                A, a_bar = an_lvl, an_b
            crossed = (c > S) if direction == -1 else (c < S)
            wicked = ((b["h"] > S and c < S) if direction == -1
                      else (b["l"] < S and c > S))
            broke_anchor = (c < A) if direction == -1 else (c > A)
            if crossed:
                exc_ext = b["h"] if direction == -1 else b["l"]
                exc_deadline = j + EXCURSION_BARS
                state = "above_s"
                stats["excursions"] += 1
            elif wicked:
                EXT = b["h"] if direction == -1 else b["l"]
                state = "wait_ll"
                stats["sweeps"] += 1
            elif broke_anchor:
                consumed.add((s_bar, a_bar))
                state = "idle"
                stats["invalid_early_break"] += 1
        elif state == "above_s":
            exc_ext = (max(exc_ext, b["h"]) if direction == -1
                       else min(exc_ext, b["l"]))
            back = (c < S) if direction == -1 else (c > S)
            broke_anchor = (c < A) if direction == -1 else (c > A)
            if back:
                EXT = exc_ext
                state = "wait_ll"
                stats["sweeps"] += 1
                stats["sweeps_close"] += 1
            elif j > exc_deadline or broke_anchor:
                consumed.add((s_bar, a_bar))
                state = "idle"
                stats["invalid_break" if j > exc_deadline
                      else "invalid_early_break"] += 1
        elif state == "wait_ll":
            if an_lvl is not None and an_b > a_bar and (
                    (direction == -1 and an_lvl < A) or
                    (direction == 1 and an_lvl > A)):
                A, a_bar = an_lvl, an_b
            over_ext = (c > EXT) if direction == -1 else (c < EXT)
            broke_anchor = (c < A) if direction == -1 else (c > A)
            if over_ext:
                consumed.add((s_bar, a_bar))
                state = "idle"
                stats["invalid_over_ext"] += 1
            elif broke_anchor:
                if direction == -1:
                    zone_lo, zone_hi = S, EXT
                else:
                    zone_lo, zone_hi = EXT, S
                events.append({"dir": direction, "qml": S, "extreme": EXT,
                               "ll_idx": j, "ll_close_t": b["t"] + 3600,
                               "zone_lo": zone_lo, "zone_hi": zone_hi,
                               "anchor": A, "atr_ll": atr[j]})
                consumed.add((s_bar, a_bar))
                state = "idle"
                stats["qm_formed"] += 1
    return events, stats


def detect_qm_events(bars, atr, n=SWING_N):
    """双向 QM 事件（看跌 + 看涨），按 ll_idx 时间顺序合并。"""
    ev_s, st_s = detect_qm_events_dir(bars, atr, n, -1)
    ev_l, st_l = detect_qm_events_dir(bars, atr, n, +1)
    events = sorted(ev_s + ev_l, key=lambda e: e["ll_idx"])
    stats = Counter()
    for k in set(list(st_s.keys()) + list(st_l.keys())):
        stats[k + "_short"] = st_s.get(k, 0)
        stats[k + "_long"] = st_l.get(k, 0)
        stats[k] = st_s.get(k, 0) + st_l.get(k, 0)
    stats["qm_formed_short"] = len(ev_s)
    stats["qm_formed_long"] = len(ev_l)
    return events, stats


# ----------------------------------------------------------------------
# 回测入场（1h）：LL 后 24 根内首次回到入场区
# ----------------------------------------------------------------------
def build_qm_signals_1h(bars, atr, events, structural=True):
    """返回 (signals, stats)。
    signals key=入场根 t，value={direction, atr, tag, qml, extreme,
    zone_width_atr, retest_type, [stop_abs]}。structural=True 时带
    stop_abs（HH/极值 + 0.25xATR 缓冲）；False 时只带 atr（对照 2
    用固定 1xATR/2xATR 出场）。"""
    sh_level, _, sl_level, _ = confirmed_levels(bars, SWING_N)
    sigs = {}
    stats = Counter()
    for ev in events:
        d = ev["dir"]
        ll = ev["ll_idx"]
        zone_lo, zone_hi = ev["zone_lo"], ev["zone_hi"]
        stats["qm_events"] += 1
        outcome = None
        for j in range(ll + 1, min(ll + RETRACE_BARS + 1, len(bars) - 1)):
            b = bars[j]
            c = b["c"]
            if (d == -1 and c > zone_hi) or (d == 1 and c < zone_lo):
                stats["invalidated"] += 1
                outcome = "invalidated"
                break
            if d == -1:
                touch = b["h"] >= zone_lo and c <= zone_hi
            else:
                touch = b["l"] <= zone_hi and c >= zone_lo
            if not touch:
                continue
            stats["triggered"] += 1
            if atr[j] is None:
                outcome = "no_atr"
                break
            zw = zone_hi - zone_lo
            if zw < 1.0 * atr[j]:
                stats["skipped_narrow"] += 1
                outcome = "narrow"
                break
            entry_t = bars[j + 1]["t"]
            if entry_t in sigs:
                stats["dup_entry"] += 1
                outcome = "dup"
                break
            # B2 诊断：回测前是否出现更深的新摆动点（延迟回测）
            if d == -1:
                late = sl_level[j] is not None and sl_level[j] < ev["anchor"]
            else:
                late = sh_level[j] is not None and sh_level[j] > ev["anchor"]
            sig = {"direction": d, "atr": atr[j],
                   "tag": f"QM{'+' if d == 1 else '-'}",
                   "qml": ev["qml"], "extreme": ev["extreme"],
                   "zone_width_atr": round(zw / atr[j], 2),
                   "retest_type": "late" if late else "quick",
                   "ll_idx": ll}
            if structural:
                buf = SL_BUFFER_ATR * atr[j]
                sig["stop_abs"] = (zone_hi + buf) if d == -1 else (zone_lo - buf)
            sigs[entry_t] = sig
            stats["signals"] += 1
            outcome = "signal"
            break
        if outcome is None:
            stats["expired"] += 1
    return sigs, stats


# ----------------------------------------------------------------------
# 回测入场（15m，诊断臂 D）：LL 之后 96 根 15m 内，先触及入场区，
# 随后 15m 出现小级别 CHoCH（收盘破最近已确认 15m 摆动低/高，N=3）
# 才进，下一根 15m 开盘进。结构止损（15m ATR 的 0.25x 缓冲）。
# ----------------------------------------------------------------------
def build_qm_signals_15m(bars1h, bars15, atr15, events):
    _, _, sl15, _ = confirmed_levels(bars15, SWING_N)
    sh15, _, _, _ = confirmed_levels(bars15, SWING_N)
    idx15_of_t = {b["t"]: i for i, b in enumerate(bars15)}
    sigs = {}
    stats = Counter()
    for ev in events:
        if not (int(T15_START.timestamp()) <= ev["ll_close_t"]
                < int(T15_END.timestamp())):
            continue
        stats["events_in_window"] += 1
        start = idx15_of_t.get(ev["ll_close_t"])
        if start is None:
            stats["no_start15"] += 1
            continue
        d = ev["dir"]
        zone_lo, zone_hi = ev["zone_lo"], ev["zone_hi"]
        touched = False
        outcome = None
        for k in range(start, min(start + 96, len(bars15) - 1)):
            b = bars15[k]
            c = b["c"]
            if (d == -1 and c > zone_hi) or (d == 1 and c < zone_lo):
                stats["invalidated"] += 1
                outcome = "invalidated"
                break
            if not touched:
                if d == -1:
                    touch = b["h"] >= zone_lo and c <= zone_hi
                else:
                    touch = b["l"] <= zone_hi and c >= zone_lo
                if touch:
                    touched = True
                    stats["touched"] += 1
                continue
            # 已触及：等 15m CHoCH（收盘破最近已确认摆动低/高）
            if d == -1:
                sl = sl15[k]
                choch = (sl is not None and bars15[k - 1]["c"] >= sl > c)
            else:
                sh = sh15[k]
                choch = (sh is not None and bars15[k - 1]["c"] <= sh < c)
            if not choch:
                continue
            stats["triggered"] += 1
            if atr15[k] is None:
                outcome = "no_atr"
                break
            zw = zone_hi - zone_lo
            if zw < 1.0 * atr15[k]:
                stats["skipped_narrow"] += 1
                outcome = "narrow"
                break
            entry_t = bars15[k + 1]["t"]
            if entry_t in sigs:
                stats["dup_entry"] += 1
                outcome = "dup"
                break
            buf = SL_BUFFER_ATR * atr15[k]
            sigs[entry_t] = {"direction": d, "atr": atr15[k],
                             "tag": f"QM15{'+' if d == 1 else '-'}",
                             "qml": ev["qml"], "extreme": ev["extreme"],
                             "zone_width_atr": round(zw / atr15[k], 2),
                             "retest_type": "15m-choch",
                             "stop_abs": (zone_hi + buf) if d == -1
                             else (zone_lo - buf)}
            stats["signals"] += 1
            outcome = "signal"
            break
        if outcome is None:
            stats["expired"] += 1
    return sigs, stats


# ----------------------------------------------------------------------
# 通用引擎（结构止损版）：simulate_generic 一字不变的口径，唯一区别是
# 信号可带 stop_abs（绝对止损价，结构止损），止盈 = 入场价 ± 2x止损
# 距离；无 stop_abs 时退回固定 1xATR/2xATR（对照 2 用）。
# ----------------------------------------------------------------------
def simulate_qm(symbol, bars, signals, funding, days_subset, max_per_day,
                max_hold, label, bars_per_day):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    skipped_gap = 0
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss")
                        exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit")
                        exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss")
                        exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit")
                        exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= max_hold - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if "stop_abs" in sig:
                    stop = sig["stop_abs"]
                    sl_dist = abs(stop - entry)
                    # 入场价已越过结构止损：跳过（结构止损下必然会出现）
                    if ((sig["direction"] == 1 and stop >= entry) or
                            (sig["direction"] == -1 and stop <= entry)):
                        skipped_gap += 1
                        continue
                    tp = entry + sig["direction"] * TP_MULT_STRUCT * sl_dist
                else:
                    sl_dist = a
                    stop = (entry - sl_dist if sig["direction"] == 1
                            else entry + sl_dist)
                    tp = (entry + 2.0 * a if sig["direction"] == 1
                          else entry - 2.0 * a)
                if notional * (sl_dist / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                pos = {"symbol": symbol, "variant": label,
                       "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "sl_dist": sl_dist,
                       "sl_dist_atr": round(sl_dist / a, 2) if a else None,
                       "qml": sig.get("qml"), "extreme": sig.get("extreme"),
                       "zone_width_atr": sig.get("zone_width_atr"),
                       "retest_type": sig.get("retest_type", ""),
                       "killzone": in_killzone(b["t"]),
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0,
                       "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": max_hold, "tag": sig.get("tag", "")}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days), skipped_gap


def main():
    print("盈利策略迭代 · 第十七轮：QM 左肩 QML 回测（学习笔记方向 2，全模拟）")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；"
          "时间戳对齐、零缺口。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    all_results, all_trades = [], []
    pooled = {}

    def record(res, trades_full, family, variant, gran, split_fn, setup_stats=None,
               extra=None):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        if setup_stats is not None:
            res["setup_stats"] = {k: (dict(v) if isinstance(v, Counter) else v)
                                  for k, v in setup_stats.items()}
        if extra:
            res.update(extra)
        all_results.append(res)
        if trades_full is not None:
            pooled.setdefault(family, [])
            for t in trades_full:
                pooled[family].append(t["pnl"] / START_EQUITY)
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def split_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def _f(v, fmt):
        return "None" if v is None else format(v, fmt)

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={_f(res['win_rate'], '.4f')} "
              f"盈亏比={_f(res['profit_factor'], '.2f')} 平均赢={res['avg_win_usdt']:+.0f} "
              f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={_f(res['t_taker'], '.2f')}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={_f(res['gross_per_trade_usdt'], '+.2f')} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={_f(res['avg_hold_min'], '.1f')}分钟 出场={res['reason_counts']}")

    def run_family_qm(family, label, bars_by_sym, signals_by_sym, funding_by_sym,
                      subsets, max_per_day, max_hold, bars_per_day, split_fn, gran,
                      setup_stats_by_sym=None):
        skipped_total = 0
        for sym in SYMBOLS:
            bars = bars_by_sym[sym]
            funding = funding_by_sym[sym]
            for wname, subset in subsets:
                trades, curve, ndays, sk = simulate_qm(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    max_per_day, max_hold, label, bars_per_day)
                skipped_total += sk if subset is None else 0
                res = summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                # 诊断：结构止损距离（xATR 中位数）、Killzone 内占比
                if trades:
                    sds = sorted(t["sl_dist_atr"] for t in trades
                                 if t.get("sl_dist_atr") is not None)
                    res["median_sl_dist_atr"] = round(
                        sds[len(sds) // 2], 2) if sds else None
                    kz = [t for t in trades if t.get("killzone")]
                    res["killzone_trades"] = len(kz)
                    res["killzone_taker_net_pct"] = round(
                        sum(t["pnl"] for t in kz) / START_EQUITY, 4)
                    rt = Counter(t.get("retest_type", "") for t in trades)
                    res["retest_type_counts"] = dict(rt)
                res["skipped_gap"] = sk
                record(res, trades if subset is None else None, family, label,
                       gran, split_fn,
                       setup_stats_by_sym.get(sym) if setup_stats_by_sym else None)
                show(res, sym, wname)
        return skipped_total

    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}

    # ================= QM 事件检测（1h，N=3）=================
    print("\n=== QM 事件检测（1h，N=3，8 币）===")
    qm_events, qm_stats = {}, {}
    for sym in SYMBOLS:
        qm_events[sym], qm_stats[sym] = detect_qm_events(data1h[sym][0], atr1h[sym])
    tot = Counter()
    for v in qm_stats.values():
        tot.update(v)
    print(f"[QM 形成] 8 币合计：左肩对 pairs={tot['pairs']} / 扫荡 "
          f"sweeps={tot['sweeps']}（其中收盘上破后收回 {tot['sweeps_close']}）/ "
          f"excursion={tot['excursions']} / QM 形成 qm_formed={tot['qm_formed']} "
          f"（空 {tot['qm_formed_short']} / 多 {tot['qm_formed_long']}）/ 作废："
          f"未扫先破 {tot['invalid_early_break']} / 真突破 {tot['invalid_break']} / "
          f"穿过极值 {tot['invalid_over_ext']}")

    # ================= A 主臂：QM-1h-结构止损 =================
    print("\n=== A 主臂：QM-1h-结构止损（365d 1h，8 币）===")
    sig_a, st_a = {}, {}
    for sym in SYMBOLS:
        sig_a[sym], st_a[sym] = build_qm_signals_1h(
            data1h[sym][0], atr1h[sym], qm_events[sym], structural=True)
    tot_a = Counter()
    for v in st_a.values():
        tot_a.update(v)
    print(f"[A] 回测漏斗（8 币合计）：QM 事件 {tot_a['qm_events']} / 触发 "
          f"{tot_a['triggered']} / 信号 {tot_a['signals']} / 作废：失效 "
          f"{tot_a['invalidated']} / 过期 {tot_a['expired']} / 区间太窄 "
          f"{tot_a['skipped_narrow']} / 重复入场 {tot_a['dup_entry']}")
    run_family_qm("QM-A", "R17-QM-A", {s: data1h[s][0] for s in SYMBOLS}, sig_a,
                  {s: data1h[s][1] for s in SYMBOLS},
                  [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
                  MAX_PER_DAY, MAX_HOLD_1H, 24, split_1h, "1h",
                  setup_stats_by_sym=st_a)

    # ================= C 对照 2：QM-1h-固定 ATR =================
    print("\n=== C 对照 2：QM-1h-固定 ATR（365d 1h，8 币）===")
    sig_c, st_c = {}, {}
    for sym in SYMBOLS:
        sig_c[sym], st_c[sym] = build_qm_signals_1h(
            data1h[sym][0], atr1h[sym], qm_events[sym], structural=False)
    tot_c = Counter()
    for v in st_c.values():
        tot_c.update(v)
    print(f"[C] 回测漏斗（8 币合计）：QM 事件 {tot_c['qm_events']} / 触发 "
          f"{tot_c['triggered']} / 信号 {tot_c['signals']} / 作废：失效 "
          f"{tot_c['invalidated']} / 过期 {tot_c['expired']} / 区间太窄 "
          f"{tot_c['skipped_narrow']} / 重复入场 {tot_c['dup_entry']}")
    run_family_qm("QM-C", "R17-QM-C", {s: data1h[s][0] for s in SYMBOLS}, sig_c,
                  {s: data1h[s][1] for s in SYMBOLS},
                  [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
                  MAX_PER_DAY, MAX_HOLD_1H, 24, split_1h, "1h",
                  setup_stats_by_sym=st_c)

    # ================= B 对照 1：S1 原版（一字不变复用）=================
    print("\n=== B 对照 1：S1 原版（第十一轮一字不变，365d 1h，8 币）===")
    sig_b, st_b = {}, {}
    for sym in SYMBOLS:
        sig_b[sym], st_b[sym] = build_s1_signals(data1h[sym][0], atr1h[sym],
                                                 use_sweep=True)
    print(f"[B/S1] setup 统计（8 币合计）：扫荡 "
          f"{sum(v['sweeps'] for v in st_b.values())} 次 / BOS "
          f"{sum(v['bos'] for v in st_b.values())} 次 / CHOCH "
          f"{sum(v['choch'] for v in st_b.values())} 次 / 信号 "
          f"{sum(v['signals'] for v in st_b.values())} 个 "
          f"（作废：过期 {sum(v['armed_expired'] for v in st_b.values())} / "
          f"证伪 {sum(v['armed_invalidated'] for v in st_b.values())}）")
    for sym in SYMBOLS:
        bars = data1h[sym][0]
        funding = data1h[sym][1]
        for wname, subset in [("365d", None), ("前185d", front_1h),
                              ("后180d", back_1h)]:
            trades, curve, ndays = simulate_generic(
                sym, bars, sig_b[sym], funding, subset,
                MAX_PER_DAY, MAX_HOLD_1H, "R17-S1", 24)
            res = summarize(sym, trades, curve, "R17-S1", len(sig_b[sym]))
            res["split"] = wname
            res["days"] = ndays
            if trades:
                kz = [t for t in trades if in_killzone(t["entry_t"])]
                res["killzone_trades"] = len(kz)
                res["killzone_taker_net_pct"] = round(
                    sum(t["pnl"] for t in kz) / START_EQUITY, 4)
            record(res, trades if subset is None else None, "S1-B", "R17-S1",
                   "1h", split_1h, st_b[sym])
            show(res, sym, wname)

    # ================= D 诊断臂：QM-15m-结构止损 =================
    print("\n=== D 诊断臂：QM-15m-结构止损（1h 结构 + 15m CHoCH 确认，103d，8 币）===")
    sig_d, st_d = {}, {}
    for sym in SYMBOLS:
        sig_d[sym], st_d[sym] = build_qm_signals_15m(
            data1h[sym][0], data15[sym][0], atr15[sym], qm_events[sym])
    tot_d = Counter()
    for v in st_d.values():
        tot_d.update(v)
    print(f"[D] 15m 触发漏斗（8 币合计）：窗口内 QM 事件 "
          f"{tot_d['events_in_window']} / 触及 {tot_d['touched']} / CHoCH 触发 "
          f"{tot_d['triggered']} / 信号 {tot_d['signals']} / 作废：失效 "
          f"{tot_d['invalidated']} / 过期 {tot_d['expired']} / 区间太窄 "
          f"{tot_d['skipped_narrow']} / 重复入场 {tot_d['dup_entry']}")
    run_family_qm("QM-D", "R17-QM-D", {s: data15[s][0] for s in SYMBOLS}, sig_d,
                  {s: data15[s][1] for s in SYMBOLS},
                  [("103d", None), ("前51d", front_15), ("后52d", back_15)],
                  MAX_PER_DAY, MAX_HOLD_15M, 96, split_15, "15m",
                  setup_stats_by_sym=st_d)

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, wnames) in [
            ("QM-A", "1h", ["365d", "前185d", "后180d"]),
            ("QM-C", "1h", ["365d", "前185d", "后180d"]),
            ("S1-B", "1h", ["365d", "前185d", "后180d"]),
            ("QM-D", "15m", ["103d", "前51d", "后52d"])]:
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["split"] == wname]
            n_tr = sum(r["trades"] for r in rs)
            avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
            avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
            avg_g = sum(r["gross_usdt"] for r in rs)
            avg_c = sum(r["taker_cost_sum"] for r in rs)
            print(f"[{fam} {gran} {wname}] 币均 Taker {avg_t*100:+.2f}% | "
                  f"M2 {avg_m2*100:+.2f}% | 笔数 {n_tr} | "
                  f"毛利合计 {avg_g:+.0f} | 成本合计 {avg_c:+.0f}")

    # ---- pooled t（全期逐笔，Taker）----
    print("\n=== Pooled t（全期逐笔，Taker，1x）===")
    for fam in ["QM-A", "QM-C", "S1-B", "QM-D"]:
        pnls = pooled.get(fam, [])
        print(f"[{fam}] n={len(pnls)} pooled t={t_value(pnls)}")

    # ---- 写文件 ----
    out_sum = os.path.join(DATA_DIR, "gate_iter_round17_summary.json")
    out_tr = os.path.join(DATA_DIR, "gate_iter_round17_trades.csv")
    with open(out_sum, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    if all_trades:
        keys = []
        for t in all_trades:
            for k in t.keys():
                if k not in keys:
                    keys.append(k)
        with open(out_tr, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(all_trades)
    print(f"\n写出：{out_sum}（{len(all_results)} 条）")
    print(f"写出：{out_tr}（{len(all_trades)} 笔）")


if __name__ == "__main__":
    main()
