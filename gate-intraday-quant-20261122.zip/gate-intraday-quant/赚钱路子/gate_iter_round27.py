#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十七轮：新发明方向——日开盘区间突破（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

问题：突破当天 00:00-01:00（日开盘区间）有没有延续性？
加密货币没有收盘，日线开盘 00:00 UTC 是一个自然锚点（也是资金费
结算点之一）。第十轮 M3 测的是 4h 开盘区间 + EMA 确认，第二十三轮
测的是日内时段开盘根自身方向，但“日 1h 开盘区间”还没有单独测过。

跑前写死的规则（单组参数，不许用全样本挑）：
  主臂 MAIN：日开盘区间 = 每天 00:00 UTC 第一根 1h K 线的高低点。
    随后价格以 1h 收盘价上破区间高点则做多、下破区间低点则做空，
    入场为触发根下一根 1h 开盘价；止损 1xATR、止盈 2xATR（用户要求
    的 1:2）；当天 23:00 强制平仓；每天每币最多 1 笔（先破哪边做
    哪边，破了就不再反向）。
  对照 1 CTRL1：同一规则但区间取 00:00-04:00 前 4 根 1h 的高低点
    （即 M3 的区间定义、去掉 EMA 确认），判断区间长度有没有影响。
  对照 2 CTRL2：反向——上破做空、下破做多，判断方向是延续还是反转。
  对照 3 CTRL3：同一规则但用 15m 粒度执行（区间仍为 00:00-01:00
    的 1h 高低；扫描每根 15m 收盘价破位，入场为触发根下一根 15m
    开盘价；ATR 用 15m ATR），判断粒度有没有影响。
    注：若触发仍用 1h 收盘判定，CTRL3 与主臂在重叠窗口上将完全
    相同、对照失去意义，因此“15m 粒度执行”按扫描 15m 收盘破位
    执行——这是本臂唯一合理的读法，跑前写死于此。
  通用口径（与前轮一致）：ATR 为 14 周期 Wilder ATR（执行粒度），
    只用触发根及之前已收盘的根；同根同时碰止损和止盈先判止损；
    入场根本身不判止损/止盈（前轮同款约定）；单日 -2% 熔断保留在
    引擎里（与前轮同款），但每天最多 1 笔、单笔止损亏损约 0.1-0.3%
    权益，熔断理论上触发不了，跑后如实报告触发数；
    成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
    双边）；M1/M2 对照同第七/九/二十轮；资金费按实际费率计
    （08:00/16:00 结算点，2026-05-21 之前无数据按 0 计）。
    每笔名义 = 入场时权益 x 10%（约 10,000 USDT，1x）。

与前轮的逐项区别（跑前写死，报告里逐项写清，不许事后 reinterpret）：
  vs 第十轮 M3：M3 是 4h 开盘区间（00:00-04:00 四根 1h 的高低点）
    + 1h 收盘首次破位 + 1h EMA20 确认，信号窗口 04:00-20:00，
    最多持 8 根、每天每币最多 2 笔；本轮主臂是日 1h 区间
    （00:00-01:00 一根 1h 的高低点）+ 收盘破位直接入场，不加任何
    确认（不加 EMA、不加趋势、不加振幅过滤），无 max_hold、无信号
    窗口上限（除 23:00 强制平仓外），每天每币最多 1 笔。
    本轮 CTRL1 = M3 的区间定义去掉 EMA 确认、再把每天上限从 2 笔
    收紧到 1 笔、去掉 20:00 窗口上限与 8 根 max_hold，是 M3c
    （第十轮 M3 的无确认对照）的近似复刻、不是一字复刻，数字只能
    定性对照、不能要求相等（见复核）。
  vs 第二十三轮：第二十三轮是日内时段开盘根（09:00/15:00 等整点
    那根 15m/1h K 线自身的收盘方向），信号源是开盘根、没有区间
    概念；本轮是日线开盘区间（00:00-01:00 的高低区间），信号源是
    价格对区间的收盘破位。两个轮次共享的只有“开盘”二字，信号、
    笔数、毛利数字没有任何可比口径上的相等关系。

数据（复用本地缓存，不联网）：
  1h：2025-11-16~2026-11-15，365 个完整日，8 币各 8,761 根（含末根
    2026-11-16 00:00 未走完半根，见下）；前半段 2025-11-16~2026-05-19
    （185 天）、后半段 2026-05-20~2026-11-15（180 天）。
  15m：2026-08-06~2026-11-16，103 个完整日，8 币各 9,888 根；
    前半段 2026-08-06~09-25（51 天）、后半段 2026-09-26~11-16（52 天）。
  末根半根处理（沿用第十五轮）：缓存 1h 的末根 2026-11-16 00:00 是
    取数时未走完的半根（o=h=l=c、v=0），排除该根，改用 15m 合成的
    已完成根；合成前校验重叠段与缓存 1h 一致（半根除外）。主臂/
    对照 1/2 只用 365 个完整日，不涉及该根；对照 3 的 2026-11-16
    当天区间用合成根（该日 15m 完整 96 根，合成 00:00 根已完成）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) 脚本跑两遍，summary 与 trades 的 md5 两次运行完全一致。
  (b) 主臂首笔交易人工核对触发链、入场价、止损/止盈、PnL 全对上 CSV。
  (c) 漏斗算术自洽：每天区间数 → 突破数 → 执行数；
      天数 = 无突破天数 + ATR 缺失天数 + 无同日下一根天数 + 执行天数。
  (d) 对照 1 与第十轮 M3c（-11.62%，3,404 笔）定性对照：同为 4h
      区间无确认突破，量级应在同一档；差异只应来自每天上限 2→1、
      窗口与 max_hold 的去掉——若量级差出一个数量级，先查引擎。
  (e) 1h 合成校验：重叠段合成 1h vs 缓存 1h 最大相对误差 < 1e-9。

运行：python3 gate_iter_round27.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round27_summary.json
      + data/gate_iter_round27_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]

# ---- 预注册、跑前写死：单组参数，不许用全样本挑 ----
TP_MULT = 2.0            # 止盈 2xATR（用户要求的 1:2）
SL_MULT = 1.0            # 止损 1xATR
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)    # 前半段止于 05-19
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)   # 前半段止于 09-25

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def synthesize(bars, per_block, block_secs):
    """把小周期根按时间戳聚合成大周期根；只保留满 per_block 根的块。
    块起始 = t - (t % block_secs)，与 UTC 边界对齐。（第十一轮原函数）"""
    blocks = {}
    for b in bars:
        start = b["t"] - (b["t"] % block_secs)
        blocks.setdefault(start, []).append(b)
    out = []
    for start in sorted(blocks):
        grp = sorted(blocks[start], key=lambda x: x["t"])
        if len(grp) != per_block:
            continue
        out.append({"t": start, "o": grp[0]["o"], "h": max(g["h"] for g in grp),
                    "l": min(g["l"] for g in grp), "c": grp[-1]["c"],
                    "v": sum(g["v"] for g in grp),
                    "sum": sum(g["sum"] for g in grp)})
    return out


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def build_1h_combined(sym):
    """缓存 1h 去掉末根半根 + 15m 合成的 11-16 当天 24 根；校验重叠段。
    只用于对照 3 的区间（2026-11-16 当天区间）；主臂/对照 1/2 不用它。"""
    cached = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
    bars15 = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
    synth = synthesize(bars15, 4, 3600)
    cache_by_t = {b["t"]: b for b in cached}
    last_t = cached[-1]["t"]
    max_rel_err = 0.0
    for b in synth:
        if b["t"] in cache_by_t and b["t"] != last_t:
            c = cache_by_t[b["t"]]
            for k in ("o", "h", "l", "c"):
                denom = abs(c[k]) if c[k] != 0 else 1.0
                max_rel_err = max(max_rel_err, abs(b[k] - c[k]) / denom)
    extra = [b for b in synth if b["t"] >= last_t]
    assert len(extra) == 24, f"{sym} 合成 1h 补 11-16 应为 24 根，实际 {len(extra)}"
    assert extra[0]["t"] == last_t and extra[-1]["t"] == last_t + 23 * 3600
    combined = cached[:-1] + extra
    assert all(combined[i]["t"] < combined[i + 1]["t"]
               for i in range(len(combined) - 1))
    return combined, max_rel_err


# ----------------------------------------------------------------------
# 日开盘区间突破信号：每天最多 1 个信号（先破哪边做哪边）。
#   or_bars: 构成区间的日内 1h 根数（MAIN/CTRL2/CTRL3=1，CTRL1=4）。
#   scan_bars: 执行粒度当日全部根；or_end_idx: 区间最后一根在当日序列
#     里的下标，扫描从下一根开始；触发根 = 首根收盘价严格越出区间。
#   ATR 缺失处理（只影响首日热身）：触发根 ATR 为 None 时，该次破位
#     不计为信号，继续向后找首根 ATR 可用的破位根；若全天都没有，
#     记为 atr_skip 天（不算无突破天）。
#   触发根若是当日最后一根（无同日下一根可入场），信号作废，记为
#     no_sameday 天。
# ----------------------------------------------------------------------
def build_daily_orb_1h(day_bars, atr_by_gi, gi_of_t, or_bars, reverse=False):
    or_hi = max(b["h"] for b in day_bars[:or_bars])
    or_lo = min(b["l"] for b in day_bars[:or_bars])
    atr_skip = False
    for i in range(or_bars, len(day_bars)):
        b = day_bars[i]
        if b["c"] > or_hi:
            direction = -1 if reverse else 1
        elif b["c"] < or_lo:
            direction = 1 if reverse else -1
        else:
            continue
        a = atr_by_gi[gi_of_t[b["t"]]]
        if a is None:
            atr_skip = True
            continue
        if i + 1 >= len(day_bars):
            return None, "no_sameday", or_hi, or_lo
        entry_bar = day_bars[i + 1]
        sig = {"direction": direction, "atr": a, "sl_mult": SL_MULT,
               "tp_mult": TP_MULT, "signal_t": b["t"],
               "signal_o": b["o"], "signal_c": b["c"],
               "or_hi": or_hi, "or_lo": or_lo, "or_bars": or_bars,
               "entry_t": entry_bar["t"]}
        return sig, "signal", or_hi, or_lo
    return None, ("atr_skip" if atr_skip else "no_break"), or_hi, or_lo


def build_daily_orb_15m(day_bars15, atr15_by_gi, gi15_of_t,
                        or_hi, or_lo, reverse=False):
    """day_bars15: 当日 96 根 15m；or_hi/or_lo: 当日 1h 00:00 根高低。
    扫描从 01:00 根（下标 4）开始：区间在 01:00 收盘时才完整。"""
    atr_skip = False
    for i in range(4, len(day_bars15)):
        b = day_bars15[i]
        if b["c"] > or_hi:
            direction = -1 if reverse else 1
        elif b["c"] < or_lo:
            direction = 1 if reverse else -1
        else:
            continue
        a = atr15_by_gi[gi15_of_t[b["t"]]]
        if a is None:
            atr_skip = True
            continue
        if i + 1 >= len(day_bars15):
            return None, "no_sameday", or_hi, or_lo
        entry_bar = day_bars15[i + 1]
        sig = {"direction": direction, "atr": a, "sl_mult": SL_MULT,
               "tp_mult": TP_MULT, "signal_t": b["t"],
               "signal_o": b["o"], "signal_c": b["c"],
               "or_hi": or_hi, "or_lo": or_lo, "or_bars": 1,
               "entry_t": entry_bar["t"]}
        return sig, "signal", or_hi, or_lo
    return None, ("atr_skip" if atr_skip else "no_break"), or_hi, or_lo


def simulate_daily(symbol, bars, signals, funding, days_subset, label,
                   bars_per_day, gran):
    """signals: {entry_t: sig}（全窗口）。days_subset: None=全窗口，否则
    只模拟该子集的天。每天最多 1 笔（信号本身已保证）。返回
    (trades, curve, ndays, skipped)。"""
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    skipped = Counter()
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            # 15m 版 23:00 强制平仓：在 23:00 根开盘价平仓（先于止损/止盈判断）
            if pos is not None and gran == "15m" and dt.hour == 23 and dt.minute == 0:
                close_trade(pos, b["t"], b["o"], "eod")
                pos = None
                continue
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None:
                if day_stopped:
                    continue
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    skipped["circuit"] += 1
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "signal_t": sig["signal_t"], "signal_o": sig["signal_o"],
                       "signal_c": sig["signal_c"],
                       "or_hi": sig["or_hi"], "or_lo": sig["or_lo"],
                       "entry_t": b["t"], "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
    # 收尾：当日收盘仍持仓则在最后一根收盘价平仓（1h 版；15m 版已在 23:00 开盘平仓）
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days), skipped


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "t_gross": t_value([(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def main():
    print("盈利策略迭代 · 第二十七轮：日开盘区间突破（全模拟）")
    print("主臂 MAIN 日 1h 区间（00:00-01:00）收盘破位直接入场；对照 1：4h 区间；对照 2：反向；对照 3：15m 执行。")
    print("止损 1xATR / 止盈 2xATR；每天每币最多 1 笔；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15, data1h_comb = {}, {}, {}
    max_rel_err_all = 0.0
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
        combined, mre = build_1h_combined(sym)
        data1h_comb[sym] = combined
        max_rel_err_all = max(max_rel_err_all, mre)
        assert len(combined) == 8784, f"{sym} 合成后 1h 应为 8784 根，实际 {len(combined)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print(f"数据校验通过：8 币各 8,761 根 1h / 365 个完整日；各 9,888 根 15m / 103 个完整日；时间戳对齐、零缺口。")
    print(f"1h 合成校验：重叠段合成 1h vs 缓存 1h 最大相对误差 {max_rel_err_all:.2e}（半根除外）；合并后每币 8,784 根。")
    assert max_rel_err_all < 1e-9

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- 信号生成：每臂每币每天最多 1 个信号 ----
    # sigs[(arm, gran, sym)] = {entry_t: sig}；outcomes[(arm, gran, sym)] = {day: outcome}
    sigs, outcomes = {}, {}
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    gi1h = {s: {b["t"]: i for i, b in enumerate(data1h[s][0])} for s in SYMBOLS}
    gi15 = {s: {b["t"]: i for i, b in enumerate(data15[s][0])} for s in SYMBOLS}
    # 1h 执行臂：MAIN(1 根区间)、CTRL1(4 根区间)、CTRL2(1 根区间，反向)
    for arm, or_bars, reverse in (("MAIN", 1, False), ("CTRL1", 4, False),
                                  ("CTRL2", 1, True)):
        for sym in SYMBOLS:
            bars, _ = data1h[sym]
            days = group_days(bars, 24)
            sd, oc = {}, {}
            for day, db in days.items():
                sig, outcome, _, _ = build_daily_orb_1h(db, atr1h[sym], gi1h[sym], or_bars, reverse)
                oc[day] = outcome
                if sig is not None:
                    sd[sig["entry_t"]] = sig
            sigs[(arm, "1h", sym)] = sd
            outcomes[(arm, "1h", sym)] = oc
    # 15m 执行臂 CTRL3：区间来自 1h 00:00 根（合成 1h，含 11-16）
    for sym in SYMBOLS:
        bars15, _ = data15[sym]
        days15 = group_days(bars15, 96)
        comb_by_t = {b["t"]: b for b in data1h_comb[sym]}
        sd, oc = {}, {}
        for day, db15 in days15.items():
            or_t = int(datetime(day.year, day.month, day.day, tzinfo=timezone.utc).timestamp())
            or_bar = comb_by_t[or_t]
            sig, outcome, _, _ = build_daily_orb_15m(
                db15, atr15[sym], gi15[sym], or_bar["h"], or_bar["l"], reverse=False)
            oc[day] = outcome
            if sig is not None:
                sd[sig["entry_t"]] = sig
        sigs[("CTRL3", "15m", sym)] = sd
        outcomes[("CTRL3", "15m", sym)] = oc
    for arm, gran in (("MAIN", "1h"), ("CTRL1", "1h"), ("CTRL2", "1h"), ("CTRL3", "15m")):
        tot_sig = sum(len(sigs[(arm, gran, s)]) for s in SYMBOLS)
        tot_days = sum(len(outcomes[(arm, gran, s)]) for s in SYMBOLS)
        cnt = Counter()
        for s in SYMBOLS:
            cnt.update(outcomes[(arm, gran, s)].values())
        br = tot_sig / tot_days if tot_days else 0
        print(f"[{arm}-{gran}] 天数 {tot_days}：信号 {tot_sig}（突破率 {br*100:.1f}%）| "
              f"无突破 {cnt['no_break']} / ATR 缺失 {cnt['atr_skip']} / "
              f"无同日下一根 {cnt['no_sameday']}。")

    ARMS = [
        ("MAIN", "ORB-day-1h", "1h", data1h, 24,
         [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
        ("CTRL1", "ORB-day-4h", "1h", data1h, 24,
         [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
        ("CTRL2", "ORB-day-1h-rev", "1h", data1h, 24,
         [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
        ("CTRL3", "ORB-day-1h-15m", "15m", data15, 96,
         [("103d", None), ("前51d", front_15), ("后52d", back_15)],
         lambda et: "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"),
    ]

    all_results, all_trades = [], []
    funnel_exec = {}
    for arm, label, gran, data, bpd, windows, split_fn in ARMS:
        print(f"\n=== {arm} {label} · {gran}（TP {TP_MULT}，SL {SL_MULT}，每天每币最多 1 笔）===")
        for sym in SYMBOLS:
            sig_dict = sigs[(arm, gran, sym)]
            for wname, subset in windows:
                bars, funding = data[sym]
                trades, curve, ndays, skipped = simulate_daily(
                    sym, bars, sig_dict, funding, subset, label, bpd, gran)
                # 该窗口内的漏斗（按天聚合 outcome）
                oc = outcomes[(arm, gran, sym)]
                oc_days = oc if subset is None else {d: o for d, o in oc.items() if d in subset}
                fc = Counter(oc_days.values())
                res = summarize(sym, trades, curve, label, len(sig_dict))
                res["arm"] = arm
                res["variant"] = label
                res["family"] = "ORB-day"
                res["tp_mult"] = TP_MULT
                res["granularity"] = gran
                res["split"] = wname
                res["days"] = ndays
                res["days_breakout"] = fc["signal"] + fc["no_sameday"]
                res["days_no_break"] = fc["no_break"]
                res["days_atr_skip"] = fc["atr_skip"]
                res["days_no_sameday"] = fc["no_sameday"]
                res["signals_pass"] = fc["signal"]
                res["breakout_rate"] = round((fc["signal"] + fc["no_sameday"]) / ndays, 4) if ndays else None
                res["signal_pass_rate"] = res["breakout_rate"]
                res["skipped_circuit"] = dict(skipped).get("circuit", 0)
                all_results.append(res)
                if wname in ("365d", "103d"):
                    funnel_exec[(arm, gran, sym)] = len(trades)
                    for t in trades:
                        t2 = dict(t)
                        t2["arm"] = arm
                        t2["variant"] = label
                        t2["family"] = "ORB-day"
                        t2["tp_mult"] = TP_MULT
                        t2["granularity"] = gran
                        t2["split"] = split_fn(t["entry_t"])
                        t2["entry_hour_utc"] = datetime.fromtimestamp(t["entry_t"], timezone.utc).hour
                        all_trades.append(t2)
                print(f"[{arm} {gran} {sym} {wname}] n={res['trades']} "
                      f"信号 {fc['signal']} 突破率={res['breakout_rate']*100:.1f}% "
                      f"胜率={res['win_rate']} 盈亏比={res['profit_factor']} "
                      f"Taker {res['taker_net_pct']*100:+.2f}% "
                      f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                      f"M1 {res['m1_net_pct']*100:+.2f}% M2 {res['m2_net_pct']*100:+.2f}% "
                      f"毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                      f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label, gran, data, bpd, windows, _ in ARMS:
        for wname, _ in windows:
            rs = [r for r in all_results if r["arm"] == arm
                  and r["granularity"] == gran and r["split"] == wname]
            gt = sum(r["gross_usdt"] for r in rs)
            ct = sum(r["taker_cost_sum"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            nd = sum(r["days"] for r in rs)
            nbr = sum(r["days_breakout"] for r in rs)
            wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
            wr_s = f"{wr:.3f}" if wr is not None else "—"
            gp = f"{gt/nt:+.2f}" if nt else "—"
            print(f"  {arm} {gran} {wname}：Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M1 平均 {sum(r['m1_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                  f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                  f"每笔毛利 {gp} USDT 胜率 {wr_s} | "
                  f"突破率 {nbr/nd*100:.1f}%（{nbr}/{nd} 天）")

    # ---- 漏斗校验（全期）：天数 = 无突破 + ATR 缺失 + 无同日下一根 + 执行 ----
    print("\n=== 漏斗校验（全期）===")
    for arm, label, gran, data, bpd, windows, _ in ARMS:
        full = windows[0][0]
        rs = [r for r in all_results if r["arm"] == arm
              and r["granularity"] == gran and r["split"] == full]
        nd = sum(r["days"] for r in rs)
        nb = sum(r["days_no_break"] for r in rs)
        na = sum(r["days_atr_skip"] for r in rs)
        ns = sum(r["days_no_sameday"] for r in rs)
        ne = sum(r["trades"] for r in rs)
        ncap = sum(r["skipped_circuit"] for r in rs)
        print(f"  {arm} {gran}：天数 {nd} = 无突破 {nb} + ATR 缺失 {na} + "
              f"无同日下一根 {ns} + 执行 {ne}（和 {nb+na+ns+ne}，"
              f"熔断跳过 {ncap}）→ {'✓ 自洽' if nd == nb+na+ns+ne else '✗ 不自洽！'}")

    # ---- pooled t（全期明细，Taker / 毛利 / M1）----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for arm, label, gran, data, bpd, windows, _ in ARMS:
        full = windows[0][0]
        sub = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
        for wname, _ in windows:
            s2 = [t for t in sub if wname == full or t["split"] == wname]
            vt = [t["pnl"] / START_EQUITY for t in s2]
            vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in s2]
            vm = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
            print(f"  {arm} {gran} {wname}：n={len(s2)} "
                  f"pooled t(Taker)={t_value(vt)} pooled t(毛利)={t_value(vg)} "
                  f"pooled t(M1)={t_value(vm)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    verdict = {}
    for arm, label, gran, data, bpd, windows, _ in ARMS:
        wnames = [w for w, _ in windows]
        row = {}
        for wname in wnames:
            rs = [r for r in all_results if r["arm"] == arm
                  and r["granularity"] == gran and r["split"] == wname]
            row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
        good = row[wnames[1]] > 0 and row[wnames[2]] > 0 and row[wnames[0]] > 0.02
        verdict[(arm, gran)] = good
        print(f"  {arm} {gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
              f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}% → "
              f"{'达标' if good else '不达标'}")
        for sym in SYMBOLS:
            rf = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                  and r["symbol"] == sym and r["split"] == wnames[1]][0]
            rb = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                  and r["symbol"] == sym and r["split"] == wnames[2]][0]
            both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
            print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                  f"后 {rb['taker_net_pct']*100:+.2f}% → "
                  f"{'★ 两半都为正' if both else ''}")

    # ---- 主臂 vs 三个对照：每笔毛利对照 ----
    print("\n=== 主臂 vs 三个对照（每笔毛利，全期）===")
    for arm, label, gran, data, bpd, windows, _ in ARMS:
        full = windows[0][0]
        rs = [r for r in all_results if r["arm"] == arm
              and r["granularity"] == gran and r["split"] == full]
        gt = sum(r["gross_usdt"] for r in rs)
        nt = sum(r["trades"] for r in rs)
        print(f"  {arm} {gran} 全期：n={nt} 每笔毛利 {gt/nt:+.2f} USDT "
              f"毛利合计 {gt:+.0f} Taker 平均 "
              f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% "
              f"毛利/成本 {gt/sum(r['taker_cost_sum'] for r in rs):+.2f}")

    with open(os.path.join(DATA_DIR, "gate_iter_round27_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round27_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "signal_time_utc", "entry_time_utc", "entry_hour_utc",
                    "exit_time_utc", "or_high", "or_low", "signal_open", "signal_close", "atr",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["arm"], x["granularity"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["signal_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["or_hi"], t["or_lo"], t["signal_o"], t["signal_c"], t["atr"],
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round27_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round27_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
