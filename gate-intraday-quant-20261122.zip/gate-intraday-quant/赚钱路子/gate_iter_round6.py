#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第六轮：纯永续资金费率价差，日内跨结算点（全模拟）
================================================================
只做模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。

为什么做这一轮（跑之前写死）：
  第五轮证明：现货多 + 永续空的资金费率套利在 Gate 179 天为正，
  但它要现货腿 + 持仓过夜，违反“只做合约、只做日内”两条约束，
  分叉二选一已报给用户、尚未回复。
  本轮问的是分叉里剩下的最后一个纯合约问题：不靠现货腿，
  只用两条永续腿（做多资金费率最低的币、做空资金费率最高的币），
  能不能在日内跨一个结算点把费率价差赚到手？
  若本轮为正，则分叉多一条“不用放宽约束”的路；若为负，
  则资金费率套利“必须现货腿”被坐实，分叉就只剩二选一，
  日内方向 + 纯合约资金费两条路都已封死，不再继续发明新家族。

策略（预注册，不择时、不调仓、不挑币、不网格寻优）：
  窗口 2026-05-21~2026-11-15（179 天，资金费率接口能回溯的全部长度，
  与第五轮同窗口；2026-05-21 之前没有资金费率数据）。
  每天只做 08:00 和 16:00 UTC 两个结算点（00:00 点排除：入场在前一日
  23:00、出场在次日 01:00，会跨 UTC 日、违反“日内”定义）。
  每笔交易：入场为结算前 1 小时收盘价（06:00  Bar 收盘 = 07:00 价，
  14:00 Bar 收盘 = 15:00 价），出场为结算后 1 小时收盘价
  （08:00 Bar 收盘 = 09:00 价，16:00 Bar 收盘 = 17:00 价），
  持仓约 2 小时，当天平仓、不过夜。
  选腿（入场时可观测、无前视）：按上一结算点的已结算资金费率排序，
  做多费率最低的币、做空费率最高的币（上一结算点：08:00 笔用 00:00
  的费率，16:00 笔用 08:00 的费率；不用当期结算费率选腿，因为入场时
  当期费率尚未结算、不可观测）。
  每条腿名义 10,000 USDT（10 万虚拟权益的 10%），两腿共 20,000，
  1x，不加杠杆；每天最多 2 笔（两个结算点各 1 笔），不设过滤、
  不设止损止盈（持仓仅 2 小时，止损止盈是另一组参数，不测）。
  资金费：结算时刻按当期实际费率收/付——多头付费率、空头收费率，
  净收入 = (空头币当期费率 - 多头币当期费率) × 腿名义，
  按结算时价格/入场价缩放名义（与第五轮同口径）。
  价格 PnL：多头 (出/入 - 1)，空头 -(出/入 - 1)，各按本腿名义计。

口径（写清，不藏）：
  成本主口径 Taker：一轮每腿 0.25% 名义（taker 0.075% + 滑点 0.05%，
  双边），两腿合计每笔 50 USDT = 权益的 0.05%。
  Maker 上界：每腿一轮 0.04%（maker 0.02% × 双边，不计滑点），
  每笔 8 USDT——这是执行能给出的最好情况，不是承诺。
  达标标准（与前几轮一致）：前后两半净收益都为正且全期净收益 >2%
  权益，才算“值得拿到用户面前讨论”；否则结论为不成立。
  另报分解：每笔平均资金费收入、价格 PnL、成本、毛利（扣成本前），
  以及资金费价差（上一期价差 vs 当期实现价差），说明钱从哪来、
  被谁吃掉。t 值为全部笔数 pooled t。

数据：全部复用本地缓存，不联网取数
  永续 1h：data/gate_1h_365d_{SYM}.csv（第三轮已取）
  资金费率：data/gate_funding_365d_{SYM}.json（第三/五轮已取，
  537 期/币，2026-05-21 00:00 ~ 2026-11-15 16:00 UTC）

运行：python3 gate_iter_round6.py
输出：终端打印全部表 + data/gate_iter_round6_summary.json
      + 报告 盈利策略迭代-第六轮.md（本脚本同目录）
"""
import csv, json, math, os, statistics
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT", "DOGE_USDT",
           "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
START = datetime(2026, 5, 21, 0, 0, tzinfo=timezone.utc)
END = datetime(2026, 11, 16, 0, 0, tzinfo=timezone.utc)  # 完整日止于 11-15
SPLIT = datetime(2026, 8, 19, 0, 0, tzinfo=timezone.utc)  # 约一半：90 天 / 89 天
LEG_NOTIONAL = 10_000.0
EQUITY = 100_000.0
TAKER_RT = 0.0025   # 每腿一轮 taker 成本 0.25% 名义
MAKER_RT = 0.0004   # 每腿一轮 maker 上界 0.04% 名义
SETTLEMENTS = [8, 16]  # UTC 小时；00:00 排除（会跨日）


def load_bars(sym):
    with open(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"), newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"])} for r in rows]
    return {b["t"]: b["c"] for b in sorted(bars, key=lambda b: b["t"])}


def load_funding(sym):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{sym}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def t_value(xs):
    n = len(xs)
    if n < 2:
        return None
    m = sum(xs) / n
    var = sum((x - m) ** 2 for x in xs) / (n - 1)
    sd = math.sqrt(var)
    return round(m / (sd / math.sqrt(n)), 2) if sd else None


def main():
    print("第六轮：纯永续资金费率价差，日内跨结算点（全模拟）")
    print("窗口 2026-05-21~2026-11-15（179 天）；每天 08:00/16:00 UTC 两个结算点，"
          "入场结算前 1h、出场结算后 1h，持仓约 2h；做多上一期费率最低币、"
          "做空上一期费率最高币；每腿 1 万 USDT，1x。")
    closes = {s: load_bars(s) for s in SYMBOLS}
    funding = {s: load_funding(s) for s in SYMBOLS}
    trades = []
    skipped = 0
    day = START
    while day < END:
        for h in SETTLEMENTS:
            sett = day + timedelta(hours=h)
            prev_sett = sett - timedelta(hours=8)
            entry_ts = int((sett - timedelta(hours=2)).timestamp())  # 06:00/14:00 Bar，收盘=07:00/15:00
            sett_bar_ts = int((sett - timedelta(hours=1)).timestamp())  # 07:00/15:00 Bar，收盘=结算价
            exit_ts = int(sett.timestamp())  # 08:00/16:00 Bar，收盘=09:00/17:00
            if int(prev_sett.timestamp()) not in funding[SYMBOLS[0]]:
                skipped += 1
                continue
            ranked = sorted(SYMBOLS, key=lambda s: funding[s][int(prev_sett.timestamp())])
            long_sym, short_sym = ranked[0], ranked[-1]
            prev_spread = funding[short_sym][int(prev_sett.timestamp())] - funding[long_sym][int(prev_sett.timestamp())]
            if prev_spread <= 0:
                skipped += 1
                continue
            try:
                le, ls = closes[long_sym][entry_ts], closes[short_sym][entry_ts]
                l_sett = closes[long_sym][sett_bar_ts]
                s_sett = closes[short_sym][sett_bar_ts]
                lx, sx = closes[long_sym][exit_ts], closes[short_sym][exit_ts]
            except KeyError:
                skipped += 1
                continue
            r_long = funding[long_sym][int(sett.timestamp())]
            r_short = funding[short_sym][int(sett.timestamp())]
            # 资金费：多头付、空头收，按结算时名义缩放
            fund_usdt = (r_short * (s_sett / ls) - r_long * (l_sett / le)) * LEG_NOTIONAL
            price_usdt = ((lx / le - 1) - (sx / ls - 1)) * LEG_NOTIONAL
            cost_taker = 2 * TAKER_RT * LEG_NOTIONAL
            cost_maker = 2 * MAKER_RT * LEG_NOTIONAL
            net_taker = fund_usdt + price_usdt - cost_taker
            net_maker = fund_usdt + price_usdt - cost_maker
            trades.append({
                "settlement": sett.strftime("%Y-%m-%d %H:%M UTC"),
                "long": long_sym, "short": short_sym,
                "prev_spread_pct": round(prev_spread * 100, 5),
                "realised_spread_pct": round((r_short - r_long) * 100, 5),
                "fund_usdt": round(fund_usdt, 2),
                "price_usdt": round(price_usdt, 2),
                "cost_taker_usdt": round(cost_taker, 2),
                "net_taker_usdt": round(net_taker, 2),
                "net_maker_usdt": round(net_maker, 2),
                "half": 1 if sett < SPLIT else 2,
            })
        day += timedelta(days=1)

    n = len(trades)
    nets = [t["net_taker_usdt"] for t in trades]
    net_maker = [t["net_maker_usdt"] for t in trades]
    funds = [t["fund_usdt"] for t in trades]
    prices = [t["price_usdt"] for t in trades]
    gross = [t["fund_usdt"] + t["price_usdt"] for t in trades]
    h1 = [t for t in trades if t["half"] == 1]
    h2 = [t for t in trades if t["half"] == 2]

    def summ(ts, label):
        tot = sum(t["net_taker_usdt"] for t in ts)
        tot_m = sum(t["net_maker_usdt"] for t in ts)
        return (f"{label}：{len(ts)} 笔 资金费 {sum(t['fund_usdt'] for t in ts):+.2f} "
                f"价格 {sum(t['price_usdt'] for t in ts):+.2f} "
                f"毛利(扣成本前) {sum(t['fund_usdt'] + t['price_usdt'] for t in ts):+.2f} "
                f"Taker 净 {tot:+.2f} USDT ({tot / EQUITY * 100:+.2f}% 权益) "
                f"Maker 上界净 {tot_m:+.2f} USDT ({tot_m / EQUITY * 100:+.2f}%)")

    print(f"\n交易笔数：{n}（应约 358 笔；跳过 {skipped} 笔：窗口首日无上一期费率或缺 K 线）")
    print(f"每笔平均：资金费 {statistics.mean(funds):+.2f} USDT / 价格 {statistics.mean(prices):+.2f} "
          f"/ 毛利 {statistics.mean(gross):+.2f} / Taker 成本 50.00 / Taker 净 {statistics.mean(nets):+.2f}")
    print(f"每笔平均资金费价差：上一期 {statistics.mean([t['prev_spread_pct'] for t in trades]):.5f}% "
          f"vs 当期实现 {statistics.mean([t['realised_spread_pct'] for t in trades]):.5f}% "
          f"（价差本身只有约 0.01% 量级，一腿 1 万名义对应约 1 USDT）")
    print(f"价格 PnL 波动：每笔价格 PnL 标准差 {statistics.pstdev(prices):.2f} USDT，"
          f"约每笔 2 小时两币价差波动 1% 量级")
    print(summ(h1, "前半 2026-05-21~08-18"))
    print(summ(h2, "后半 2026-08-19~11-15"))
    print(summ(trades, "全期 179 天"))
    tot = sum(nets)
    tot_m = sum(net_maker)
    print(f"\n达标判定（两半都为正且全期 Taker 净 >2% 权益）："
          f"前半 {sum(t['net_taker_usdt'] for t in h1) / EQUITY * 100:+.2f}% / "
          f"后半 {sum(t['net_taker_usdt'] for t in h2) / EQUITY * 100:+.2f}% / "
          f"全期 {tot / EQUITY * 100:+.2f}% → "
          f"{'达标' if (sum(t['net_taker_usdt'] for t in h1) > 0 and sum(t['net_taker_usdt'] for t in h2) > 0 and tot / EQUITY > 0.02) else '不达标'}")
    print(f"全部 {n} 笔 Taker 净 t 值：{t_value(nets)}；"
          f"扣成本前毛利 t 值：{t_value(gross)}；"
          f"资金费单项 t 值：{t_value(funds)}")
    print(f"胜率（Taker 净 >0 的笔数占比）：{sum(1 for x in nets if x > 0) / n * 100:.1f}%")
    # 最常选中的腿
    from collections import Counter
    print("做多最常选中：" + ", ".join(f"{k} {v}次" for k, v in Counter(t["long"] for t in trades).most_common(3)))
    print("做空最常选中：" + ", ".join(f"{k} {v}次" for k, v in Counter(t["short"] for t in trades).most_common(3)))

    summary = {
        "round": 6, "window": "2026-05-21~2026-11-15", "days": 179,
        "trades": n, "skipped": skipped,
        "per_trade_mean_fund_usdt": round(statistics.mean(funds), 2),
        "per_trade_mean_price_usdt": round(statistics.mean(prices), 2),
        "per_trade_mean_gross_usdt": round(statistics.mean(gross), 2),
        "per_trade_mean_net_taker_usdt": round(statistics.mean(nets), 2),
        "per_trade_cost_taker_usdt": 50.0,
        "per_trade_cost_maker_usdt": 8.0,
        "mean_prev_spread_pct": round(statistics.mean([t["prev_spread_pct"] for t in trades]), 5),
        "mean_realised_spread_pct": round(statistics.mean([t["realised_spread_pct"] for t in trades]), 5),
        "price_pnl_stdev_usdt": round(statistics.pstdev(prices), 2),
        "half1": {"n": len(h1), "net_taker_usdt": round(sum(t["net_taker_usdt"] for t in h1), 2),
                  "net_taker_pct": round(sum(t["net_taker_usdt"] for t in h1) / EQUITY * 100, 2),
                  "net_maker_pct": round(sum(t["net_maker_usdt"] for t in h1) / EQUITY * 100, 2),
                  "fund_usdt": round(sum(t["fund_usdt"] for t in h1), 2),
                  "price_usdt": round(sum(t["price_usdt"] for t in h1), 2)},
        "half2": {"n": len(h2), "net_taker_usdt": round(sum(t["net_taker_usdt"] for t in h2), 2),
                  "net_taker_pct": round(sum(t["net_taker_usdt"] for t in h2) / EQUITY * 100, 2),
                  "net_maker_pct": round(sum(t["net_maker_usdt"] for t in h2) / EQUITY * 100, 2),
                  "fund_usdt": round(sum(t["fund_usdt"] for t in h2), 2),
                  "price_usdt": round(sum(t["price_usdt"] for t in h2), 2)},
        "full": {"net_taker_usdt": round(tot, 2), "net_taker_pct": round(tot / EQUITY * 100, 2),
                 "net_maker_usdt": round(tot_m, 2), "net_maker_pct": round(tot_m / EQUITY * 100, 2),
                 "fund_usdt": round(sum(funds), 2), "price_usdt": round(sum(prices), 2),
                 "gross_usdt": round(sum(gross), 2),
                 "t_net_taker": t_value(nets), "t_gross": t_value(gross),
                 "win_rate_pct": round(sum(1 for x in nets if x > 0) / n * 100, 1)},
        "pass": bool(sum(t["net_taker_usdt"] for t in h1) > 0 and sum(t["net_taker_usdt"] for t in h2) > 0 and tot / EQUITY > 0.02),
        "trades_sample": trades[:5],
    }
    json.dump(summary, open(os.path.join(DATA_DIR, "gate_iter_round6_summary.json"), "w"),
              ensure_ascii=False, indent=2)
    print("\n汇总已写入：data/gate_iter_round6_summary.json")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
