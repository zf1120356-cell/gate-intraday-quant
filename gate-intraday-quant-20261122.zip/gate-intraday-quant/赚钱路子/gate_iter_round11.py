#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第十一轮：SMC（Smart Money Concepts）日内（只做合约、只做日内、只做 Gate）
============================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（用户指出）：“算了，你用 SMC 去做吧，自主分析，主观性等等。”
即：允许用 SMC（Smart Money Concepts）做日内，允许自主分析、带主观判断。
已核查：前十轮 22 个家族没有一个是 SMC（第七轮 F1-F4、第十轮多周期
共振均不是；F3 插针反转只看单根影线形态，没有结构、没有订单块、
没有 FVG、没有流动性扫荡，不是 SMC）。本轮是首次 SMC。

前提（必须先说清楚，写进报告）：
  SMC 本来是主观盘感：画哪根摆动高低点、哪个订单块算“有效”、
  哪个 FVG 值得做、扫荡算不算“扫干净”，真人交易员全凭经验判断，
  两个人画出来常常不一样。要回测，就必须先把每个概念写成客观
  规则，否则结果不可复现。本轮测的是“SMC 的一种客观形式化”，
  不是 SMC 本身；换一种形式化（比如摆动点 N=3、订单块取最强那
  腿、FVG 设最小尺寸），数字会不一样。参数跑前定死、单组、不许
  用全样本挑。

锁定的客观定义（跑前定死）：
  摆动高/低点：N=2（5 根分形）。bar i 为摆动高，当且仅当
    h[i] >= h[i-2..i+2] 中每一根，且 h[i] > h[i-1]（左侧严格大于，
    右侧允许相等，取最早一根）；摆动低对称。摆动点在 bar i+2
    收盘时才“确认”，确认之前不存在、不能用。
  结构（BOS）：收盘价上破最近一个已确认摆动高 = 看涨 BOS；
    收盘价下破最近一个已确认摆动低 = 看跌 BOS。只用已确认点。
  结构转变（CHOCH）：与最近一次 BOS 方向相反的收盘破位
    （上破摆动高后又收盘破摆动低，或反之）。
  订单块（OB）：BOS 之前 10 根内最后一根反向 K 线（看涨 BOS
    取最后一根阴线，看跌 BOS 取最后一根阳线）；区间 = 该根的
    [l, h]。10 根内没有反向 K 线则无 OB。
  FVG：连续三根中，bar[i].l > bar[i-2].h（看涨缺口，区间
    [bar[i-2].h, bar[i].l]）或 bar[i].h < bar[i-2].l（看跌缺口），
    且三根整体同向（看涨要求 c[i] > c[i-2]，看跌要求反之）。
    FVG 被“填补”= 有根收盘价穿过区间远端（看涨为收盘 < 区间下沿）。
  流动性扫荡：某根 K 线影线刺破最近已确认摆动高（h > 摆动高）
    但收盘回到摆动高之下（c < 摆动高）；看跌方向对称。

  通用：止损 1xATR，止盈 2xATR（用户要求 1:2，在 1.5~3 中间）；
  每笔保证金 10% 权益、1x；信号根收盘触发、下一根开盘成交；
  止损/止盈用盘中高低价触发（同根同时碰到先判止损）；
  单日 -2% 熔断；单笔最坏情况 (ATR+成本) > 1% 权益跳过；
  成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
  双边）；资金费按实际费率计（08:00/16:00 结算点，前半段
  2026-05-21 之前无数据按 0 计）。M1/M2 只做对照（第九轮同款）。

  S1 流动性扫荡 + CHOCH 反转（全 1h，365d，8 币）：
    扫荡（见上）发生后 8 根内出现 CHOCH（与扫荡反向），顺 CHOCH
    方向入场；8 根内未出现 CHOCH 则 setup 作废；期间若出现同向
    BOS（扫荡被证伪、价格真突破了）也作废。CHOCH 根须在
    08:00-20:00 UTC；最多持 8 根；每天每币最多 2 笔；23:00 收盘。
    对照 S1c：BOS 后 8 根内出现反向 CHOCH 即入场（不要扫荡这一步），
    其余一模一样——用来判断“扫荡”本身有没有增值。
  S2 订单块 + FVG 回踩（1h 定结构、15m 找入场，103d，8 币）：
    1h（由 15m 合成）出现 BOS 后，取 OB 区间；无 OB 则取 BOS 前
    10 根内最近一个 FVG 区间；两者都没有则无 setup。BOS 收盘后
    12h 内、15m 首次触及区间（l <= 区间上沿且 c >= 区间下沿）
    即入场（下一根 15m 开盘）；触及前若有 15m 收盘穿过区间下沿
    （看涨）则 setup 作废；12h 内未触及作废。触发根须在
    08:00-20:00 UTC；止损 1xATR(15m)、止盈 2xATR；最多持 16 根
    （4h）；每天每币最多 2 笔；23:45 收盘。
    对照 S2c：1h BOS 后直接下一根 1h 开盘顺 BOS 方向入场（不等回踩），
    其余一模一样——用来判断“等回踩”本身有没有增值。
  S3 FVG 回补 + 延续（全 1h，365d，8 币）：
    1h 上出现 FVG 后，24 根内价格首次回踩触及区间（l <= 区间上沿
    且 c >= 区间下沿）且 4h 趋势（EMA20/EMA60，由 1h 合成，只用已
    收盘 4h 根）与 FVG 方向一致，即顺 FVG 方向入场；首次触及若
    趋势不一致，FVG 视为已被消耗、作废；24 根内未触及作废；触及
    前被填补（收盘穿过区间远端）作废。触发根须在 08:00-20:00 UTC；
    最多持 8 根；每天每币最多 2 笔；23:00 收盘。
    对照 S3c：FVG 回补入场，去掉 4h 趋势过滤（回踩即进），其余
    一模一样——用来判断“趋势过滤”本身有没有增值。

  前视防控（写死在代码里）：
    - 摆动点、BOS、CHOCH、OB、FVG 全部只用已收盘的根；摆动点
      须在确认根（bar i+2）收盘后才可用。
    - 入场永远是触发根的下一根开盘价。
    - 4h 趋势只用已收盘的 4h 根（bisect_right，第十轮同款）。
    - S2 的 15m 触发根须严格晚于 1h BOS 根收盘时刻（start t >=
      BOS 收盘时刻），同收盘时刻的 15m 根不用。

窗口：
  S1 / S3：365 天 1h，2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  S2：103 天 15m，2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

运行：python3 gate_iter_round11.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round11_summary.json
      + data/gate_iter_round11_trades.csv（全期明细，split 列）
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import bisect
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005,
              "DOGE_USDT": 0.008333, "LINK_USDT": 0.0065, "XRP_USDT": 0.005,
              "BNB_USDT": 0.0066, "ADA_USDT": 0.0066}

# ---- 锁定的参数：止损 1xATR，止盈 2xATR（用户要求 1:2）----
SL_MULT = 1.0
TP_MULT = 2.0
SWING_N = 2
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)

ROUNDTRIP_COST = 0.0025
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in ["BTC_USDT", "ETH_USDT", "SOL_USDT"]:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def ema_series(closes, period):
    """标准 EMA，种子为前 period 根收盘价的 SMA；不足 period 根为 None。"""
    out = [None] * len(closes)
    if len(closes) < period:
        return out
    k = 2.0 / (period + 1)
    out[period - 1] = sum(closes[:period]) / period
    for i in range(period, len(closes)):
        out[i] = closes[i] * k + out[i - 1] * (1 - k)
    return out


def synthesize(bars, per_block, block_secs):
    """把小周期根按时间戳聚合成大周期根；只保留满 per_block 根的块。
    块起始 = t - (t % block_secs)，与 UTC 边界对齐。"""
    blocks = {}
    for b in bars:
        start = b["t"] - (b["t"] % block_secs)
        blocks.setdefault(start, []).append(b)
    out = []
    for start in sorted(blocks):
        grp = sorted(blocks[start], key=lambda x: x["t"])
        if len(grp) != per_block:
            continue
        out.append({"t": start, "o": grp[0]["o"], "h": max(g["h"] for g in grp),
                    "l": min(g["l"] for g in grp), "c": grp[-1]["c"],
                    "v": sum(g["v"] for g in grp),
                    "sum": sum(g["sum"] for g in grp)})
    return out


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def last_completed_idx(big_close_ts, small_close_t):
    """大周期收盘时刻列表里，收盘时刻 <= 小周期信号根收盘时刻的最后一根。
    返回下标，-1 表示当时还没有已收盘的大周期根（热身期）。"""
    return bisect.bisect_right(big_close_ts, small_close_t) - 1


# ----------------------------------------------------------------------
# SMC 结构检测（全部只用已收盘根）
# ----------------------------------------------------------------------
def swing_points(bars, n=SWING_N):
    """返回 [(bar_idx, kind, level, confirmed_idx)]：
    kind 'H' 摆动高 / 'L' 摆动低；confirmed_idx = bar_idx + n，
    即该摆动点在第 confirmed_idx 根收盘时才被确认、才可用。
    平顶/平底取最早一根（左侧严格大于，右侧允许相等）。"""
    out = []
    for i in range(n, len(bars) - n):
        h, l = bars[i]["h"], bars[i]["l"]
        win_h = [bars[j]["h"] for j in range(i - n, i + n + 1)]
        win_l = [bars[j]["l"] for j in range(i - n, i + n + 1)]
        if h == max(win_h) and h > bars[i - 1]["h"]:
            out.append((i, "H", h, i + n))
        if l == min(win_l) and l < bars[i - 1]["l"]:
            out.append((i, "L", l, i + n))
    return out


def confirmed_levels(bars, n=SWING_N):
    """返回四条与 bars 等长的数组：每根收盘时已确认的最近摆动高/低
    的 level 与 bar_idx（None/-1 表示当时还没有已确认的摆动点）。"""
    swings = sorted(swing_points(bars, n), key=lambda s: s[3])
    sh_level = [None] * len(bars)
    sh_idx = [-1] * len(bars)
    sl_level = [None] * len(bars)
    sl_idx = [-1] * len(bars)
    cur_sh = cur_sl = None
    cur_sh_i = cur_sl_i = -1
    p = 0
    for j in range(len(bars)):
        while p < len(swings) and swings[p][3] <= j:
            i, kind, level, _ = swings[p]
            if kind == "H":
                cur_sh, cur_sh_i = level, i
            else:
                cur_sl, cur_sl_i = level, i
            p += 1
        sh_level[j] = cur_sh
        sh_idx[j] = cur_sh_i
        sl_level[j] = cur_sl
        sl_idx[j] = cur_sl_i
    return sh_level, sh_idx, sl_level, sl_idx


def build_trend_4h(bars1h, bars4h):
    """与 bars1h 等长的 4h 趋势数组：每根 1h 收盘时已收盘的最近 4h 根
    的 EMA20/EMA60 方向（+1 只做多 / -1 只做空 / 0 热身期或无方向）。
    第十轮 build_m1_trend 一字不变的复用。"""
    closes4 = [b["c"] for b in bars4h]
    e20 = ema_series(closes4, 20)
    e60 = ema_series(closes4, 60)
    close4_ts = [b["t"] + 4 * 3600 for b in bars4h]
    trend = []
    for b in bars1h:
        j = last_completed_idx(close4_ts, b["t"] + 3600)
        if j < 0 or e20[j] is None or e60[j] is None:
            trend.append(0)
        elif e20[j] > e60[j]:
            trend.append(1)
        elif e20[j] < e60[j]:
            trend.append(-1)
        else:
            trend.append(0)
    return trend


def in_window(t, lo=8.0, hi=20.0):
    dt = datetime.fromtimestamp(t, timezone.utc)
    return lo <= dt.hour + dt.minute / 60.0 < hi


# ----------------------------------------------------------------------
# S1：流动性扫荡 + CHOCH 反转（全 1h）
# S1c 对照：BOS 后反向 CHOCH（不要扫荡这一步）
# ----------------------------------------------------------------------
def build_s1_signals(bars, atr, use_sweep=True):
    """返回 (signals, stats)。
    signals key=入场根 t，value={direction, atr, tag}；
    tag 标明触发路径（sweep_high->choch 等），供报告诊断。
    流程（逐根收盘推进，只用已确认摆动点）：
      扫荡：h[j] > SH 且 c[j] < SH（上方流动性）/ l[j] < SL 且 c[j] > SL
      CHOCH：扫荡后 8 根内，收盘破反向最近摆动点
      作废：8 根到期，或期间出现同向 BOS（扫荡被证伪）
    S1c：BOS 后 8 根内出现反向 CHOCH 即入场（不要扫荡）。"""
    closes = [b["c"] for b in bars]
    sh_level, _, sl_level, _ = confirmed_levels(bars)
    sigs = {}
    stats = {"sweeps": 0, "bos": 0, "choch": 0, "armed_expired": 0,
             "armed_invalidated": 0, "signals": 0}
    armed = None  # {"dir": 入场方向, "until": 最晚触发根下标, "kind": "sweep"/"bos"}
    last_bos_dir = 0
    for j in range(1, len(bars)):
        b, c, pc = bars[j], closes[j], closes[j - 1]
        sh, sl = sh_level[j], sl_level[j]
        # ---- 先算本根的事件（只用本根收盘时已知的信息）----
        sweep_dir = 0   # 扫荡上方流动性 -> 预期做空（-1）；扫荡下方 -> 做多（+1）
        if sh is not None and b["h"] > sh and c < sh:
            sweep_dir = -1
        elif sl is not None and b["l"] < sl and c > sl:
            sweep_dir = 1
        bos_dir = 0
        if sh is not None and pc <= sh < c:
            bos_dir = 1
        elif sl is not None and pc >= sl > c:
            bos_dir = -1
        choch_dir = 0   # 与最近一次 BOS 反向的收盘破位
        if last_bos_dir == 1 and sl is not None and pc >= sl > c:
            choch_dir = -1
        elif last_bos_dir == -1 and sh is not None and pc <= sh < c:
            choch_dir = 1
        if sweep_dir:
            stats["sweeps"] += 1
        if bos_dir:
            stats["bos"] += 1
            last_bos_dir = bos_dir
        if choch_dir:
            stats["choch"] += 1
        # ---- armed 状态推进 ----
        if armed is not None:
            if j > armed["until"]:
                stats["armed_expired"] += 1
                armed = None
            elif bos_dir != 0 and bos_dir == -armed["dir"]:
                # 同向 BOS：扫荡被证伪（价格真突破了），作废
                stats["armed_invalidated"] += 1
                armed = None
        # ---- CHOCH 触发入场（须在 armed 窗口内、方向一致、在信号窗口内）----
        if (armed is not None and choch_dir != 0 and choch_dir == armed["dir"]
                and j <= armed["until"] and in_window(b["t"])
                and atr[j] is not None and j + 1 < len(bars)):
            entry_t = bars[j + 1]["t"]
            if entry_t not in sigs:
                sigs[entry_t] = {"direction": choch_dir, "atr": atr[j],
                                 "tag": f"{armed['kind']}->{armed['dir']:+d}"}
                stats["signals"] += 1
            armed = None
        # ---- 重新布防（触发根之后才布防，避免同一根既触发又布防）----
        if use_sweep:
            if sweep_dir != 0:
                armed = {"dir": sweep_dir, "until": j + 8, "kind": "sweep"}
        else:
            if bos_dir != 0:
                armed = {"dir": -bos_dir, "until": j + 8, "kind": "bos"}
    return sigs, stats


# ----------------------------------------------------------------------
# S2：订单块 + FVG 回踩（1h 定结构、15m 找入场）
# S2c 对照：1h BOS 后直接下一根 1h 开盘顺 BOS 入场（不等回踩）
# ----------------------------------------------------------------------
def find_ob(bars, bos_idx, direction):
    """BOS 之前 10 根内最后一根反向 K 线的区间；没有则 None。
    看涨 BOS（direction=+1）取最后一根阴线；看跌取最后一根阳线。"""
    for k in range(bos_idx - 1, max(bos_idx - 11, -1), -1):
        if direction == 1 and bars[k]["c"] < bars[k]["o"]:
            return (bars[k]["l"], bars[k]["h"], "OB")
        if direction == -1 and bars[k]["c"] > bars[k]["o"]:
            return (bars[k]["l"], bars[k]["h"], "OB")
    return None


def find_fvg(bars, bos_idx, direction):
    """BOS 之前 10 根内最近一个同向 FVG 的区间；没有则 None。
    看涨 FVG：l[i] > h[i-2] 且 c[i] > c[i-2]，区间 [h[i-2], l[i]]。"""
    for i in range(bos_idx, max(bos_idx - 10, 1), -1):
        if direction == 1 and bars[i]["l"] > bars[i - 2]["h"] \
                and bars[i]["c"] > bars[i - 2]["c"]:
            return (bars[i - 2]["h"], bars[i]["l"], "FVG")
        if direction == -1 and bars[i]["h"] < bars[i - 2]["l"] \
                and bars[i]["c"] < bars[i - 2]["c"]:
            return (bars[i]["l"], bars[i - 2]["h"], "FVG")
    return None


def build_s2_signals_full(bars15, bars1h, atr15):
    """S2 完整版：先在 1h 上收集全部 BOS setup（按时间顺序），再逐个
    在 15m 上推进（触发 / 作废 / 过期）。返回 (signals, stats)。"""
    closes1 = [b["c"] for b in bars1h]
    sh_level, _, sl_level, _ = confirmed_levels(bars1h)
    idx15_of_t = {b["t"]: i for i, b in enumerate(bars15)}
    setups = []
    stats = {"bos": 0, "setups_ob": 0, "setups_fvg": 0, "setups_none": 0,
             "triggered": 0, "invalidated": 0, "expired": 0, "signals": 0,
             "trigger_zone": Counter()}
    for j in range(1, len(bars1h)):
        bos_dir = 0
        sh, sl = sh_level[j], sl_level[j]
        pc, c = closes1[j - 1], closes1[j]
        if sh is not None and pc <= sh < c:
            bos_dir = 1
        elif sl is not None and pc >= sl > c:
            bos_dir = -1
        if bos_dir == 0:
            continue
        stats["bos"] += 1
        zone = find_ob(bars1h, j, bos_dir) or find_fvg(bars1h, j, bos_dir)
        if zone is None:
            stats["setups_none"] += 1
            continue
        if zone[2] == "OB":
            stats["setups_ob"] += 1
        else:
            stats["setups_fvg"] += 1
        bos_close_t = bars1h[j]["t"] + 3600
        start15 = idx15_of_t.get(bos_close_t)
        if start15 is None:
            continue
        setups.append({"dir": bos_dir, "zone_lo": zone[0], "zone_hi": zone[1],
                       "zone_kind": zone[2], "start15": start15,
                       "until_idx15": start15 + 48, "bos_t": bos_close_t})
    sigs = {}
    for s in setups:
        outcome = None
        for k in range(s["start15"], min(s["until_idx15"], len(bars15) - 1)):
            b = bars15[k]
            d = s["dir"]
            if d == 1:
                if b["c"] < s["zone_lo"]:
                    outcome = "invalidated"
                    break
                if b["l"] <= s["zone_hi"] and in_window(b["t"]):
                    outcome = "triggered"
                    if atr15[k] is not None:
                        entry_t = bars15[k + 1]["t"]
                        if entry_t not in sigs:
                            sigs[entry_t] = {"direction": 1, "atr": atr15[k],
                                             "tag": s["zone_kind"]}
                            stats["signals"] += 1
                            stats["trigger_zone"][s["zone_kind"]] += 1
                    break
            else:
                if b["c"] > s["zone_hi"]:
                    outcome = "invalidated"
                    break
                if b["h"] >= s["zone_lo"] and in_window(b["t"]):
                    outcome = "triggered"
                    if atr15[k] is not None:
                        entry_t = bars15[k + 1]["t"]
                        if entry_t not in sigs:
                            sigs[entry_t] = {"direction": -1, "atr": atr15[k],
                                             "tag": s["zone_kind"]}
                            stats["signals"] += 1
                            stats["trigger_zone"][s["zone_kind"]] += 1
                    break
        if outcome == "triggered":
            stats["triggered"] += 1
        elif outcome == "invalidated":
            stats["invalidated"] += 1
        else:
            stats["expired"] += 1
    return sigs, stats


def build_s2c_signals(bars1h, atr1h):
    """S2c 对照：1h BOS 后直接下一根 1h 开盘顺 BOS 入场（不等回踩）。"""
    closes1 = [b["c"] for b in bars1h]
    sh_level, _, sl_level, _ = confirmed_levels(bars1h)
    sigs = {}
    stats = {"bos": 0, "signals": 0}
    for j in range(1, len(bars1h)):
        bos_dir = 0
        sh, sl = sh_level[j], sl_level[j]
        pc, c = closes1[j - 1], closes1[j]
        if sh is not None and pc <= sh < c:
            bos_dir = 1
        elif sl is not None and pc >= sl > c:
            bos_dir = -1
        if bos_dir == 0:
            continue
        stats["bos"] += 1
        if not in_window(bars1h[j]["t"]):
            continue
        if atr1h[j] is None or j + 1 >= len(bars1h):
            continue
        entry_t = bars1h[j + 1]["t"]
        if entry_t not in sigs:
            sigs[entry_t] = {"direction": bos_dir, "atr": atr1h[j], "tag": "BOS"}
            stats["signals"] += 1
    return sigs, stats


# ----------------------------------------------------------------------
# S3：FVG 回补 + 延续（全 1h，4h 趋势过滤）
# S3c 对照：FVG 回补入场，去掉 4h 趋势过滤
# ----------------------------------------------------------------------
def build_s3_signals(bars, atr, trend=None):
    """返回 (signals, stats)。
    FVG 在 bar i 形成后，24 根内首次回踩触及区间即触发（或作废）：
      触及 = l <= 区间上沿 且 c >= 区间下沿（看涨；看跌对称）
      填补作废 = 收盘穿过区间远端
      趋势不一致（trend 有值且与 FVG 方向不同）-> 首次触及即作废
    trend=None 时为 S3c（无趋势过滤）。"""
    sigs = {}
    stats = {"fvg": 0, "fvg_long": 0, "fvg_short": 0, "triggered": 0,
             "filled": 0, "trend_rejected": 0, "expired": 0, "signals": 0}
    active = []  # {"dir", "lo", "hi", "until"}
    for i in range(2, len(bars)):
        # --- 先推进已有 FVG（bar i 为回踩候选根）---
        # 注意：本根新形成的 FVG 不参与本根的触及判定（它的区间上沿
        # 就是本根最低价，必然“触及”），新 FVG 在推进之后才加入 active。
        still = []
        for f in active:
            if i > f["until"]:
                stats["expired"] += 1
                continue
            b = bars[i]
            touched = False
            filled = False
            if f["dir"] == 1:
                filled = b["c"] < f["lo"]
                touched = (not filled) and b["l"] <= f["hi"] and b["c"] >= f["lo"]
            else:
                filled = b["c"] > f["hi"]
                touched = (not filled) and b["h"] >= f["lo"] and b["c"] <= f["hi"]
            if filled:
                stats["filled"] += 1
                continue
            if touched:
                # 首次触及：趋势一致（或无过滤）则触发，否则作废
                if trend is not None and trend[i] != 0 and trend[i] != f["dir"]:
                    stats["trend_rejected"] += 1
                    continue
                if not in_window(b["t"]):
                    # 不在信号窗口内：本根不触发，FVG 继续等下一根
                    # （不在窗口内触及不算消耗——保守处理，只跳过本根）
                    still.append(f)
                    continue
                if atr[i] is not None and i + 1 < len(bars):
                    entry_t = bars[i + 1]["t"]
                    if entry_t not in sigs:
                        sigs[entry_t] = {"direction": f["dir"], "atr": atr[i],
                                         "tag": "FVG"}
                        stats["signals"] += 1
                    stats["triggered"] += 1
                continue
            still.append(f)
        active = still
        # --- 新 FVG 形成（bar i 收盘时），加入 active，从下一根起才可触及 ---
        d = 0
        if bars[i]["l"] > bars[i - 2]["h"] and bars[i]["c"] > bars[i - 2]["c"]:
            d = 1
        elif bars[i]["h"] < bars[i - 2]["l"] and bars[i]["c"] < bars[i - 2]["c"]:
            d = -1
        if d != 0:
            stats["fvg"] += 1
            if d == 1:
                stats["fvg_long"] += 1
                lo, hi = bars[i - 2]["h"], bars[i]["l"]
            else:
                stats["fvg_short"] += 1
                lo, hi = bars[i]["h"], bars[i - 2]["l"]
            active.append({"dir": d, "lo": lo, "hi": hi, "until": i + 24})
    return sigs, stats


# ----------------------------------------------------------------------
# 通用引擎：信号预生成（key=入场根时间戳），下一根开盘进，
# 止损 1xATR / 止盈 2xATR / 最多持 N 根 / 当天最后一根收盘平仓。
# 同根同时碰止损和止盈先判止损；单日 -2% 熔断。
# （第十轮 simulate_generic 一字不变的复用，仅多传一个 tag 字段。）
# ----------------------------------------------------------------------
def simulate_generic(symbol, bars, signals, funding, days_subset, max_per_day,
                     max_hold, label, bars_per_day):
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if gi - pos["entry_gi"] >= max_hold - 1:
                    close_trade(pos, b["t"], b["c"], "max_hold")
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None and not day_stopped and trades_today < max_per_day:
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                if notional * (a / entry + ROUNDTRIP_COST) / equity > 0.01:
                    continue
                stop = entry - SL_MULT * a if sig["direction"] == 1 else entry + SL_MULT * a
                tp = entry + TP_MULT * a if sig["direction"] == 1 else entry - TP_MULT * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0,
                       "max_hold": max_hold, "tag": sig.get("tag", "")}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    return trades, curve, len(days)


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": sum(1 for t in trades if t.get("liquidated")),
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def main():
    print("盈利策略迭代 · 第十一轮：SMC 日内（止损 1xATR / 止盈 2xATR，全模拟）")
    print("只做合约、只做日内、只做 Gate；不做资金费率套利；"
          "达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    assert data1h["BTC_USDT"][0][0]["t"] % 14400 == 0, "1h 起始时间戳不在 4h 边界"
    assert data15["BTC_USDT"][0][0]["t"] % 3600 == 0, "15m 起始时间戳不在整点边界"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；"
          "时间戳对齐、零缺口；4h/1h 合成边界对齐。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    all_results, all_trades = [], []
    pooled = {}  # family -> 全期逐笔 pnl_pct 列表（Taker，用于 pooled t）

    def record(res, trades_full, family, variant, gran, split_fn, setup_stats=None):
        res["family"] = family
        res["variant"] = variant
        res["granularity"] = gran
        if setup_stats is not None:
            res["setup_stats"] = {k: (dict(v) if isinstance(v, Counter) else v)
                                  for k, v in setup_stats.items()}
        all_results.append(res)
        if trades_full is not None:
            pooled.setdefault(family, [])
            for t in trades_full:
                pooled[family].append(t["pnl"] / START_EQUITY)
                t2 = dict(t)
                t2["family"] = family
                t2["variant"] = variant
                t2["granularity"] = gran
                t2["split"] = split_fn(t["entry_t"])
                all_trades.append(t2)

    def split_1h(et):
        return "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"

    def split_15(et):
        return "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"

    def show(res, sym, wname):
        print(f"[{res['label']} {sym} {wname}] n={res['trades']} 胜率={res['win_rate']} "
              f"盈亏比={res['profit_factor']} 平均赢={res['avg_win_usdt']:+.0f} "
              f"平均亏={res['avg_loss_usdt']:.0f} Taker {res['taker_net_pct']*100:+.2f}% "
              f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
              f"M2 {res['m2_net_pct']*100:+.2f}% 毛利={res['gross_usdt']:+.0f} "
              f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
              f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    def run_family(family, label, bars_by_sym, signals_by_sym, funding_by_sym,
                   subsets, max_per_day, max_hold, bars_per_day, split_fn, gran):
        for sym in SYMBOLS:
            bars = bars_by_sym[sym]
            funding = funding_by_sym[sym]
            for wname, subset in subsets:
                trades, curve, ndays = simulate_generic(
                    sym, bars, signals_by_sym[sym], funding, subset,
                    max_per_day, max_hold, label, bars_per_day)
                res = summarize(sym, trades, curve, label, len(signals_by_sym[sym]))
                res["split"] = wname
                res["days"] = ndays
                record(res, trades if subset is None else None, family, label,
                       gran, split_fn)
                show(res, sym, wname)

    # ================= S1：扫荡 + CHOCH（365d 1h）=================
    print("\n=== S1：流动性扫荡 + CHOCH 反转（365d 1h，8 币）===")
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    sig_s1, sig_s1c, st_s1, st_s1c = {}, {}, {}, {}
    for sym in SYMBOLS:
        bars = data1h[sym][0]
        sig_s1[sym], st_s1[sym] = build_s1_signals(bars, atr1h[sym], use_sweep=True)
        sig_s1c[sym], st_s1c[sym] = build_s1_signals(bars, atr1h[sym], use_sweep=False)
    print(f"[S1] setup 统计（8 币合计）：扫荡 "
          f"{sum(v['sweeps'] for v in st_s1.values())} 次 / BOS "
          f"{sum(v['bos'] for v in st_s1.values())} 次 / CHOCH "
          f"{sum(v['choch'] for v in st_s1.values())} 次 / 信号 "
          f"{sum(v['signals'] for v in st_s1.values())} 个 "
          f"（作废：过期 {sum(v['armed_expired'] for v in st_s1.values())} / "
          f"证伪 {sum(v['armed_invalidated'] for v in st_s1.values())}）")
    run_family("S1", "R11-S1", {s: data1h[s][0] for s in SYMBOLS}, sig_s1,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               2, 8, 24, split_1h, "1h")
    print("\n=== S1c 对照：BOS 后反向 CHOCH（不要扫荡）===")
    print(f"[S1c] setup 统计（8 币合计）：BOS "
          f"{sum(v['bos'] for v in st_s1c.values())} 次 / CHOCH "
          f"{sum(v['choch'] for v in st_s1c.values())} 次 / 信号 "
          f"{sum(v['signals'] for v in st_s1c.values())} 个 "
          f"（作废：过期 {sum(v['armed_expired'] for v in st_s1c.values())} / "
          f"证伪 {sum(v['armed_invalidated'] for v in st_s1c.values())}）")
    run_family("S1c", "R11-S1c", {s: data1h[s][0] for s in SYMBOLS}, sig_s1c,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               2, 8, 24, split_1h, "1h")

    # ================= S2：OB/FVG 回踩（103d 15m）=================
    print("\n=== S2：订单块 + FVG 回踩（1h 结构、15m 入场，103d，8 币）===")
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    sig_s2, st_s2 = {}, {}
    bars1h_from15 = {}
    for sym in SYMBOLS:
        bars15 = data15[sym][0]
        bars1h = synthesize(bars15, 4, 3600)
        assert len(bars1h) == 103 * 24, f"{sym} 15m 合成 1h 应为 {103*24} 根，实际 {len(bars1h)}"
        bars1h_from15[sym] = bars1h
        sig_s2[sym], st_s2[sym] = build_s2_signals_full(bars15, bars1h, atr15[sym])
    print(f"[S2] setup 统计（8 币合计）：BOS "
          f"{sum(v['bos'] for v in st_s2.values())} 次 / setup OB "
          f"{sum(v['setups_ob'] for v in st_s2.values())} / FVG "
          f"{sum(v['setups_fvg'] for v in st_s2.values())} / 无区间 "
          f"{sum(v['setups_none'] for v in st_s2.values())} / 触发 "
          f"{sum(v['triggered'] for v in st_s2.values())} / 作废 "
          f"{sum(v['invalidated'] for v in st_s2.values())} / 过期 "
          f"{sum(v['expired'] for v in st_s2.values())} / 信号 "
          f"{sum(v['signals'] for v in st_s2.values())} 个；"
          f"触发区间分布 OB/FVG = "
          f"{sum(v['trigger_zone'].get('OB', 0) for v in st_s2.values())}/"
          f"{sum(v['trigger_zone'].get('FVG', 0) for v in st_s2.values())}")
    run_family("S2", "R11-S2", {s: data15[s][0] for s in SYMBOLS}, sig_s2,
               {s: data15[s][1] for s in SYMBOLS},
               [("103d", None), ("前51d", front_15), ("后52d", back_15)],
               2, 16, 96, split_15, "15m")
    print("\n=== S2c 对照：1h BOS 后直接入场（不等回踩）===")
    atr1h15 = {s: atr_wilder(bars1h_from15[s]) for s in SYMBOLS}
    sig_s2c, st_s2c = {}, {}
    for sym in SYMBOLS:
        sig_s2c[sym], st_s2c[sym] = build_s2c_signals(bars1h_from15[sym], atr1h15[sym])
    print(f"[S2c] setup 统计（8 币合计）：BOS "
          f"{sum(v['bos'] for v in st_s2c.values())} 次 / 信号 "
          f"{sum(v['signals'] for v in st_s2c.values())} 个")
    run_family("S2c", "R11-S2c", bars1h_from15, sig_s2c,
               {s: data15[s][1] for s in SYMBOLS},
               [("103d", None), ("前51d", front_15), ("后52d", back_15)],
               2, 8, 24, split_15, "1h(from15m)")

    # ================= S3：FVG 回补 + 4h 趋势（365d 1h）=================
    print("\n=== S3：FVG 回补 + 4h 趋势延续（365d 1h，8 币）===")
    sig_s3, sig_s3c, st_s3, st_s3c = {}, {}, {}, {}
    for sym in SYMBOLS:
        bars = data1h[sym][0]
        b4 = synthesize(bars, 4, 14400)
        assert len(b4) == 2190, f"{sym} 合成 4h 应为 2190 根，实际 {len(b4)}"
        trend = build_trend_4h(bars, b4)
        sig_s3[sym], st_s3[sym] = build_s3_signals(bars, atr1h[sym], trend=trend)
        sig_s3c[sym], st_s3c[sym] = build_s3_signals(bars, atr1h[sym], trend=None)
    print(f"[S3] setup 统计（8 币合计）：FVG "
          f"{sum(v['fvg'] for v in st_s3.values())} 个（多 "
          f"{sum(v['fvg_long'] for v in st_s3.values())} / 空 "
          f"{sum(v['fvg_short'] for v in st_s3.values())}）/ 触发 "
          f"{sum(v['triggered'] for v in st_s3.values())} / 填补作废 "
          f"{sum(v['filled'] for v in st_s3.values())} / 趋势否决 "
          f"{sum(v['trend_rejected'] for v in st_s3.values())} / 过期 "
          f"{sum(v['expired'] for v in st_s3.values())} / 信号 "
          f"{sum(v['signals'] for v in st_s3.values())} 个")
    print(f"[S3c] setup 统计（8 币合计）：FVG "
          f"{sum(v['fvg'] for v in st_s3c.values())} 个 / 触发 "
          f"{sum(v['triggered'] for v in st_s3c.values())} / 填补作废 "
          f"{sum(v['filled'] for v in st_s3c.values())} / 过期 "
          f"{sum(v['expired'] for v in st_s3c.values())} / 信号 "
          f"{sum(v['signals'] for v in st_s3c.values())} 个")
    run_family("S3", "R11-S3", {s: data1h[s][0] for s in SYMBOLS}, sig_s3,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               2, 8, 24, split_1h, "1h")
    print("\n=== S3c 对照：FVG 回补入场（无 4h 趋势过滤）===")
    run_family("S3c", "R11-S3c", {s: data1h[s][0] for s in SYMBOLS}, sig_s3c,
               {s: data1h[s][1] for s in SYMBOLS},
               [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
               2, 8, 24, split_1h, "1h")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for (fam, gran, wnames) in [
            ("S1", "1h", ["365d", "前185d", "后180d"]),
            ("S1c", "1h", ["365d", "前185d", "后180d"]),
            ("S2", "15m", ["103d", "前51d", "后52d"]),
            ("S2c", "1h(from15m)", ["103d", "前51d", "后52d"]),
            ("S3", "1h", ["365d", "前185d", "后180d"]),
            ("S3c", "1h", ["365d", "前185d", "后180d"])]:
        for wname in wnames:
            rs = [r for r in all_results if r["family"] == fam and r["granularity"] == gran
                  and r["split"] == wname]
            n_tr = sum(r["trades"] for r in rs)
            avg_t = sum(r["taker_net_pct"] for r in rs) / len(rs)
            avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
            avg_g = sum(r["gross_usdt"] for r in rs)
            avg_c = sum(r["taker_cost_sum"] for r in rs)
            print(f"[{fam} {gran} {wname}] 币均 Taker {avg_t*100:+.2f}% | "
                  f"M2 {avg_m2*100:+.2f}% | 笔数 {n_tr} | "
                  f"毛利合计 {avg_g:+.0f} | 成本合计 {avg_c:+.0f}")

    # ---- pooled t（全期逐笔，Taker）----
    print("\n=== Pooled t（全期逐笔，Taker，1x）===")
    for fam in ["S1", "S1c", "S2", "S2c", "S3", "S3c"]:
        pnls = pooled.get(fam, [])
        print(f"[{fam}] n={len(pnls)} pooled t={t_value(pnls)}")

    # ---- 写文件 ----
    out_sum = os.path.join(DATA_DIR, "gate_iter_round11_summary.json")
    out_tr = os.path.join(DATA_DIR, "gate_iter_round11_trades.csv")
    with open(out_sum, "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    if all_trades:
        keys = list(all_trades[0].keys())
        with open(out_tr, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(all_trades)
    print(f"\n写出：{out_sum}（{len(all_results)} 条）")
    print(f"写出：{out_tr}（{len(all_trades)} 笔）")


if __name__ == "__main__":
    main()
