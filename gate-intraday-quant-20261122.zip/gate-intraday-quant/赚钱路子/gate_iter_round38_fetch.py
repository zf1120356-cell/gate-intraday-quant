#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第三十八轮取数：S1 验证宇宙 12 个新币的 1h 365d / 资金费（Gate 公开接口）。
币种名单（跑前写死，见 盈利策略迭代-第三十八轮.md §0.3 与 data/gate_iter_round38_selection.json）：
  MMT, WLD, PIEVERSE, AVAX, KERNEL, PAXG, ARB, FIL, CYBER, TAO, ENA, INJ。
取数窗口：1h 2025-11-16~2026-11-16（8,760 根真实根）、资金费 2026-05-25 起
（接口 180 天保留期边界：2026-11-21 实测 from=2026-05-22 报
"from time exceeds 180-day limit"；from=2026-05-25 在边界上不稳定——
同一 URL curl 可取、脚本连续 3 次报 180 天错，取数脚本遇此错自动把起点
顺延 1 天重试；05-25 之前无数据按 0 计，与前轮同一约定——第 24 轮取数时
边界是 05-22，边界随时间推移，属接口保留期而非口径变更）。
取数方法照抄第二十四轮（7 天分片 from/to，不带 limit——limit 不能与 from/to 同用）。
资金费分片改 10 天（limit=100；4h 结算币种 30 天分片会超 100 条）。
粒度说明：15m × 365 天窗口不存在——2026-11-21 01:32 UTC 实测，
Gate /futures/usdt/candlesticks 对 15m 只允许最近 10,000 根回溯
（自 2026-08-06 起报 400 "Candlestick too long ago"），故本轮取 1h。
BTC 1h 365d 已有缓存（gate_1h_365d_BTC_USDT.csv）；MMT/WLD/PIEVERSE 的 1h
365d 缓存由分系统三十七轮的取数先行拉到（同接口同窗口），本脚本校验
根数后复用，不重复拉接口。
"""
import csv
import json
import os
import subprocess
import time
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
BASE = "https://api.gateio.ws/api/v4"

NEW_SYMBOLS = ["MMT_USDT", "WLD_USDT", "PIEVERSE_USDT", "AVAX_USDT",
               "KERNEL_USDT", "PAXG_USDT", "ARB_USDT", "FIL_USDT",
               "CYBER_USDT", "TAO_USDT", "ENA_USDT", "INJ_USDT"]

START_1H = datetime(2025, 11, 16, tzinfo=timezone.utc)
END_1H = datetime(2026, 11, 16, tzinfo=timezone.utc)
FUNDING_START = datetime(2026, 5, 25, tzinfo=timezone.utc)


def http_get_json(url, retries=3):
    for i in range(retries):
        try:
            out = subprocess.run(["curl", "-s", "--max-time", "60", url],
                                 capture_output=True, text=True, timeout=70)
            data = json.loads(out.stdout)
            if isinstance(data, dict) and "label" in data:
                raise ValueError(f"API error: {data}")
            return data
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles(contract, interval, start, end, path):
    bars = []
    cur = start
    while cur < end:
        nxt = min(cur + timedelta(days=7), end)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval={interval}"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get_json(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    bars = [b for b in bars
            if int(start.timestamp()) <= b["t"] < int(end.timestamp())]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] {interval} 已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}", flush=True)
    return bars


def fetch_funding(contract):
    # 本轮专属文件（_r38 后缀）：共享文件名 gate_funding_365d_{币}.json 正由分系统
    # 三十七轮的取数同时写入（其资金费自 2026-08-01 起），为避免竞写导致覆盖范围
    # 不确定，本轮资金费单独存 _r38 文件；数值与共享文件在重叠区间一致。
    path = os.path.join(DATA_DIR, f"gate_funding_365d_{contract}_r38.json")
    out = {}
    cur = FUNDING_START
    shifts = 0
    while cur < END_1H:
        nxt = min(cur + timedelta(days=10), END_1H)
        url = (f"{BASE}/futures/usdt/funding_rate?contract={contract}&limit=100"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        try:
            data = http_get_json(url)
        except ValueError as e:
            # 180 天边界不稳定（2026-11-21 实测：同一 from=2026-05-25，
            # curl 可取、脚本连续 3 次报 "from time exceeds 180-day limit"）：
            # 起点顺延 1 天重试，最多顺延 5 天；顺延部分按 0 计并记录。
            if "180-day" in str(e) and shifts < 5:
                shifts += 1
                print(f"[{contract}] 资金费起点 {cur.date()} 触 180 天边界，顺延 1 天（第 {shifts} 次）", flush=True)
                cur = cur + timedelta(days=1)
                continue
            raise
        for d in data:
            t = int(d["t"])
            t = (t // 28800) * 28800
            out[t] = float(d["r"])
        cur = nxt
        time.sleep(0.3)
    with open(path, "w") as f:
        json.dump(out, f)
    print(f"[{contract}] 资金费率已取：{len(out)} 条", flush=True)
    return out


def main():
    for sym in NEW_SYMBOLS:
        p1h = os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv")
        nlines = sum(1 for _ in open(p1h)) if os.path.exists(p1h) else 0
        # 8,761 行 = 8,760 真实根 + 表头；8,762 行 = 另含 2026-11-16 00:00 平值占位根
        if nlines not in (8761, 8762):
            fetch_candles(sym, "1h", START_1H, END_1H, p1h)
        else:
            print(f"[{sym}] 1h 用缓存（{nlines - 1} 根）", flush=True)
    for sym in NEW_SYMBOLS:
        pf = os.path.join(DATA_DIR, f"gate_funding_365d_{sym}_r38.json")
        if not os.path.exists(pf):
            fetch_funding(sym)
        else:
            print(f"[{sym}] 资金费率用缓存（_r38）", flush=True)
    print("全部取数完成。")


if __name__ == "__main__":
    main()
