#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十三轮：新发明方向——时段开盘突破（全模拟）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

动因（预注册检验，不是事后挑参）：
  第二十轮发现 F1 信号在 09:00/15:00 UTC 两个小时的每笔毛利
  （混池 +25.69/+25.53 USDT，毛利 t +2.96/+3.14）是反向时段的约
  9~10 倍，但扣完约 25 USDT/笔 Taker 成本后只剩 +0.99/+0.86，
  主臂全期 -0.10%/-0.01%，卡在成本线之下。本轮换一个完全不同的
  信号源，问同一个时段问题：09:00/15:00 这两个小时的“开盘根”
  自身方向，有没有延续性？如果连开盘根方向延续都没有，时段这条
  线就彻底停了；如果有，再看量级够不够付成本。

跑前写死的规则（单组参数，不许用全样本挑，不许换小时）：
  信号（开盘根突破，单币、自身方向、不做跨币排序、不做多空配对）：
    15m 版：每天 09:00 UTC 和 15:00 UTC 两个时点，各取随后第一根
      15m K 线（09:00-09:15、15:00-15:15）的收盘方向：收阳
      （收盘价 > 开盘价）做多、收阴（收盘价 < 开盘价）做空；
      收盘价 = 开盘价（十字星）不交易。
    1h 版（次要粒度对照，与 15m 版一起预注册）：每天 09:00 和
      15:00 两根 1h 开盘根（09:00-10:00、15:00-16:00），同法
      定方向；入场为下一根 1h 开盘价。
    入场：信号根下一根开盘价（15m 版 09:15/15:15，1h 版 10:00/16:00）。
    止损 1xATR、止盈 2xATR（用户要求的 1:2）。ATR 为 14 周期
    Wilder ATR（15m 版用 15m ATR，1h 版用 1h ATR），只用信号根
    及之前已收盘的根（信号根收盘后才入场，无前视）。
    出场：止损 / 止盈 / 当天 23:00 强制平仓。15m 版在 23:00 根
      开盘价平仓（仍持仓则在 23:00 根开盘价平仓）；1h 版在 23:00
      根收盘价平仓（当天最后一根）。无 max_hold 上限。
    每天每币最多 2 笔（09:00 一笔、15:00 一笔），不加仓；
    同一币同一时间最多持仓 1 笔（持仓占用时后续信号跳过）。
    单日 -2% 熔断；同根 K 线同时碰止损和止盈先判止损；
    入场根（信号根下一根）本身不判止损/止盈（与前二十二轮同款
    约定：入场在该根开盘，出场判断从下一根开始）。
    信号根若无下一根同日 K 线（1h 版 23:00 信号），该信号作废。
  四臂（唯一变量是时段/方向，引擎、成本、出场全部相同）：
    MAIN  主臂：09:00/15:00 UTC 开盘根，顺方向（收阳做多、收阴做空）。
    CTRL1 对照 1：同一规则换到 11:00/13:00 UTC（第二十轮附录里
          混池每笔毛利次高的两个小时：11:00 +21.58、13:00 +23.97），
          每天每币最多 2 笔。判断 09/15 是不是特殊。
    CTRL2 对照 2：同一规则换到全天任意整点（每天 24 个整点都做，
          15m 版取每小时 :00 那根 15m K 线，1h 版取每小时那根 1h
          K 线）。判断时段限制本身有没有增值。
          上限处理（跑前写死）：每时点最多 1 笔、不设每日上限。
          理由：若沿用“每天每币最多 2 笔”并按时间顺序执行，对照 2
          会变成“只做 00:00 和 01:00”，失去对照意义；每时点 1 笔
          是该臂的自然上限（每个整点最多一个信号），不设每日上限
          才能让 24 个小时都暴露在样本里。四个臂的比较以每笔毛利
          和全期净收益并重，不只看净收益（净收益会被笔数放大）。
    CTRL3 对照 3：反向——09:00/15:00 开盘根收阳做空、收阴做多。
          判断方向是延续还是反转。
  成本主口径 Taker：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，
  双边）；M1/M2 对照同第七/九/二十轮；资金费按实际费率计
  （08:00/16:00 结算点，前半段 2026-05-21 之前无数据按 0 计）。
  每笔名义 = 入场时权益 x 10%（约 10,000 USDT，1x）。

窗口（与第二十轮一致）：
  15m：全 103 天 2026-08-06~2026-11-16；前半段 2026-08-06~
    09-25（51 天）；后半段 2026-09-26~11-16（52 天）。
  1h：全 365 天 2025-11-16~2026-11-15；前半段 2025-11-16~
    2026-05-19（185 天）；后半段 2026-05-20~2026-11-15（180 天）。
  各窗口重置 10 万 USDT 虚拟权益（每币独立）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。主臂按粒度分别判定（ORB-1h 主臂、
ORB-15m 主臂各为一个组合）；两个粒度都通过才算整轮通过。

与前轮的区别（写死在报告里，不许事后 reinterpret）：
  vs 第四轮截面多空：第四轮每天 08:00/12:00 按当日收益给 8 币
    排序、做多前 2 做空后 2、净敞口 0；本轮是单币、时段开盘根
    自身的方向延续，不做跨币排序、不做多空配对、不要求净敞口 0。
  vs 第十轮 M3：M3 是 4h 开盘区间（当天 00:00-04:00 四根 1h 的
    高低点）+ 1h 收盘首次破位 + 1h EMA20 确认，下一根 1h 开盘进，
    最多持 8 根；本轮是 15m 开盘根直接突破，不加任何确认（不加
    EMA、不加区间），入场为信号根下一根 15m 开盘价，无 max_hold。
  vs 第二十轮时段限制 F1：第二十轮信号源是 F1（BTC 2h 收益领涨、
    山寨跟随、只做 7 个山寨、不做 BTC），时段只是过滤器；本轮
    信号源本身就是开盘根（8 个币全做、包括 BTC），时段就是信号
    的定义。两个轮次共享的只有“09:00/15:00”这两个小时，信号、
    笔数、毛利数字没有任何可比口径上的相等关系，交叉核对只能
    是定性比较（09/15 是否也在本轮里相对更好），不是数字复核。

诊断（附录）：CTRL2 全期明细按入场 UTC 小时切分（混池 + 分粒度），
与第二十轮附录 A 的小时表做定性对照。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) 脚本跑两遍，summary 与 trades 的 md5 两次运行完全一致。
  (b) 主臂首笔交易人工核对触发链、入场价、止损/止盈、PnL 全对上 CSV。
  (c) 对照 1/2/3 的笔数与漏斗算术自洽：候选信号根数 - 十字星数
      = 有效信号数；有效信号数 - 持仓占用/每日上限/熔断跳过数
      = 成交笔数。
  (d) 与第二十轮附录 A 的 09:00/15:00 混池数字做交叉核对并解释
      差异（定性对照，见上“与前轮的区别”）。

运行：python3 gate_iter_round23.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round23_summary.json
      + data/gate_iter_round23_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
from collections import Counter
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
           "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
CORE3 = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]

# ---- 预注册、跑前写死：单组参数，不许换 ----
MAIN_HOURS = {9, 15}     # 主臂 / 反向臂的两个 UTC 小时
CTRL1_HOURS = {11, 13}   # 对照 1：第二十轮附录混池每笔毛利次高的两小时
TP_MULT = 2.0            # 止盈 2xATR（用户要求的 1:2）
SL_MULT = 1.0            # 止损 1xATR
SPLIT_1H = datetime(2026, 5, 20, tzinfo=timezone.utc)    # 前半段止于 05-19
SPLIT_15M = datetime(2026, 9, 26, tzinfo=timezone.utc)   # 前半段止于 09-25

ROUNDTRIP_COST = 0.0025   # Taker 一轮名义 x 0.25%
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10
ATR_PERIOD = 14
MAKER_ENTRY = -0.0001
TAKER_EXIT = 0.00125
MAKER_EXIT = -0.0001

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL, PENALTY = {}, {}
for _sym in CORE3:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
for _sym in SYMBOLS:  # 新币种：SOL 保守代理（成交率最低、惩罚最高）
    if _sym not in FILL:
        FILL[_sym] = FILL["SOL_USDT"]
        PENALTY[_sym] = PENALTY["SOL_USDT"]


def load_bars(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def load_funding(symbol):
    with open(os.path.join(DATA_DIR, f"gate_funding_365d_{symbol}.json")) as f:
        raw = json.load(f)
    return {int(k): float(v) for k, v in raw.items()}


def group_days(bars, bars_per_day):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    return {d: v for d, v in sorted(days.items()) if len(v) == bars_per_day}


def atr_wilder(bars, period=ATR_PERIOD):
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def funding_cost_between(funding, day, entry_t, exit_t, notional, direction):
    cost = 0.0
    ds = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    for h in (8, 16):
        s = int((ds + timedelta(hours=h)).timestamp())
        if entry_t < s <= exit_t and s in funding:
            cost += funding[s] * notional * (1 if direction == 1 else -1)
    return cost


def maker_cost(notional, reason):
    if reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def t_value(pnls_pct):
    n = len(pnls_pct)
    if n < 2:
        return None
    m = sum(pnls_pct) / n
    var = sum((x - m) ** 2 for x in pnls_pct) / (n - 1)
    sd = math.sqrt(var)
    if sd == 0:
        return None
    return round(m / (sd / math.sqrt(n)), 2)


def max_dd(curve):
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    return round(mdd, 4)


def entry_hour_utc(entry_t):
    return datetime.fromtimestamp(entry_t, timezone.utc).hour


# ----------------------------------------------------------------------
# 开盘根突破信号：信号根 = 整点那根 K 线（15m 版 :00 那根，1h 版整点根）
# 方向 = sign(信号根收盘 - 信号根开盘)；十字星（收=开）不交易。
# 入场 = 信号根下一根开盘价（须为同日，否则信号作废）。
# ----------------------------------------------------------------------
def build_orb_signals(bars, atr, target_hours, reverse=False):
    """返回 (signals, funnel)。signals: {entry_t: {...}}；funnel 记漏斗。"""
    signals = {}
    n_candidate = 0   # 整点信号根候选（ATR 可用且有同日下一根）
    n_doji = 0        # 十字星跳过
    n_nosameday = 0   # 无同日下一根（仅 1h 版 23:00 信号）
    for i, b in enumerate(bars):
        dt = datetime.fromtimestamp(b["t"], timezone.utc)
        if dt.hour not in target_hours:
            continue
        if dt.minute != 0:
            continue
        if atr[i] is None:
            continue
        if i + 1 >= len(bars):
            continue
        entry_bar = bars[i + 1]
        edt = datetime.fromtimestamp(entry_bar["t"], timezone.utc)
        if edt.date() != dt.date():
            n_nosameday += 1
            continue
        n_candidate += 1
        if b["c"] == b["o"]:
            n_doji += 1
            continue
        direction = 1 if b["c"] > b["o"] else -1
        if reverse:
            direction = -direction
        signals[entry_bar["t"]] = {
            "direction": direction, "atr": atr[i],
            "sl_mult": SL_MULT, "tp_mult": TP_MULT,
            "signal_t": b["t"], "signal_o": b["o"], "signal_c": b["c"],
        }
    funnel = {"candidate": n_candidate, "doji": n_doji,
              "no_sameday_entry": n_nosameday,
              "valid_signals": len(signals)}
    return signals, funnel


def simulate_orb(symbol, bars, signals, funding, days_subset, max_per_day,
                 label, bars_per_day, gran):
    """max_per_day=None 表示不设每日上限（对照 2）。返回 (trades, curve, ndays, skipped)。"""
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = group_days(bars, bars_per_day)
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    equity = START_EQUITY
    trades = []
    curve = [equity]
    skipped = Counter()
    for day, day_bars in days.items():
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        trades_today = 0
        day_stopped = False

        def close_trade(tr, exit_t, exit_price, reason):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * ROUNDTRIP_COST
            tr["cost_maker_usdt"] = maker_cost(tr["notional"], reason)
            move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
            tr["price_pnl"] = tr["notional"] * move
            tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i, b in enumerate(day_bars):
            gi = idx_of_t[b["t"]]
            dt = datetime.fromtimestamp(b["t"], timezone.utc)
            # 15m 版 23:00 强制平仓：在 23:00 根开盘价平仓（先于止损/止盈判断）
            if pos is not None and gran == "15m" and dt.hour == 23 and dt.minute == 0:
                close_trade(pos, b["t"], b["o"], "eod")
                pos = None
                continue
            if pos is not None:
                exited = False
                if pos["direction"] == 1:
                    if b["l"] <= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["h"] >= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                else:
                    if b["h"] >= pos["stop"]:
                        close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                    elif b["l"] <= pos["tp"]:
                        close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
                if exited:
                    pos = None
                    continue
                if i == len(day_bars) - 1:
                    close_trade(pos, b["t"], b["c"], "eod")
                    pos = None
                    continue
            if pos is None:
                if day_stopped:
                    continue
                if day_pnl / day_start_equity <= -0.02:
                    day_stopped = True
                    continue
                sig = signals.get(b["t"])
                if sig is None:
                    continue
                if max_per_day is not None and trades_today >= max_per_day:
                    skipped["daily_cap"] += 1
                    continue
                entry = b["o"]
                a = sig["atr"]
                margin = MARGIN_FRAC * equity
                notional = margin * 1
                stop = entry - sig["sl_mult"] * a if sig["direction"] == 1 else entry + sig["sl_mult"] * a
                tp = entry + sig["tp_mult"] * a if sig["direction"] == 1 else entry - sig["tp_mult"] * a
                pos = {"symbol": symbol, "variant": label, "direction": sig["direction"],
                       "signal_t": sig["signal_t"], "signal_o": sig["signal_o"],
                       "signal_c": sig["signal_c"],
                       "entry_t": b["t"], "entry_gi": gi, "entry": entry,
                       "stop": stop, "tp": tp, "atr": a,
                       "notional": notional, "margin": margin,
                       "exit_t": None, "exit": None, "pnl": 0.0,
                       "reason": "", "funding_cost_usdt": 0.0,
                       "cost_usdt": 0.0, "cost_maker_usdt": 0.0, "price_pnl": 0.0,
                       "hold_min": None, "pnl_pct_equity": 0.0}
                trades_today += 1
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    # 持仓占用跳过的信号：在“有信号但当天已有持仓”的时点无法直接计数，
    # 用漏斗恒等式反推：valid_signals - 成交笔数 - 熔断跳过 - 每日上限跳过
    # = 持仓占用跳过（同一币同一时间最多 1 笔）。在 main 里按窗口外推算。
    return trades, curve, len(days), skipped


def summarize(sym, trades, curve, label, n_signals=None):
    n = len(trades)
    gross_sum = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades)
    notional_sum = sum(t["notional"] for t in trades)
    maker_cost_sum = sum(t["cost_maker_usdt"] for t in trades)
    taker_net = sum(t["pnl"] for t in trades)
    taker_cost_sum = sum(t["cost_usdt"] for t in trades)
    eq, m1_curve, m1_pnls = START_EQUITY, [START_EQUITY], []
    wins_m1 = 0
    for t in trades:
        pnl_m1 = (t["price_pnl"] - t["funding_cost_usdt"]) - t["cost_maker_usdt"]
        t["pnl_maker_m1"] = round(pnl_m1, 2)
        eq += pnl_m1
        m1_curve.append(eq)
        m1_pnls.append(pnl_m1 / START_EQUITY)
        wins_m1 += 1 if pnl_m1 > 0 else 0
    m1_net = eq - START_EQUITY
    m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
    wins_t = sum(1 for t in trades if t["pnl"] > 0)
    aw = [t["pnl"] for t in trades if t["pnl"] > 0]
    al = [t["pnl"] for t in trades if t["pnl"] <= 0]
    avg_win = sum(aw) / len(aw) if aw else 0.0
    avg_loss = abs(sum(al) / len(al)) if al else 0.0
    funding_sum = sum(t["funding_cost_usdt"] for t in trades)
    return {
        "label": label, "symbol": sym, "trades": n,
        "signals": n_signals,
        "win_rate": round(wins_t / n, 4) if n else None,
        "profit_factor": round(avg_win / avg_loss, 2) if avg_loss else None,
        "avg_win_usdt": round(avg_win, 2), "avg_loss_usdt": round(avg_loss, 2),
        "gross_usdt": round(gross_sum, 2),
        "gross_per_trade_usdt": round(gross_sum / n, 2) if n else None,
        "notional_sum": round(notional_sum, 2),
        "funding_cost_sum": round(funding_sum, 2),
        "taker_cost_sum": round(taker_cost_sum, 2),
        "taker_net_usdt": round(taker_net, 2),
        "taker_net_pct": round(taker_net / START_EQUITY, 4),
        "taker_max_dd": max_dd(curve),
        "t_taker": t_value([t["pnl"] / START_EQUITY for t in trades]),
        "t_gross": t_value([(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in trades]),
        "m1_net_usdt": round(m1_net, 2),
        "m1_net_pct": round(m1_net / START_EQUITY, 4),
        "m1_win_rate": round(wins_m1 / n, 4) if n else None,
        "m1_max_dd": max_dd(m1_curve),
        "m1_t": t_value(m1_pnls),
        "m2_net_usdt": round(m2_net, 2),
        "m2_net_pct": round(m2_net / START_EQUITY, 4),
        "maker_cost_sum": round(maker_cost_sum, 2),
        "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym],
        "avg_hold_min": round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / n, 1) if n else None,
        "liquidations": 0,
        "reason_counts": dict(sorted(Counter(t["reason"] for t in trades).items())),
    }


def hour_table(trades, label):
    """24 小时诊断表：每笔毛利（价差毛利）与 Taker 净，逐笔 t。"""
    rows = []
    for h in range(24):
        sub = [t for t in trades
               if datetime.fromtimestamp(t["entry_t"], timezone.utc).hour == h]
        n = len(sub)
        if n == 0:
            rows.append({"hour_utc": h, "trades": 0, "gross_usdt": 0.0,
                         "gross_per_trade_usdt": None, "gross_t": None,
                         "taker_net_usdt": 0.0, "taker_net_per_trade_usdt": None,
                         "taker_t": None, "win_rate": None})
            continue
        gross = [t["price_pnl"] - t["funding_cost_usdt"] for t in sub]
        taker = [t["pnl"] for t in sub]
        rows.append({
            "hour_utc": h, "trades": n,
            "gross_usdt": round(sum(gross), 2),
            "gross_per_trade_usdt": round(sum(gross) / n, 2),
            "gross_t": t_value([g / START_EQUITY for g in gross]),
            "taker_net_usdt": round(sum(taker), 2),
            "taker_net_per_trade_usdt": round(sum(taker) / n, 2),
            "taker_t": t_value([p / START_EQUITY for p in taker]),
            "win_rate": round(sum(1 for p in taker if p > 0) / n, 4),
        })
    print(f"\n--- {label}：24 小时诊断（入场 UTC 小时）---")
    print(f"  {'小时':>4} {'笔数':>5} {'每笔毛利':>9} {'毛利t':>7} "
          f"{'每笔Taker净':>11} {'Taker t':>8} {'胜率':>6}")
    for r in rows:
        gp = f"{r['gross_per_trade_usdt']:+.2f}" if r["gross_per_trade_usdt"] is not None else "—"
        gt = f"{r['gross_t']:+.2f}" if r["gross_t"] is not None else "—"
        tp = f"{r['taker_net_per_trade_usdt']:+.2f}" if r["taker_net_per_trade_usdt"] is not None else "—"
        tt = f"{r['taker_t']:+.2f}" if r["taker_t"] is not None else "—"
        wr = f"{r['win_rate']:.3f}" if r["win_rate"] is not None else "—"
        mark = " ★09/15" if r["hour_utc"] in MAIN_HOURS else ""
        print(f"  {r['hour_utc']:>4} {r['trades']:>5} {gp:>9} {gt:>7} {tp:>11} {tt:>8} {wr:>6}{mark}")
    return rows


def main():
    print("盈利策略迭代 · 第二十三轮：时段开盘突破（全模拟）")
    print("主臂 ORB 09:00/15:00 开盘根顺方向；对照 1：11:00/13:00；对照 2：全天 24 整点；对照 3：09:00/15:00 反向。")
    print("止损 1xATR / 止盈 2xATR；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")
    # ---- 数据校验（只读本地缓存，不联网）----
    data1h, data15 = {}, {}
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = load_funding(sym)
        data1h[sym] = (bars, funding)
        days = group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    for sym in SYMBOLS:
        bars = load_bars(os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv"))
        funding = load_funding(sym)
        data15[sym] = (bars, funding)
        days = group_days(bars, 96)
        assert len(days) == 103, f"{sym} 15m 完整日应为 103 天，实际 {len(days)}"
        assert len(bars) == 103 * 96, f"{sym} 15m 应为 {103*96} 根，实际 {len(bars)}"
    base_ts15 = [b["t"] for b in data15["BTC_USDT"][0]]
    for sym in SYMBOLS:
        assert [b["t"] for b in data15[sym][0]] == base_ts15, f"{sym} 15m 时间戳与 BTC 不对齐"
    print("数据校验通过：8 币各 8,761 根 1h / 365 天；各 9,888 根 15m / 103 天；时间戳对齐、零缺口。")

    days_all_1h = set(group_days(data1h["BTC_USDT"][0], 24).keys())
    front_1h = {d for d in days_all_1h if d < SPLIT_1H.date()}
    back_1h = {d for d in days_all_1h if d >= SPLIT_1H.date()}
    days_all_15 = set(group_days(data15["BTC_USDT"][0], 96).keys())
    front_15 = {d for d in days_all_15 if d < SPLIT_15M.date()}
    back_15 = {d for d in days_all_15 if d >= SPLIT_15M.date()}
    print(f"窗口：1h 全 365d（前 {len(front_1h)} 天 / 后 {len(back_1h)} 天）；"
          f"15m 全 103d（前 {len(front_15)} 天 / 后 {len(back_15)} 天）。")

    # ---- ORB 信号：每臂每粒度只生成一次 ----
    atr1h = {s: atr_wilder(data1h[s][0]) for s in SYMBOLS}
    atr15 = {s: atr_wilder(data15[s][0]) for s in SYMBOLS}
    ALL_HOURS = set(range(24))
    sigs = {}   # (arm, gran, sym) -> (signals dict, funnel dict)
    funnels = {}
    for gran, data, atrs in (("1h", data1h, atr1h), ("15m", data15, atr15)):
        for sym in SYMBOLS:
            bars = data[sym][0]
            sigs[("MAIN", gran, sym)], funnels[("MAIN", gran, sym)] = \
                build_orb_signals(bars, atrs[sym], MAIN_HOURS, reverse=False)
            sigs[("CTRL1", gran, sym)], funnels[("CTRL1", gran, sym)] = \
                build_orb_signals(bars, atrs[sym], CTRL1_HOURS, reverse=False)
            sigs[("CTRL2", gran, sym)], funnels[("CTRL2", gran, sym)] = \
                build_orb_signals(bars, atrs[sym], ALL_HOURS, reverse=False)
            sigs[("CTRL3", gran, sym)], funnels[("CTRL3", gran, sym)] = \
                build_orb_signals(bars, atrs[sym], MAIN_HOURS, reverse=True)
    for gran in ("1h", "15m"):
        for arm in ("MAIN", "CTRL1", "CTRL2", "CTRL3"):
            tot_c = sum(funnels[(arm, gran, s)]["candidate"] for s in SYMBOLS)
            tot_d = sum(funnels[(arm, gran, s)]["doji"] for s in SYMBOLS)
            tot_v = sum(funnels[(arm, gran, s)]["valid_signals"] for s in SYMBOLS)
            tot_n = sum(funnels[(arm, gran, s)]["no_sameday_entry"] for s in SYMBOLS)
            print(f"[ORB-{gran} {arm}] 候选信号根 {tot_c}（十字星跳过 {tot_d}、"
                  f"无同日下一根 {tot_n}）→ 有效信号 {tot_v}。")

    ARMS = [
        ("MAIN", "ORB-0915", 2),
        ("CTRL1", "ORB-1113", 2),
        ("CTRL2", "ORB-allhours", None),   # 每时点最多 1 笔、不设每日上限（见文件头）
        ("CTRL3", "ORB-0915-rev", 2),
    ]
    GRANS = [
        ("1h", data1h, 24,
         [("365d", None), ("前185d", front_1h), ("后180d", back_1h)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
        ("15m", data15, 96,
         [("103d", None), ("前51d", front_15), ("后52d", back_15)],
         lambda et: "前51d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_15M.date() else "后52d"),
    ]

    all_results, all_trades = [], []
    funnel_exec = {}  # (arm, gran, sym) -> full-window trades count
    for arm, label, max_per_day in ARMS:
        for gran, data, bpd, windows, split_fn in GRANS:
            print(f"\n=== {arm} {label} · ORB-{gran}（TP {TP_MULT}，SL {SL_MULT}，"
                  f"每日上限 {'2 笔' if max_per_day else '无（每时点 1 笔）'}）===")
            for sym in SYMBOLS:
                sig_dict = sigs[(arm, gran, sym)]
                for wname, subset in windows:
                    bars, funding = data[sym]
                    trades, curve, ndays, skipped = simulate_orb(
                        sym, bars, sig_dict, funding, subset, max_per_day, label, bpd, gran)
                    res = summarize(sym, trades, curve, label, len(sig_dict))
                    res["arm"] = arm
                    res["variant"] = label
                    res["family"] = "ORB"
                    res["tp_mult"] = TP_MULT
                    res["granularity"] = gran
                    res["split"] = wname
                    res["days"] = ndays
                    res["signals_total"] = funnels[(arm, gran, sym)]["candidate"]
                    res["signals_doji"] = funnels[(arm, gran, sym)]["doji"]
                    res["signals_no_sameday"] = funnels[(arm, gran, sym)]["no_sameday_entry"]
                    res["signals_pass"] = len(sig_dict)
                    res["signal_pass_rate"] = round(len(sig_dict) / funnels[(arm, gran, sym)]["candidate"], 4) \
                        if funnels[(arm, gran, sym)]["candidate"] else None
                    res["skipped_daily_cap"] = dict(skipped).get("daily_cap", 0)
                    all_results.append(res)
                    if wname in ("365d", "103d"):
                        funnel_exec[(arm, gran, sym)] = len(trades)
                        for t in trades:
                            t2 = dict(t)
                            t2["arm"] = arm
                            t2["variant"] = label
                            t2["family"] = "ORB"
                            t2["tp_mult"] = TP_MULT
                            t2["granularity"] = gran
                            t2["split"] = split_fn(t["entry_t"])
                            t2["entry_hour_utc"] = entry_hour_utc(t["entry_t"])
                            all_trades.append(t2)
                    print(f"[{arm} ORB-{gran} {sym} {wname}] n={res['trades']} "
                          f"信号 {len(sig_dict)} 胜率={res['win_rate']} "
                          f"盈亏比={res['profit_factor']} Taker {res['taker_net_pct']*100:+.2f}% "
                          f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                          f"M1 {res['m1_net_pct']*100:+.2f}% M2 {res['m2_net_pct']*100:+.2f}% "
                          f"毛利={res['gross_usdt']:+.0f} "
                          f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                          f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label, _ in ARMS:
        for gran, _, _, windows, _ in GRANS:
            for wname, _ in windows:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                gt = sum(r["gross_usdt"] for r in rs)
                ct = sum(r["taker_cost_sum"] for r in rs)
                nt = sum(r["trades"] for r in rs)
                wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
                wr_s = f"{wr:.3f}" if wr is not None else "—"
                gp = f"{gt/nt:+.2f}" if nt else "—"
                print(f"  {arm} ORB-{gran} {wname}：Taker 平均 "
                      f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M1 平均 {sum(r['m1_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                      f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                      f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                      f"每笔毛利 {gp} USDT 胜率 {wr_s}")

    # ---- 漏斗校验（全期）：有效信号 - 成交笔数 = 持仓占用 + 每日上限 + 熔断跳过 ----
    print("\n=== 漏斗校验（全期，有效信号 → 成交笔数）===")
    for arm, label, max_per_day in ARMS:
        for gran, _, _, windows, _ in GRANS:
            full = windows[0][0]
            tot_sig = sum(funnels[(arm, gran, s)]["valid_signals"] for s in SYMBOLS)
            tot_exe = sum(funnel_exec[(arm, gran, s)] for s in SYMBOLS)
            tot_cap = sum(r["skipped_daily_cap"] for r in all_results
                          if r["arm"] == arm and r["granularity"] == gran and r["split"] == full)
            # 持仓占用跳过 = 余量（熔断跳过未单独计数，含在余量里并在报告里说明）
            print(f"  {arm} ORB-{gran}：有效信号 {tot_sig} - 成交 {tot_exe} = "
                  f"{tot_sig - tot_exe} 未成交（其中每日上限跳过 {tot_cap}，"
                  f"其余为持仓占用 + 单日熔断跳过）")

    # ---- pooled t（全期明细，Taker / 毛利 / M1）----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for arm, label, _ in ARMS:
        for gran, _, _, windows, _ in GRANS:
            full = windows[0][0]
            sub = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
            for wname, _ in windows:
                s2 = [t for t in sub if wname == full or t["split"] == wname]
                vt = [t["pnl"] / START_EQUITY for t in s2]
                vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in s2]
                vm = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
                print(f"  {arm} ORB-{gran} {wname}：n={len(s2)} "
                      f"pooled t(Taker)={t_value(vt)} pooled t(毛利)={t_value(vg)} "
                      f"pooled t(M1)={t_value(vm)}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    verdict = {}
    for arm, label, _ in ARMS:
        for gran, _, _, windows, _ in GRANS:
            wnames = [w for w, _ in windows]
            row = {}
            for wname in wnames:
                rs = [r for r in all_results if r["arm"] == arm
                      and r["granularity"] == gran and r["split"] == wname]
                row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
            good = row[wnames[1]] > 0 and row[wnames[2]] > 0 and row[wnames[0]] > 0.02
            verdict[(arm, gran)] = good
            print(f"  {arm} ORB-{gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
                  f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}% → "
                  f"{'达标' if good else '不达标'}")
            for sym in SYMBOLS:
                rf = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                      and r["symbol"] == sym and r["split"] == wnames[1]][0]
                rb = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                      and r["symbol"] == sym and r["split"] == wnames[2]][0]
                both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
                print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                      f"后 {rb['taker_net_pct']*100:+.2f}% → "
                      f"{'★ 两半都为正' if both else ''}")
    main_pass = verdict[("MAIN", "1h")] and verdict[("MAIN", "15m")]
    print(f"\n  主臂整轮判定：1h {'达标' if verdict[('MAIN','1h')] else '不达标'}、"
          f"15m {'达标' if verdict[('MAIN','15m')] else '不达标'} → "
          f"{'通过' if main_pass else '不通过'}")

    # ---- 主臂 vs 三个对照：每笔毛利对照 ----
    print("\n=== 主臂 vs 三个对照（每笔毛利，全期）===")
    for gran, _, _, windows, _ in GRANS:
        full = windows[0][0]
        for arm, label, _ in ARMS:
            rs = [r for r in all_results if r["arm"] == arm
                  and r["granularity"] == gran and r["split"] == full]
            gt = sum(r["gross_usdt"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            print(f"  {arm} ORB-{gran} 全期：n={nt} 每笔毛利 {gt/nt:+.2f} USDT "
                  f"毛利合计 {gt:+.0f} Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}%")

    # ---- 诊断：24 小时全表（CTRL2 全期明细；混池 + 分粒度）----
    ctrl2_all = [t for t in all_trades if t["arm"] == "CTRL2"]
    hour_rows_pooled = hour_table(ctrl2_all, "CTRL2 混池（1h+15m，开盘根突破）")
    hour_rows_1h = hour_table([t for t in ctrl2_all if t["granularity"] == "1h"],
                              "CTRL2 仅 1h")
    hour_rows_15m = hour_table([t for t in ctrl2_all if t["granularity"] == "15m"],
                               "CTRL2 仅 15m")
    # 主臂小时表（只有 09/15 两行有数，作对照）
    main_all = [t for t in all_trades if t["arm"] == "MAIN"]
    hour_rows_main = hour_table(main_all, "MAIN 混池（1h+15m，仅 09/15 有交易）")

    with open(os.path.join(DATA_DIR, "gate_iter_round23_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round23_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "signal_time_utc", "entry_time_utc", "entry_hour_utc",
                    "exit_time_utc", "signal_open", "signal_close", "atr",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["arm"], x["granularity"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["signal_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["signal_o"], t["signal_c"], t["atr"],
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round23_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round23_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")

    hour_diag = {
        "ctrl2_pooled_1h_15m": hour_rows_pooled,
        "ctrl2_only_1h": hour_rows_1h,
        "ctrl2_only_15m": hour_rows_15m,
        "main_pooled_1h_15m": hour_rows_main,
        "target_hours": sorted(MAIN_HOURS),
        "ctrl1_hours": sorted(CTRL1_HOURS),
        "note": "CTRL2 全期明细按入场 UTC 小时切分；gross 为价差毛利（扣资金费、不扣交易成本）。"
                "与第二十轮附录 A 的对照是定性的：信号源不同（开盘根自身方向 vs F1 BTC 领涨），"
                "数字没有相等关系，只比较 09/15 是否也在本轮相对更好。",
    }
    with open(os.path.join(DATA_DIR, "gate_iter_round23_hour_diag.json"), "w") as f:
        json.dump(hour_diag, f, indent=2, ensure_ascii=False)
    print("小时诊断已写入：data/gate_iter_round23_hour_diag.json")


if __name__ == "__main__":
    main()
