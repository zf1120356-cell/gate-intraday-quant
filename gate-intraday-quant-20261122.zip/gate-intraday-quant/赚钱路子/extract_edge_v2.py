#!/usr/bin/env python3
"""盈利优势提取 · 第二版汇总脚本（第十七到第二十八轮）

范围：第十七（QM）、十八（Breaker）、十九（SMT 任务书版）、二十（时段限制 F1）、
二十一（SMT 笔记原文版）、二十二（执行层 Maker 实测，summary 为 dict 结构，
本脚本只读其 tiers 数字）、二十三（时段开盘突破）、二十四（新币种泛化）、
二十五（跨所领涨 OKX）、二十六（工作日/周末）、二十七（日开盘区间突破）、
二十八（淡化上破·新币种检验）。
不含：第 1-10 轮、第五轮资金费率套利、第十三轮、第十一至十六轮（见第一版）。

读 data/gate_iter_round{17..28}_summary.json，输出总表数字。
口径与第一版一致：每币独立 10 万 USDT、1x；主口径 Taker（双边约 25 USDT/笔）；
M1 = Maker 100% 成交上界，M2 = Maker 混合现实口径；
币均 % = 各币净 USDT 之和 / (币数 × 100,000)；
毛利 = 价差盈亏 - 资金费（不扣交易成本）；毛利/成本 = 毛利 / Taker 成本合计；
盈亏平衡线约每笔毛利 +25 USDT。
用法：python3 extract_edge_v2.py
"""
import json
import os
from collections import defaultdict

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
ROUNDS = {r: f"gate_iter_round{r}_summary.json" for r in range(17, 29)}
EQUITY_PER_COIN = 100_000.0


def is_full(split):
    s = str(split or "")
    return bool(s) and "前" not in s and "后" not in s


# 第28轮的淡化上破 label（ORB-day-fade-up）把新 12 币主臂（2,088 笔）与原 8 币
# 对照（1,392 笔）写在同一个 label 下，summary.json 里只能按币种集合拆分。
# 其余轮次的 label 本身已区分臂/宇宙，不受此影响。
R28_NEW12 = {
    "ZEC_USDT", "EVAA_USDT", "HYPE_USDT", "LTC_USDT", "BLESS_USDT",
    "XLM_USDT", "AKE_USDT", "NEAR_USDT", "PEPE_USDT", "UNI_USDT",
    "SUI_USDT", "XAUT_USDT",
}


def combo_key(rnd, r):
    key = (r.get("label"), r.get("granularity"))
    if rnd == 28 and r.get("label") == "ORB-day-fade-up":
        key = key + (("新12币" if r.get("symbol") in R28_NEW12 else "原8币"),)
    return key


def gross_pt(r):
    if r.get("gross_per_trade_usdt") is not None:
        return r["gross_per_trade_usdt"]
    if r.get("gross_usdt") is not None and r.get("trades"):
        return r["gross_usdt"] / r["trades"]
    return None


def load_summary(fname):
    with open(os.path.join(BASE, fname), encoding="utf-8") as f:
        return json.load(f)


def main():
    print("# 盈利优势提取 · 第二版脚本复现总表（第十七到第二十八轮）")
    print("# 币均% = 合计净 USDT / (币数 x 100000)；毛利/成本 = 毛利合计 / Taker 成本合计")
    print()
    all_full_rows = []
    for rnd, fname in sorted(ROUNDS.items()):
        d = load_summary(fname)
        if isinstance(d, dict):
            # 第22轮：dict 结构，tiers 数字见报告正文，这里只打印关键层
            print(f"== 第{rnd}轮 {fname}：dict 结构（执行层专项，见报告）")
            tiers = d.get("tiers", {})
            for arm, tv in tiers.items():
                print(f"  [tiers] {arm}: {json.dumps(tv, ensure_ascii=False)[:400]}")
            tau = d.get("tau", {})
            print(f"  [tau] {json.dumps(tau, ensure_ascii=False)[:400]}")
            print(f"  [verdict] {json.dumps(d.get('verdict'), ensure_ascii=False)[:400]}")
            print()
            continue
        full = [r for r in d if is_full(r.get("split"))]
        all_full_rows.extend(full)
        print(f"== 第{rnd}轮 {fname}：全期行 {len(full)}")
        groups = defaultdict(list)
        for r in full:
            groups[combo_key(rnd, r)].append(r)
        for key, rs in sorted(groups.items(), key=lambda kv: str(kv[0])):
            lab = " ".join(str(x) for x in key)
            n = sum(r.get("trades", 0) or 0 for r in rs)
            gross = sum(r.get("gross_usdt", 0) or 0 for r in rs)
            tc = sum(r.get("taker_cost_sum", 0) or 0 for r in rs)
            tak = sum(r.get("taker_net_usdt", 0) or 0 for r in rs)
            m1 = sum(r.get("m1_net_usdt", 0) or 0 for r in rs)
            m2 = sum(r.get("m2_net_usdt", 0) or 0 for r in rs)
            ncoins = len({r.get("symbol") for r in rs})
            denom = ncoins * EQUITY_PER_COIN
            print(
                f"  [组合] {lab}: n={n} 毛利={gross:.0f} 每笔毛利={gross / n if n else 0:.2f} "
                f"毛利/成本={gross / tc if tc else float('nan'):.3f} "
                f"Taker币均={tak / denom * 100:.2f}% M1币均={m1 / denom * 100:.2f}% "
                f"M2币均={m2 / denom * 100:.2f}%"
            )
        print("  [单币全期 Taker>0]")
        for r in sorted(full, key=lambda x: -(x.get("taker_net_pct") or 0)):
            if (r.get("taker_net_pct") or 0) > 0:
                print(
                    f"    {r.get('label')} {r.get('granularity')} {r.get('symbol')} n={r.get('trades')} "
                    f"Taker={r['taker_net_pct'] * 100:.2f}% t_taker={r.get('t_taker')} "
                    f"M1={(r.get('m1_net_pct') or 0) * 100:.2f}% m1_t={r.get('m1_t')} "
                    f"毛利/笔={gross_pt(r)} 毛利/成本={(r.get('gross_usdt') or 0) / (r.get('taker_cost_sum') or 1):.3f}"
                )
        print("  [单币全期 M1>0 且 n>=20]")
        for r in sorted(full, key=lambda x: -(x.get("m1_net_pct") or 0)):
            if (r.get("m1_net_pct") or 0) > 0 and (r.get("trades") or 0) >= 20:
                print(
                    f"    {r.get('label')} {r.get('granularity')} {r.get('symbol')} n={r.get('trades')} "
                    f"M1={r['m1_net_pct'] * 100:.2f}% m1_t={r.get('m1_t')} "
                    f"Taker={r.get('taker_net_pct') * 100:.2f}% 毛利/笔={gross_pt(r)}"
                )
        groups2 = defaultdict(dict)
        for r in d:
            groups2[(r.get("label"), r.get("granularity"), r.get("symbol"))][str(r.get("split"))] = r
        print("  [前后两半都为正的币x组合格子]")
        for (lab, gran, sym), mp in sorted(groups2.items(), key=lambda kv: str(kv[0])):
            pre = [v for k, v in mp.items() if "前" in k]
            post = [v for k, v in mp.items() if "后" in k]
            if not pre or not post:
                continue
            for field in ("taker_net_pct", "m1_net_pct", "m2_net_pct"):
                pv, qv = pre[0].get(field), post[0].get(field)
                if pv is not None and qv is not None and pv > 0 and qv > 0:
                    print(
                        f"    {lab} {gran} {sym} {field} 前 n={pre[0].get('trades')} "
                        f"{pv * 100:.2f}% / 后 n={post[0].get('trades')} {qv * 100:.2f}%"
                    )
        print()

    n_pos_taker = sum(1 for r in all_full_rows if (r.get("taker_net_pct") or 0) > 0)
    print(f"全范围（17-28轮，含第22轮除外）全期行总数={len(all_full_rows)}，"
          f"其中 Taker 为正的单币行={n_pos_taker}")
    print()
    # 全期 Taker 为正但 n<5 的行（另标，不单独成行）
    print("== n<5 的 Taker 为正全期行（已筛出，不单独成行）")
    for r in sorted(all_full_rows, key=lambda x: -(x.get("taker_net_pct") or 0)):
        if (r.get("taker_net_pct") or 0) > 0 and (r.get("trades") or 0) < 5:
            print(
                f"  {r.get('label')} {r.get('granularity')} {r.get('symbol')} n={r.get('trades')} "
                f"Taker={r['taker_net_pct'] * 100:.2f}% t={r.get('t_taker')} 毛利/笔={gross_pt(r)}"
            )


if __name__ == "__main__":
    main()
