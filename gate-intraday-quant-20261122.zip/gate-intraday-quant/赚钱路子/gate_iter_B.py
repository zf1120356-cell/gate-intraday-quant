#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
迭代 B：Maker 执行实测（全模拟，不下单、不开户、不碰真钱）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约。

任务：
  1. 取 Gate 1 分钟 K 线（公开接口 GET /futures/usdt/candlesticks，
     interval=1m），实测能取到的窗口与接口限制。
  2. 用 1m 数据实测挂单成交率和逆向选择：信号价挂限价单，之后
     若干根内价格是否触及、触及后价格继续往不利方向走多少。
  3. 把实测结果套到 S3 低换手策略（Gate新策略研究.md，221 笔）上：
     Taker 版 / Maker 100% 成交版 / Maker 实测成交率版三档净收益。

运行：python3 gate_iter_B.py
输出：终端打印全部表 + data/gate_iter_B_summary.json
      + data/gate_1m_7d_{BTC,ETH,SOL}_USDT.csv（本次取到的 1m 原始数据）
"""
import csv
import json
import math
import os
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_new_strategies as gns  # 复用 S3 的 run_single / rsi / atr（30m 口径）

BASE = "https://api.gateio.ws/api/v4/futures/usdt/candlesticks"
SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
FETCH_TS = datetime.now(timezone.utc)

# ---- 接口限制（本次实测得到，写死在代码里当作记录）----
# limit 上限 = 2000（2001/2500/3000/5000 均报 400 Invalid request parameter
# `limit` value）；from 再往前推超过最近 10000 根即报 400
# "Candlestick too long ago. Maximum 10000 points recently are allowed"。
# 因此 1m 理论最长窗口 = 10000 分钟 ≈ 6.94 天，且必须用 from 分页取。
LIMIT_MAX = 2000
MAX_POINTS = 10000


def fetch_page(contract, interval, limit, frm=None):
    url = f"{BASE}?contract={contract}&interval={interval}&limit={limit}"
    if frm is not None:
        url += f"&from={frm}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)


def fetch_1m(contract):
    """往回分页取到最近 10000 根 1m K 线。返回 (bars, notes)。"""
    notes = []
    bars = []
    # 第 1 页：最近 2000 根
    page = fetch_page(contract, "1m", LIMIT_MAX)
    bars.extend(page)
    notes.append(f"page1: {len(page)} bars, "
                 f"{datetime.fromtimestamp(min(b['t'] for b in page), timezone.utc)}"
                 f" -> {datetime.fromtimestamp(max(b['t'] for b in page), timezone.utc)}")
    # 往回翻：每页 from = 已取最早时间 - 2000 分钟
    while len(bars) < MAX_POINTS:
        earliest = min(b["t"] for b in bars)
        frm = earliest - LIMIT_MAX * 60
        try:
            page = fetch_page(contract, "1m", LIMIT_MAX, frm=frm)
        except urllib.error.HTTPError as e:
            notes.append(f"pagination stopped at {len(bars)} bars: HTTP {e.code} "
                         f"{e.read().decode()[:160]}")
            break
        new = [b for b in page if b["t"] < earliest]
        if not new:
            notes.append(f"pagination stopped at {len(bars)} bars: empty page")
            break
        bars.extend(new)
        notes.append(f"page from={datetime.fromtimestamp(frm, timezone.utc)}: "
                     f"{len(new)} new bars")
    bars.sort(key=lambda b: b["t"])
    # API 返回的价格/量是字符串，转成数值
    for b in bars:
        for k in ("o", "h", "l", "c", "v", "sum"):
            b[k] = float(b[k])
    # 去重 + 连续性检查
    seen, dedup = set(), []
    for b in bars:
        if b["t"] not in seen:
            seen.add(b["t"])
            dedup.append(b)
    gaps = [(a["t"], c["t"]) for a, c in zip(dedup, dedup[1:])
            if c["t"] - a["t"] != 60]
    return dedup, notes, gaps


def save_csv(bars, path):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t", "o", "h", "l", "c", "v", "sum"])
        for b in bars:
            w.writerow([b["t"], b["o"], b["h"], b["l"], b["c"], b["v"], b["sum"]])


def load_1m(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
             "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
             "sum": float(r["sum"])} for r in rows]
    bars.sort(key=lambda b: b["t"])
    return bars


def aggregate_30m(bars_1m):
    """1m 聚合成 30m（o=首根开，h=最高，l=最低，c=末根收，v=求和）。"""
    out = []
    cur = None
    for b in bars_1m:
        slot = (b["t"] // 1800) * 1800
        if cur is None or cur["t"] != slot:
            if cur is not None:
                out.append(cur)
            cur = {"t": slot, "o": b["o"], "h": b["h"], "l": b["l"],
                   "c": b["c"], "v": b["v"], "sum": b["sum"]}
        else:
            cur["h"] = max(cur["h"], b["h"])
            cur["l"] = min(cur["l"], b["l"])
            cur["c"] = b["c"]
            cur["v"] += b["v"]
            cur["sum"] += b["sum"]
    if cur is not None:
        out.append(cur)
    return out


# ---------------------------------------------------------------- 2. 通用挂单实测
def generic_fill_test(bars_1m, offsets=(0.0, 0.0002, 0.0005, 0.001),
                      windows=(30, 120), post_min=30):
    """信号 = 每个 30m 对齐 bar 的收盘价；双向各挂一单（买限价在收盘价
    下方 d、卖限价在收盘价上方 d）。统计触及率、触及耗时、触及后 30 分钟
    的逆向 excursion 与漂移，并与全体信号的 taker 等价漂移对比。"""
    idx = {b["t"]: i for i, b in enumerate(bars_1m)}
    closes = [b["c"] for b in bars_1m]
    res = {}
    for d in offsets:
        for W in windows:
            filled, missed = [], []
            for i, b in enumerate(bars_1m):
                if b["t"] % 1800 != 0:      # 只取 :00 / :30 对齐的 bar 收盘
                    continue
                if i + max(W, post_min) + 1 >= len(bars_1m):
                    continue
                for direction in (1, -1):    # 1=买限价，-1=卖限价
                    limit = b["c"] * (1 - direction * d) if direction == 1 \
                        else b["c"] * (1 + d)
                    # taker 等价漂移：信号价持有 30 分钟（方向收益）
                    taker_drift = direction * (closes[i + post_min] - b["c"]) / b["c"]
                    fill_i = None
                    for k in range(i + 1, i + W + 1):
                        bk = bars_1m[k]
                        touched = (bk["l"] <= limit) if direction == 1 else (bk["h"] >= limit)
                        if touched and bk["v"] > 0:
                            fill_i = k
                            break
                    if fill_i is None:
                        missed.append({"taker_drift": taker_drift})
                        continue
                    # 触及后 30 分钟：逆向 excursion 与漂移
                    seg = bars_1m[fill_i + 1: fill_i + 1 + post_min]
                    if len(seg) < post_min:
                        continue
                    if direction == 1:
                        adv_exc = (limit - min(s["l"] for s in seg)) / limit
                    else:
                        adv_exc = (max(s["h"] for s in seg) - limit) / limit
                    post_drift = direction * (seg[-1]["c"] - limit) / limit
                    filled.append({"taker_drift": taker_drift,
                                   "post_drift": post_drift,
                                   "adv_exc": adv_exc,
                                   "mins_to_fill": fill_i - i})
            if filled or missed:
                n = len(filled) + len(missed)
                mean_taker_all = sum(x["taker_drift"] for x in filled + missed) / n
                mean_taker_filled = (sum(x["taker_drift"] for x in filled) / len(filled)
                                     if filled else None)
                mean_post = (sum(x["post_drift"] for x in filled) / len(filled)
                             if filled else None)
                # 逆向选择惩罚 = 全体信号的 30m 漂移 - 已成交单触及后 30m 漂移
                penalty = (mean_taker_all - mean_post) if mean_post is not None else None
                res[(d, W)] = {
                    "n_signals": n, "n_filled": len(filled),
                    "fill_rate": round(len(filled) / n, 4) if n else None,
                    "median_mins_to_fill": sorted(x["mins_to_fill"] for x in filled)[len(filled) // 2] if filled else None,
                    "mean_taker_drift_all": round(mean_taker_all, 5),
                    "mean_taker_drift_filled": round(mean_taker_filled, 5) if mean_taker_filled is not None else None,
                    "mean_post_fill_drift_30m": round(mean_post, 5) if mean_post is not None else None,
                    "mean_adverse_excursion_30m": round(sum(x["adv_exc"] for x in filled) / len(filled), 5) if filled else None,
                    "adverse_penalty_frac": round(penalty, 5) if penalty is not None else None,
                    "frac_filled_with_adv_exc_over_0.1pct": round(sum(1 for x in filled if x["adv_exc"] >= 0.001) / len(filled), 4) if filled else None,
                    "mean_taker_drift_missed": round(sum(x["taker_drift"] for x in missed) / len(missed), 5) if missed else None,
                }
    return res


# ---------------------------------------------------------------- 3. S3 180 天三档
def s3_tiers(trades_180d):
    """trades_180d: run_single('S3-rsi') 全 180 天的 trades（已含 price_pnl、
    funding_cost_usdt、cost_usdt、notional）。
    返回每币三档（Taker / Maker100 / Maker实测）所需的每笔均值。"""
    out = {}
    for sym in SYMBOLS:
        ts = [t for t in trades_180d if t["symbol"] == sym]
        n = len(ts)
        gross = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in ts)  # 毛利（扣资金费）
        cost_taker = sum(t["cost_usdt"] for t in ts)
        mean_notional = sum(t["notional"] for t in ts) / n if n else 0.0
        out[sym] = {
            "n": n,
            "gross_usdt": round(gross, 2),
            "mean_gross_per_trade_usdt": round(gross / n, 2) if n else None,
            "cost_taker_usdt": round(cost_taker, 2),
            "mean_notional": round(mean_notional, 2),
            "net_taker_usdt": round(gross - cost_taker, 2),
            "net_taker_pct": round((gross - cost_taker) / 100000, 4),
            # Maker 100%：一轮成本 = 名义 x (-0.02%)，即每笔倒赚 0.02% 名义
            "net_maker100_usdt": round(gross + 0.0002 * sum(t["notional"] for t in ts), 2),
            "net_maker100_pct": round((gross + 0.0002 * sum(t["notional"] for t in ts)) / 100000, 4),
        }
    return out


def apply_measured(s3, fill, penalty_frac, exit_mode):
    """把实测成交率 f 与逆向选择惩罚套到 S3 上。
    exit_mode: 'maker' = 出场也按 Maker 返佣计（-0.01%/边）；
               'taker' = 出场按 Taker 计（0.075% 费 + 0.05% 滑点 = 0.125%/边），
               入场 Maker 返佣 -0.01%。只计成交的 f*N 笔，错失的计 0。"""
    out = {}
    for sym in SYMBOLS:
        s = s3[sym]
        n, g_mean = s["n"], s["mean_gross_per_trade_usdt"]
        mn = s["mean_notional"]
        penalty_usdt = penalty_frac * mn            # 每笔成交交易的毛利折损
        filled_gross = g_mean - penalty_usdt        # 成交交易的期望毛利
        if exit_mode == "maker":
            cost_per_filled = -0.0002 * mn          # 一轮 Maker：倒赚
        else:
            cost_per_filled = (-0.0001 + 0.00125) * mn  # 入场返佣 + 出场 Taker
        per_filled_net = filled_gross - cost_per_filled
        net = fill * n * per_filled_net
        out[sym] = {
            "fill_rate": fill, "penalty_frac": penalty_frac,
            "penalty_usdt_per_filled": round(penalty_usdt, 2),
            "filled_gross_per_trade_usdt": round(filled_gross, 2),
            "cost_per_filled_usdt": round(cost_per_filled, 2),
            "net_per_filled_trade_usdt": round(per_filled_net, 2),
            "expected_filled_trades": round(fill * n, 1),
            "net_usdt": round(net, 2),
            "net_pct": round(net / 100000, 4),
        }
    return out


def main():
    print("迭代 B：Maker 执行实测（全模拟）")
    print(f"取数时间（UTC）：{FETCH_TS.strftime('%Y-%m-%d %H:%M:%S')}")
    print("接口：GET https://api.gateio.ws/api/v4/futures/usdt/candlesticks")
    print("实测限制：limit 上限 2000（2001+ 报 400）；from 超过最近 10000 根"
          " 报 400 'Candlestick too long ago'；1m 最长窗口 ≈ 6.94 天；"
          "tick 数据无公开接口，取不到。")
    summary = {"fetch_time_utc": FETCH_TS.isoformat(), "symbols": {}}
    bars_1m_all = {}

    # ---- 1. 取 1m ----
    for sym in SYMBOLS:
        bars, notes, gaps = fetch_1m(sym)
        # 剔除最后一根（取数时刻未走完的进行中 bar）
        dropped_last = bars[-1]
        bars = bars[:-1]
        zero_vol = sum(1 for b in bars if b["v"] == 0)
        path = os.path.join(DATA_DIR, f"gate_1m_7d_{sym}.csv")
        save_csv(bars, path)
        bars_1m_all[sym] = bars
        first = datetime.fromtimestamp(bars[0]["t"], timezone.utc)
        last = datetime.fromtimestamp(bars[-1]["t"], timezone.utc)
        print(f"\n[{sym}] 1m：{len(bars)} 根，{first} ~ {last} UTC "
              f"（约 {(bars[-1]['t'] - bars[0]['t']) / 86400:.2f} 天），"
              f"零成交量分钟 {zero_vol} 根，缺口 {len(gaps)} 处")
        for nt in notes:
            print(f"    {nt}")
        print(f"    剔除未走完末根 t={datetime.fromtimestamp(dropped_last['t'], timezone.utc)}"
              f"（v={dropped_last['v']}）；落盘 {path}")
        summary["symbols"][sym] = {
            "n_1m": len(bars),
            "first_utc": first.isoformat(), "last_utc": last.isoformat(),
            "zero_volume_bars": zero_vol, "gaps": len(gaps), "fetch_notes": notes,
        }

    # ---- 2. 通用挂单实测 ----
    print("\n=== 2. 通用挂单实测：每 30m 收盘价挂限价单（双向，1m 判定触及）===")
    print("读法：fill_rate=触及率；adverse_penalty=全体信号 30m 漂移 - 已成交单"
          "触及后 30m 漂移（>0 说明成交的单子事后走势更差，即逆向选择）；"
          "adv_exc=触及后 30m 内价格继续往不利方向走的最大幅度。")
    fill_all = {}
    for sym in SYMBOLS:
        res = generic_fill_test(bars_1m_all[sym])
        fill_all[sym] = res
        print(f"\n[{sym}]")
        for (d, W), r in sorted(res.items()):
            print(f"  偏移 {d*100:.2f}% / 窗口 {W} 分钟：n={r['n_signals']} "
                  f"成交率={r['fill_rate']*100:.1f}% 中位耗时={r['median_mins_to_fill']}分钟 "
                  f"全体漂移={r['mean_taker_drift_all']*100:+.3f}% "
                  f"成交后漂移={r['mean_post_fill_drift_30m']*100:+.3f}% "
                  f"逆向惩罚={r['adverse_penalty_frac']*100:+.3f}% "
                  f"逆向 excursion={r['mean_adverse_excursion_30m']*100:.3f}% "
                  f"（>{0.1}% 的占 {r['frac_filled_with_adv_exc_over_0.1pct']*100:.0f}%） "
                  f"错失单漂移={r['mean_taker_drift_missed']*100:+.3f}%")
        summary["symbols"][sym]["generic_fill"] = {
            f"offset_{d}_window_{W}": r for (d, W), r in res.items()}

    # ---- 2b. S3 在 1m 窗口内的信号：1m 实测成交 ----
    print("\n=== 2b. S3 在 1m 窗口内（1m 聚合 30m 后重跑）的信号成交实测 ===")
    s3_1m_trades = {}
    for sym in SYMBOLS:
        bars30 = aggregate_30m(bars_1m_all[sym])
        # 只保留完整交易日（48 根）；funding 置空（7 天窗口内资金费影响 <0.01%）
        res, trades = gns.run_single(bars30, {}, sym, None, "S3-rsi",
                                     leverage=1, max_trades_day=2, label="S3-rsi-1mwin")
        idx = {b["t"]: i for i, b in enumerate(bars_1m_all[sym])}
        rows = []
        for t in trades:
            ei = idx.get(t["entry_t"])
            if ei is None:
                continue
            direction = t["direction"]
            filled, mins = False, None
            for k in range(ei, min(ei + 60, len(bars_1m_all[sym]))):
                bk = bars_1m_all[sym][k]
                touched = (bk["l"] <= t["entry"]) if direction == 1 else (bk["h"] >= t["entry"])
                if touched and bk["v"] > 0:
                    filled, mins = True, k - ei
                    break
            rows.append({"entry_time": datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                         "direction": "LONG" if direction == 1 else "SHORT",
                         "entry": t["entry"], "filled_60m": filled,
                         "mins_to_fill": mins, "taker_pnl_usdt": round(t["pnl"], 2)})
        s3_1m_trades[sym] = rows
        nfill = sum(1 for r in rows if r["filled_60m"])
        print(f"[{sym}] 30m 聚合 {len(bars30)} 根，完整日 {res['days']} 天，"
              f"S3 信号 {len(rows)} 笔，60 分钟内触及 {nfill} 笔 "
              f"（{nfill / len(rows) * 100:.0f}%）" if rows else f"[{sym}] S3 信号 0 笔")
        for r in rows:
            print(f"    {r['entry_time']} {r['direction']} entry={r['entry']} "
                  f"filled60m={r['filled_60m']} mins={r['mins_to_fill']} "
                  f"taker_pnl={r['taker_pnl_usdt']:+.2f} USDT")
        summary["symbols"][sym]["s3_1m_window"] = {
            "n_30m_bars": len(bars30), "days": res["days"],
            "trades": rows, "fill_rate_60m": (nfill / len(rows) if rows else None)}

    # ---- 3. S3 180 天重跑 + 三档 ----
    print("\n=== 3. S3 180 天重跑（30m 缓存数据）与三档净收益 ===")
    trades_180d = []
    for sym in SYMBOLS:
        bars = gns.load_bars(sym)
        funding = gns.load_funding(sym)
        res, trades = gns.run_single(bars, funding, sym, None, "S3-rsi",
                                     leverage=1, max_trades_day=2, label="S3-rsi")
        trades_180d.extend(trades)
        print(f"[{sym}] 重跑：{res['trades']} 笔 胜率={res['win_rate']} "
              f"净收益={res['net_return']*100:+.2f}%（报告值："
              f"{'BTC -1.86%' if sym=='BTC_USDT' else 'ETH -2.18%' if sym=='ETH_USDT' else 'SOL -0.79%'}）")
    s3 = s3_tiers(trades_180d)
    print("\n三档口径：Taker 一轮名义 x 0.25%；Maker100 一轮名义 x -0.02%"
          "（返佣，100% 成交、无滑点假设）；Maker 实测用 1m 通用测试"
          " d=0 / 30 分钟窗口的成交率与逆向惩罚，错失的单计 0。")
    # 主实测参数：d=0、W=30 的成交率与惩罚（三币分别取各自实测值）
    measured_maker, measured_real = {}, {}
    for sym in SYMBOLS:
        r = fill_all[sym][(0.0, 30)]
        f, pen = r["fill_rate"], r["adverse_penalty_frac"]
        measured_maker[sym] = apply_measured(s3, f, pen, "maker")[sym]
        measured_real[sym] = apply_measured(s3, f, pen, "taker")[sym]
    for sym in SYMBOLS:
        s = s3[sym]
        mm, mr = measured_maker[sym], measured_real[sym]
        print(f"\n[{sym}] S3 {s['n']} 笔，平均毛利/笔 {s['mean_gross_per_trade_usdt']:+.2f} USDT，"
              f"平均名义 {s['mean_notional']:.0f} USDT")
        print(f"  Taker：          净 {s['net_taker_usdt']:+.2f} USDT（{s['net_taker_pct']*100:+.2f}%）")
        print(f"  Maker 100%：     净 {s['net_maker100_usdt']:+.2f} USDT（{s['net_maker100_pct']*100:+.2f}%）")
        print(f"  Maker 实测（出场也 Maker）：净 {mm['net_usdt']:+.2f} USDT（{mm['net_pct']*100:+.2f}%）"
              f"｜成交率 {mm['fill_rate']*100:.1f}%，期望成交 {mm['expected_filled_trades']} 笔，"
              f"逆向惩罚 {mm['penalty_usdt_per_filled']:.2f} USDT/笔，"
              f"成交单净 {mm['net_per_filled_trade_usdt']:+.2f} USDT/笔")
        print(f"  Maker 实测（出场 Taker，更现实）：净 {mr['net_usdt']:+.2f} USDT（{mr['net_pct']*100:+.2f}%）"
              f"｜成交单净 {mr['net_per_filled_trade_usdt']:+.2f} USDT/笔")
    summary["s3_180d"] = s3
    summary["s3_maker_measured_exit_maker"] = measured_maker
    summary["s3_maker_measured_exit_taker"] = measured_real

    # ---- 3c. 混合现实档：按 S3 真实出场结构加权 ----
    # 止损/EOD 必须市价（Taker 0.125%/边，含滑点），止盈可用限价（Maker -0.01%）；
    # 入场 Maker（-0.01%）。这是比“出场全 Taker”更准、比“出场全 Maker”更现实的档。
    print("\n=== 3c. 混合现实档（入场 Maker + 出场按真实结构加权）===")
    blended = {}
    for sym in SYMBOLS:
        ts = [t for t in trades_180d if t["symbol"] == sym]
        n_taker_exit = sum(1 for t in ts if t["reason"] in ("stop_loss", "eod"))
        n_maker_exit = sum(1 for t in ts if t["reason"] == "take_profit")
        exit_frac = (n_taker_exit * 0.00125 + n_maker_exit * (-0.0001)) / len(ts)
        rt_cost_frac = -0.0001 + exit_frac   # 一轮总成本率
        r = fill_all[sym][(0.0, 30)]
        f, pen = r["fill_rate"], r["adverse_penalty_frac"]
        s = s3[sym]
        filled_gross = s["mean_gross_per_trade_usdt"] - pen * s["mean_notional"]
        per_filled = filled_gross - rt_cost_frac * s["mean_notional"]
        net = f * s["n"] * per_filled
        blended[sym] = {"stop_eod_share": round(n_taker_exit / len(ts), 3),
                        "tp_share": round(n_maker_exit / len(ts), 3),
                        "roundtrip_cost_pct": round(rt_cost_frac * 100, 4),
                        "net_usdt": round(net, 2), "net_pct": round(net / 100000, 4),
                        "net_per_filled_trade_usdt": round(per_filled, 2)}
        print(f"[{sym}] 出场：止损/EOD {n_taker_exit} 笔（{n_taker_exit/len(ts)*100:.0f}%，Taker）"
              f"＋止盈 {n_maker_exit} 笔（{n_maker_exit/len(ts)*100:.0f}%，Maker）→ "
              f"一轮成本 {rt_cost_frac*100:+.4f}% 名义；净 {net:+.2f} USDT"
              f"（{net/100000*100:+.2f}%），成交单净 {per_filled:+.2f} USDT/笔")
    summary["s3_maker_blended_realistic"] = blended
    print("\n=== 3b. 交叉核对：S3 180 天信号在 30m 粒度的回踩率 ===")
    print("口径：限价 = 入场价（下一根 30m 开盘价）下方/上方 d，窗口 = 入场当根 + 下一根"
          " 30m（60 分钟）；d=0 在 30m 上恒为 100%（当根 low 恒 ≤ open），故只测 d>0。")
    proxy = {}
    for sym in SYMBOLS:
        bars = gns.load_bars(sym)
        by_t = {b["t"]: i for i, b in enumerate(bars)}
        ts = [t for t in trades_180d if t["symbol"] == sym]
        row = {}
        for d in (0.0002, 0.0005, 0.001):
            hit = 0
            for t in ts:
                i = by_t[t["entry_t"]]
                seg = bars[i:i + 2]
                if t["direction"] == 1:
                    ok = min(b["l"] for b in seg) <= t["entry"] * (1 - d)
                else:
                    ok = max(b["h"] for b in seg) >= t["entry"] * (1 + d)
                hit += ok
            row[f"d_{d}"] = round(hit / len(ts), 4) if ts else None
        proxy[sym] = row
        print(f"[{sym}] {len(ts)} 笔：回踩 0.02%={row['d_0.0002']*100:.1f}% "
              f"0.05%={row['d_0.0005']*100:.1f}% 0.10%={row['d_0.001']*100:.1f}%（60 分钟内）")
    summary["s3_30m_proxy_fill"] = proxy

    # ---- 敏感性：W=120 的成交率 ----
    print("\n=== 敏感性：放宽到 120 分钟窗口，Maker 实测（出场 Taker）会变多少 ===")
    for sym in SYMBOLS:
        r = fill_all[sym][(0.0, 120)]
        m = apply_measured(s3, r["fill_rate"], r["adverse_penalty_frac"], "taker")[sym]
        print(f"[{sym}] 成交率 {r['fill_rate']*100:.1f}%（120 分钟），逆向惩罚 "
              f"{r['adverse_penalty_frac']*100:+.3f}%，净 {m['net_usdt']:+.2f} USDT"
              f"（{m['net_pct']*100:+.2f}%），成交单净 {m['net_per_filled_trade_usdt']:+.2f} USDT/笔")
        summary["symbols"][sym]["sensitivity_w120_exit_taker"] = m

    with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json"), "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print("\n汇总已写入：data/gate_iter_B_summary.json")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
