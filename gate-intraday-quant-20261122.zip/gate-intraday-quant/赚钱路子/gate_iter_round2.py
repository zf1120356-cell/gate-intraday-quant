#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二轮（全模拟，不下单、不开户、不碰真钱）
================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
上一轮（见 盈利策略迭代.md）没达标：15 个策略 + 2 个执行层，
180 天 1 倍没有一个前后两半都赚钱。最接近的是 A（S3 20/80 低换手，
-0.35%）和 B（Maker 混合现实，-0.28%）。

本轮只做两件事，不发明新家族：
  1. A+B 组合：用 A 的 111 笔交易明细（data/gate_iter_A_trades.csv）
     直接套 B 的 Maker 混合现实成本重算，前 90 / 后 90 / 全 180 天
     分开汇报。达标标准不变：前后两半都为正且 180 天 1 倍净收益 >2%
     才算找到，否则不算。绝不用算术粗估代替脚本验证。
  2. C1 再收紧：只做高波动日里振幅排前 10% 的日子，规则用前 90 天
     定、后 90 天验证，同样分三段汇报。

口径（与前置一致，除非另有说明）：
  数据：data/gate_30m_180d_{BTC,ETH,SOL}_USDT.csv（2026-05-20~11-15，
  180 个完整 UTC 日），资金费率 data/gate_funding_180d_{...}.json。
  只用缓存，不重新取数。
  Taker 成本：一轮名义 x 0.25%（taker 0.075% + 滑点 0.05%，双边）。
  各窗口重置 10 万 USDT 虚拟权益（前 90 天 05-20~08-17 / 后 90 天
  08-18~11-15 / 全 180 天），与 A/B/C 报告完全一致。

Part 1（A+B）成本定义——逐字复用 B 的混合现实档（iteration_B_maker.md §3c）：
  入场 Maker：-0.01% 名义（返佣）。
  出场：止损 / EOD 只能市价 Taker 0.125%/边（0.075% 费 + 0.05% 滑点）；
        止盈可用限价 Maker -0.01%。
  即每笔 Maker 混合成本 = 名义 x (-0.0001 + 出场费率)，止盈笔 -0.02%，
  止损/EOD 笔 +0.115%。
  再套 B 的 1m 实测（d=0、30 分钟窗口，见 data/gate_iter_B_summary.json，
  本脚本直接从该 JSON 读数，不手抄）：
  成交率 f：BTC 0.9925 / ETH 0.9925 / SOL 0.9865；
  逆向选择惩罚：BTC 0.003% / ETH 0.006% / SOL 0.006% 名义。
  混合现实净收益（B 的公式，按窗口逐笔加总的等价写法）：
    net_M2 = f * (gross_sum - penalty * notional_sum - maker_cost_sum)
  其中 gross = price_pnl - funding_cost（A 明细已含 funding_cost_usdt 列）。
  另报 M1 档（Maker 成本、100% 成交、无惩罚，逐笔重算权益曲线）作为
  上界对照：M1 若都不达标，M2 更不可能达标；M1 达标而 M2 不达标，
  说明瓶颈在成交环节而非成本本身。
  M2 是期望值口径（错失的单计 0），没有逐笔权益曲线，因此不报 M2 的
  最大回撤——不编造。

Part 2（C1 再收紧）定义——“振幅排前 10%”的操作化（本轮唯一一次定义，
写死在代码里，不看后 90 天）：
  r = 当天开盘 2h 振幅 R0 / 前 20 个完整日同窗口振幅的中位数（与 C1 同款）。
  阈值 = 前 90 天（05-20~08-17，含 20 天热身后约 70 个可算 r 的日子）
  里 r 的第 90 百分位（type-7 线性插值），按币分别定死。
  规则：只在 r >= 该阈值的日子交易；其余 C1 规则原样（方向 ±0.15%、
  入场 02:00 bar 开盘、止损 1xATR、止盈 2xATR、每天每币 1 笔、23:30
  强制平仓）。阈值若 >1.3，则原 1.3 门控被包含，不再单独起作用。
  另有一种读法——“在 C1 高波动日集合内部再取前 10%”——会只剩约
  5 天/币、约 5 笔交易，样本量无法检验，本轮不采用，已在报告局限里
  写明。

运行：python3 gate_iter_round2.py
输出：终端打印全部表 + data/gate_iter_round2_AB_summary.json
      + data/gate_iter_round2_AB_trades.csv（M1 逐笔）
      + data/gate_iter_round2_C1t_summary.json
      + data/gate_iter_round2_C1t_trades.csv
"""
import csv
import json
import os
import statistics
import sys
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_C as gc  # 复用 C 的 load_bars / load_funding / group_days / atr_wilder 等

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
START_EQUITY = 100_000.0
SPLIT = datetime(2026, 8, 18, tzinfo=timezone.utc)
WINDOWS = [("180d", None), ("前90d", "front"), ("后90d", "back")]

# ---- B 的实测参数：直接从 gate_iter_B_summary.json 读，不手抄 ----
with open(os.path.join(DATA_DIR, "gate_iter_B_summary.json")) as f:
    B_SUMMARY = json.load(f)
FILL = {}
PENALTY = {}
for _sym in SYMBOLS:
    _r = B_SUMMARY["symbols"][_sym]["generic_fill"]["offset_0.0_window_30"]
    FILL[_sym] = _r["fill_rate"]
    PENALTY[_sym] = _r["adverse_penalty_frac"]
MAKER_ENTRY = -0.0001          # 入场 Maker 返佣
TAKER_EXIT = 0.00125           # 出场市价：0.075% 费 + 0.05% 滑点
MAKER_EXIT = -0.0001           # 出场限价（止盈）返佣
TAKER_ROUNDTRIP = 0.0025


def maker_cost(notional, reason):
    """B 混合现实档的每笔成本。止损/EOD 只能市价，止盈可用限价。"""
    if reason in ("stop_loss", "eod"):
        exit_rate = TAKER_EXIT
    elif reason == "take_profit":
        exit_rate = MAKER_EXIT
    else:
        # A 明细里没有其他出场原因；一旦出现，按最保守的市价计并在报告里点名
        exit_rate = TAKER_EXIT
    return notional * (MAKER_ENTRY + exit_rate)


def window_of(entry_iso):
    dt = datetime.fromisoformat(entry_iso)
    return "front" if dt < SPLIT else "back"


# ---------------------------------------------------------------- Part 1：A+B
def part1_ab():
    print("=" * 72)
    print("Part 1：A+B —— A 的 111 笔明细直接套 B 的 Maker 混合现实成本")
    print("B 参数来源：data/gate_iter_B_summary.json（d=0、30 分钟窗口）")
    for s in SYMBOLS:
        print(f"  {s}：成交率 f={FILL[s]}，逆向惩罚={PENALTY[s]*100:.3f}% 名义")
    print("M0=Taker 复现（校验）/ M1=Maker 成本 100% 成交 / M2=Maker 混合现实（B 公式）")
    path = os.path.join(DATA_DIR, "gate_iter_A_trades.csv")
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 111, f"A 明细应为 111 笔，实际 {len(rows)}"
    for r in rows:
        r["notional"] = float(r["notional"])
        r["gross"] = float(r["price_pnl_usdt"]) - float(r["funding_cost_usdt"])
        r["cost_taker"] = float(r["cost_usdt"])
        r["cost_maker"] = maker_cost(r["notional"], r["reason"])
        r["win"] = window_of(r["entry_time_utc"])
        # 校验：CSV 里的 taker 成本应等于名义 x 0.25%（允许 0.05 USDT 舍入）
        assert abs(r["cost_taker"] - r["notional"] * TAKER_ROUNDTRIP) < 0.05, r

    # 校验：按窗口重算的 Taker 净收益必须复现 A 报告（±2 USDT 舍入容差）
    a_sum = json.load(open(os.path.join(DATA_DIR, "gate_iter_A_summary.json")))
    a_lookup = {(d["symbol"], d["split"]): d for d in a_sum}
    for sym in SYMBOLS:
        for wname, wkey in WINDOWS:
            sub = [r for r in rows if r["symbol"] == sym and (wkey is None or r["win"] == wkey)]
            net = sum(r["gross"] - r["cost_taker"] for r in sub)
            ref = a_lookup[(sym, wname)]["total_pnl"]
            assert abs(net - ref) < 2.0, (sym, wname, net, ref)
    print("  校验通过：111 笔按窗口重算的 Taker 净收益与 A 报告一致（±2 USDT）。")

    results, m1_trades = [], []
    for sym in SYMBOLS:
        for wname, wkey in WINDOWS:
            sub = sorted([r for r in rows if r["symbol"] == sym and (wkey is None or r["win"] == wkey)],
                         key=lambda x: x["entry_time_utc"])
            n = len(sub)
            gross_sum = sum(r["gross"] for r in sub)
            notional_sum = sum(r["notional"] for r in sub)
            maker_cost_sum = sum(r["cost_maker"] for r in sub)
            taker_net = gross_sum - sum(r["cost_taker"] for r in sub)
            # M1：逐笔 Maker 成本，100% 成交，重算权益曲线与最大回撤。
            # 明细只写 180d 这一遍（111 笔），split 列标该笔所属半段；
            # 前/后 90d 的 M1 数字由同一批 111 笔按半段分组算出，不重复写行。
            eq, curve, wins = START_EQUITY, [START_EQUITY], 0
            for r in sub:
                pnl_m1 = r["gross"] - r["cost_maker"]
                if wname == "180d":
                    r2 = dict(r)
                    r2["pnl_maker_m1"] = round(pnl_m1, 2)
                    r2["cost_maker_usdt"] = round(r["cost_maker"], 2)
                    r2["split"] = "前90d" if r["win"] == "front" else "后90d"
                    m1_trades.append(r2)
                eq += pnl_m1
                curve.append(eq)
                wins += 1 if pnl_m1 > 0 else 0
            peak, mdd = curve[0], 0.0
            for v in curve:
                peak = max(peak, v)
                mdd = min(mdd, (v - peak) / peak)
            m1_net = eq - START_EQUITY
            # M2：B 公式期望值（错失的单计 0）
            m2_net = FILL[sym] * (gross_sum - PENALTY[sym] * notional_sum - maker_cost_sum)
            res = {"part": "A+B", "symbol": sym, "split": wname, "trades": n,
                   "gross_usdt": round(gross_sum, 2),
                   "notional_sum": round(notional_sum, 2),
                   "maker_cost_sum": round(maker_cost_sum, 2),
                   "taker_net_usdt": round(taker_net, 2),
                   "taker_net_pct": round(taker_net / START_EQUITY, 4),
                   "m1_net_usdt": round(m1_net, 2),
                   "m1_net_pct": round(m1_net / START_EQUITY, 4),
                   "m1_win_rate": round(wins / n, 4) if n else None,
                   "m1_max_dd": round(mdd, 4),
                   "m2_net_usdt": round(m2_net, 2),
                   "m2_net_pct": round(m2_net / START_EQUITY, 4),
                   "fill_rate": FILL[sym], "penalty_frac": PENALTY[sym]}
            results.append(res)
            print(f"[A+B {sym} {wname}] n={n} 毛利={gross_sum:+.0f} "
                  f"Maker成本={maker_cost_sum:+.0f} | Taker {taker_net/1000:+.2f}% "
                  f"| M1 {m1_net/1000:+.2f}%（胜率 {wins/n*100:.1f}%）"
                  f" | M2 {m2_net/100000*100:+.2f}%")
    print("\n--- Part 1 汇总：三币平均（各币独立 10 万 USDT，1x）---")
    for wname, _ in WINDOWS:
        rs = [r for r in results if r["split"] == wname]
        for key in ("taker_net_pct", "m1_net_pct", "m2_net_pct"):
            avg = sum(r[key] for r in rs) / len(rs)
            print(f"  {wname} {key} 平均 {avg*100:+.2f}%  "
                  f"（{' / '.join(f'{r['symbol'][:3]} {r[key]*100:+.2f}%' for r in rs)}）")
    with open(os.path.join(DATA_DIR, "gate_iter_round2_AB_summary.json"), "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round2_AB_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "split", "symbol", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "notional", "gross_usdt", "maker_cost_usdt",
                    "pnl_maker_m1_usdt", "reason", "liquidated", "hold_min"])
        for t in sorted(m1_trades, key=lambda x: (x["entry_time_utc"], x["symbol"])):
            w.writerow(["A+B-M1", t["split"], t["symbol"],
                        "LONG" if t["direction"] == "LONG" else "SHORT",
                        t["entry_time_utc"], t["exit_time_utc"],
                        t["entry"], t["exit"], t["notional"],
                        round(t["gross"], 2), t["cost_maker_usdt"], t["pnl_maker_m1"],
                        t["reason"], t["liquidated"], t["hold_min"]])
    print("汇总已写入：data/gate_iter_round2_AB_summary.json")
    print("明细已写入：data/gate_iter_round2_AB_trades.csv（M1 逐笔）")
    return results


# ---------------------------------------------------------------- Part 2：C1 再收紧（前 10% 高波动日）
def pct90(vals):
    """第 90 百分位，type-7 线性插值（与 numpy 默认一致），写死方法防歧义。"""
    s = sorted(vals)
    n = len(s)
    if n == 1:
        return s[0]
    pos = 0.9 * (n - 1)
    lo = int(pos)
    hi = min(lo + 1, n - 1)
    return s[lo] * (1 - (pos - lo)) + s[hi] * (pos - lo)


def run_c1t(bars, funding, symbol, days_subset, ratio_min, label="C1t-top10"):
    """C1 引擎（gate_iter_C.py run_c1 的同款逻辑，只加 ratio_min 一道门控）。
    门控：r = R0 / 前 20 日 R0 中位数，需 r >= max(1.3, ratio_min)。"""
    atr = gc.atr_wilder(bars)
    idx_of_t = {b["t"]: i for i, b in enumerate(bars)}
    days = gc.group_days(bars, 48)
    day_list = sorted(days)
    open_range = {}
    for d in day_list:
        db = days[d]
        open_range[d] = max(b["h"] for b in db[:4]) - min(b["l"] for b in db[:4])
    if days_subset is not None:
        days = {d: v for d, v in days.items() if d in days_subset}
    liq_move = gc.make_engine(symbol, funding)
    equity = gc.START_EQUITY
    trades = []
    curve = [equity]
    stats = {"hivol_days": 0, "days_seen": 0, "gate_days": 0}
    for day, day_bars in days.items():
        stats["days_seen"] += 1
        day_start_equity = equity
        day_pnl = 0.0
        pos = None
        pos_in_list = day_list.index(day)
        if pos_in_list < 20:
            continue
        prior = [open_range[d] for d in day_list[pos_in_list - 20:pos_in_list]]
        med = statistics.median(prior)
        r0 = open_range[day]
        if med == 0:
            continue
        r = r0 / med
        if r < 1.3:
            continue
        stats["hivol_days"] += 1
        if r < ratio_min:
            continue
        stats["gate_days"] += 1
        ret2h = day_bars[3]["c"] / day_bars[0]["o"] - 1
        if ret2h >= 0.0015:
            sig = 1
        elif ret2h <= -0.0015:
            sig = -1
        else:
            continue
        gi4 = idx_of_t[day_bars[4]["t"]]
        a = atr[gi4]
        if a is None:
            continue
        entry = day_bars[4]["o"]
        margin = gc.MARGIN_FRAC * equity
        notional = margin * 1
        if notional * (a / entry + gc.ROUNDTRIP_COST) / equity > 0.01:
            continue
        pos = {"symbol": symbol, "variant": label, "direction": sig,
               "entry_t": day_bars[4]["t"], "entry": entry,
               "stop": entry - a if sig == 1 else entry + a,
               "tp": entry + 2 * a if sig == 1 else entry - 2 * a,
               "atr": a, "notional": notional, "margin": margin,
               "exit_t": None, "exit": None, "pnl": 0.0,
               "liquidated": False, "reason": "", "funding_cost_usdt": 0.0,
               "cost_usdt": 0.0, "price_pnl": 0.0, "hold_min": None,
               "pnl_pct_equity": 0.0, "ratio_r": round(r, 3)}

        def close_trade(tr, exit_t, exit_price, reason, liquidated=False):
            nonlocal equity, day_pnl
            tr["exit_t"], tr["exit"] = exit_t, exit_price
            tr["reason"] = reason
            tr["liquidated"] = liquidated
            tr["hold_min"] = (exit_t - tr["entry_t"]) / 60
            tr["funding_cost_usdt"] = gc.funding_cost_between(
                funding, day, tr["entry_t"], exit_t, tr["notional"], tr["direction"])
            tr["cost_usdt"] = tr["notional"] * gc.ROUNDTRIP_COST
            if liquidated:
                tr["price_pnl"] = -tr["margin"]
                tr["pnl"] = -tr["margin"] - tr["notional"] * (0.00075 + 0.0005)
            else:
                move = (exit_price - tr["entry"]) / tr["entry"] * tr["direction"]
                tr["price_pnl"] = tr["notional"] * move
                tr["pnl"] = tr["price_pnl"] - tr["cost_usdt"] - tr["funding_cost_usdt"]
            tr["pnl_pct_equity"] = tr["pnl"] / day_start_equity
            equity += tr["pnl"]
            day_pnl += tr["pnl"]
            trades.append(tr)
            curve.append(equity)

        for i in range(4, len(day_bars)):
            b = day_bars[i]
            if pos is None:
                break
            adv = ((pos["entry"] - b["l"]) / pos["entry"] if pos["direction"] == 1
                   else (b["h"] - pos["entry"]) / pos["entry"])
            if adv >= liq_move:
                close_trade(pos, b["t"], b["c"], "liquidated", liquidated=True)
                pos = None
                break
            exited = False
            if pos["direction"] == 1:
                if b["l"] <= pos["stop"]:
                    close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                elif b["h"] >= pos["tp"]:
                    close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
            else:
                if b["h"] >= pos["stop"]:
                    close_trade(pos, b["t"], pos["stop"], "stop_loss"); exited = True
                elif b["l"] <= pos["tp"]:
                    close_trade(pos, b["t"], pos["tp"], "take_profit"); exited = True
            if exited:
                pos = None
                break
            if i == len(day_bars) - 1:
                close_trade(pos, b["t"], b["c"], "eod")
                pos = None
                break
        if pos is not None:
            close_trade(pos, day_bars[-1]["t"], day_bars[-1]["c"], "eod")
            pos = None
    res = gc.summarize(equity, gc.START_EQUITY, trades, label)
    res["symbol"] = symbol
    res["days"] = stats["days_seen"]
    res["hivol_days"] = stats["hivol_days"]
    res["gate_days"] = stats["gate_days"]
    res["avg_hold_min"] = round(sum(t["hold_min"] for t in trades if t["hold_min"] is not None) / len(trades), 1) if trades else None
    gc.add_mdd(res, curve)
    res["gross_usdt"] = round(sum(t["price_pnl"] - t["funding_cost_usdt"] for t in trades), 2)
    res["cost_usdt"] = round(sum(t["cost_usdt"] for t in trades), 2)
    return res, trades


def part2_c1t():
    print("=" * 72)
    print("Part 2：C1 再收紧 —— 只做振幅比 r 排前 10% 的日子")
    print("r = 当天开盘 2h 振幅 / 前 20 日同窗口振幅中位数；阈值 = 前 90 天 r 的第 90 百分位（type-7），按币定死")
    data = {}
    for sym in SYMBOLS:
        data[sym] = (gc.load_bars(sym), gc.load_funding(sym))

    # ---- 引擎校验：ratio_min=1.3 时必须复现 gate_iter_C.py 的 C1 数字 ----
    print("  引擎校验（ratio_min=1.3 应复现 C1：BTC -0.72%/45 笔、ETH -0.75%/44 笔、SOL -1.15%/48 笔）")
    for sym in SYMBOLS:
        bars, funding = data[sym]
        res, _ = run_c1t(bars, funding, sym, None, 1.3, label="C1-check")
        print(f"    校验 {sym} 180d：净收益 {res['net_return']*100:+.2f}% 笔数={res['trades']}（C1 报告值见上行）")
        assert res["trades"] in (44, 45, 48), res

    # ---- 阈值：只用前 90 天定 ----
    thresholds, r_front = {}, {}
    for sym in SYMBOLS:
        bars, _ = data[sym]
        days = gc.group_days(bars, 48)
        day_list = sorted(days)
        open_range = {d: max(b["h"] for b in days[d][:4]) - min(b["l"] for b in days[d][:4])
                      for d in day_list}
        vals = []
        for d in day_list:
            if d >= datetime(2026, 8, 18, tzinfo=timezone.utc).date():
                continue
            pos = day_list.index(d)
            if pos < 20:
                continue
            med = statistics.median([open_range[x] for x in day_list[pos - 20:pos]])
            if med > 0:
                vals.append(open_range[d] / med)
        thresholds[sym] = pct90(vals)
        r_front[sym] = vals
        print(f"  阈值 {sym}：前 90 天 r 的 p90 = {thresholds[sym]:.3f}（n={len(vals)}，中位 r={statistics.median(vals):.3f}，"
              f"前 90 天过 1.3 门控的日子约 {sum(1 for v in vals if v >= 1.3)} 天）")

    results, all_trades = [], []
    for sym in SYMBOLS:
        bars, funding = data[sym]
        days_all = set(gc.group_days(bars, 48).keys())
        days_a = {d for d in days_all if d < datetime(2026, 8, 18).date()}
        days_b = {d for d in days_all if d >= datetime(2026, 8, 18).date()}
        for split_name, subset in [("180d", None), ("前90d", days_a), ("后90d", days_b)]:
            res, trades = run_c1t(bars, funding, sym, subset, thresholds[sym])
            res["split"] = split_name
            res["ratio_threshold"] = round(thresholds[sym], 3)
            results.append(res)
            if split_name == "180d":
                for t in trades:
                    t["variant"] = "C1t-top10"
                    t["split"] = "180d"
                all_trades.extend(trades)
            print(f"[C1t-top10 {sym} {split_name}] 门控通过 {res['gate_days']} 天 / 高波动日 {res['hivol_days']} 天，"
                  f"笔数={res['trades']} 胜率={res['win_rate']} 净收益={res['net_return']*100:+.2f}% "
                  f"盈亏比={res['profit_factor']} 最大回撤={res['max_dd']*100:.2f}% "
                  f"毛利={res['gross_usdt']:+.0f} 成本=-{res['cost_usdt']:.0f} 平均持仓={res['avg_hold_min']}分钟 爆仓={res['liquidations']}")
    print("\n--- Part 2 汇总：三币平均（各币独立 10 万 USDT，1x）---")
    for split_name in ["180d", "前90d", "后90d"]:
        rs = [r for r in results if r["split"] == split_name]
        avg = sum(r["net_return"] for r in rs) / len(rs)
        tot = sum(r["trades"] for r in rs)
        gross = sum(r["gross_usdt"] for r in rs)
        cost = sum(r["cost_usdt"] for r in rs)
        print(f"  C1t-top10 {split_name}：平均净收益 {avg*100:+.2f}%  总笔数 {tot}  "
              f"毛利={gross:+.0f} 成本=-{cost:.0f} 净={gross-cost:+.0f} USDT  "
              f"（{' / '.join(f'{r['symbol'][:3]} {r['net_return']*100:+.2f}%' for r in rs)}）")
    with open(os.path.join(DATA_DIR, "gate_iter_round2_C1t_summary.json"), "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round2_C1t_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "split", "symbol", "direction", "entry_time_utc", "exit_time_utc",
                    "entry", "exit", "notional", "pnl_usdt", "price_pnl_usdt",
                    "cost_usdt", "funding_cost_usdt", "reason", "liquidated", "hold_min", "ratio_r"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["symbol"])):
            w.writerow([t.get("variant", ""), t.get("split", ""), t.get("symbol", ""),
                        "LONG" if t.get("direction") == 1 else "SHORT",
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t.get("entry"), t.get("exit"), t.get("notional"),
                        round(t["pnl"], 2), round(t.get("price_pnl", 0), 2),
                        round(t.get("cost_usdt", 0), 2), round(t.get("funding_cost_usdt", 0), 2),
                        t.get("reason", ""), t.get("liquidated", False), t.get("hold_min"),
                        t.get("ratio_r")])
    print("汇总已写入：data/gate_iter_round2_C1t_summary.json")
    print("明细已写入：data/gate_iter_round2_C1t_trades.csv")
    return results


def main():
    print("盈利策略迭代 · 第二轮（全模拟，不下单、不开户、不碰真钱）")
    print("达标标准：前后两半都为正且 180 天 1 倍净收益 >2%，否则不算找到。")
    ab = part1_ab()
    c1t = part2_c1t()
    print("=" * 72)
    print("=== 达标判定（主口径：Part 1 的 M2 混合现实；Part 2 的 Taker）===")
    for wname in ["前90d", "后90d", "180d"]:
        rs = [r for r in ab if r["split"] == wname]
        avg_m2 = sum(r["m2_net_pct"] for r in rs) / len(rs)
        avg_m1 = sum(r["m1_net_pct"] for r in rs) / len(rs)
        print(f"  A+B {wname}：M2 平均 {avg_m2*100:+.2f}%｜M1 平均 {avg_m1*100:+.2f}%")
    for wname in ["前90d", "后90d", "180d"]:
        rs = [r for r in c1t if r["split"] == wname]
        avg = sum(r["net_return"] for r in rs) / len(rs)
        print(f"  C1t-top10 {wname}：平均 {avg*100:+.2f}%")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
