#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第三十七轮取数：全新币种宇宙的 1h/15m/资金费（Gate 公开接口）。
只做取数与选择记录，不跑回测。

选择规则（跑前写死；见 37 轮报告 §0 与附录）：
  快照：2026-11-21 01:22 UTC 拉 Gate /futures/usdt/tickers（1,037 个合约），
  按 volume_24h_quote（USDT 计价 24h 成交量）降序。
  依次检查，取前 8 个全部通过的币；名单跑前定死，跑后不换。
  排除：
    (1) 已回测过的 20 个币：原 8 币（BTC/ETH/SOL/DOGE/LINK/XRP/BNB/ADA，
        1~36 轮全部用它们）+ 24 轮 12 币（ZEC/EVAA/HYPE/LTC/BLESS/XLM/
        AKE/NEAR/PEPE/UNI/SUI/XAUT，24 轮 MAIN-1h/MAIN-15m 已测）。
        用户指示“不能用回测过的币种”+ v2 R2。
    (2) 非虚拟币合约：代币化股票/ETF/指数/大宗商品（24 轮报告已成文
        的名单，照抄；金银现货 XAU/XAG 同属此类）。金背书代币
        （XAUT/PAXG 类）按 24 轮先例不归入此类（24 轮 XAUT 按成文标准
        入选并单独标注）；XAUT 本身已在 (1) 里排除。
    (3) spread（(最低卖-最高买)/中间价，快照值）> 0.07%（24 轮同标准）。
    (4) 1h 首周（2025-11-16~2025-11-23）K 线 < 160 根（365 天连续性初筛，
        24 轮同标准）。
    (5) 全量复核：1h 8,761 根连续（2025-11-16~2026-11-16）、15m 自实际
        起点起连续（起点 08-09 时 9,504 根、08-10 时 9,408 根）且时间戳
        与 BTC 对齐段一致；不满足的跳过并记录原因。
  取数窗口（与 35/36 轮的偏差，已核实、见下）：1h 2025-11-16~2026-11-16、
  15m 2026-08-09~2026-11-16（99 天，9,504 根）；资金费 2026-08-01 起
  （覆盖全部窗口的结算点；funding_cost_between 只用入场日与入场日+1 的
  08:00/16:00 点）。
  偏差原因（实测，非推测）：Gate /futures/usdt/candlesticks 对 15m 只提供
  最近 10,000 根（约 104 天）回溯——2026-11-21 实测 BTC 15m 从
  2026-08-06 取数报 400 “Candlestick too long ago. Maximum 10000 points
  recently are allowed”，从 2026-08-09 起可取（08-09 00:00 当时约
  9,991 根前）。因此 35/36 轮的 103 天窗口（2026-08-06 起）对任何新币
  都已无法复现；本轮窗口起点改为最早可取的 2026-08-09（99 天），
  前半段 2026-08-09~09-20（43 天）、后半段 2026-09-21~11-16（57 天，
  与 35/36 轮后半段一字相同）。若首段取数 400，起点顺延至 08-10
  （98 天）并记录实际起点。1h 不受影响（8,761 根 < 10,000）。
  本偏差不影响多币/单币/全量三臂之间的内部比较（同窗口、同信号），
  但 37 轮数字与 35/36 轮不是同一窗口，不可逐项等同比较。
取数方法照抄第二十四轮（1h/资金费）与第八轮（15m）的 fetch 函数。
运行：python3 gate_iter_round37_fetch.py（联网拉 Gate 公开接口）
输出：data/gate_1h_365d_{币}.csv、data/gate_15m_103d_{币}.csv、
      data/gate_funding_365d_{币}.json、data/gate_iter_round37_selection.json
"""
import csv
import json
import os
import time
import urllib.request
from datetime import datetime, timedelta, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
BASE = "https://api.gateio.ws/api/v4"
TICKERS_SNAPSHOT = "/tmp/gate_tickers_20261121.json"

# 已回测过的 20 个币（排除）：原 8 币 + 24 轮 12 币
EXCLUDED_USED = {
    "BTC_USDT", "ETH_USDT", "SOL_USDT", "DOGE_USDT",
    "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT",
    "ZEC_USDT", "EVAA_USDT", "HYPE_USDT", "LTC_USDT",
    "BLESS_USDT", "XLM_USDT", "AKE_USDT", "NEAR_USDT",
    "PEPE_USDT", "UNI_USDT", "SUI_USDT", "XAUT_USDT",
}
EXCLUDED_REASON = {
    "BTC_USDT": "已回测：原8币（1~36轮）", "ETH_USDT": "已回测：原8币（1~36轮）",
    "SOL_USDT": "已回测：原8币（1~36轮）", "DOGE_USDT": "已回测：原8币（1~36轮）",
    "LINK_USDT": "已回测：原8币（1~36轮）", "XRP_USDT": "已回测：原8币（1~36轮）",
    "BNB_USDT": "已回测：原8币（1~36轮）", "ADA_USDT": "已回测：原8币（1~36轮）",
    "ZEC_USDT": "已回测：24轮12币", "EVAA_USDT": "已回测：24轮12币",
    "HYPE_USDT": "已回测：24轮12币", "LTC_USDT": "已回测：24轮12币",
    "BLESS_USDT": "已回测：24轮12币", "XLM_USDT": "已回测：24轮12币",
    "AKE_USDT": "已回测：24轮12币", "NEAR_USDT": "已回测：24轮12币",
    "PEPE_USDT": "已回测：24轮12币", "UNI_USDT": "已回测：24轮12币",
    "SUI_USDT": "已回测：24轮12币", "XAUT_USDT": "已回测：24轮12币",
}
# 非虚拟币合约（24 轮报告已成文的代币化股票/ETF/指数/贵金属/大宗商品名单照抄，
# 另加本次快照里同类的 PAXG 除外说明见文件头；XAU/XAG 为金银现货合约）
NON_CRYPTO = {
    "SOXL_USDT": "代币化ETF（半导体3倍做多）", "SOXS_USDT": "代币化ETF（半导体3倍做空）",
    "SQQQ_USDT": "代币化ETF（纳指3倍做空）", "QQQ_USDT": "代币化ETF（纳斯达克100）",
    "SPY_USDT": "代币化ETF（标普500）", "NAS100_USDT": "指数合约（纳斯达克100）",
    "XAU_USDT": "贵金属现货合约（黄金）", "XAG_USDT": "贵金属现货合约（白银）",
    "CL_USDT": "大宗商品合约（原油）",
    "NVDA_USDT": "代币化股票（英伟达）", "MU_USDT": "代币化股票（美光）",
    "INTC_USDT": "代币化股票（英特尔）", "GOOGL_USDT": "代币化股票（谷歌）",
    "AMD_USDT": "代币化股票（AMD）", "SNDK_USDT": "代币化股票（闪迪）",
    "WDC_USDT": "代币化股票（西部数据）", "MSTR_USDT": "代币化股票（MicroStrategy）",
    "CRCL_USDT": "代币化股票（Circle）", "SAMSUNG_USDT": "代币化股票（三星）",
    "SKHY_USDT": "代币化股票（SK海力士）", "SKHYNIX_USDT": "代币化股票（SK海力士）",
    "SNXX_USDT": "代币化股票", "SPCX_USDT": "代币化股票",
    "OPENAI_USDT": "代币化私企股权（OpenAI）", "MUU_USDT": "代币化股票",
    "BZ_USDT": "代币化股票", "BTW_USDT": "代币化股票",
    "KORU_USDT": "代币化股票", "BREV_USDT": "代币化股票",
    "CXMT_USDT": "代币化股票", "UNITREE_USDT": "代币化股票（宇树）",
    "NBIS_USDT": "代币化股票", "AAOI_USDT": "代币化股票",
    "LITE_USDT": "代币化股票", "IREN_USDT": "代币化股票（IREN）",
}
SPREAD_MAX = 0.0007
FIRST_WEEK_MIN_BARS = 160
TARGET_N = 8

START_1H = datetime(2025, 11, 16, tzinfo=timezone.utc)
END_1H = datetime(2026, 11, 16, tzinfo=timezone.utc)
# 15m 起点 2026-08-09：Gate 15m 只提供最近 10,000 根回溯，08-06 已取不到
# （实测 400）；08-09 00:00 当时约 9,991 根前，刚好在限内。先取 15m 再取
# 1h（15m 最怕边界推移），首段 400 则顺延至 08-10 并记录实际起点。
START_15M_CANDIDATES = [datetime(2026, 8, 9, tzinfo=timezone.utc),
                         datetime(2026, 8, 10, tzinfo=timezone.utc),
                         datetime(2026, 8, 11, tzinfo=timezone.utc)]
END_15M = datetime(2026, 11, 17, tzinfo=timezone.utc)
FUNDING_START = datetime(2026, 8, 1, tzinfo=timezone.utc)
FIRST_WEEK_END = datetime(2025, 11, 23, tzinfo=timezone.utc)


def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "gate-r37-fetch/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles(contract, interval, start, end, path):
    bars = []
    cur = start
    while cur < end:
        nxt = min(cur + timedelta(days=7), end)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval={interval}"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    if interval == "15m":
        bars = [b for b in bars
                if int(start.timestamp()) <= b["t"] < int(end.timestamp())]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] {interval} 已取：{len(bars)} 根 "
          f"{datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ "
          f"{datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}", flush=True)
    return bars


def fetch_funding(contract):
    path = os.path.join(DATA_DIR, f"gate_funding_365d_{contract}.json")
    out = {}
    cur = FUNDING_START
    while cur < END_1H:
        nxt = min(cur + timedelta(days=30), END_1H)
        url = (f"{BASE}/futures/usdt/funding_rate?contract={contract}&limit=100"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            t = int(d["t"])
            t = (t // 28800) * 28800
            out[t] = float(d["r"])
        cur = nxt
        time.sleep(0.3)
    with open(path, "w") as f:
        json.dump(out, f)
    print(f"[{contract}] 资金费率已取：{len(out)} 条", flush=True)
    return out


def first_week_bars(contract):
    url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=1h"
           f"&from={int(START_1H.timestamp())}&to={int(FIRST_WEEK_END.timestamp())}")
    data = http_get(url)
    return len(data)


def check_continuity_1h(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    ts = [int(r["t"]) for r in rows]
    ok = (len(ts) == 8761 and ts[0] == int(START_1H.timestamp())
          and ts[-1] == int(END_1H.timestamp())
          and all(ts[i + 1] - ts[i] == 3600 for i in range(len(ts) - 1)))
    return ok, len(ts), ts[0] if ts else None, ts[-1] if ts else None


def file_bar_count(path):
    if not os.path.exists(path):
        return 0
    with open(path, newline="") as f:
        return sum(1 for _ in f) - 1


def fetch_15m_with_fallback(sym, p15):
    """15m 先取（最怕 10,000 根边界推移）；起点 08-09，首段 400 则顺延。
    返回实际起点 datetime；全部失败则抛错。"""
    for start in START_15M_CANDIDATES:
        try:
            bars = fetch_candles(sym, "15m", start, END_15M, p15)
            return start, bars
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode()[:160]
            except Exception:
                pass
            print(f"[{sym}] 15m 起点 {start.date()} 取数失败（{e.code}）：{body}，顺延下一候选起点",
                  flush=True)
            continue
    raise RuntimeError(f"{sym} 15m 三个候选起点全部取数失败")


def check_continuity_15m(path, base_ts, start):
    """15m 复核：根数 = 起点~11-17 的 15m 根数，时间戳须与 BTC 对齐段一致。
    base_ts 为 BTC 103 天全量时间戳；取其中 >= start 的一段作基准。"""
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    ts = [int(r["t"]) for r in rows]
    base_seg = [t for t in base_ts if t >= int(start.timestamp())]
    ok = (len(ts) == len(base_seg) and ts == base_seg)
    return ok, len(ts), len(base_seg)


def main():
    with open(TICKERS_SNAPSHOT) as f:
        tickers = json.load(f)
    snap_mtime = datetime.fromtimestamp(
        os.path.getmtime(TICKERS_SNAPSHOT), timezone.utc).isoformat()
    rows = []
    for t in tickers:
        try:
            vol = float(t["volume_24h_quote"])
            bid = float(t["highest_bid"]); ask = float(t["lowest_ask"])
        except (KeyError, TypeError, ValueError):
            continue
        mid = (bid + ask) / 2
        spread = (ask - bid) / mid if mid else 9.99
        rows.append({"contract": t["contract"], "vol": vol, "spread": spread})
    rows.sort(key=lambda r: -r["vol"])

    # BTC 的 15m 时间戳作对齐基准
    with open(os.path.join(DATA_DIR, "gate_15m_103d_BTC_USDT.csv"), newline="") as f:
        base_ts = [int(r["t"]) for r in csv.DictReader(f)]
    assert len(base_ts) == 9888, f"BTC 15m 基准应为 9888 根，实际 {len(base_ts)}"

    selection = {
        "fetch_time_utc": snap_mtime,
        "source": "GET /futures/usdt/tickers（1,037 个合约），按 volume_24h_quote 降序",
        "rule": ("排除已回测20币；排除非虚拟币合约（代币化股票/ETF/指数/贵金属/大宗商品）；"
                 "spread<=0.07%；1h首周>=160根；全量复核1h 8761根连续、15m自实际起点连续且与BTC对齐；"
                 "15m窗口起点2026-08-09（99天）：Gate 15m只提供最近10000根回溯，35/36轮的103天窗口已无法复现"),
        "skipped": [],
        "selected": [],
    }
    selected = []
    for i, r in enumerate(rows, 1):
        sym = r["contract"]
        if len(selected) >= TARGET_N:
            break
        entry = {"rank": i, "symbol": sym, "vol_24h_quote_usdt": r["vol"],
                 "spread_pct": round(r["spread"] * 100, 4)}
        if sym in EXCLUDED_USED:
            entry["reason"] = EXCLUDED_REASON[sym]
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        if sym in NON_CRYPTO:
            entry["reason"] = f"非虚拟币合约：{NON_CRYPTO[sym]}"
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        if r["spread"] > SPREAD_MAX:
            entry["reason"] = f"spread {r['spread']*100:.4f}% > 0.07%"
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        try:
            n_fw = first_week_bars(sym)
        except Exception as e:
            entry["reason"] = f"1h首周拉取失败：{e}"
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        if n_fw < FIRST_WEEK_MIN_BARS:
            entry["reason"] = f"1h首周仅 {n_fw} 根 < 160 根（365天历史不足）"
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        # 全量取数：15m 先取（最怕 10,000 根边界推移），再取 1h、资金费；
        # 已有合规缓存的跳过（断点续跑）。
        p1h = os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv")
        p15 = os.path.join(DATA_DIR, f"gate_15m_103d_{sym}.csv")
        pf = os.path.join(DATA_DIR, f"gate_funding_365d_{sym}.json")
        try:
            start15, _bars15 = fetch_15m_with_fallback(sym, p15)
        except Exception as e:
            entry["reason"] = f"15m取数失败：{e}"
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        if file_bar_count(p1h) != 8761:
            fetch_candles(sym, "1h", START_1H, END_1H, p1h)
        else:
            print(f"[{sym}] 1h 用缓存（8,761 根）", flush=True)
        if not os.path.exists(pf):
            fetch_funding(sym)
        else:
            print(f"[{sym}] 资金费率用缓存", flush=True)
        ok1, n1, t0, t1 = check_continuity_1h(p1h)
        ok15, n15, n15_exp = check_continuity_15m(p15, base_ts, start15)
        if not ok1:
            entry["reason"] = (f"1h全量复核不通过：{n1} 根（应 8761），"
                               f"首 {t0} 末 {t1}")
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        if not ok15:
            entry["reason"] = (f"15m全量复核不通过：{n15} 根（应 {n15_exp}，"
                               f"起点 {start15.date()}，与BTC不对齐）")
            selection["skipped"].append(entry)
            print(f"#{i} {sym} 跳过：{entry['reason']}", flush=True)
            continue
        entry["reason"] = "入选"
        entry["start_15m"] = start15.date().isoformat()
        entry["bars_15m"] = n15
        selection["selected"].append(entry)
        selected.append(sym)
        print(f"#{i} {sym} 入选（第 {len(selected)} 个；15m 起点 {start15.date()}，{n15} 根）",
              flush=True)

    selection["selected_symbols"] = selected
    with open(os.path.join(DATA_DIR, "gate_iter_round37_selection.json"), "w") as f:
        json.dump(selection, f, indent=2, ensure_ascii=False)
    print(f"\n新宇宙（{len(selected)} 个）：{selected}")
    print(f"跳过记录：{len(selection['skipped'])} 条，见 data/gate_iter_round37_selection.json")
    assert len(selected) == TARGET_N, f"只选出 {len(selected)} 个，不足 {TARGET_N} 个"


if __name__ == "__main__":
    main()
