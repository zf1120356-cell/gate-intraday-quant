#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gate 日内永续合约量化回测（全模拟，不下单、不开户、不碰真钱）
交易所：Gate (gate.io)  USDT 永续合约
标的：BTC_USDT / ETH_USDT / SOL_USDT
周期：15m K 线，UTC 自然日，当天平仓、不过夜
取数：Gate 公开接口，无需 API Key
  - K 线：GET /futures/usdt/candlesticks?contract=X&interval=15m&from=&to=
  - 资金费率：GET /futures/usdt/funding_rate?contract=X&limit=1000
  - 合约参数：GET /futures/usdt/contracts/X

成本（保守口径，以 2026-11-17 实测 API 返回为准）：
  - taker 手续费 0.075%/边（合约字段 taker_fee_rate=0.00075）
    注：Gate 官网费率页 VIP0 公布为 maker 0.02%/taker 0.05%，
    第三方 2026-11-01 核对亦为 0.02%/0.05%；API 返回的 0.075% 更高，
    本回测用 0.075% 做保守测算，真实 VIP0 成本只会更低。
  - 滑点 0.05%/边；一轮开平总成本 = 名义本金 x (0.075%+0.05%) x 2 = 0.25%
  - 资金费：持仓跨过 UTC 08:00/16:00 结算点时，按当日实际资金费率计
    （多头费率>0 时付钱，空头收钱；反之亦然）

仓位：每笔用当前权益的 10% 做保证金，名义 = 保证金 x 杠杆（只测 1x/2x/3x）
强平：反向波动达到 (1/杠杆 - 维持保证金率) 即爆仓，亏掉全部保证金
  维持保证金率：BTC/ETH 0.3%，SOL 0.5%（2026-11-17 API 实测）

策略（全部日内、UTC 日、23:45 强制平仓）：
  A) ORB-1h 开盘区间突破：前 4 根 15m（00:00-01:00 UTC）高低点为区间，
     01:00 后首根收盘突破上沿做多、下沿做空；止损为区间另一沿，
     止盈为入场价 +/- 2x 区间宽度；每天最多 1 笔。
  B) VWAP 均值回归：日内 VWAP（典型价 x 成交额加权），滚动 20 根收盘价标准差，
     收盘 < VWAP-1.5σ 做多，> VWAP+1.5σ 做空；回踩 VWAP 或触及入场 +/-2.5σ 止损出场；
     每天最多 2 笔。
  C) EMA 动量（自选）：15m EMA9/EMA21 金叉做多、死叉做空，只在 08:00-20:00 UTC
     （伦敦+纽约活跃时段）内发信号；反向交叉或收盘出场；每天最多 3 笔。
     选它理由：与 A（区间突破）、B（均值回归）是三种不同的市场假设——
     A 赌开盘定方向，B 赌价格回归均值，C 赌活跃时段趋势延续；三者同测，
     若全部不赚钱，说明不是某一个参数的问题，而是日内本身没有稳定 edge。

运行：python3 gate_intraday_sim.py
输出：终端打印汇总表 + data/gate_intraday_summary.json
缓存：data/gate_15m_{SYM}.csv, data/gate_funding_{SYM}.json（离线可复现）
"""
import csv
import json
import math
import os
import statistics
import time
import urllib.request
from datetime import datetime, timezone, timedelta

BASE = "https://api.gateio.ws/api/v4"
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(DATA_DIR, exist_ok=True)

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT"]
MAINT_RATE = {"BTC_USDT": 0.003, "ETH_USDT": 0.003, "SOL_USDT": 0.005}
TAKER = 0.00075   # Gate API 实测 2026-11-17
SLIPPAGE = 0.0005  # 每边
ROUNDTRIP_COST = (TAKER + SLIPPAGE) * 2  # 0.25% 名义本金
START_EQUITY = 100_000.0
MARGIN_FRAC = 0.10  # 每笔保证金占权益 10%

# 回测窗口：90 个完整 UTC 日
END_DAY = datetime(2026, 11, 16, tzinfo=timezone.utc)   # 不含（11-16 未走完）
START_DAY = datetime(2026, 8, 18, tzinfo=timezone.utc)  # 含


def http_get(url, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "gate-intraday-sim/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(2 * (i + 1))


def fetch_candles(contract):
    """15m K 线，from/to 分页（Gate 不允许 limit 与 from/to 同用），每 7 天一页。"""
    path = os.path.join(DATA_DIR, f"gate_15m_{contract}.csv")
    if os.path.exists(path):
        with open(path, newline="") as f:
            rows = list(csv.DictReader(f))
        bars = [{"t": int(r["t"]), "o": float(r["o"]), "h": float(r["h"]),
                 "l": float(r["l"]), "c": float(r["c"]), "v": float(r["v"]),
                 "sum": float(r["sum"])} for r in rows]
        if bars and bars[0]["t"] <= int(START_DAY.timestamp()) and bars[-1]["t"] >= int((END_DAY - timedelta(minutes=15)).timestamp()):
            print(f"[{contract}] K 线用缓存：{len(bars)} 根 {datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ {datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
            return bars
    bars = []
    cur = START_DAY
    while cur < END_DAY:
        nxt = min(cur + timedelta(days=7), END_DAY)
        url = (f"{BASE}/futures/usdt/candlesticks?contract={contract}&interval=15m"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            bars.append({"t": int(d["t"]), "o": float(d["o"]), "h": float(d["h"]),
                         "l": float(d["l"]), "c": float(d["c"]), "v": float(d["v"]),
                         "sum": float(d["sum"])})
        cur = nxt
        time.sleep(0.3)
    bars = sorted({b["t"]: b for b in bars}.values(), key=lambda b: b["t"])
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["t", "o", "h", "l", "c", "v", "sum"])
        w.writeheader()
        w.writerows(bars)
    print(f"[{contract}] K 线已取：{len(bars)} 根 {datetime.fromtimestamp(bars[0]['t'], timezone.utc).date()} ~ {datetime.fromtimestamp(bars[-1]['t'], timezone.utc).date()}")
    return bars


def fetch_funding(contract):
    """资金费率历史，返回 {settlement_ts: rate}。
    Gate 单次最多返回约 100 条（实测 limit=1000 只回 90 条），故用 from/to 按 30 天分页取。
    注意：from/to 分页返回的 t 会带 +1 秒偏移，统一向下取整到 8h 结算点。"""
    path = os.path.join(DATA_DIR, f"gate_funding_{contract}.json")
    out = {}
    cur = START_DAY
    while cur < END_DAY:
        nxt = min(cur + timedelta(days=30), END_DAY)
        url = (f"{BASE}/futures/usdt/funding_rate?contract={contract}&limit=100"
               f"&from={int(cur.timestamp())}&to={int(nxt.timestamp())}")
        data = http_get(url)
        for d in data:
            t = int(d["t"])
            t = (t // 28800) * 28800  # 归一化到结算点
            out[t] = float(d["r"])
        cur = nxt
        time.sleep(0.3)
    with open(path, "w") as f:
        json.dump(out, f)
    print(f"[{contract}] 资金费率已取：{len(out)} 条 "
          f"{datetime.fromtimestamp(min(out), timezone.utc).date()} ~ {datetime.fromtimestamp(max(out), timezone.utc).date()}")
    return out


def group_days(bars):
    days = {}
    for b in bars:
        d = datetime.fromtimestamp(b["t"], timezone.utc).date()
        days.setdefault(d, []).append(b)
    # 只保留 96 根的完整日
    return {d: v for d, v in sorted(days.items()) if len(v) == 96}


def ema_series(values, period):
    k = 2 / (period + 1)
    out = []
    ema = None
    for i, v in enumerate(values):
        if ema is None:
            ema = sum(values[:period]) / period if i == period - 1 else v
            if i < period - 1:
                out.append(None)
                continue
        else:
            ema = v * k + ema * (1 - k)
        out.append(ema)
    return out


class Trade:
    __slots__ = ("direction", "entry_t", "exit_t", "entry", "exit", "pnl", "liquidated", "reason",
                 "_notional", "_eq_at_entry")

    def __init__(self, direction, entry_t, entry):
        self.direction = direction  # 1 多 / -1 空
        self.entry_t = entry_t
        self.entry = entry
        self.exit_t = None
        self.exit = None
        self.pnl = 0.0
        self.liquidated = False
        self.reason = ""


def run_strategy(bars_by_day, funding, symbol, strategy, leverage):
    """返回 (trades, equity_curve, liquidations)。equity 起点 100000 USDT 虚拟。"""
    maint = MAINT_RATE[symbol]
    liq_move = 1.0 / leverage - maint  # 反向波动达到即爆仓
    equity = START_EQUITY
    trades = []
    curve = [equity]
    liquidations = 0

    for day, bars in bars_by_day.items():
        closes = [b["c"] for b in bars]
        ema9 = ema_series(closes, 9)
        ema21 = ema_series(closes, 21)
        # 日内 VWAP
        cum_pv, cum_v, vwap = 0.0, 0.0, [None] * len(bars)
        for i, b in enumerate(bars):
            tp = (b["h"] + b["l"] + b["c"]) / 3
            cum_pv += tp * b["sum"]
            cum_v += b["sum"]
            vwap[i] = cum_pv / cum_v if cum_v else b["c"]
        # 开盘区间（前 4 根）
        or_high = max(b["h"] for b in bars[:4])
        or_low = min(b["l"] for b in bars[:4])
        or_range = or_high - or_low

        pos = None
        trades_today = 0
        max_trades = {"ORB": 1, "VWAP": 2, "EMA": 3}[strategy]
        entry_sigma = None

        def funding_cost(tr):
            # 持仓跨过 08:00/16:00 UTC 结算点，按实际费率计
            cost = 0.0
            day_start = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
            for h in (8, 16):
                s = int((day_start + timedelta(hours=h)).timestamp())
                if tr.entry_t < s <= tr.exit_t and s in funding:
                    rate = funding[s]
                    cost += rate * tr._notional * (1 if tr.direction == 1 else -1)
            return cost

        for i, b in enumerate(bars):
            bar_start = datetime.fromtimestamp(b["t"], timezone.utc)
            hour = bar_start.hour + bar_start.minute / 60.0

            # ---- 持仓管理（用收盘价触发，下一根开盘成交；简化：触发即按收盘价成交）----
            if pos is not None:
                # 强平检查：用本根最高/最低价
                if pos.direction == 1:
                    adv = (pos.entry - b["l"]) / pos.entry
                else:
                    adv = (b["h"] - pos.entry) / pos.entry
                if adv >= liq_move:
                    pos.exit_t, pos.exit, pos.liquidated = b["t"], b["c"], True
                    pos.reason = "liquidated"
                    liquidations += 1
                    margin = 0.10 * pos._eq_at_entry
                    pos.pnl = -margin - pos._notional * (TAKER + SLIPPAGE)
                    equity += pos.pnl
                    trades.append(pos)
                    curve.append(equity)
                    pos = None
                    continue
                exited = False
                if strategy == "ORB":
                    if pos.direction == 1:
                        if b["c"] <= or_low or b["c"] >= pos.entry + 2 * or_range:
                            pos.reason = "stop_or_tp"
                            exited = True
                    else:
                        if b["c"] >= or_high or b["c"] <= pos.entry - 2 * or_range:
                            pos.reason = "stop_or_tp"
                            exited = True
                elif strategy == "VWAP":
                    if pos.direction == 1 and b["c"] >= vwap[i]:
                        pos.reason = "vwap_cross"
                        exited = True
                    elif pos.direction == -1 and b["c"] <= vwap[i]:
                        pos.reason = "vwap_cross"
                        exited = True
                    elif entry_sigma and abs(b["c"] - pos.entry) / pos.entry >= 0 and (
                            (pos.direction == 1 and b["c"] <= pos.entry - 2.5 * entry_sigma)
                            or (pos.direction == -1 and b["c"] >= pos.entry + 2.5 * entry_sigma)):
                        pos.reason = "stop"
                        exited = True
                elif strategy == "EMA":
                    if ema9[i] is not None and ema21[i] is not None:
                        if pos.direction == 1 and ema9[i] < ema21[i]:
                            pos.reason = "cross"
                            exited = True
                        elif pos.direction == -1 and ema9[i] > ema21[i]:
                            pos.reason = "cross"
                            exited = True
                if i == len(bars) - 1:  # 23:45 强制平仓
                    pos.reason = "eod"
                    exited = True
                if exited:
                    pos.exit_t, pos.exit = b["t"], b["c"]
                    move = (pos.exit - pos.entry) / pos.entry * pos.direction
                    fc = funding_cost(pos)
                    pos.pnl = pos._notional * move - pos._notional * ROUNDTRIP_COST - fc
                    equity += pos.pnl
                    trades.append(pos)
                    curve.append(equity)
                    pos = None
                    continue

            # ---- 开仓信号（收盘价触发，下一根开盘价成交）----
            if pos is None and trades_today < max_trades and i < len(bars) - 1:
                sig = 0
                if strategy == "ORB" and i >= 4:
                    if b["c"] > or_high:
                        sig = 1
                    elif b["c"] < or_low:
                        sig = -1
                elif strategy == "VWAP" and i >= 20:
                    sigma = statistics.pstdev(closes[i - 19:i + 1])
                    if b["c"] < vwap[i] - 1.5 * sigma:
                        sig, entry_sigma = 1, sigma
                    elif b["c"] > vwap[i] + 1.5 * sigma:
                        sig, entry_sigma = -1, sigma
                elif strategy == "EMA" and 8.0 <= hour < 20.0 and ema9[i] is not None and ema21[i] is not None and ema9[i - 1] is not None and ema21[i - 1] is not None:
                    if ema9[i - 1] <= ema21[i - 1] and ema9[i] > ema21[i]:
                        sig = 1
                    elif ema9[i - 1] >= ema21[i - 1] and ema9[i] < ema21[i]:
                        sig = -1
                if sig:
                    nxt = bars[i + 1]
                    entry = nxt["o"]
                    margin = MARGIN_FRAC * equity
                    tr = Trade(sig, nxt["t"], entry)
                    tr._notional = margin * leverage
                    tr._eq_at_entry = equity
                    pos = tr
                    trades_today += 1
        # 日内收尾：理论上 23:45 已平；若因信号在最后一根才触发则不持仓过夜（直接丢弃）
        if pos is not None:
            pos.exit_t, pos.exit, pos.reason = bars[-1]["t"], bars[-1]["c"], "eod"
            move = (pos.exit - pos.entry) / pos.entry * pos.direction
            fc = funding_cost(pos)
            pos.pnl = pos._notional * move - pos._notional * ROUNDTRIP_COST - fc
            equity += pos.pnl
            trades.append(pos)
            curve.append(equity)
            pos = None

    # 指标
    wins = [t for t in trades if t.pnl > 0]
    total_ret = (equity - START_EQUITY) / START_EQUITY
    # 最大回撤（按成交后权益曲线）
    peak, mdd = curve[0], 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = min(mdd, (v - peak) / peak)
    hold_min = [ (t.exit_t - t.entry_t) / 60 for t in trades if t.exit_t ]
    return {
        "symbol": symbol, "strategy": strategy, "leverage": leverage,
        "days": len(bars_by_day), "trades": len(trades),
        "win_rate": round(len(wins) / len(trades), 4) if trades else None,
        "net_return": round(total_ret, 4),
        "final_equity": round(equity, 2),
        "max_dd": round(mdd, 4),
        "avg_hold_min": round(sum(hold_min) / len(hold_min), 1) if hold_min else None,
        "liquidations": liquidations,
        "total_pnl": round(sum(t.pnl for t in trades), 2),
    }


def main():
    bj = datetime.now(timezone.utc) + timedelta(hours=8)
    print(f"取数时间（北京时间）：{bj.strftime('%Y-%m-%d %H:%M')}  数据源：Gate 公开接口  全模拟")
    print(f"窗口：{START_DAY.date()} ~ {END_DAY.date() - timedelta(days=1)}（90 个完整 UTC 日），15m，"
          f"成本：一轮开平名义 x 0.25%（taker 0.075%+滑点 0.05%，双边），资金费按实际费率计")
    results = []
    for sym in SYMBOLS:
        bars = fetch_candles(sym)
        funding = fetch_funding(sym)
        days = group_days(bars)
        print(f"[{sym}] 完整交易日：{len(days)} 天")
        for strat in ["ORB", "VWAP", "EMA"]:
            for lev in [1, 2, 3]:
                r = run_strategy(days, funding, sym, strat, lev)
                results.append(r)
                print(f"[{sym} {strat} {lev}x] 笔数={r['trades']} 胜率={r['win_rate']} "
                      f"净收益={r['net_return']*100:.2f}% 最大回撤={r['max_dd']*100:.2f}% "
                      f"平均持仓={r['avg_hold_min']}分钟 爆仓={r['liquidations']}")
    # 汇总：按策略 x 杠杆取三币平均净收益
    print("\n=== 汇总：三币平均净收益（各币独立 10 万 USDT 虚拟权益）===")
    for strat in ["ORB", "VWAP", "EMA"]:
        for lev in [1, 2, 3]:
            rs = [r for r in results if r["strategy"] == strat and r["leverage"] == lev]
            avg = sum(r["net_return"] for r in rs) / len(rs)
            tot_trades = sum(r["trades"] for r in rs)
            tot_liq = sum(r["liquidations"] for r in rs)
            print(f"{strat} {lev}x：平均净收益 {avg*100:.2f}%  总笔数 {tot_trades}  总爆仓 {tot_liq}")
    with open(os.path.join(DATA_DIR, "gate_intraday_summary.json"), "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print("\n模拟结束：本脚本不下单、不开户、不碰真钱。")


if __name__ == "__main__":
    main()
