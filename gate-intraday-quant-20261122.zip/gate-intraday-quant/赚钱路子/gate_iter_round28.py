#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盈利策略迭代 · 第二十八轮：日开盘区间“淡化上破”在新币种宇宙上的预注册检验（全模拟）
====================================================================================
只做日内、只做 Gate (gate.io) USDT 永续合约，杠杆只用 1x。
全程模拟，不下单、不开户、不碰真钱、不建议投真钱、不承诺收益。
不做资金费率套利。

背景：第二十七轮主臂（顺做日开盘区间突破）全亏，但反向臂 CTRL2 的
毛利 t +2.12 名义显著；拆方向×半段后只有“淡化上破”（价格上破日区间
后做空）一个格子两半同号——全期每笔毛利 +11.26 USDT（前 +18.66 /
后 +2.93）。在同一批 8 个币数据上再开一轮去“验证”它是循环论证，
不许做。本轮用第二十四轮的新 12 币宇宙做唯一不循环的检验。

跑前写死的规则（单组参数，不许用全样本挑）：
  主臂 MAIN（唯一主臂）：淡化上破单臂——每天 00:00 UTC 第一根 1h K 线
    的高低点构成当日开盘区间；随后价格以 1h 收盘价上破区间高点则做空
    （淡化），入场为触发根下一根 1h 开盘价；止损 1xATR、止盈 2xATR
    （用户要求的 1:2）；当天 23:00 强制平仓；每天每币最多 1 笔。
    下破区间不做（第二十七轮里淡化下破前后翻号）。
    语义（与第二十七轮 CTRL2 的淡化上破格子一字对应）：每天只看当日
    首个 ATR 有效的破位——若首个破位是上破则做空；若首个破位是下破，
    当天不做（记为 down_first，不再等后面的上破）。ATR 缺失的破位
    按第二十七轮约定跳过、继续向后找（只影响首日热身）。
  对照 1 CTRL1：同一批新 12 币上的第二十七轮 CTRL2 全版（上破做空 +
    下破做多），用来判断单臂相对全版有没有变化；并可拆方向得到新币
    的淡化上破/淡化下破格子。
  对照 2 CTRL2：原 8 币上的淡化上破单臂，用来确认引擎零口径漂移：
    必须与第二十七轮已发表的拆分格子在“交易集合”上一字复现——
    同 1,392 笔（前 737 / 后 655），逐笔入场/出场/方向/出场原因
    全部相同，每笔毛利占名义比全期 +0.1153%（前 +0.1904% /
    后 +0.0307%）一字相同。注意：USDT 计价的每笔毛利（第二十七轮
    发表值全期 +11.26 / 前 +18.66 / 后 +2.93）在本轮单臂独立运行
    里会略高（全期约 +11.45），差值 +1.7% 纯粹是权益路径效应——
    单臂运行跳过了淡化下破那些亏钱的交易，权益回撤更小、每笔名义
    略大，不是引擎差异；复核以交易集合与毛利/名义比为准（见报告 §8）。
  预期（跑前写死）：仍不达标——第二十七轮后半段淡化上破只有 +2.93
    USDT，量级太弱；新币种上大概率连这个量级都没有。

与前轮的逐项区别（跑前写死，报告里逐项写清，不许事后 reinterpret）：
  vs 第二十七轮主臂 MAIN：主臂是顺做（上破做多/下破做空）；本轮主臂
    只做其中“上破做空”这一半，且是先破方向决定是否交易（首个破位
    是下破则当天空仓），不是“每天必做一笔”。
  vs 第二十七轮 CTRL2：CTRL2 是反向全版（上破做空 + 下破做多，每天
    必做一笔）；本轮主臂是 CTRL2 的 SHORT 子集（只保留上破触发的那
    些交易），CTRL1 是 CTRL2 在新 12 币上的一字复刻（引擎 import
    第二十七轮，零口径漂移），CTRL2 是主臂在原 8 币上的一字复刻
    （复核用）。
  vs 第二十四轮：新 12 币宇宙、缓存、资金费口径全部复用第二十四轮
    （含资金费接口 180 天保留期边界 2026-05-22、新币 05-21 按 0 计、
    HYPE/BLESS/AKE 4h 结算已重拉并按 4h 归并）；XAUT 按成文标准入选，
    报告给出剔除 XAUT 的敏感性（第二十四轮同款）。

数据（复用本地缓存，不联网）：
  1h：2025-11-16~2026-11-15，365 个完整日；原 8 币与新 12 币各 8,761 根
    （含末根 2026-11-16 00:00 未走完半根，group_days 只取满 24 根的
    日，主臂/对照都不涉及该根）；前半段 2025-11-16~2026-05-19
    （185 天）、后半段 2026-05-20~2026-11-15（180 天）。
  本轮规则只在 1h 上定义（区间、触发、入场全是 1h），不跑 15m 臂；
    15m 缓存不参与本轮（第二十七轮 15m 上的淡化上破格子前后翻号，
    不作为本轮的对照）。
  资金费：data/gate_funding_365d_{...}.json；原币自 2026-05-21 起、
    新币自 2026-05-22 起，之前按 0 计（第二十四轮同款约定）。

达标标准（不变）：前后两半都为正且全期 1 倍净收益 >2% 才算找到，
否则诚实写不达标。主口径 Taker。

复核（跑后必须通过，否则先修引擎再出报告）：
  (a) 脚本跑两遍，summary 与 trades 的 md5 两次运行完全一致。
  (b) 对照 2（原 8 币淡化上破单臂）必须与第二十七轮已发表格子在
      “交易集合”上一字复现：同 1,392 笔（前 737 / 后 655），逐笔
      入场/出场/方向/出场原因全部相同，每笔毛利占名义比全期
      +0.1153%（前 +0.1904% / 后 +0.0307%）一字相同；USDT 计价
      的每笔毛利会因权益路径效应略高约 +1.7%（见上），不是引擎差异。
  (c) 主臂首笔新币交易人工核对触发链、入场价、止损/止盈、PnL 全对上 CSV。
  (d) 漏斗算术自洽：天数 = 信号 + 首破下破 + 无突破 + ATR 缺失 +
      无同日下一根（主臂/对照 2）；对照 1 同第二十七轮（天数 =
      信号 + 无突破 + ATR 缺失 + 无同日下一根）。
  (e) 对照 1（新 12 币 CTRL2 全版）的淡化上破/淡化下破方向格子，
      与主臂在新币上的信号数满足：主臂信号数 = 对照 1 里首破为
      上破的交易数（同一批破位、同一天）。

运行：python3 gate_iter_round28.py（不联网，只读本地缓存）
输出：终端打印全部表 + data/gate_iter_round28_summary.json
      + data/gate_iter_round28_trades.csv
复现：跑两遍，两个文件的 md5 应完全一致。
"""
import csv
import json
import math
import os
import sys
from collections import Counter
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
sys.path.insert(0, SCRIPT_DIR)
import gate_iter_round27 as r27  # 引擎一字复用，零口径漂移

# ---- 预注册、跑前写死：单组参数，不许用全样本挑 ----
TP_MULT = 2.0            # 止盈 2xATR（用户要求的 1:2）
SL_MULT = 1.0            # 止损 1xATR
SPLIT_1H = r27.SPLIT_1H  # 前半段止于 2026-05-19
START_EQUITY = r27.START_EQUITY

ORIG8 = ["BTC_USDT", "ETH_USDT", "SOL_USDT",
         "DOGE_USDT", "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
NEW12 = ["ZEC_USDT", "EVAA_USDT", "HYPE_USDT", "LTC_USDT", "BLESS_USDT",
         "XLM_USDT", "AKE_USDT", "NEAR_USDT", "PEPE_USDT", "UNI_USDT",
         "SUI_USDT", "XAUT_USDT"]
ALL20 = ORIG8 + NEW12

# 新币种 Maker 成交率/惩罚用 SOL 保守代理（第二十四轮同款约定）
for _sym in NEW12:
    if _sym not in r27.FILL:
        r27.FILL[_sym] = r27.FILL["SOL_USDT"]
        r27.PENALTY[_sym] = r27.PENALTY["SOL_USDT"]


def build_daily_orb_fade_up(day_bars, atr_by_gi, gi_of_t, or_bars=1):
    """淡化上破单臂：每天只看当日首个 ATR 有效的破位。
    首个破位是上破 → SHORT 信号；首个破位是下破 → 当天不做
    （outcome 'down_first'）。ATR 缺失的破位跳过、继续向后找
    （第二十七轮同款约定，只影响首日热身）。"""
    or_hi = max(b["h"] for b in day_bars[:or_bars])
    or_lo = min(b["l"] for b in day_bars[:or_bars])
    atr_skip = False
    for i in range(or_bars, len(day_bars)):
        b = day_bars[i]
        if b["c"] > or_hi:
            direction = -1
        elif b["c"] < or_lo:
            direction = 1  # 先记方向，但 ATR 缺失时不算数、继续向后找
        else:
            continue
        a = atr_by_gi[gi_of_t[b["t"]]]
        if a is None:
            atr_skip = True
            continue
        if direction == 1:
            return None, "down_first", or_hi, or_lo
        if i + 1 >= len(day_bars):
            return None, "no_sameday", or_hi, or_lo
        entry_bar = day_bars[i + 1]
        sig = {"direction": direction, "atr": a, "sl_mult": SL_MULT,
               "tp_mult": TP_MULT, "signal_t": b["t"],
               "signal_o": b["o"], "signal_c": b["c"],
               "or_hi": or_hi, "or_lo": or_lo, "or_bars": or_bars,
               "entry_t": entry_bar["t"]}
        return sig, "signal", or_hi, or_lo
    return None, ("atr_skip" if atr_skip else "no_break"), or_hi, or_lo


def main():
    print("盈利策略迭代 · 第二十八轮：日开盘区间“淡化上破”在新币种宇宙上的预注册检验（全模拟）")
    print("主臂 MAIN 淡化上破单臂（新 12 币）；对照 1：新 12 币 CTRL2 全版；对照 2：原 8 币淡化上破单臂（复核）。")
    print("止损 1xATR / 止盈 2xATR；每天每币最多 1 笔；达标标准：前后两半都为正且全期 1 倍净收益 >2%。")

    # ---- 数据校验（只读本地缓存，不联网）----
    data1h = {}
    for sym in ALL20:
        bars = r27.load_bars(os.path.join(DATA_DIR, f"gate_1h_365d_{sym}.csv"))
        funding = r27.load_funding(sym)
        data1h[sym] = (bars, funding)
        days = r27.group_days(bars, 24)
        assert len(days) == 365, f"{sym} 1h 完整日应为 365 天，实际 {len(days)}"
        assert len(bars) == 8761, f"{sym} 1h 应为 8761 根，实际 {len(bars)}"
    base_ts = [b["t"] for b in data1h["BTC_USDT"][0]]
    for sym in ALL20:
        assert [b["t"] for b in data1h[sym][0]] == base_ts, f"{sym} 1h 时间戳与 BTC 不对齐"
    print("数据校验通过：20 币各 8,761 根 1h / 365 个完整日；时间戳对齐、零缺口。")

    days_all = set(r27.group_days(data1h["BTC_USDT"][0], 24).keys())
    front = {d for d in days_all if d < SPLIT_1H.date()}
    back = {d for d in days_all if d >= SPLIT_1H.date()}
    print(f"窗口：1h 全 365d（前 {len(front)} 天 / 后 {len(back)} 天）。")

    # ---- 信号生成：每臂每币每天最多 1 个信号 ----
    sigs, outcomes = {}, {}
    atr1h = {s: r27.atr_wilder(data1h[s][0]) for s in ALL20}
    gi1h = {s: {b["t"]: i for i, b in enumerate(data1h[s][0])} for s in ALL20}

    # 主臂 MAIN：新 12 币淡化上破单臂
    for sym in NEW12:
        bars, _ = data1h[sym]
        days = r27.group_days(bars, 24)
        sd, oc = {}, {}
        for day, db in days.items():
            sig, outcome, _, _ = build_daily_orb_fade_up(db, atr1h[sym], gi1h[sym], 1)
            oc[day] = outcome
            if sig is not None:
                sd[sig["entry_t"]] = sig
        sigs[("MAIN", "1h", sym)] = sd
        outcomes[("MAIN", "1h", sym)] = oc
    # 对照 1 CTRL1：新 12 币 CTRL2 全版（上破做空 + 下破做多，第二十七轮原样）
    for sym in NEW12:
        bars, _ = data1h[sym]
        days = r27.group_days(bars, 24)
        sd, oc = {}, {}
        for day, db in days.items():
            sig, outcome, _, _ = r27.build_daily_orb_1h(db, atr1h[sym], gi1h[sym], 1, True)
            oc[day] = outcome
            if sig is not None:
                sd[sig["entry_t"]] = sig
        sigs[("CTRL1", "1h", sym)] = sd
        outcomes[("CTRL1", "1h", sym)] = oc
    # 对照 2 CTRL2：原 8 币淡化上破单臂（复核）
    for sym in ORIG8:
        bars, _ = data1h[sym]
        days = r27.group_days(bars, 24)
        sd, oc = {}, {}
        for day, db in days.items():
            sig, outcome, _, _ = build_daily_orb_fade_up(db, atr1h[sym], gi1h[sym], 1)
            oc[day] = outcome
            if sig is not None:
                sd[sig["entry_t"]] = sig
        sigs[("CTRL2", "1h", sym)] = sd
        outcomes[("CTRL2", "1h", sym)] = oc

    for arm, gran, syms in (("MAIN", "1h", NEW12), ("CTRL1", "1h", NEW12),
                            ("CTRL2", "1h", ORIG8)):
        tot_sig = sum(len(sigs[(arm, gran, s)]) for s in syms)
        tot_days = sum(len(outcomes[(arm, gran, s)]) for s in syms)
        cnt = Counter()
        for s in syms:
            cnt.update(outcomes[(arm, gran, s)].values())
        print(f"[{arm}-{gran}] 天数 {tot_days}：信号 {tot_sig}（突破率 {tot_sig/tot_days*100:.1f}%）| "
              f"首破下破 {cnt['down_first']} / 无突破 {cnt['no_break']} / "
              f"ATR 缺失 {cnt['atr_skip']} / 无同日下一根 {cnt['no_sameday']}。")

    ARMS = [
        ("MAIN", "ORB-day-fade-up", "1h", NEW12,
         [("365d", None), ("前185d", front), ("后180d", back)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
        ("CTRL1", "ORB-day-1h-rev", "1h", NEW12,
         [("365d", None), ("前185d", front), ("后180d", back)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
        ("CTRL2", "ORB-day-fade-up", "1h", ORIG8,
         [("365d", None), ("前185d", front), ("后180d", back)],
         lambda et: "前185d" if datetime.fromtimestamp(et, timezone.utc).date() < SPLIT_1H.date() else "后180d"),
    ]

    all_results, all_trades = [], []
    for arm, label, gran, syms, windows, split_fn in ARMS:
        print(f"\n=== {arm} {label} · {gran}（TP {TP_MULT}，SL {SL_MULT}，每天每币最多 1 笔）===")
        for sym in syms:
            sig_dict = sigs[(arm, gran, sym)]
            for wname, subset in windows:
                bars, funding = data1h[sym]
                trades, curve, ndays, skipped = r27.simulate_daily(
                    sym, bars, sig_dict, funding, subset, label, 24, gran)
                oc = outcomes[(arm, gran, sym)]
                oc_days = oc if subset is None else {d: o for d, o in oc.items() if d in subset}
                fc = Counter(oc_days.values())
                res = r27.summarize(sym, trades, curve, label, len(sig_dict))
                res["arm"] = arm
                res["variant"] = label
                res["family"] = "ORB-day-fade-up"
                res["tp_mult"] = TP_MULT
                res["granularity"] = gran
                res["split"] = wname
                res["days"] = ndays
                res["days_breakout"] = fc["signal"] + fc["no_sameday"]
                res["days_down_first"] = fc["down_first"]
                res["days_no_break"] = fc["no_break"]
                res["days_atr_skip"] = fc["atr_skip"]
                res["days_no_sameday"] = fc["no_sameday"]
                res["signals_pass"] = fc["signal"]
                res["breakout_rate"] = round((fc["signal"] + fc["no_sameday"]) / ndays, 4) if ndays else None
                res["signal_pass_rate"] = res["breakout_rate"]
                res["skipped_circuit"] = dict(skipped).get("circuit", 0)
                all_results.append(res)
                if wname == "365d":
                    for t in trades:
                        t2 = dict(t)
                        t2["arm"] = arm
                        t2["variant"] = label
                        t2["family"] = "ORB-day-fade-up"
                        t2["tp_mult"] = TP_MULT
                        t2["granularity"] = gran
                        t2["split"] = split_fn(t["entry_t"])
                        t2["entry_hour_utc"] = datetime.fromtimestamp(t["entry_t"], timezone.utc).hour
                        all_trades.append(t2)
                print(f"[{arm} {gran} {sym} {wname}] n={res['trades']} "
                      f"信号 {fc['signal']} 首破下破={fc['down_first']} "
                      f"胜率={res['win_rate']} 盈亏比={res['profit_factor']} "
                      f"Taker {res['taker_net_pct']*100:+.2f}% "
                      f"(t={res['t_taker']}, MDD {res['taker_max_dd']*100:.2f}%) | "
                      f"M1 {res['m1_net_pct']*100:+.2f}% M2 {res['m2_net_pct']*100:+.2f}% "
                      f"毛利={res['gross_usdt']:+.0f} "
                      f"每笔毛利={res['gross_per_trade_usdt']:+.2f} 成本={res['taker_cost_sum']:+.0f} "
                      f"持仓={res['avg_hold_min']}分钟 出场={res['reason_counts']}")

    # ---- 汇总平均 ----
    print("\n=== 汇总：平均净收益（各币独立 10 万 USDT，1x，主口径 Taker）===")
    for arm, label, gran, syms, windows, _ in ARMS:
        for wname, _ in windows:
            rs = [r for r in all_results if r["arm"] == arm
                  and r["granularity"] == gran and r["split"] == wname]
            gt = sum(r["gross_usdt"] for r in rs)
            ct = sum(r["taker_cost_sum"] for r in rs)
            nt = sum(r["trades"] for r in rs)
            nd = sum(r["days"] for r in rs)
            nbr = sum(r["days_breakout"] for r in rs)
            wr = (sum(r["win_rate"] * r["trades"] for r in rs) / nt) if nt else None
            wr_s = f"{wr:.3f}" if wr is not None else "—"
            gp = f"{gt/nt:+.2f}" if nt else "—"
            print(f"  {arm} {gran} {wname}：Taker 平均 "
                  f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M1 平均 {sum(r['m1_net_pct'] for r in rs)/len(rs)*100:+.2f}% / "
                  f"M2 平均 {sum(r['m2_net_pct'] for r in rs)/len(rs)*100:+.2f}% | "
                  f"毛利合计 {gt:+.0f} 成本合计 {ct:+.0f} 笔数 {nt} "
                  f"每笔毛利 {gp} USDT 胜率 {wr_s} | "
                  f"突破率 {nbr/nd*100:.1f}%（{nbr}/{nd} 天）")

    # ---- 漏斗校验（全期）----
    print("\n=== 漏斗校验（全期）===")
    for arm, label, gran, syms, windows, _ in ARMS:
        full = windows[0][0]
        rs = [r for r in all_results if r["arm"] == arm
              and r["granularity"] == gran and r["split"] == full]
        nd = sum(r["days"] for r in rs)
        nb = sum(r["days_no_break"] for r in rs)
        na = sum(r["days_atr_skip"] for r in rs)
        ns = sum(r["days_no_sameday"] for r in rs)
        ndf = sum(r["days_down_first"] for r in rs)
        ne = sum(r["trades"] for r in rs)
        ncap = sum(r["skipped_circuit"] for r in rs)
        print(f"  {arm} {gran}：天数 {nd} = 首破下破 {ndf} + 无突破 {nb} + ATR 缺失 {na} + "
              f"无同日下一根 {ns} + 执行 {ne}（和 {ndf+nb+na+ns+ne}，"
              f"熔断跳过 {ncap}）→ {'✓ 自洽' if nd == ndf+nb+na+ns+ne else '✗ 不自洽！'}")

    # ---- pooled t（全期明细，Taker / 毛利 / M1）----
    print("\n=== Pooled t 值（全期明细，逐笔净收益占权益 %）===")
    for arm, label, gran, syms, windows, _ in ARMS:
        full = windows[0][0]
        sub = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
        for wname, _ in windows:
            s2 = [t for t in sub if wname == full or t["split"] == wname]
            vt = [t["pnl"] / START_EQUITY for t in s2]
            vg = [(t["price_pnl"] - t["funding_cost_usdt"]) / START_EQUITY for t in s2]
            vm = [t["pnl_maker_m1"] / START_EQUITY for t in s2]
            print(f"  {arm} {gran} {wname}：n={len(s2)} "
                  f"pooled t(Taker)={r27.t_value(vt)} pooled t(毛利)={r27.t_value(vg)} "
                  f"pooled t(M1)={r27.t_value(vm)}")

    # ---- 方向格子诊断：对照 1 拆方向（SHORT=淡化上破，LONG=淡化下破）----
    print("\n=== 方向格子诊断（每笔毛利，全期混池）===")
    for arm, gran in (("MAIN", "1h"), ("CTRL1", "1h"), ("CTRL2", "1h")):
        sub = [t for t in all_trades if t["arm"] == arm and t["granularity"] == gran]
        for d in (1, -1):
            for wname in ("前185d", "后180d", "all"):
                s2 = [t for t in sub if t["direction"] == d and (wname == "all" or t["split"] == wname)]
                if not s2:
                    print(f"  {arm} {'LONG' if d==1 else 'SHORT'} {wname}：n=0")
                    continue
                g = sum(t["price_pnl"] - t["funding_cost_usdt"] for t in s2)
                print(f"  {arm} {'LONG' if d==1 else 'SHORT'} {wname}：n={len(s2)} "
                      f"每笔毛利 {g/len(s2):+.2f} USDT 毛利合计 {g:+.0f}")

    # ---- 达标判定 ----
    print("\n=== 达标判定（主口径 Taker）===")
    for arm, label, gran, syms, windows, _ in ARMS:
        wnames = [w for w, _ in windows]
        row = {}
        for wname in wnames:
            rs = [r for r in all_results if r["arm"] == arm
                  and r["granularity"] == gran and r["split"] == wname]
            row[wname] = sum(r["taker_net_pct"] for r in rs) / len(rs)
        good = row[wnames[1]] > 0 and row[wnames[2]] > 0 and row[wnames[0]] > 0.02
        print(f"  {arm} {gran} Taker：前 {row[wnames[1]]*100:+.2f}% / "
              f"后 {row[wnames[2]]*100:+.2f}% / 全 {row[wnames[0]]*100:+.2f}% → "
              f"{'达标' if good else '不达标'}")
        for sym in syms:
            rf = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                  and r["symbol"] == sym and r["split"] == wnames[1]][0]
            rb = [r for r in all_results if r["arm"] == arm and r["granularity"] == gran
                  and r["symbol"] == sym and r["split"] == wnames[2]][0]
            both = rf["taker_net_pct"] > 0 and rb["taker_net_pct"] > 0
            print(f"    {sym}: 前 {rf['taker_net_pct']*100:+.2f}% / "
                  f"后 {rb['taker_net_pct']*100:+.2f}% → "
                  f"{'★ 两半都为正' if both else ''}")

    # ---- XAUT 敏感性：主臂剔除 XAUT ----
    print("\n=== XAUT 敏感性（主臂 MAIN，剔除 XAUT 后 11 币平均）===")
    for wname in ("前185d", "后180d", "365d"):
        rs = [r for r in all_results if r["arm"] == "MAIN"
              and r["granularity"] == "1h" and r["split"] == wname
              and r["symbol"] != "XAUT_USDT"]
        print(f"  MAIN 除 XAUT {wname}：Taker 平均 "
              f"{sum(r['taker_net_pct'] for r in rs)/len(rs)*100:+.2f}% "
              f"（{len(rs)} 币）")

    with open(os.path.join(DATA_DIR, "gate_iter_round28_summary.json"), "w") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    with open(os.path.join(DATA_DIR, "gate_iter_round28_trades.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["family", "arm", "variant", "tp_mult", "granularity", "split", "symbol",
                    "direction", "signal_time_utc", "entry_time_utc", "entry_hour_utc",
                    "exit_time_utc", "or_high", "or_low", "signal_open", "signal_close", "atr",
                    "entry", "exit", "notional", "pnl_taker_usdt", "pnl_maker_m1_usdt",
                    "price_pnl_usdt", "cost_taker_usdt", "cost_maker_usdt",
                    "funding_cost_usdt", "reason", "hold_min"])
        for t in sorted(all_trades, key=lambda x: (x["entry_t"], x["arm"], x["granularity"], x["symbol"])):
            w.writerow([t["family"], t["arm"], t["variant"], t["tp_mult"], t["granularity"],
                        t["split"], t["symbol"], "LONG" if t["direction"] == 1 else "SHORT",
                        datetime.fromtimestamp(t["signal_t"], timezone.utc).isoformat(),
                        datetime.fromtimestamp(t["entry_t"], timezone.utc).isoformat(),
                        t["entry_hour_utc"],
                        datetime.fromtimestamp(t["exit_t"], timezone.utc).isoformat() if t.get("exit_t") else "",
                        t["or_hi"], t["or_lo"], t["signal_o"], t["signal_c"], t["atr"],
                        t["entry"], t["exit"], t["notional"],
                        round(t["pnl"], 2), t.get("pnl_maker_m1"),
                        round(t["price_pnl"], 2), round(t["cost_usdt"], 2),
                        round(t["cost_maker_usdt"], 2), round(t["funding_cost_usdt"], 2),
                        t["reason"], t["hold_min"]])
    print("\n汇总已写入：data/gate_iter_round28_summary.json "
          f"({len(all_results)} 条)")
    print(f"明细已写入：data/gate_iter_round28_trades.csv ({len(all_trades)} 笔)")
    print("模拟结束：本脚本不下单、不开户、不碰真钱；以上均为模拟结果，不承诺收益。")


if __name__ == "__main__":
    main()
