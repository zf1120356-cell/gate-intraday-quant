#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
实测 Gate 8 个币的真实交易摩擦（为纸面引擎真实成本模型提供参数）
- 订单簿：spread / 10,000 名义市价单扫盘成本（3 次快照取中位数）
- 1m K 线（24h）：平均 |1m 收益|、p90 |1m 收益|、平均 1m 振幅、破位后 1 分钟延续（止损单超滑实测）
只读公开接口，不花真钱。输出 JSON 到 paper_cost_measure_YYYY-MM-DD.json。
"""
import json
import math
import os
import statistics
import time
import urllib.request

API = "https://api.gateio.ws/api/v4/futures/usdt"
COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]
CONTRACT = {c: f"{c}_USDT" for c in COINS}
NOMINAL = 10000.0
BASE = os.path.dirname(os.path.abspath(__file__))


def get(url, retries=3):
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.load(r)
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1 * (i + 1))
    raise RuntimeError(f"{url}: {last}")


def pct(vals, q):
    s = sorted(vals)
    if not s:
        return None
    k = (len(s) - 1) * q
    f, c = math.floor(k), math.ceil(k)
    if f == c:
        return s[int(k)]
    return s[f] * (c - k) + s[c] * (k - f)


def main():
    out = {"measured_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "nominal_usdt": NOMINAL, "coins": {}}
    # 1) 合约乘数（quanto_multiplier：1 张合约 = 多少基础币）
    mult = {}
    for c in COINS:
        d = get(f"{API}/contracts/{CONTRACT[c]}")
        mult[c] = float(d["quanto_multiplier"])
    out["quanto_multiplier"] = mult
    # 交叉校验：volume_24h_usdt / (volume_24h * last) 应约等于 quanto_multiplier
    tk = {d["contract"]: d for d in get(f"{API}/tickers")}
    for c in COINS:
        d = tk[CONTRACT[c]]
        chk = float(d["volume_24h_quote"]) / (float(d["volume_24h"]) * float(d["last"]))
        out["coins"].setdefault(c, {})["quanto_check"] = round(chk, 6)

    # 2) 订单簿：3 次快照（间隔约 60 秒）
    snaps = {c: [] for c in COINS}
    for s in range(3):
        for c in COINS:
            ob = get(f"{API}/order_book?contract={CONTRACT[c]}&limit=20")
            asks = [(float(x["p"]), float(x["s"])) for x in ob["asks"]]
            bids = [(float(x["p"]), float(x["s"])) for x in ob["bids"]]
            asks.sort()
            bids.sort(reverse=True)
            best_ask, best_bid = asks[0][0], bids[0][0]
            mid = (best_ask + best_bid) / 2
            spread_bps = (best_ask - best_bid) / mid * 10000
            res = {"mid": mid, "spread_bps": spread_bps,
                   "best_ask": best_ask, "best_bid": best_bid}
            # 扫盘 10,000 名义的 VWAP（按张数×乘数×价 = 名义累加）
            for side, levels in (("ask", asks), ("bid", bids)):
                remain = NOMINAL
                notional = 0.0
                vwap_num = 0.0
                for price, size in levels:
                    lvl_notional = size * mult[c] * price
                    take = min(lvl_notional, remain)
                    vwap_num += take * price
                    notional += take
                    remain -= take
                    if remain <= 0:
                        break
                if notional <= 0:
                    res[f"walk_{side}"] = None
                    continue
                vwap = vwap_num / notional
                res[f"walk_{side}"] = {
                    "filled_usdt": round(notional, 2),
                    "vwap": vwap,
                    "vwap_vs_mid_bps": (vwap - mid) / mid * 10000 if side == "ask" else (mid - vwap) / mid * 10000,
                    "vwap_vs_best_bps": (vwap - best_ask) / mid * 10000 if side == "ask" else (best_bid - vwap) / mid * 10000,
                }
            snaps[c].append(res)
        if s < 2:
            time.sleep(60)
    for c in COINS:
        ss = snaps[c]
        out["coins"][c]["orderbook"] = {
            "spread_bps_median": round(statistics.median([x["spread_bps"] for x in ss]), 3),
            "spread_bps_snaps": [round(x["spread_bps"], 3) for x in ss],
            "mid": ss[-1]["mid"],
            "ask_walk_vs_mid_bps_median": round(statistics.median([x["walk_ask"]["vwap_vs_mid_bps"] for x in ss]), 3),
            "bid_walk_vs_mid_bps_median": round(statistics.median([x["walk_bid"]["vwap_vs_mid_bps"] for x in ss]), 3),
            "ask_walk_vs_best_bps_median": round(statistics.median([x["walk_ask"]["vwap_vs_best_bps"] for x in ss]), 3),
            "bid_walk_vs_best_bps_median": round(statistics.median([x["walk_bid"]["vwap_vs_best_bps"] for x in ss]), 3),
            "ask_filled_usdt_min": min(x["walk_ask"]["filled_usdt"] for x in ss),
            "bid_filled_usdt_min": min(x["walk_bid"]["filled_usdt"] for x in ss),
        }

    # 3) 1m K 线（24h，1440 根）
    for c in COINS:
        bars = get(f"{API}/candlesticks?contract={CONTRACT[c]}&interval=1m&limit=1440")
        bars = [{"t": int(b["t"]), "o": float(b["o"]), "h": float(b["h"]),
                 "l": float(b["l"]), "c": float(b["c"])} for b in bars]
        bars.sort(key=lambda b: b["t"])
        rets = [abs(bars[i]["c"] / bars[i - 1]["c"] - 1) * 10000 for i in range(1, len(bars))]
        rng = [(b["h"] - b["l"]) / ((b["h"] + b["l"]) / 2) * 10000 for b in bars]
        # ATR(14) 1m（Wilder），取均值
        trs = []
        for i, b in enumerate(bars):
            if i == 0:
                trs.append(b["h"] - b["l"])
            else:
                pc = bars[i - 1]["c"]
                trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
        atr = sum(trs[:14]) / 14
        atrs = [atr]
        for i in range(14, len(trs)):
            atr = (atr * 13 + trs[i]) / 14
            atrs.append(atr)
        mid_price = statistics.median([b["c"] for b in bars])
        atr_bps = [a / mid_price * 10000 for a in atrs]
        # 破位后 1 分钟延续（止损单超滑实测）：本根收盘破上一根低点/高点，
        # 下一根的最低/最高相对本根收盘又延伸多少（bps），双向取均值
        over = []
        for i in range(1, len(bars) - 1):
            if bars[i]["c"] < bars[i - 1]["l"]:  # 向下破位
                over.append((bars[i]["c"] - bars[i + 1]["l"]) / bars[i]["c"] * 10000)
            elif bars[i]["c"] > bars[i - 1]["h"]:  # 向上破位
                over.append((bars[i + 1]["h"] - bars[i]["c"]) / bars[i]["c"] * 10000)
        out["coins"][c]["vol_1m"] = {
            "n_bars": len(bars),
            "mean_abs_ret_bps": round(statistics.mean(rets), 3),
            "p90_abs_ret_bps": round(pct(rets, 0.90), 3),
            "p99_abs_ret_bps": round(pct(rets, 0.99), 3),
            "mean_range_bps": round(statistics.mean(rng), 3),
            "atr14_1m_bps_mean": round(statistics.mean(atr_bps), 3),
            "breakout_overshoot_next1m_bps_mean": round(statistics.mean(over), 3) if over else None,
            "breakout_overshoot_next1m_bps_p90": round(pct(over, 0.90), 3) if over else None,
            "n_breakouts": len(over),
        }
    day = time.strftime("%Y-%m-%d", time.gmtime())
    path = os.path.join(BASE, f"paper_cost_measure_{day}.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"写出：{path}")
    for c in COINS:
        ob = out["coins"][c]["orderbook"]
        v = out["coins"][c]["vol_1m"]
        print(f"{c}: spread={ob['spread_bps_median']}bp 扫盘ask={ob['ask_walk_vs_mid_bps_median']}bp/"
              f"bid={ob['bid_walk_vs_mid_bps_median']}bp 充10k={ob['ask_filled_usdt_min']}/"
              f"{ob['bid_filled_usdt_min']}USDT | 1m均|ret|={v['mean_abs_ret_bps']}bp "
              f"p90={v['p90_abs_ret_bps']}bp 振幅={v['mean_range_bps']}bp ATR={v['atr14_1m_bps_mean']}bp "
              f"破位延续均值={v['breakout_overshoot_next1m_bps_mean']}bp p90={v['breakout_overshoot_next1m_bps_p90']}bp "
              f"n={v['n_breakouts']}")


if __name__ == "__main__":
    main()
