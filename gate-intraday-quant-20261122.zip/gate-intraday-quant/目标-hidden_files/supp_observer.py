#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘中补充触发（live 盘中拒绝观察）——独立观察模块
====================================================
归属：主系统主观层。只作纸面观察，不上真钱。
设计见《纸面交易/盘中补充触发-设计.md》v1（预注册）。

本模块不依赖引擎，可独立测试/扫描；引擎（副本）调用它。
做空/做多对称定义；本文件只实现判定 + 计划文件写入/解析，
不做任何交易、不读 live 引擎状态、不碰分系统。

关键参数（设计 v1 定稿，扫描 v6 验证）：
  ATR_PERIOD=14（Wilder，15m）
  CLUSTER_TOL=0.5×ATR15（簇内两根高点相差上限）
  CLUSTER_GAP_MIN/MAX=8/16 根（簇两根相隔 2–4h）
  CLUSTER_RECENCY=24 根（簇第二根距探针 ≤6h，位子要新鲜）
  BAND_PAD=0.25×ATR15（位带半宽）
  STRENGTH=1.5×ATR15（探针上影 或 确认根跌幅/涨幅，任一达标）
  L1_LOOKBACK_1H=4（最近 4 根有效 1h）
  L1_FIRST_EXCEED_WINDOW=8 根（2h 内首次上破）
"""
import os
import re
from datetime import datetime, timezone

ATR_PERIOD = 14
CLUSTER_TOL = 0.5
CLUSTER_GAP_MIN = 8
CLUSTER_GAP_MAX = 16
CLUSTER_RECENCY = 24
BAND_PAD = 0.25
STRENGTH = 1.5
L1_LOOKBACK_1H = 4
L1_FIRST_EXCEED_WINDOW = 8

SUPP_SECTION_HDR = "## 盘中补充触发"


def atr_wilder(bars, period=ATR_PERIOD):
    """Wilder ATR，与引擎一字相同。bars: [{t,o,h,l,c}...] 按时间升序。"""
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = bars[i - 1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = [None] * len(bars)
    if len(trs) >= period:
        atr[period - 1] = sum(trs[:period]) / period
        for i in range(period, len(trs)):
            atr[i] = (atr[i - 1] * (period - 1) + trs[i]) / period
    return atr


def fmt_ts(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")


def _is_valid_1h(b):
    """排除 h==l 的扁平占位根（Gate 1h 接口偶尔返回当前小时占位根）。"""
    return b["h"] > b["l"]


def _find_l1(bars1h, probe_t, direction):
    """L1：最近 4 根有效已收盘 1h 的高点区（做空）/低点区（做多）。
    返回 (zone_extreme, last_extreme) 或 None。
    做空：zone_extreme=ZoneMax（4 根高点最大），last_extreme=最近一根 1h 高点。
    做多：zone_extreme=ZoneMin（4 根低点最小），last_extreme=最近一根 1h 低点。"""
    closed = [b for b in bars1h if b["t"] + 3600 <= probe_t and _is_valid_1h(b)]
    if len(closed) < L1_LOOKBACK_1H:
        return None
    last4 = closed[-L1_LOOKBACK_1H:]
    if direction == -1:
        return max(b["h"] for b in last4), last4[-1]["h"]
    return min(b["l"] for b in last4), last4[-1]["l"]


def _find_l2(bars15, probe_idx, atr, direction, day_start_t):
    """L2：当日此前两根 15m 的极值相差 <=0.5×ATR、相隔 8–16 根；
    取极值最大的那一对（做空取最高点最大，做多取最低点最小）；
    簇第二根距探针 <=24 根。
    返回 (level, band_lo, band_hi, bar_a, bar_b) 或 None。
    做空：level=min(两根高点)；做多：level=max(两根低点)。"""
    prior = [b for b in bars15[:probe_idx] if b["t"] >= day_start_t]
    if len(prior) < CLUSTER_GAP_MIN + 1:
        return None
    half = CLUSTER_TOL * atr
    idx_of = {b["t"]: i for i, b in enumerate(bars15)}
    best = None
    for a in range(len(prior)):
        for c in range(a + CLUSTER_GAP_MIN, min(a + CLUSTER_GAP_MAX + 1, len(prior))):
            pa, pc = prior[a], prior[c]
            va = pa["h"] if direction == -1 else pa["l"]
            vc = pc["h"] if direction == -1 else pc["l"]
            if abs(va - vc) > half:
                continue
            # 簇第二根距探针 <=24 根
            if probe_idx - idx_of[pc["t"]] > CLUSTER_RECENCY:
                continue
            if direction == -1:
                key = (max(va, vc), pc["t"])
            else:
                key = (-min(va, vc), pc["t"])
            if best is None or key > best[0]:
                best = (key, (pa, pc))
    if best is None:
        return None
    pa, pc = best[1]
    # 探针新鲜度：探针根须在簇第二根（较晚测试）之后至少 8 根（2h）。
    # 否则是同一段行情里的连续触碰，不是新鲜回踩（11-17 15:15 六币同发
    # 就是反例：簇第二根 14:15~15:00，探针 15:15 仅隔 1~2 根）。
    if probe_idx - idx_of[pc["t"]] < CLUSTER_GAP_MIN:
        return None
    if direction == -1:
        level = min(pa["h"], pc["h"])
        hi = max(pa["h"], pc["h"])
        return level, level - BAND_PAD * atr, hi + BAND_PAD * atr, pa, pc
    level = max(pa["l"], pc["l"])
    lo = min(pa["l"], pc["l"])
    return level, lo - BAND_PAD * atr, level + BAND_PAD * atr, pa, pc


def detect_probe(bars15, bars1h, probe_idx, direction, day_start_t):
    """判定 bars15[probe_idx] 是否为一根合格的探针根（不含确认）。
    返回 level_info dict 或 None。level_info: {kind, level, band, bars}。
    注意：强度与确认由调用方在确认根收盘后判定（见 detect_on_closed_bar）。"""
    probe = bars15[probe_idx]
    atrs = atr_wilder(bars15)
    atr = atrs[probe_idx]
    if atr is None or atr <= 0:
        return None
    # L1
    l1 = _find_l1(bars1h, probe["t"], direction)
    if l1 is not None:
        zone_ext, last_ext = l1
        if direction == -1:
            ok = probe["h"] > zone_ext and probe["c"] < last_ext
        else:
            ok = probe["l"] < zone_ext and probe["c"] > last_ext
        if ok:
            prev = bars15[max(0, probe_idx - L1_FIRST_EXCEED_WINDOW):probe_idx]
            if direction == -1:
                exceeded = any(b["h"] > zone_ext for b in prev)
            else:
                exceeded = any(b["l"] < zone_ext for b in prev)
            if not exceeded:
                return {"kind": "L1", "level": zone_ext, "band": None,
                        "bars": None, "atr15": atr}
    # L2
    l2 = _find_l2(bars15, probe_idx, atr, direction, day_start_t)
    if l2 is not None:
        level, blo, bhi, pa, pc = l2
        if direction == -1:
            ok = probe["h"] >= blo and probe["c"] < level
        else:
            ok = probe["l"] <= bhi and probe["c"] > level
        if ok:
            return {"kind": "L2", "level": level, "band": (blo, bhi),
                    "bars": (pa, pc), "atr15": atr}
    return None


def detect_on_closed_bar(bars15, bars1h, coin, atr1h_plan, day_start_t,
                          atr1h_source="plan", directions=(-1,)):
    """每根 15m 收盘调用：bars15/bars1h 为截至本根（含本根，已收盘）的历史。
    本根 = 确认根，上一根 = 探针根。任一方向有合格触发即返回 trigger dict，
    否则返回 None。单币每天最多 1 条由调用方保证（fired 后不再调用）。
    directions：v1 只开做空 (-1,)。做多对称定义已实现、但 11-20 扫描显示
    做多会在 16:00 全市场反弹处触发 7 次（BTC 13:45、SOL 10:15、DOGE/LINK/
    XRP/BNB/ADA 16:00），属另一路信号、未单独验证，v1 不启用，待另行验证。"""
    if len(bars15) < 20:
        return None
    confirm = bars15[-1]
    probe = bars15[-2]
    atrs = atr_wilder(bars15)
    atr = atrs[len(bars15) - 1]
    if atr is None or atr <= 0:
        return None
    probe_idx = len(bars15) - 2
    for direction in directions:
        info = detect_probe(bars15, bars1h, probe_idx, direction, day_start_t)
        if info is None:
            continue
        # 确认：确认根收盘 < 探针根收盘（做空）/ > 探针根收盘（做多）
        if direction == -1 and not (confirm["c"] < probe["c"]):
            continue
        if direction == 1 and not (confirm["c"] > probe["c"]):
            continue
        # 强度：探针上影/下影 或 确认根跌幅/涨幅 >= 1.5×ATR15
        if direction == -1:
            wick = probe["h"] - probe["c"]
            move = confirm["o"] - confirm["c"]
        else:
            wick = probe["c"] - probe["l"]
            move = confirm["c"] - confirm["o"]
        if not (wick >= STRENGTH * atr or move >= STRENGTH * atr):
            continue
        ref_entry = confirm["c"]
        if atr1h_plan is None or atr1h_plan <= 0:
            return None
        if direction == -1:
            sl, tp = ref_entry + atr1h_plan, ref_entry - 2 * atr1h_plan
        else:
            sl, tp = ref_entry - atr1h_plan, ref_entry + 2 * atr1h_plan
        if info["kind"] == "L1":
            lvl_txt = f"L1 {info['level']:.4g}"
        else:
            pa, pc = info["bars"]
            va = pa["h"] if direction == -1 else pa["l"]
            vc = pc["h"] if direction == -1 else pc["l"]
            lvl_txt = (f"L2 {info['level']:.4g}（{fmt_ts(pa['t'])[11:]}/"
                       f"{fmt_ts(pc['t'])[11:]}簇 {va:.4g}/{vc:.4g}）")
        d_txt = "做空" if direction == -1 else "做多"
        basis = (f"{fmt_ts(probe['t'])[11:]}探针高{probe['h']:.4g}收{probe['c']:.4g}收回位内，"
                 f"{fmt_ts(confirm['t'])[11:]}确认收{confirm['c']:.4g}"
                 f"{'跌幅' if direction == -1 else '涨幅'}{move / atr:.2f}xATR15"
                 f"（探针{'上影' if direction == -1 else '下影'}{wick / atr:.2f}x）")
        return {
            "coin": coin, "direction": direction,
            "trigger_t": confirm["t"] + 900,          # 确认根收盘时刻（UTC 秒）
            "pending_entry_t": confirm["t"] + 900,    # 下一根 15m 开盘 = 确认根收盘
            "confirm_bar_t": confirm["t"],
            "probe_bar_t": probe["t"],
            "level_type": info["kind"],
            "level": info["level"],
            "level_txt": lvl_txt,
            "ref_entry": ref_entry,
            "sl": sl, "tp": tp,
            "atr_1h": atr1h_plan,
            "atr_1h_source": atr1h_source,
            "basis": basis,
            "wick_x": round(wick / atr, 2),
            "confirm_x": round(move / atr, 2),
            "atr15": round(atr, 4),
        }
    return None


# ----------------------------------------------------------------------
# 计划文件写入 / 解析（“盘中补充触发”小节）
# ----------------------------------------------------------------------
def _supp_row(trigger):
    # 参考价/止损/止盈/ATR 用 .10g 全精度写（解析后要回引擎重算 SL/TP，.4g 会截断）；
    # level_txt / basis 里的价格只作展示，用 .4g。
    d = "做空" if trigger["direction"] == -1 else "做多"
    return ("| {coin} | {d} | {ct} | {et} | {lvl} | {ref:.10g} | {sl:.10g} | {tp:.10g} | "
            "{atr:.10g} | {basis} |").format(
        coin=trigger["coin"], d=d,
        ct=fmt_ts(trigger["confirm_bar_t"]),
        et=fmt_ts(trigger["pending_entry_t"]),
        lvl=trigger["level_txt"], ref=trigger["ref_entry"],
        sl=trigger["sl"], tp=trigger["tp"], atr=trigger["atr_1h"],
        basis=trigger["basis"])


def append_supp_trigger(plan_path, trigger, lock_path=None):
    """确认后、入场前把补充触发写进当日计划文件“盘中补充触发”小节。
    幂等：同一币同一方向同一天只写一条（已存在则返回 False，不重复写）。
    只追加/新建该小节，绝不改动计划文件其他部分。返回 True=新写入。
    lock_path：引擎传入其 LOCK_PATH 时，先拿排他锁再读写（避免与引擎的
    append_plan_record 并发写同一文件互相覆盖）；单线程调用传 None 即可。"""
    lockf = None
    if lock_path is not None:
        import fcntl
        lockf = open(lock_path, "w")
        fcntl.flock(lockf, fcntl.LOCK_EX)
    try:
        return _append_supp_trigger_locked(plan_path, trigger)
    finally:
        if lockf is not None:
            import fcntl
            fcntl.flock(lockf, fcntl.LOCK_UN)
            lockf.close()


def _append_supp_trigger_locked(plan_path, trigger):
    with open(plan_path, encoding="utf-8") as f:
        text = f.read()
    existing = parse_supp_triggers(text)
    for t in existing:
        if t["coin"] == trigger["coin"] and t["direction"] == trigger["direction"]:
            return False
    row = _supp_row(trigger)
    hdr = ("| 币 | 方向 | 确认根UTC | 入场时间UTC | 参考位 | 参考入场价 | 止损 | 止盈 | "
           "1h ATR | 确认依据 |")
    sep = "|---|---|---|---|---|---|---|---|---|---|"
    if SUPP_SECTION_HDR in text:
        # 在小节末尾追加一行（插在小节表格之后、下一节之前）
        lines = text.splitlines()
        out = []
        inserted = False
        in_sec = False
        for ln in lines:
            out.append(ln)
            if ln.strip().startswith(SUPP_SECTION_HDR):
                in_sec = True
                continue
            if in_sec and not inserted:
                if ln.strip().startswith("|") and "确认根UTC" not in ln and not ln.strip().startswith("|---"):
                    out.append(row)
                    inserted = True
        if not inserted:
            out.append(row)
        text = "\n".join(out) + "\n"
    else:
        text = text.rstrip("\n") + "\n\n" + SUPP_SECTION_HDR + "（观察模块追加，计划原文不动；时间均为 UTC）\n\n"
        text += hdr + "\n" + sep + "\n" + row + "\n"
    with open(plan_path, "w", encoding="utf-8") as f:
        f.write(text)
    return True


def parse_supp_triggers(text):
    """解析计划文件“盘中补充触发”小节，返回 [trigger, ...]。
    trigger: {coin, direction, confirm_bar_t, pending_entry_t, level_txt,
              ref_entry, sl, tp, atr_1h, basis}。解析失败的行跳过（不报错、
              不编数——缺字段的行直接丢弃并在调用方日志里记一条）。"""
    triggers = []
    lines = text.splitlines()
    start = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith(SUPP_SECTION_HDR):
            start = i
            break
    if start is None:
        return triggers
    for ln in lines[start + 1:]:
        s = ln.strip()
        if s.startswith("#"):
            break
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) < 10 or "确认根UTC" in cells[0] or cells[0].startswith("---"):
            continue
        try:
            coin = None
            for c in ("BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"):
                if c in cells[0]:
                    coin = c
                    break
            if coin is None:
                continue
            direction = -1 if "做空" in cells[1] else (1 if "做多" in cells[1] else 0)
            if direction == 0:
                continue
            ct = datetime.strptime(cells[2], "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
            et = datetime.strptime(cells[3], "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
            ref = float(cells[5].replace(",", ""))
            sl = float(cells[6].replace(",", ""))
            tp = float(cells[7].replace(",", ""))
            atr = float(cells[8].replace(",", ""))
        except (ValueError, IndexError):
            continue
        triggers.append({
            "coin": coin, "direction": direction,
            "confirm_bar_t": int(ct.timestamp()),
            "pending_entry_t": int(et.timestamp()),
            "level_txt": cells[4], "ref_entry": ref, "sl": sl, "tp": tp,
            "atr_1h": atr, "basis": cells[9] if len(cells) > 9 else "",
            "level_type": "L2" if cells[4].strip().startswith("L2") else "L1",
            "level": None,
        })
    return triggers
