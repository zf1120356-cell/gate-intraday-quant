#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分系统 SUB-SMC 计划驱动层单元测试（paper_engine.py）。
用假 GateClient、dry_log=True，不联网、不碰真实计划文件与 live 状态。
跑法：python3 test_sub_plan.py（全部通过 exit 0，否则 exit 1）。
"""
import json
import os
import sys
import tempfile
from datetime import datetime, timedelta, timezone, date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import paper_engine as pe
from paper_engine import Engine, parse_plan_table, fmt_ts

SUB_PLAN_TEXT = """# 分系统纸面交易 · 2026-11-17（日内纸面，前瞻模拟）
数据截止：2026-11-17 08:23 UTC
| 币 | 方向 | 入场区 | 参考入场价 | 止损（1 倍 ATR） | 止盈（2 倍 ATR） | 触发条件（缺一不可） | 失效条件 |
|---|---|---|---|---|---|---|---|
| ETH | 做空（OTE 拒绝） | 1,800.3–1,819.3 | 1,809.8 | 1,829.1 | 1,771.2 | ① 15m 反弹摸进 1,800.3–1,819.3 OTE 区；② 随后一根 15m 收盘回到 1,800.3 下方（拒绝确认，同根收盘不算） | 触发前 1h 收盘上破 1,822（看跌 FVG 上沿）；入场后 15m 收盘上破 1,829.1 即止损 |
"""

SMALL_PLAN_TEXT = """# 分系统纸面交易 · 2026-11-17（测试）
数据截止：2026-11-17 08:23 UTC
| 币 | 方向 | 入场区 | 参考入场价 | 止损（1 倍 ATR） | 止盈（2 倍 ATR） | 触发条件（缺一不可） | 失效条件 |
|---|---|---|---|---|---|---|---|
| ETH | 做空 | 95–105 | 100 | 110 | 80 | ① 15m 摸进 95–105 区；② 随后一根 15m 收盘回到 95 下方 | 触发前 1h 收盘上破 112；入场后 15m 收盘上破 110 即止损 |
"""


class FakeClient:
    def __init__(self):
        self.log_fn = lambda *a, **k: None

    def funding_rates(self, contract, limit=10):
        return {}

    def tickers(self):
        return {}

    def candles(self, contract, interval, limit=None, frm=None, to=None):
        return []


def ts(y, mo, d, h, mi=0):
    return int(datetime(y, mo, d, h, mi, tzinfo=timezone.utc).timestamp())


def bar(t, o, h, l, c):
    return {"t": t, "o": o, "h": h, "l": l, "c": c}


def fresh_engine():
    return Engine(client=FakeClient(), dry_log=True)


# ----------------------------------------------------------------------
def test_parse_sub_plan():
    """① parse_plan_table 能解析分系统计划表。"""
    plans = parse_plan_table(SUB_PLAN_TEXT)
    assert "ETH" in plans, f"ETH 未解析出：{plans}"
    p = plans["ETH"]
    assert p["direction"] == -1, p
    assert p["touch"] == {"kind": "zone", "lo": 1800.3, "hi": 1819.3}, p["touch"]
    assert p["confirm_steps"] == [("below", 1800.3)], p["confirm_steps"]
    assert p["invalid"] == {"kind": "above", "level": 1822.0}, p["invalid"]
    assert abs(p["ref_entry"] - 1809.8) < 1e-9 and abs(p["sl"] - 1829.1) < 1e-9
    # ATR 反推：|止损-参考价| = 19.3
    assert abs(abs(p["sl"] - p["ref_entry"]) - 19.3) < 1e-9


def test_trigger_flow_no_killzone():
    """② 分系统触发流程：触及→确认→confirmed，确认根收盘不在 Killzone 内也能确认；
    对照：同一触发条件走主观层在 Killzone 外不确认。"""
    plans = parse_plan_table(SUB_PLAN_TEXT)
    p = plans["ETH"]
    mt = ts(2026, 11, 17, 3, 0)  # plan_mtime：03:00，之后收盘的 K 线才评估
    touch = bar(ts(2026, 11, 17, 4, 0), 1810, 1820, 1805, 1815)   # 高 1820 ≥ 1800.3 触及
    confirm = bar(ts(2026, 11, 17, 4, 15), 1810, 1812, 1795, 1798)  # 收 1798 < 1800.3 确认
    assert fmt_ts(confirm["t"] + 900).endswith("04:30:00Z")  # 确认收盘 04:30 UTC，Killzone 外
    # 分系统：确认
    eng = fresh_engine()
    eng.sub_plan_on_closed_bar("ETH", touch, p, mt)
    assert eng.state["sub_plans"]["ETH"]["status"] == "touched"
    eng.sub_plan_on_closed_bar("ETH", confirm, p, mt)
    st = eng.state["sub_plans"]["ETH"]
    assert st["status"] == "confirmed", st
    assert st["pending_entry_t"] == ts(2026, 11, 17, 4, 30), st
    # 主观层对照：同一根确认收盘在 Killzone 外 → 回到 waiting，不确认
    eng2 = fresh_engine()
    eng2.subj_on_closed_bar("ETH", touch, p, mt)
    assert eng2.state["plans"]["ETH"]["status"] == "touched"
    eng2.subj_on_closed_bar("ETH", confirm, p, mt)
    assert eng2.state["plans"]["ETH"]["status"] == "waiting", eng2.state["plans"]["ETH"]


def test_night_window():
    """③ 北京时间不开新单：pending 入场 18:00 UTC 跳过，23:00 UTC 允许入场。"""
    plans = parse_plan_table(SUB_PLAN_TEXT)
    p = plans["ETH"]
    # 18:00 UTC = 北京时间 02:00 → 跳过
    eng = fresh_engine()
    eng.state["sub_plans"]["ETH"] = {"status": "confirmed",
                                     "pending_entry_t": ts(2026, 11, 17, 18, 0)}
    eng.sub_plan_try_entry("ETH", ts(2026, 11, 17, 18, 0), 1805, p)
    assert eng.state["sub_plans"]["ETH"]["status"] == "done", eng.state["sub_plans"]["ETH"]
    assert eng.state["positions"] == []
    # 23:00 UTC = 北京时间 07:00（不含）→ 允许入场
    eng2 = fresh_engine()
    eng2.state["sub_plans"]["ETH"] = {"status": "confirmed",
                                      "pending_entry_t": ts(2026, 11, 17, 23, 0)}
    eng2.sub_plan_try_entry("ETH", ts(2026, 11, 17, 23, 0), 1805, p)
    assert len(eng2.state["positions"]) == 1, eng2.state["positions"]
    pos = eng2.state["positions"][0]
    assert pos["layer"] == "sub" and pos["direction"] == -1
    assert pos["tp"] is None, pos  # 无固定止盈
    assert abs(pos["sl"] - (1805 + 19.3)) < 1e-6, pos  # 止损 = 入场价 + 1×ATR
    assert pos["peak"] == pos["entry"] and pos["trail_active"] is False


def test_trailing_activation_and_exit():
    """④ 跟踪激活：有利浮动 ≥2×ATR 激活、止损棘轮、mark 触止损时出场原因为 trailing_stop。"""
    plans = parse_plan_table(SMALL_PLAN_TEXT)
    p = plans["ETH"]  # ref 100，ATR 10，做空
    eng = fresh_engine()
    t0 = ts(2026, 11, 17, 10, 0)
    eng.state["sub_plans"]["ETH"] = {"status": "confirmed", "pending_entry_t": t0}
    eng.sub_plan_try_entry("ETH", t0, 100, p)
    assert len(eng.state["positions"]) == 1
    pos = eng.state["positions"][0]
    assert abs(pos["sl"] - 110) < 1e-9 and pos["tp"] is None
    # 第一根：最低 75 → 有利浮动 25 ≥ 2×ATR(20)，激活；止损棘轮到 75+10=85
    eng.sub_update_trail("ETH", bar(t0 + 900, 100, 101, 75, 78))
    assert pos["trail_active"] is True, pos
    assert abs(pos["sl"] - 85) < 1e-9, pos
    assert abs(pos["peak"] - 75) < 1e-9, pos
    # 第二根：最高 86 ≥ 止损 85 → 出场 trailing_stop
    eng.check_positions_bar("ETH", bar(t0 + 1800, 78, 86, 77, 80))
    assert eng.state["positions"] == []
    assert len(eng.state["trades"]) == 1
    assert eng.state["trades"][0]["reason"] == "trailing_stop", eng.state["trades"][0]


def test_carryover_load_state():
    """⑤ 跨夜结转：_load_state 能把昨日未平 sub 持仓结转到新一天。"""
    tmp = tempfile.mkdtemp()
    state_path = os.path.join(tmp, "state.json")
    old_state_path = pe.STATE_PATH
    try:
        pos = {"coin": "ETH", "layer": "sub", "direction": -1,
               "entry_t": ts(2026, 11, 17, 23, 0), "entry": 1805.0,
               "entry_ref": 1805.0, "sl": 1824.3, "tp": None,
               "entry_bar_t": ts(2026, 11, 17, 23, 0)}
        with open(state_path, "w") as f:
            json.dump({"date": "2030-01-01", "positions": [pos],
                       "plans": {}, "trades": []}, f)
        eng = fresh_engine()
        eng.today = date(2030, 1, 2)  # 与 state 文件日期不同天，触发结转分支
        pe.STATE_PATH = state_path
        eng._load_state()
        assert len(eng.state["positions"]) == 1, eng.state["positions"]
        assert eng.state["positions"][0]["coin"] == "ETH"
        assert eng.state["positions"][0]["layer"] == "sub"
    finally:
        pe.STATE_PATH = old_state_path


def test_max_one_per_day():
    """⑥ 每天每币最多 1 笔：成交 1 笔后同一币第二条触发不再入场。"""
    plans = parse_plan_table(SUB_PLAN_TEXT)
    p = plans["ETH"]
    mt = ts(2026, 11, 17, 3, 0)
    eng = fresh_engine()
    # 第一笔：触及→确认→入场→止损出场
    eng.sub_plan_on_closed_bar("ETH", bar(ts(2026, 11, 17, 4, 0), 1810, 1820, 1805, 1815), p, mt)
    eng.sub_plan_on_closed_bar("ETH", bar(ts(2026, 11, 17, 4, 15), 1810, 1812, 1795, 1798), p, mt)
    assert eng.state["sub_plans"]["ETH"]["status"] == "confirmed"
    eng.sub_plan_try_entry("ETH", ts(2026, 11, 17, 4, 30), 1805, p)
    assert len(eng.state["positions"]) == 1
    eng.check_positions_bar("ETH", bar(ts(2026, 11, 17, 4, 30), 1805, 1830, 1800, 1810))
    assert len(eng.state["trades"]) == 1
    assert eng.state["sub_plans"]["ETH"]["trades_done"] == 1
    assert eng.state["sub_plans"]["ETH"]["status"] == "triggered"
    # 第二条触发：触及根不再推进（status 已是 triggered）
    eng.sub_plan_on_closed_bar("ETH", bar(ts(2026, 11, 17, 5, 0), 1810, 1820, 1805, 1815), p, mt)
    eng.sub_plan_on_closed_bar("ETH", bar(ts(2026, 11, 17, 5, 15), 1810, 1812, 1795, 1798), p, mt)
    assert eng.state["sub_plans"]["ETH"]["status"] == "triggered"
    assert len(eng.state["positions"]) == 0 and len(eng.state["trades"]) == 1


def test_record_routing():
    """⑦ 记录路由：sub 层 open/close 只追加到分系统计划文件、主计划文件无分系统记录；
    主观层 open/close 只进主计划文件；daily_summary 按层拆分。"""
    tmp = tempfile.mkdtemp()
    main_dir, sub_dir = os.path.join(tmp, "main"), os.path.join(tmp, "sub")
    os.makedirs(main_dir)
    os.makedirs(sub_dir)
    day = datetime.now(timezone.utc).date()
    for d in (main_dir, sub_dir):
        with open(os.path.join(d, f"{day.isoformat()}.md"), "w") as f:
            f.write("# 测试计划\n")
    old_plan, old_sub, old_state = pe.PLAN_DIR, pe.SUB_PLAN_DIR, pe.STATE_PATH
    try:
        pe.PLAN_DIR, pe.SUB_PLAN_DIR = main_dir, sub_dir
        pe.STATE_PATH = os.path.join(tmp, "state.json")
        eng = fresh_engine()
        eng.log_event = lambda *a, **k: None  # 不写真实日志文件
        eng.dry_log = False  # 允许 append_plan_record 写文件（目录已 monkeypatch）
        t0 = ts(2026, 11, 17, 10, 0)
        pos_sub = eng.open_position("ETH", "sub", -1, t0, 1805, 1824.3, None,
                                    extra={"plan_sl": 1829.1, "plan_tp": 1771.2,
                                           "atr": 19.3, "entry_bar_t": t0})
        pos_sub["peak"] = pos_sub["entry"]
        pos_sub["trail_active"] = False
        eng.close_position(pos_sub, t0 + 900, 1800, "stop_loss")
        pos_subj = eng.open_position("SOL", "subj", 1, t0, 72.0, 71.4, 73.2,
                                     extra={"plan_sl": 71.64, "plan_tp": 73.5, "atr_1h": 0.62})
        eng.close_position(pos_subj, t0 + 900, 73.2, "take_profit")
        eng.daily_summary()
        with open(os.path.join(main_dir, f"{day.isoformat()}.md")) as f:
            main_txt = f.read()
        with open(os.path.join(sub_dir, f"{day.isoformat()}.md")) as f:
            sub_txt = f.read()
        assert "分系统做空入场" in sub_txt, sub_txt
        assert "分系统做空平仓" in sub_txt, sub_txt
        assert "分系统" not in main_txt, main_txt
        assert "主观做多入场" in main_txt, main_txt
        assert "主观做多平仓" in main_txt, main_txt
        assert "主观" not in sub_txt, sub_txt
        # daily_summary 拆分：主文件汇总只含主观 1 笔，分系统文件汇总只含 sub 1 笔
        assert main_txt.count("当日结算汇总：成交 1 笔") == 1, main_txt
        assert sub_txt.count("当日结算汇总：成交 1 笔") == 1, sub_txt
        assert "见分系统说明" in sub_txt and "见程序说明" in main_txt
    finally:
        pe.PLAN_DIR, pe.SUB_PLAN_DIR, pe.STATE_PATH = old_plan, old_sub, old_state


def test_invalidation():
    """⑧ 失效：1h 收盘越过失效价后计划作废，之后触及也不再触发。"""
    plans = parse_plan_table(SUB_PLAN_TEXT)
    p = plans["ETH"]  # 失效：1h 收盘上破 1822
    eng = fresh_engine()
    eng.sub_plan_on_closed_1h("ETH", bar(ts(2026, 11, 17, 9, 0), 1820, 1830, 1815, 1825), p)
    assert eng.state["sub_plans"]["ETH"]["status"] == "invalidated"
    eng.sub_plan_on_closed_bar("ETH", bar(ts(2026, 11, 17, 9, 15), 1810, 1820, 1805, 1815), p,
                               ts(2026, 11, 17, 3, 0))
    assert eng.state["sub_plans"]["ETH"]["status"] == "invalidated"
    assert eng.state["positions"] == []


def test_load_today_sub_plan():
    """附加：load_today_sub_plan 读分系统计划目录；无文件时返回 (None, None, [])。"""
    tmp = tempfile.mkdtemp()
    old_sub = pe.SUB_PLAN_DIR
    try:
        pe.SUB_PLAN_DIR = tmp
        eng = fresh_engine()
        assert eng.load_today_sub_plan() == (None, None, [])
        day = datetime.now(timezone.utc).date()
        with open(os.path.join(tmp, f"{day.isoformat()}.md"), "w") as f:
            f.write(SUB_PLAN_TEXT)
        plans, mtime, trigs = eng.load_today_sub_plan()
        assert plans is not None and "ETH" in plans, plans
        assert mtime is not None and mtime >= ts(2026, 11, 17, 8, 23)
        assert trigs == []
    finally:
        pe.SUB_PLAN_DIR = old_sub


# ----------------------------------------------------------------------
# v1.2（早上偏向 + 每时段现判）：空表计划 + 盘中补充触发 sub_supp_*
# ----------------------------------------------------------------------
EMPTY_SUB_PLAN_TEXT = """# 分系统纸面交易 · 2026-11-17（日内纸面，前瞻模拟）
数据截止：2026-11-17 08:23 UTC
| 币 | 方向 | 入场区 | 参考入场价 | 止损（1 倍 ATR） | 止盈（2 倍 ATR） | 触发条件（缺一不可） | 失效条件 |
|---|---|---|---|---|---|---|---|
"""


def _supp_trigger(coin="ETH", direction=-1, pending_t=None, ref=1800.0, atr=19.3):
    """一条分系统补充触发（与 supp_observer.parse_supp_triggers 同形）。"""
    if pending_t is None:
        pending_t = ts(2026, 11, 17, 15, 0)
    return {
        "coin": coin, "direction": direction,
        "confirm_bar_t": pending_t - 900, "pending_entry_t": pending_t,
        "level_txt": "主观 1810（测试）", "ref_entry": ref,
        "sl": ref + atr if direction == -1 else ref - atr,
        "tp": ref - 2 * atr if direction == -1 else ref + 2 * atr,
        "atr_1h": atr, "basis": "测试触发", "level_type": "JUDGE", "level": 1810.0,
    }


def test_empty_table_no_error():
    """⑫ v1.2 空表计划：parse_plan_table 返回 {}，load 返回 ({}, mtime, [])，不报错。"""
    plans = parse_plan_table(EMPTY_SUB_PLAN_TEXT)
    assert plans == {}, plans
    tmp = tempfile.mkdtemp()
    old_sub = pe.SUB_PLAN_DIR
    try:
        pe.SUB_PLAN_DIR = tmp
        eng = fresh_engine()
        day = datetime.now(timezone.utc).date()
        with open(os.path.join(tmp, f"{day.isoformat()}.md"), "w") as f:
            f.write(EMPTY_SUB_PLAN_TEXT)
        plans, mtime, trigs = eng.load_today_sub_plan()
        assert plans == {} and trigs == [] and mtime is not None
        # 空表时各币 sub_plan 为 None，live 循环里的 `if sub_plan is not None`
        # 守卫会跳过触发判定与入场；这里只确认加载本身不报错、无持仓
        assert eng.state["positions"] == []
    finally:
        pe.SUB_PLAN_DIR = old_sub


def test_sub_supp_register_and_entry():
    """⑬ sub_supp 登记 + 入场：登记后 status confirmed；待入场开盘入场，
    层 sub、tp=None、止损按实际入场价重算、跟踪初始状态正确。"""
    eng = fresh_engine()
    trig = _supp_trigger()
    assert eng.sub_supp_register(trig, source="file") is True
    st = eng.state["sub_supp"]["ETH"]
    assert st["status"] == "confirmed" and st["pending_entry_t"] == ts(2026, 11, 17, 15, 0)
    # 待入场前一根不开
    eng.sub_supp_try_entry("ETH", ts(2026, 11, 17, 14, 45), 1801)
    assert eng.state["positions"] == []
    # 待入场开盘 1801 入场做空：SL = 1801 + 19.3
    eng.sub_supp_try_entry("ETH", ts(2026, 11, 17, 15, 0), 1801)
    assert len(eng.state["positions"]) == 1
    pos = eng.state["positions"][0]
    assert pos["layer"] == "sub" and pos["direction"] == -1
    assert pos["tp"] is None and abs(pos["sl"] - 1820.3) < 1e-9, pos
    assert pos["peak"] == pos["entry"] and pos["trail_active"] is False
    assert pos.get("supp") is True
    assert st["status"] == "triggered" and st["trades_done"] == 1


def test_sub_supp_night_window():
    """⑭ 夜禁：待入场 18:00 UTC（北京时间 02:00）跳过，status done，无持仓。"""
    eng = fresh_engine()
    trig = _supp_trigger(pending_t=ts(2026, 11, 17, 18, 0))
    assert eng.sub_supp_register(trig, source="file") is True
    eng.sub_supp_try_entry("ETH", ts(2026, 11, 17, 18, 0), 1801)
    assert eng.state["sub_supp"]["ETH"]["status"] == "done"
    assert eng.state["positions"] == []


def test_sub_supp_stale():
    """⑮ 过期：pending 已过 15 分钟以上，merge 记 stale、不登记。"""
    eng = fresh_engine()
    trig = _supp_trigger(pending_t=ts(2026, 11, 17, 15, 0))
    eng.sub_supp_merge([trig], ts(2026, 11, 17, 15, 16))  # 已过 16 分钟
    st = eng.state["sub_supp"].get("ETH", {})
    assert st.get("trigger") is not None and st.get("status") == "done", st
    # 未过期的登记
    eng2 = fresh_engine()
    eng2.sub_supp_merge([trig], ts(2026, 11, 17, 14, 50))
    assert eng2.state["sub_supp"]["ETH"]["status"] == "confirmed"


def test_sub_supp_one_per_day_shared_cap():
    """⑯ 每天每币 1 条（与早上计划共用上限）：成交 1 笔后第二条不登记；
    早上计划已成交时补充触发不登记。"""
    eng = fresh_engine()
    trig = _supp_trigger()
    assert eng.sub_supp_register(trig, source="file") is True
    eng.sub_supp_try_entry("ETH", ts(2026, 11, 17, 15, 0), 1801)
    assert len(eng.state["positions"]) == 1
    # 第二条同一币：不登记
    trig2 = _supp_trigger(pending_t=ts(2026, 11, 17, 16, 0))
    assert eng.sub_supp_register(trig2, source="file") is False
    # 早上计划已成交：不登记
    eng2 = fresh_engine()
    eng2.state["sub_plans"]["ETH"] = {"status": "triggered", "trades_done": 1}
    assert eng2.sub_supp_register(_supp_trigger(), source="file") is False


def test_sub_supp_mtime_reload():
    """⑰ mtime 重读：空表计划文件先加载为 ({}, mtime, [])；判断任务追加一条
    补充触发后，再加载即解析出该触发并可登记。"""
    tmp = tempfile.mkdtemp()
    old_sub = pe.SUB_PLAN_DIR
    try:
        pe.SUB_PLAN_DIR = tmp
        eng = fresh_engine()
        day = datetime.now(timezone.utc).date()
        path = os.path.join(tmp, f"{day.isoformat()}.md")
        with open(path, "w") as f:
            f.write(EMPTY_SUB_PLAN_TEXT)
        plans, mtime1, trigs1 = eng.load_today_sub_plan()
        assert plans == {} and trigs1 == []
        trig = _supp_trigger(pending_t=ts(2026, 11, 17, 15, 0))
        assert pe.supp_observer.append_supp_trigger(path, trig) is True
        # 追加后 mtime 变化（显式 bump，避免文件系统粒度问题）
        os.utime(path, (mtime1 + 60, mtime1 + 60))
        plans, mtime2, trigs2 = eng.load_today_sub_plan()
        assert plans == {} and len(trigs2) == 1, trigs2
        assert trigs2[0]["coin"] == "ETH" and trigs2[0]["pending_entry_t"] == ts(2026, 11, 17, 15, 0)
        assert mtime2 > mtime1
        # merge 登记（now=14:50，未过期）
        eng.sub_supp_merge(trigs2, ts(2026, 11, 17, 14, 50))
        assert eng.state["sub_supp"]["ETH"]["status"] == "confirmed"
        # 幂等：重复 append 同币同方向不重复写
        assert pe.supp_observer.append_supp_trigger(path, trig) is False
    finally:
        pe.SUB_PLAN_DIR = old_sub


def test_sub_supp_open_position_guard():
    """⑱ 入场前已有未平分系统持仓：补充触发不入场（不叠加）；主观层同币持仓不受影响。"""
    eng = fresh_engine()
    t0 = ts(2026, 11, 17, 15, 0)
    pos_subj = eng.open_position("ETH", "subj", -1, t0, 1801, 1820.3, 1762.4,
                                 extra={"plan_sl": 1819.3, "plan_tp": 1761.4, "atr_1h": 19.3})
    pos_sub = eng.open_position("ETH", "sub", -1, t0, 1801, 1820.3, None,
                                extra={"plan_sl": 1819.3, "plan_tp": 1761.4,
                                       "atr": 19.3, "entry_bar_t": t0})
    pos_sub["peak"] = pos_sub["entry"]
    pos_sub["trail_active"] = False
    assert len(eng.state["positions"]) == 2
    trig = _supp_trigger(pending_t=t0)
    assert eng.sub_supp_register(trig, source="file") is True
    eng.sub_supp_try_entry("ETH", t0, 1801)
    assert len(eng.state["positions"]) == 2, eng.state["positions"]  # 未叠加
    # 平掉分系统持仓后，主观层持仓还在（身份按 币/层/入场时刻 区分）
    eng.close_position(pos_sub, t0 + 900, 1795, "trailing_stop")
    assert len(eng.state["positions"]) == 1
    assert eng.state["positions"][0]["layer"] == "subj"


def test_rebuild_from_log_sub_branches():
    """附加：_rebuild_from_log 的三个分系统分支。"""
    eng = fresh_engine()
    eng.today = date(2030, 1, 3)
    logp = os.path.join(pe.BASE, "paper_engine_replay_2030-01-03.log")
    try:
        with open(logp, "w") as f:
            f.write(json.dumps({"type": "sub_plan_triggered", "coin": "ETH"}) + "\n")
            f.write(json.dumps({"type": "sub_plan_entry_missed", "coin": "SOL"}) + "\n")
            f.write(json.dumps({"type": "sub_plan_invalidated", "coin": "BTC"}) + "\n")
        st = eng._rebuild_from_log()
        assert st["sub_plans"]["ETH"]["status"] == "triggered", st["sub_plans"]
        assert st["sub_plans"]["SOL"]["status"] == "done"
        assert st["sub_plans"]["SOL"]["missed"] is True
        assert st["sub_plans"]["BTC"]["status"] == "invalidated"
    finally:
        if os.path.exists(logp):
            os.remove(logp)


def test_close_one_layer_keeps_other():
    """⑪ 同币同根两层持仓：平掉主观层持仓后，分系统同币持仓必须还在
    （2026-11-20 回放实测 bug：close_position 按 (币, 入场时刻) 删持仓，
    主观层平仓误删分系统持仓，持仓凭空消失、无出场记录）。"""
    eng = fresh_engine()
    t0 = ts(2026, 11, 17, 10, 0)
    pos_subj = eng.open_position("SOL", "subj", 1, t0, 72.0, 71.4, 73.2,
                                 extra={"plan_sl": 71.64, "plan_tp": 73.5, "atr_1h": 0.62})
    pos_sub = eng.open_position("SOL", "sub", 1, t0, 72.0, 71.4, None,
                                extra={"plan_sl": 71.64, "plan_tp": 73.5,
                                       "atr": 0.62, "entry_bar_t": t0})
    pos_sub["peak"] = pos_sub["entry"]
    pos_sub["trail_active"] = False
    assert len(eng.state["positions"]) == 2
    eng.close_position(pos_subj, t0 + 900, 71.4, "stop_loss")
    assert len(eng.state["positions"]) == 1, eng.state["positions"]
    assert eng.state["positions"][0]["layer"] == "sub"
    assert len(eng.state["trades"]) == 1
    eng.close_position(pos_sub, t0 + 1800, 73.0, "trailing_stop")
    assert eng.state["positions"] == []
    assert len(eng.state["trades"]) == 2
    assert eng.state["trades"][1]["layer"] == "sub"


TESTS = [
    ("① parse_plan_table 解析分系统计划表", test_parse_sub_plan),
    ("② 触发流程（Killzone 外确认）+ 主观对照", test_trigger_flow_no_killzone),
    ("③ 北京时间不开新单（18:00 跳过 / 23:00 允许）", test_night_window),
    ("④ 跟踪激活与 trailing_stop 出场", test_trailing_activation_and_exit),
    ("⑤ 跨夜结转 _load_state", test_carryover_load_state),
    ("⑥ 每天每币最多 1 笔", test_max_one_per_day),
    ("⑦ 记录路由（主/分系统计划文件分离）", test_record_routing),
    ("⑧ 1h 收盘失效", test_invalidation),
    ("⑨ load_today_sub_plan", test_load_today_sub_plan),
    ("⑩ _rebuild_from_log 分系统分支", test_rebuild_from_log_sub_branches),
    ("⑪ 同币同根两层持仓互不误删", test_close_one_layer_keeps_other),
    ("⑫ v1.2 空表计划不报错", test_empty_table_no_error),
    ("⑬ sub_supp 登记 + 入场", test_sub_supp_register_and_entry),
    ("⑭ sub_supp 夜禁跳过", test_sub_supp_night_window),
    ("⑮ sub_supp 过期作废", test_sub_supp_stale),
    ("⑯ sub_supp 每天每币 1 条（与早上计划共用）", test_sub_supp_one_per_day_shared_cap),
    ("⑰ sub_supp mtime 重读", test_sub_supp_mtime_reload),
    ("⑱ sub_supp 未平持仓不叠加", test_sub_supp_open_position_guard),
]


def main():
    passed, failed = 0, []
    for name, fn in TESTS:
        try:
            fn()
            print(f"PASS {name}")
            passed += 1
        except Exception as e:  # noqa: BLE001 - 测试 runner 汇总报错
            print(f"FAIL {name}: {type(e).__name__}: {e}")
            failed.append(name)
    print(f"\n{passed}/{len(TESTS)} 通过")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
