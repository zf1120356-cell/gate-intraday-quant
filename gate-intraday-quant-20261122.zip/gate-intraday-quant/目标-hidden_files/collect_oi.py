#!/usr/bin/env python3
"""Hourly Gate USDT-perp tickers snapshot for OI research (simulation only).
Appends one row per contract per run to oi_snapshots.csv.
Public endpoint, no auth, no real money, no trading.
"""
import csv
import json
import os
import subprocess
import time
import urllib.request
from datetime import datetime, timezone

SYMBOLS = ["BTC_USDT", "ETH_USDT", "SOL_USDT", "DOGE_USDT",
           "LINK_USDT", "XRP_USDT", "BNB_USDT", "ADA_USDT"]
BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "oi_snapshots.csv")
URL = "https://api.gateio.ws/api/v4/futures/usdt/tickers"

def fetch_tickers():
    # Gate returns ~486KB; urllib occasionally hits a truncated read
    # (http.client.IncompleteRead) on this endpoint while curl succeeds.
    # Retry a few times, then fall back to curl instead of losing the hour.
    last_exc = None
    for attempt in range(3):
        try:
            req = urllib.request.Request(
                URL, headers={"Accept": "application/json",
                              "User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.load(r)
        except Exception as e:  # IncompleteRead, URLError, timeout, ...
            last_exc = e
            if attempt < 2:
                time.sleep(5)
    # urllib truncated repeatedly (2026-11-19 08:14 run: 6/6 attempts
    # IncompleteRead while curl returned HTTP 200, 486KB, parse OK).
    try:
        out = subprocess.run(
            ["curl", "-sS", "-m", "30", "-H", "Accept: application/json",
             "-H", "User-Agent: Mozilla/5.0", URL],
            capture_output=True, text=True, timeout=40, check=True)
        return json.loads(out.stdout)
    except Exception as e:
        raise last_exc if last_exc is not None else e


def main():
    data = fetch_tickers()
    by_contract = {d["contract"]: d for d in data if isinstance(d, dict)}
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    exists = os.path.exists(OUT)
    rows = []
    for sym in SYMBOLS:
        d = by_contract.get(sym)
        if not d:
            continue
        rows.append({
            "ts_utc": now,
            "contract": sym,
            "total_size": d.get("total_size"),
            "funding_rate": d.get("funding_rate"),
            "funding_rate_indicative": d.get("funding_rate_indicative"),
            "mark_price": d.get("mark_price"),
            "last": d.get("last"),
            "index_price": d.get("index_price"),
            "volume_24h": d.get("volume_24h"),
            "volume_24h_usdt": d.get("volume_24h_usdt"),
        })
    with open(OUT, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else
                           ["ts_utc", "contract", "total_size", "funding_rate",
                            "funding_rate_indicative", "mark_price", "last",
                            "index_price", "volume_24h", "volume_24h_usdt"])
        if not exists:
            w.writeheader()
        w.writerows(rows)
    print(f"{now} wrote {len(rows)} rows to {OUT}")

if __name__ == "__main__":
    main()
