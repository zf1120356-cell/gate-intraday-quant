#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""拉取 Gate 公开 K 线 + tickers，保存原始数据，输出计划所需的计算值。
只读公开接口，不动真钱。输出供人工写 SMC 计划使用，不直接生成计划文件。
用法：python3 fetch_plan_data.py 2026-11-20
"""
import json, os, subprocess, sys, time
from datetime import datetime, timezone

COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]
API = "https://api.gateio.ws/api/v4/futures/usdt"
OUT_DIR = "/home/hatch/workspace/赚钱路子/data"


def get(url, retries=3):
    """urllib 经 egress 代理拉 Gate 大响应必截断（2026-11-19 实测 0/10），改用 curl。"""
    last = None
    for i in range(retries):
        try:
            cp = subprocess.run(["curl", "-sS", "-m", "25", "-w", "\n%{http_code}", url],
                                capture_output=True, text=True, timeout=30)
            body, _, code = cp.stdout.rpartition("\n")
            http_code = int(code.strip()) if code.strip().isdigit() else 0
            if cp.returncode == 0 and http_code == 200:
                return json.loads(body)
            last = f"curl exit {cp.returncode} http {http_code}: {cp.stderr.strip()[:150]}"
        except Exception as e:
            last = e
        time.sleep(1 * (i + 1))
    raise RuntimeError(f"GET 失败 {url}: {last}")


def atr(bars, n=14):
    """Wilder ATR：bars 为 [t,o,h,l,c,v] 升序。返回最后一根收盘时的 ATR。"""
    trs = []
    for i in range(1, len(bars)):
        h, l, pc = bars[i][2], bars[i][3], bars[i - 1][4]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    a = sum(trs[:n]) / n
    for tr in trs[n:]:
        a = (a * (n - 1) + tr) / n
    return a


def fmt_ts(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%m-%d %H:%M")


def main():
    day = sys.argv[1]
    raw = {"fetched_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
           "candles_1h": {}, "candles_15m": {}, "tickers": {}}
    for c in COINS:
        for iv in ("1h", "15m"):
            data = get(f"{API}/candlesticks?contract={c}_USDT&interval={iv}&limit=200")
            assert isinstance(data, list) and len(data) == 200, (c, iv, len(data) if isinstance(data, list) else data)
            bars = sorted([[int(b["t"]), float(b["o"]), float(b["h"]), float(b["l"]),
                            float(b["c"]), float(b["v"])] for b in data])
            # 连续性检查：1h 间隔 3600，15m 间隔 900
            step = 3600 if iv == "1h" else 900
            gaps = sum(1 for i in range(1, len(bars)) if bars[i][0] - bars[i - 1][0] != step)
            assert gaps == 0, (c, iv, "gaps", gaps)
            raw[f"candles_{iv}"][c] = bars
    tk = get(f"{API}/tickers")
    raw["tickers"] = {d["contract"]: d for d in tk if isinstance(d, dict)}
    path = os.path.join(OUT_DIR, f"paper_{day}_raw.json")
    with open(path, "w") as f:
        json.dump(raw, f)
    print(f"原始数据已存：{path}（{raw['fetched_at_utc']}）")

    now = int(time.time())
    print(f"\n现在 UTC {datetime.fromtimestamp(now, tz=timezone.utc).strftime('%H:%M:%S')}")
    for c in COINS:
        h1 = raw["candles_1h"][c]
        m15 = raw["candles_15m"][c]
        closed1h = [b for b in h1 if b[0] + 3600 <= now]
        closed15 = [b for b in m15 if b[0] + 900 <= now]
        last1, last15 = closed1h[-1], closed15[-1]
        a1, a15 = atr(closed1h), atr(closed15)
        # 24h：最近 24 根已收盘 1h
        w24 = closed1h[-24:]
        chg24 = (last1[4] / w24[0][4] - 1) * 100
        lo24, hi24 = min(b[3] for b in w24), max(b[2] for b in w24)
        # P/D：最近 20 根 1h 区间位置
        w20 = closed1h[-20:]
        lo20, hi20 = min(b[3] for b in w20), max(b[2] for b in w20)
        pd = (last1[4] - lo20) / (hi20 - lo20) * 100
        # 最近一根看跌腿：从最近摆动高点到最近低点（近 48 根 1h 内最高→其后最低）
        seg = closed1h[-72:]
        hi_i = max(range(len(seg)), key=lambda i: seg[i][2])
        lo_i = max(range(hi_i, len(seg)), key=lambda i: -seg[i][3])
        leg_hi, leg_lo = seg[hi_i], seg[lo_i]
        leg = (leg_lo[3] - leg_hi[2]) / a1
        ote_lo = leg_lo[3] + 0.62 * (leg_hi[2] - leg_lo[3])
        ote_hi = leg_lo[3] + 0.79 * (leg_hi[2] - leg_lo[3])
        # FVG（3 根结构，≥0.5 ATR）：看涨 low[i] > high[i-2]；看跌 high[i] < low[i-2]
        fvgs = []
        for i in range(2, len(closed1h)):
            if closed1h[i][3] > closed1h[i - 2][2] and (closed1h[i][3] - closed1h[i - 2][2]) >= 0.5 * a1:
                fvgs.append(("牛", fmt_ts(closed1h[i - 1][0]), closed1h[i - 2][2], closed1h[i][3]))
            if closed1h[i][2] < closed1h[i - 2][3] and (closed1h[i - 2][3] - closed1h[i][2]) >= 0.5 * a1:
                fvgs.append(("熊", fmt_ts(closed1h[i - 1][0]), closed1h[i][2], closed1h[i - 2][3]))
        t = raw["tickers"].get(f"{c}_USDT", {})
        mark = float(t.get("mark_price", 0)) if t else 0
        fr = t.get("funding_rate", "")
        print(f"\n== {c} == 现价1h收 {last1[4]}（{fmt_ts(last1[0])}）| mark {mark} | ATR1h {a1:.6g} ATR15m {a15:.6g}")
        print(f"  24h {chg24:+.2f}% 区间 {lo24}–{hi24} | P/D 20根 {pd:.0f}% | 资金费 {fr}")
        print(f"  最近腿：高 {leg_hi[2]}（{fmt_ts(leg_hi[0])}）→ 低 {leg_lo[3]}（{fmt_ts(leg_lo[0])}）腿幅 {leg:.2f}×ATR | OTE [{ote_lo:.6g}, {ote_hi:.6g}]")
        print(f"  FVG(≥0.5ATR，近8个)：{fvgs[-8:]}")
        # 15m 最近 8 根收盘价（供系统层 F1 参考）
        c15 = [b[4] for b in closed15[-9:]]
        r2h = (c15[-1] / c15[0] - 1) * 100 if len(c15) == 9 else None
        print(f"  15m 2h收益(8根)：{r2h:+.2f}% | 最后15m收 {last15[4]}（{fmt_ts(last15[0])}）")


if __name__ == "__main__":
    main()
