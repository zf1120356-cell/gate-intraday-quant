#!/usr/bin/env python3
"""开仓汇报检查：扫引擎 JSONL 日志，找出水位线之后的新开仓（主系统 only）。

- 只报主系统（layer subj/sys；supp/盘中判断的触发在引擎里也记 subj 层）。
  分系统（layer sub）不报——按用户 2026-11-20 指示，分系统只在分系统窗口出现。
- 水位线存 hidden_files/entry_notify_watermark.json，记最后已报事件的
  (ts, key)；日志按时间追加，元组比较即不重不漏。
- 时间一律输出北京时间。只读日志与水位线，不改引擎、不改计划、不改 state。
- 输出：无新开仓时只打一行 NO_NEW_ENTRIES；有则每笔打一段，开仓汇报的
  cron 按此原样转达。
"""
import json
import os
from datetime import datetime, timedelta, timezone

BASE = os.path.dirname(os.path.abspath(__file__))
WM_PATH = os.path.join(BASE, "entry_notify_watermark.json")
BEIJING = timezone(timedelta(hours=8))


def _parse_ts(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def _fmt_price(x):
    if x is None:
        return "-"
    s = f"{x:.8f}".rstrip("0").rstrip(".")
    return s if s not in ("-0", "") else "0"


def load_wm():
    try:
        with open(WM_PATH) as f:
            wm = json.load(f)
        return (wm.get("last_ts", ""), wm.get("last_key", ""))
    except (OSError, ValueError):
        return ("", "")


def save_wm(last_ts, last_key):
    tmp = WM_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"last_ts": last_ts, "last_key": last_key}, f)
    os.replace(tmp, WM_PATH)


def main():
    last_ts, last_key = load_wm()
    now_utc = datetime.now(timezone.utc).date()
    days = [now_utc, now_utc - timedelta(days=1)]
    new_entries = []
    for d in days:
        logp = os.path.join(BASE, f"paper_engine_{d.isoformat()}.log")
        if not os.path.exists(logp):
            continue
        with open(logp) as f:
            for line in f:
                try:
                    ev = json.loads(line)
                except ValueError:
                    continue
                if ev.get("type") != "entry":
                    continue
                pos = ev.get("position") or {}
                if pos.get("layer") == "sub":
                    continue
                ts = ev.get("ts", "")
                key = f"{pos.get('coin', '')}|{pos.get('layer', '')}|{pos.get('entry_t', '')}"
                if (ts, key) <= (last_ts, last_key):
                    continue
                new_entries.append((ts, key, ev, pos))
    if not new_entries:
        print("NO_NEW_ENTRIES")
        return 0
    new_entries.sort(key=lambda x: (x[0], x[1]))
    for ts, key, ev, pos in new_entries:
        coin = pos.get("coin", "?")
        d = "多" if pos.get("direction") == 1 else "空"
        layer = "盘中判断" if pos.get("supp") else {"subj": "早上计划", "sys": "系统层"}.get(pos.get("layer"), pos.get("layer", "?"))
        bj = _parse_ts(ts).astimezone(BEIJING).strftime("%m-%d %H:%M")
        liq = pos.get("liq")
        lev = pos.get("leverage")
        margin = pos.get("margin")
        extra = ""
        if liq is not None and lev is not None:
            extra = f"，爆仓价 {_fmt_price(liq)}（{lev} 倍逐仓，保证金 {margin} USDT）"
        print(f"开仓 {bj} 北京时间：{coin} {layer}做{d}，入场 {_fmt_price(pos.get('entry'))}，"
              f"止损 {_fmt_price(pos.get('sl'))}，止盈 {_fmt_price(pos.get('tp')) if pos.get('tp') is not None else '-'}"
              f"{extra}")
    save_wm(new_entries[-1][0], new_entries[-1][1])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
