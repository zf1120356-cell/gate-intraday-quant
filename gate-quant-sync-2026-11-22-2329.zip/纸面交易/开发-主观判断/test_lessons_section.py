#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
教训 feed 快照——演示与断言（原型验证）。
不拉 Gate 数据：只读样本 feed + 判断账，调 judge_packet.build_lessons_section，
并把 lessons 段注入一份已有的真实 packet（ETH 11-22 02:15）作演示输出。

断言（数字全部来自引擎日志 / 判断账，见《判断层-学习回路-设计.md》§8）：
  - feed_version 是 judgment-lessons/1.1（reflection 格式）；
  - L01/L02 是 candidate；L03/L05/L06/L07/L08 是 observation；L04 是 struck；
  - 每条 recent lesson 与 struck 项都带 reflection、不带 effect（用户 2026-11-22 23:14
    纠正：教训是反思提示，不是封顶）；
  - recent_cases 是列表（当前为空，待每日结算按设计 §13 写第一条真 case）；
  - live 总计 7 笔 4 赢 3 亏，净 +4.7175（20x 口径）；
  - 读者定级强组 3 笔净 +5.4524；v2 事后强组 4 笔净 +11.4596；
  - Q5 未回答组 2 笔净 -6.9726；
  - lessons 段不含本候选的定级/结论字段。
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import judge_packet as jpk  # noqa: E402

PAPER_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易")


def main():
    sec = jpk.build_lessons_section()
    assert sec["available"] is True, sec
    assert sec["feed_version"] == "judgment-lessons/1.1", sec["feed_version"]
    by_id = {L["id"]: L for L in sec["recent_lessons"]}
    # 新格式：教训带 reflection（反思提示），不带 effect（硬封顶已删）
    for L in sec["recent_lessons"] + sec["struck"]:
        assert "reflection" in L and isinstance(L["reflection"], str) \
            and len(L["reflection"]) > 50, L["id"]
        assert "effect" not in L, f"{L['id']} 仍带旧 effect 字段"
    assert isinstance(sec["recent_cases"], list), sec["recent_cases"]
    assert by_id["L01"]["status"] == "candidate", by_id["L01"]
    assert by_id["L02"]["status"] == "candidate", by_id["L02"]
    assert by_id["L03"]["status"] == "observation"
    assert by_id["L05"]["status"] == "observation"
    assert by_id["L06"]["status"] == "observation"
    assert by_id["L07"]["status"] == "observation"
    assert by_id["L08"]["status"] == "observation"
    assert [s["id"] for s in sec["struck"]] == ["L04"], sec["struck"]
    assert "L04" not in by_id, "struck 的教训不得进 recent_lessons"

    g = sec["group_stats"]
    assert g["closed_trades_n"] == 7, g
    assert g["total_live"] == {"n": 7, "wins": 4, "losses": 3, "net_20x": 4.7175}, g["total_live"]
    assert g["by_grade_reader"]["强"] == {"n": 3, "wins": 2, "losses": 1, "net_20x": 5.4524}, g["by_grade_reader"]
    assert g["by_grade_v2"]["强"] == {"n": 4, "wins": 3, "losses": 1, "net_20x": 11.4596}, g["by_grade_v2"]
    assert g["by_grade_v2"]["中"] == {"n": 3, "wins": 1, "losses": 2, "net_20x": -6.7421}, g["by_grade_v2"]
    assert g["q5_unanswered_below_1_5"] == {"n": 2, "wins": 0, "losses": 2, "net_20x": -6.9726}, g["q5_unanswered_below_1_5"]
    assert g["override_group"] == {"n": 1, "wins": 1, "losses": 0, "net_20x": 4.9664}, g["override_group"]
    assert g["shadow_total"] == {"n": 6, "wins": 5, "losses": 1, "net_20x": 14.62}, g["shadow_total"]
    assert "n<5" in g["sample_warning"], g["sample_warning"]

    # lessons 段不得含本候选的定级/结论字段（按键名精确查，不是子串查：
    # by_grade_reader / by_grade_v2 是历史分组的标签，不是本笔的定级）
    def _keys(o):
        if isinstance(o, dict):
            for k, v in o.items():
                yield k
                yield from _keys(v)
        elif isinstance(o, list):
            for v in o:
                yield from _keys(v)
    for banned in ("decision", "grade", "write", "would_write"):
        assert banned not in set(_keys(sec)), f"lessons 段泄漏结论字段 {banned}"

    # 注入演示：把 lessons 段放进已有的真实 ETH packet（02:15 UTC 11-22）
    src = os.path.join(HERE, "packets", "packet_ETH_1795313700.json")
    pkt = json.load(open(src, encoding="utf-8"))
    pkt["lessons"] = sec
    pkt["packet_version"] = jpk.PACKET_VERSION
    out = os.path.join(HERE, "packets", "packet_ETH_1795313700_lessons.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(pkt, f, ensure_ascii=False, indent=1)
    print("断言全部通过。")
    print(f"演示 packet 已写：{out}")
    print("lessons 段摘要：")
    print(json.dumps({"recent_lessons": [(L["id"], L["status"]) for L in sec["recent_lessons"]],
                      "struck": [s["id"] for s in sec["struck"]],
                      "total_live": g["total_live"],
                      "q5_group": g["q5_unanswered_below_1_5"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
