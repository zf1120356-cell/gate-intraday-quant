#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
推理读盘——事实包打包器（judge_packet.py）
====================================================
归属：主系统主观层（推理读盘判断层，见《判断层-推理读盘-设计.md》）。
只呈现事实，不做决定。

作用：给一个候选（币 + 方向 + 确认根），把读者读盘需要的全部事实
打包成一个 packet JSON：
  预检种类（A/B/C/D）、最近 40 根 15m + 最近 30 根 1h 原始 K 线（全部截断
  至确认根，不含未来数据）、ATR、参考位与测试史、探针/确认根的测量数、
  1h 结构数、P/D 数、附近 FVG 边、事前检查数、量数、盘口快照（live 才有；
  影子重建时历史盘口不存在，记“抓不到”）、regime 指标 D24/D6/V（v2 §1.4）、
  介入结构三列（±2 / ±6 / §1.6 显著结构，v2 §1.6）、早上计划方向与状态、
  机械止损止盈参考数（执行层固定 1×/2×ATR，见设计 §4）。
  1.1 新增：教训 feed 快照（lessons 段，见《判断层-学习回路-设计.md》§4）——
  本 tick 有效的教训（观察/候选/规则）+ 判断账分组统计（只含已平仓交易，
  全部带笔数 n，n<5 的数字只作背景）。lessons 段是“过去的事实”，不是对本
  候选的结论：它不含本笔的定级建议，读者按 brief §8 使用。

红线（写死在代码里，审计时可 grep 验证）：
  - 本文件不调用 decide()、不调用 build_trigger()、不调用 write_trigger()；
  - 输出的 packet 里没有任何结论字段：没有 decision/grade/write、
    没有任何一项的“通过/不通过”、没有量/盘口的 verdict、没有
    “对齐/不对齐”“走完/未走完”“破位失败”这类判断词——只有数字、
    原始 K 线和“算不出/抓不到”。
  - 读者（推理 agent）按下发的 rubric（v2 叙事模板 7 问 + 训练校准 1–8）
    自己读盘、自己定级（强/中/弱）。机器只盯盘、只呈现事实。

数据来源：Gate 公开接口（curl，与引擎同款），K 线截断至确认根（含）；
1h 只取确认根时刻之前已收盘的根（与 judge_read.brief 同口径）。
拉数失败 → 直接报错退出，绝不输出缺数据的 packet。

用法（影子重建，历史盘口不存在）：
  python3 judge_packet.py --coin ETH --direction -1 \
      --confirm-t <确认根UTC秒> --plan-file <当日计划文件> [--out DIR]
用法（live tick，决策时刻抓盘口）：
  python3 judge_packet.py --coin ETH --direction -1 --confirm-t <秒> \
      --plan-file <当日计划> --book fetch [--out DIR]
  或 --book-json <盘口JSON文件>（编排器每 tick 每币只抓一次盘口时用）。

输出：<out>/packet_<COIN>_<confirm_t>.json，并打印一行摘要。
"""
import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import judge_precheck as jp  # noqa: E402
import judge_read as jr  # noqa: E402
from judge_precheck import atr_wilder  # noqa: E402

ENGINE_DIR = os.path.expanduser(
    "~/workspace/goals/gate-intraday-perpetual-quant-strategy/hidden_files")
PLAN_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易")
FEED_PATH = os.path.join(PLAN_DIR, "判断教训-feed.json")
LEDGER_PATH = os.path.join(PLAN_DIR, "判断账.jsonl")
PACKET_VERSION = "judge-packet/1.1"
BARS15_N = 40
BARS1H_N = 30
REGIME_WINDOW_1H = 100   # V 用过去 100 根 1h 的 ATR 分位（v2 §1.4）
STRUCT_WINDOW_HOURS = 48  # 介入结构只看 48 小时内的位子（v2 §1.6）


def fmt_ts(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")


def fmt_bj(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).astimezone(
        timezone(__import__("datetime").timedelta(hours=8))).strftime("%H:%M")


# ---------------------------------------------------------------- regime
def regime_indicators(bars1h_closed, atr1h):
    """v2 §1.4：D24/D6/V，全部用决策时刻之前已收盘的 1h K 线算。
    D24 =（最近收盘 − 24h 前收盘）/ ATR1h；D6 同理（6h 前）；
    V = 当前 ATR1h 在过去 100 根 1h ATR 里的分位。
    ATR 口径：regime 用决策时刻的 live Wilder ATR（v2 §1.4 原文“14 根 1h
    平均真实波幅”），与执行用的早上计划 ATR（packet 的 atr.atr1h）区分，
    两者都写进 packet，读者可见。
    返回数字 + 按 v2 阈值算出的 regime 分类（测量，读者可不同意）。
    审计注：v2 文档 regime 表的 ETH 11-22 D24（+3.83）按本定义复算为
    +3.20（live ATR）/+2.20（plan ATR）；+3.83 疑似用了 24h 前那根的
    最低价 1613.48 而非收盘价 1625.22（(1685.45−1613.48)/18.81=3.83），
    regime 分类不受影响（均为震荡）。"""
    closes = [b["c"] for b in bars1h_closed]
    atrs = atr_wilder(bars1h_closed)
    vals = [a for a in atrs if a is not None]
    atr_live = vals[-1] if vals else None
    if len(closes) < 25 or atr_live is None or atr_live <= 0:
        return {"d24": None, "d6": None, "v": None, "regime": None,
                "atr1h_live": atr_live,
                "note": "1h 数据不足 25 根或 live ATR1h 算不出，regime 算不出"}
    d24 = (closes[-1] - closes[-25]) / atr_live
    d6 = (closes[-1] - closes[-7]) / atr_live
    v = None
    if len(vals) >= 50:
        prev = vals[-101:-1]
        if len(prev) >= 50:
            v = sum(1 for x in prev if x <= atr_live) / len(prev)
    regime = None
    if d24 is not None and v is not None:
        if v >= 0.7 and abs(d24) >= 2:
            regime = "瀑布"
        elif v <= 0.4:
            regime = "震荡"
        else:
            regime = "过渡"
    return {"d24": round(d24, 2), "d6": round(d6, 2),
            "v": (round(v, 2) if v is not None else None),
            "regime": regime, "atr1h_live": round(atr_live, 4),
            "note": "D24/D6 用 live Wilder ATR1h（v2 §1.4 原文口径）；执行用的 ATR1h 见 packet 的 atr.atr1h（优先早上计划表）。regime 分类按 v2 §1.4 阈值（瀑布 V≥0.7 且 |D24|≥2；震荡 V≤0.4；其余过渡）算出，是测量不是决定"}


# ------------------------------------------------------- 介入结构（三列）
def _median(xs):
    s = sorted(xs)
    n = len(s)
    return s[n // 2] if n % 2 == 1 else (s[n // 2 - 1] + s[n // 2]) / 2.0


def _swing_levels(bars, window, direction):
    """±window 摆动极值。做空找摆动低点（支撑），做多找摆动高点（阻力）。
    返回 [(t, price)]，只含 bars 里的根。"""
    out = []
    for i, b in enumerate(bars):
        lo_i = max(0, i - window)
        hi_i = min(len(bars), i + window + 1)
        if direction == -1:
            if b["l"] == min(x["l"] for x in bars[lo_i:hi_i]):
                out.append((b["t"], b["l"]))
        else:
            if b["h"] == max(x["h"] for x in bars[lo_i:hi_i]):
                out.append((b["t"], b["h"]))
    return out


def intervening_structures(bars1h_closed, direction, ref, sl, tp, atr1h):
    """v2 §1.6：入场到机械止盈之间最近的结构位，三列各记一个。
    做空：结构位是 ref 之下、TP 之上的低点；做多反之。
    (a) ±6 摆动极值（13 根窗口）——同时也是 §1.6 定义的 (a) 项；
    (b) 位移根极值：单根 1h 波幅 ≥ 过去 100 根中位波幅 2 倍的 K 线极值；
    (c) 拒绝影线极值：影线 ≥ 该根波幅 50% 的 K 线极值（做空看下影、做多看上影）；
    (d) FVG 边（未填补的，见 judge_read.fvg_edges）。
    §1.6 显著结构 = (a)(b)(c)(d) 里离入场最近的一个。
    每列返回 {level, rr, source} 或 None（无）。RR = |ref-level| / |ref-SL|。
    只有数字，没有“拦/不拦”的判断。"""
    win = [b for b in bars1h_closed if b["t"] >= bars1h_closed[-1]["t"] - STRUCT_WINDOW_HOURS * 3600] \
        if bars1h_closed else []
    # 48h 窗口按确认根时刻算：调用方传进来的 bars1h_closed 已截断至决策时刻，
    # 这里用最后 48 根 1h 近似 48 小时（1h 一根，48 根 = 48 小时）。
    win = bars1h_closed[-48:] if len(bars1h_closed) >= 48 else bars1h_closed

    def between(level):
        return (tp < level < ref) if direction == -1 else (ref < level < tp)

    def nearest(cands):
        cands = [c for c in cands if between(c[1])]
        if not cands:
            return None
        t, level, src = min(cands, key=lambda c: abs(c[1] - ref))
        rr = abs(ref - level) / abs(ref - sl) if sl != ref else None
        return {"level": level, "rr": (round(rr, 2) if rr is not None else None),
                "source": src, "t": fmt_ts(t)}

    # (a) ±6 摆动
    sw6 = [(t, p, "±6摆动") for (t, p) in _swing_levels(win, 6, direction)]
    plus6 = nearest(sw6)
    # ±2 摆动（独立一列）
    sw2 = [(t, p, "±2摆动") for (t, p) in _swing_levels(win, 2, direction)]
    plus2 = nearest(sw2)
    # (b) 位移根
    ranges = [b["h"] - b["l"] for b in bars1h_closed[-100:]] if bars1h_closed else []
    med_r = _median(ranges) if ranges else None
    disp = []
    if med_r:
        for b in win:
            if (b["h"] - b["l"]) >= 2 * med_r:
                ext = b["l"] if direction == -1 else b["h"]
                disp.append((b["t"], ext, "位移根极值"))
    # (c) 拒绝影线
    wick = []
    for b in win:
        rng = b["h"] - b["l"]
        if rng <= 0:
            continue
        if direction == -1 and (b["c"] - b["l"]) >= 0.5 * rng:
            wick.append((b["t"], b["l"], "拒绝影线极值"))
        if direction == 1 and (b["h"] - b["c"]) >= 0.5 * rng:
            wick.append((b["t"], b["h"], "拒绝影线极值"))
    # (d) FVG 边
    fvg_c = []
    for f in jr.fvg_edges(bars1h_closed):
        for edge in (f["lo"], f["hi"]):
            fvg_c.append((f["t"], edge, f"FVG边（{f['kind']}）"))
    # 全部候选（按离入场距离排序）：只取最近一个会漏掉真正重要的位子——
    # 实测 ETH 空 11-22：最近的是 1675.84（11-21 16:00 一根 1h 的下影极值，
    # 琐碎），而真正被价格尊重的是 1647.38（11-20 15:00 位移根低点，RR 1.13）。
    # “显著”本身是读者的判断，机器只呈现实测的梯子，不预选。
    def _cand_list(cands):
        seen = {}
        for (t, level, src) in cands:
            if between(level):
                seen.setdefault(round(level, 8), (t, level, src))
        out = []
        for (t, level, src) in seen.values():
            rr = abs(ref - level) / abs(ref - sl) if sl != ref else None
            out.append({"level": level, "rr": (round(rr, 2) if rr is not None else None),
                        "source": src, "t": fmt_ts(t)})
        out.sort(key=lambda c: abs(c["level"] - ref))
        return out
    all_cands = sw6 + disp + wick + fvg_c
    significant = nearest(sw6 + disp + wick + fvg_c)
    return {"plus2": plus2, "plus6": plus6, "significant": significant,
            "candidates": _cand_list(all_cands),
            "note": "candidates 是入场到机械止盈之间 48h 内全部结构位（按离入场距离排序），供读者 Q5 判断哪一个才是'显著结构'；plus2/plus6/significant 三列只取各定义最近的一个，供 12-18 三种定义对比记账；是否拦住价格由读者判断，packet 不判断"}


# ------------------------------------------------------------- 早上计划
def _parse_float(x):
    try:
        return float(str(x).strip().replace(",", ""))
    except (TypeError, ValueError):
        return None


def morning_plan_facts(plan_path, coin, confirm_t, atr1h, ref_close, direction):
    """早上计划的方向与状态（事实，不判断“活着/死了”）：
    - direction：plan_directions 的方向（+1/-1/None，含 v1.2 预案表补充）；
    - trigger_row：早上预案表里该币的行（入场区/参考价/止损/止盈/触发与失效条件原文）；
    - morning_traded：引擎日志里该币早上计划（subj 层、非 supp）在决策时刻前是否已成交；
    - morning_stale：引擎日志里该币早上计划是否记过 entry_missed stale_expired；
    - plan_tp_gap_x：确认收盘相对早上计划止盈的距离（×ATR1h；做空为 (收盘−止盈)/ATR1h，
      做多为 (止盈−收盘)/ATR1h；正数 = 价格已越过止盈一侧）。
    引擎日志缺失时 traded/stale 记 None（算不出），不猜。"""
    out = {"direction": None, "direction_txt": None, "trigger_row": None,
           "morning_traded": None, "morning_stale": None, "plan_tp_gap_x": None}
    if not plan_path or not os.path.exists(plan_path):
        out["note"] = "当日计划文件不存在，早上计划方向算不出"
        return out
    dirs = jr.plan_directions(plan_path)
    d = dirs.get(coin)
    out["direction"] = d
    out["direction_txt"] = ("做多" if d == 1 else "做空" if d == -1 else None)
    text = open(plan_path, encoding="utf-8").read()
    lines = text.split("\n")
    for i, ln in enumerate(lines):
        if re.match(r"^\|\s*币\s*\|\s*方向\s*\|\s*入场区", ln):
            for row in lines[i + 1:i + 12]:
                parts = [p.strip() for p in row.strip().strip("|").split("|")]
                if len(parts) >= 2 and parts[0] == coin:
                    out["trigger_row"] = {
                        "direction_txt": parts[1] if len(parts) > 1 else None,
                        "entry_zone": parts[2] if len(parts) > 2 else None,
                        "ref": _parse_float(parts[3]) if len(parts) > 3 else None,
                        "sl": _parse_float(parts[4]) if len(parts) > 4 else None,
                        "tp": _parse_float(parts[5]) if len(parts) > 5 else None,
                        "conditions": " | ".join(parts[6:]) if len(parts) > 6 else None,
                    }
                    break
            break
    # 引擎日志：决策时刻前该币早上计划的成交 / stale_expired
    date_str = datetime.fromtimestamp(confirm_t, tz=timezone.utc).strftime("%Y-%m-%d")
    log_path = os.path.join(ENGINE_DIR, f"paper_engine_{date_str}.log")
    if not os.path.exists(log_path):
        out["note"] = (out.get("note", "") + "；引擎日志缺失，morning_traded/stale 算不出").strip("；")
        return out
    traded, stale = False, False
    deadline = confirm_t + 900
    for line in open(log_path, encoding="utf-8"):
        try:
            ev = json.loads(line)
        except (ValueError, TypeError):
            continue
        if ev.get("coin") != coin:
            continue
        try:
            ev_ts = int(datetime.strptime(ev.get("ts", "2000-01-01T00:00:00Z"),
                                          "%Y-%m-%dT%H:%M:%SZ").replace(
                                              tzinfo=timezone.utc).timestamp())
        except (ValueError, TypeError):
            continue
        if ev_ts > deadline:
            continue
        if ev.get("type") == "entry":
            pos = ev.get("position", {}) or {}
            if pos.get("layer") == "subj" and not pos.get("supp"):
                traded = True
        if ev.get("type") == "entry_missed" and ev.get("reason") == "stale_expired":
            stale = True
    out["morning_traded"] = traded
    out["morning_stale"] = stale
    row = out["trigger_row"]
    if row and row.get("tp") is not None and atr1h:
        gap = ((ref_close - row["tp"]) if direction == -1 else (row["tp"] - ref_close)) / atr1h
        out["plan_tp_gap_x"] = round(gap, 2)
    return out


# ------------------------------------------------------- 教训 feed 快照（学习回路）
def _group_stats(rows):
    """判断账分组统计。只含 kind==live 的已平仓主系统交易；影子另计，不混入。
    每组都带 n；n<5 的组在 sample_warning 里点名。算不出（字段缺失）的组
    记 None，不编数。返回 dict（全是过去的事实，不是对本候选的结论）。"""
    live = [r for r in rows if r.get("kind") == "live"]
    shadow = [r for r in rows if r.get("kind") in ("blocked_shadow", "no_shadow")]

    def agg(rs):
        rs = [r for r in rs if r.get("outcome", {}).get("net_20x") is not None]
        if not rs:
            return None
        return {"n": len(rs),
                "wins": sum(1 for r in rs if r["outcome"]["net_20x"] > 0),
                "losses": sum(1 for r in rs if r["outcome"]["net_20x"] < 0),
                "net_20x": round(sum(r["outcome"]["net_20x"] for r in rs), 4)}

    def by(key):
        out = {}
        for r in live:
            out.setdefault(r.get(key), []).append(r)
        return {str(k): agg(v) for k, v in out.items() if agg(v) is not None}

    q5_bad = [r for r in live
              if r.get("q5_rr") is not None and r["q5_rr"] < 1.5
              and r.get("q5_answered") is False]
    q5_ok = [r for r in live
             if (r.get("q5_rr") is None and r.get("q5_rr_basis", "").startswith("无介入结构"))
             or r.get("q5_answered") is True]
    over = [r for r in live if r.get("override")]
    small = []
    for name, g in [("by_grade_reader", by("grade_reader")),
                    ("by_grade_v2", by("grade_v2")),
                    ("by_regime", by("regime"))]:
        for k, v in g.items():
            if v["n"] < 5:
                small.append(f"{name}.{k} n={v['n']}")
    return {
        "as_of_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        "closed_trades_n": len(live),
        "total_live": agg(live),
        "by_grade_reader": by("grade_reader"),
        "by_grade_v2": by("grade_v2"),
        "by_regime": by("regime"),
        "q5_unanswered_below_1_5": agg(q5_bad),
        "q5_answered_or_no_structure": agg(q5_ok),
        "override_group": agg(over),
        "shadow_total": agg(shadow),
        "shadow_note": "影子（被拦/未写）与 live 分开记，不混入任何 live 组；影子按半权计入教训晋升，不计入胜率",
        "sample_warning": ("全部的组 n<5：数字只作背景，不作证据；教训晋升只看 feed 的 status。"
                           if small else "样本充足"),
        "small_groups": small,
        "note": "只含已平仓主系统判断交易；未平仓不计；分级有读者定级（grade_reader）与 v2 事后重分级（grade_v2）两列，两者分歧的行见判断账",
    }


def build_lessons_section(feed_path=None, ledger_path=None):
    """教训 feed 的本 tick 快照（学习回路，设计 §4）：
    recent_lessons = 本 tick 有效的教训（observation/candidate/rule，
    按 id 排序，只含 pattern.applies_to == all 的——现阶段全部教训都适用全币全向）；
    struck = 已证伪的教训（只作“勿用”提醒）；
    recent_cases = 平仓复盘案例（设计 §13，最近 5 条，最新在前；是单笔的反思，不是规则）；
    group_stats = 判断账分组统计（见 _group_stats）。
    feed 或 ledger 缺失 → 对应段 available=False，不报错、不让 packet 打包失败。
    本函数不做决定：只呈现 feed 内容与历史分组数。教训的 reflection 是反思提示
    （上次发生了什么、当时看错了哪一点、这次多问一句什么），不是封顶动作。"""
    feed_path = feed_path or FEED_PATH
    ledger_path = ledger_path or LEDGER_PATH
    out = {"available": True, "feed_version": None, "feed_updated_at_utc": None,
           "recent_lessons": [], "struck": [], "recent_cases": [], "group_stats": None,
           "note": "教训是过去的事实与方法增量，不是本候选的结论；读者按 brief §8 使用"}
    try:
        with open(feed_path, encoding="utf-8") as f:
            feed = json.load(f)
    except (OSError, ValueError) as e:
        out["available"] = False
        out["reason"] = f"教训 feed 读不到：{e}（packet 其余部分不受影响）"
        out["group_stats"] = None
        return out
    out["feed_version"] = feed.get("feed_version")
    out["feed_updated_at_utc"] = feed.get("updated_at_utc")
    for L in feed.get("lessons", []):
        g = L.get("group_so_far", {}) or {}
        item = {"id": L["id"], "status": L["status"], "title": L["title"],
                "attaches_to": L.get("attaches_to"),
                "condition": L["pattern"]["condition"],
                "reflection": L.get("reflection"),
                "n": g.get("n") or g.get("n_pairs") or g.get("n_shadow"),
                "net_20x": g.get("net_20x") if g.get("net_20x") is not None
                           else g.get("net_shadow_20x"),
                "falsification": L.get("falsification")}
        if L["status"] == "struck":
            out["struck"].append(item)
        elif L["status"] in ("observation", "candidate", "rule"):
            out["recent_lessons"].append(item)
    for c in reversed((feed.get("cases", []) or [])[-5:]):
        out["recent_cases"].append({
            "id": c.get("id"), "trade": c.get("trade"),
            "closed": c.get("closed"), "net_20x": c.get("net_20x"),
            "misread": c.get("misread"), "watch_next": c.get("watch_next"),
            "related_lesson": c.get("related_lesson")})
    try:
        rows = [json.loads(ln) for ln in open(ledger_path, encoding="utf-8")
                if ln.strip()]
        out["group_stats"] = _group_stats(rows)
    except (OSError, ValueError) as e:
        out["group_stats"] = {"available": False,
                              "reason": f"判断账读不到：{e}（分组统计算不出）"}
    return out


# ------------------------------------------------------------- 打包主流程
def build_packet(coin, direction, confirm_t, plan_path=None, book_mode="none",
                 book_json=None, out_dir=None, lessons_feed=None,
                 ledger_path=None):
    """打包一个候选的事实包。拉数失败或简报算不出时抛异常（不输出缺数据的包）。
    lessons_feed：教训 feed 路径（默认 FEED_PATH）；feed 缺失时 lessons 段记
    available=False，不影响 packet 其余部分（见 build_lessons_section）。"""
    # 1. 拉数（Gate 公开接口，curl）并截断至确认根
    bars15 = jp.fetch_gate_15m(f"{coin}_USDT", limit=500)
    bars1h = jr.fetch_gate_1h(f"{coin}_USDT", limit=300)
    bars15 = [b for b in bars15 if b["t"] <= confirm_t]
    bars1h_closed = [b for b in bars1h if b["t"] + 3600 <= confirm_t + 900]
    if not bars15 or bars15[-1]["t"] != confirm_t:
        raise RuntimeError(f"15m 数据里没有确认根 {fmt_ts(confirm_t)}（最后 {fmt_ts(bars15[-1]['t']) if bars15 else '无'}）")
    if len(bars1h_closed) < 25:
        raise RuntimeError(f"1h 已收盘根不足 25 根（{len(bars1h_closed)} 根），算不出")
    # 2. 预检种类（事实：这个候选为什么被扫出来）
    cands = jp.precheck_coin(bars15, coin)
    pre = {"kinds": None, "level": None, "level_txt": None,
           "note": "预检未报出此候选（影子重建时数据截断差异可能导致，读者仍按 packet 读盘）"}
    for c in cands:
        if c["direction"] == direction:
            pre = {"kinds": c["kinds"], "level": c["level"],
                   "level_txt": c["level_txt"], "note": c["reason"]}
            break
    # 3. 简报测量数（只取事实字段，结论字段全部去掉——见 strip）
    b = jr.brief(coin, direction, confirm_t, bars15, bars1h,
                 plan_path=plan_path if plan_path and os.path.exists(plan_path) else None,
                 book=None)
    if "error" in b:
        raise RuntimeError(f"简报算不出：{b['error']}")
    # 4. 盘口（live 才有；影子重建一律“抓不到”）
    book = {"available": False, "reason": "影子重建：历史盘口不存在，抓不到"}
    if book_mode == "fetch":
        try:
            raw = jr.fetch_gate_book(f"{coin}_USDT")
            info = jr.analyze_book(raw, b["level"], direction, b["atr15"])
            book = {"available": True, "wall_x": info.get("wall_x"),
                    "wall_size": info.get("wall_size"), "imb": info.get("imb"),
                    "txt": info.get("txt")}
        except Exception as e:
            book = {"available": False, "reason": f"决策时刻盘口拉取失败：{e}"}
    elif book_json:
        try:
            raw = json.load(open(book_json, encoding="utf-8"))
            info = jr.analyze_book(raw, b["level"], direction, b["atr15"])
            book = {"available": True, "wall_x": info.get("wall_x"),
                    "wall_size": info.get("wall_size"), "imb": info.get("imb"),
                    "txt": info.get("txt")}
        except Exception as e:
            book = {"available": False, "reason": f"盘口文件读不到：{e}"}
    # 5. 结构数（只取数字，不取 structure_ok 结论）
    closes = [x["c"] for x in bars1h_closed]
    struct = {
        "recent_max_close": max(closes[-6:]), "prev_max_close": max(closes[-12:-6]),
        "recent_min_close": min(closes[-6:]), "prev_min_close": min(closes[-12:-6]),
        "d_max": max(closes[-6:]) - max(closes[-12:-6]),
        "d_min": min(closes[-6:]) - min(closes[-12:-6]),
        "threshold": 0.5 * b["atr1h"],
        "note": "数字本身；是否'明确反向趋势'由读者按校准 2 判断，packet 不判断",
    }
    # 6. 事前检查数（只取数字）
    if direction == -1:
        played_x = (b["level"] - b["confirm"]["c"]) / b["atr1h"]
    else:
        played_x = (b["confirm"]["c"] - b["level"]) / b["atr1h"]
    failed_nums = []
    for f in b["near_fvg"]:
        failed_nums.append({"kind": f["kind"], "lo": f["lo"], "hi": f["hi"], "t": f["t"]})
    # 7. 量数（去掉 verdict，只留数字与测量标记）
    vol = b.get("volume") or {}
    volume = {"probe_x": vol.get("probe_x"), "confirm_x": vol.get("confirm_x"),
              "rej_x": vol.get("rej_x"), "climax": vol.get("climax"),
              "divergence": vol.get("divergence"), "vol1h_x": vol.get("vol1h_x"),
              "txt": vol.get("txt")}
    # 8. regime 与介入结构
    regime = regime_indicators(bars1h_closed, b["atr1h"])
    ref = b["confirm"]["c"]
    atr1h = b["atr1h"]
    if direction == -1:
        mech_sl, mech_tp = ref + atr1h, ref - 2 * atr1h
    else:
        mech_sl, mech_tp = ref - atr1h, ref + 2 * atr1h
    inter = intervening_structures(bars1h_closed, direction, ref, mech_sl, mech_tp, atr1h)
    # 9. 早上计划事实
    mplan = morning_plan_facts(plan_path, coin, confirm_t, atr1h, ref, direction)
    # 10. 教训 feed 快照（学习回路，1.1 新增；只呈现过去的事实，不做本笔决定）
    lessons = build_lessons_section(feed_path=lessons_feed, ledger_path=ledger_path)
    # 10. 测试史数字（去掉 gaps/span/recent 结论布尔，只留原始数字）
    tests = b["tests"]
    test_times = [t["t"] for t in tests]
    span_h = ((max(test_times) - min(test_times)) / 3600.0) if len(test_times) >= 2 else None
    gaps = [(test_times[j] - test_times[i]) // 900
            for i in range(len(test_times)) for j in range(i + 1, len(test_times))]
    packet = {
        "packet_version": PACKET_VERSION,
        "coin": coin, "direction": direction,
        "direction_txt": "做空" if direction == -1 else "做多",
        "confirm_t": confirm_t, "confirm_utc": fmt_ts(confirm_t),
        "confirm_bj": fmt_bj(confirm_t),
        "probe_t": b["probe_t"], "probe_utc": fmt_ts(b["probe_t"]),
        "pending_entry_t": confirm_t + 900,
        "pending_entry_utc": fmt_ts(confirm_t + 900),
        # 订正 2026-11-22：旧值 confirm_t+900-120 是入场根开盘前 2 分钟，
        # 但 packet 只能在确认根收盘（=入场根开盘）后才建得出来，旧 deadline
        # 在建包时就已过期，影子读盘会全是 read_miss。引擎实测行为：
        # supp_merge 在 pending_entry_t+900 内都登记触发，supp_try_entry 在
        # 入场根内任何一次轮询看到触发都按该根开盘价入场（11-22 ETH 02:31:33
        # 写触发、pending_entry 02:30，02:31:48 按 02:30 根开盘价入场）；
        # 晚于入场根收盘才作废（supp_stale）。所以正确 deadline 是入场根
        # 收盘前 2 分钟 = confirm_t+1800-120。
        "write_by_utc": fmt_ts(confirm_t + 1800 - 120),
        "write_by_note": "触发须在入场根（pending_entry 起的那根 15m）收盘前写进计划并被引擎登记；留 2 分钟给引擎 30 秒轮询，读者最晚在 write_by 前完成决定",
        "built_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        "data_source": "Gate 公开接口（curl），15m/1h 均截断至确认根，不含未来数据",
        "precheck": pre,
        "bars15": [[x["t"], x["o"], x["h"], x["l"], x["c"], x["v"]]
                   for x in bars15[-BARS15_N:]],
        "bars1h": [[x["t"], x["o"], x["h"], x["l"], x["c"], x["v"]]
                   for x in bars1h_closed[-BARS1H_N:]],
        "bars_note": "bars15 为确认根之前最近 40 根 15m；bars1h 为决策时刻前已收盘的最近 30 根 1h；[t,o,h,l,c,v]，t 为开盘时刻 UTC 秒",
        "atr": {"atr15": b["atr15"], "atr1h": b["atr1h"],
                "atr1h_source": b["atr1h_source"]},
        "level": {"value": b["level"], "tests": tests, "test_count": b["test_count"],
                  "spread": b["test_spread"], "span_hours": span_h,
                  "gaps_bars": gaps,
                  "last_test_to_probe_bars": ((b["probe_t"] - max(test_times)) // 900
                                              if test_times else None),
                  "pair": b["pair"]},
        "probe": {"t": b["probe"]["t"], "o": b["probe"]["o"], "h": b["probe"]["h"],
                  "l": b["probe"]["l"], "c": b["probe"]["c"],
                  "wick_x": b["probe"]["wick_x"],
                  "close_vs_level_x": round((b["probe"]["c"] - b["level"]) / b["atr15"], 2)
                  if direction == -1 else round((b["level"] - b["probe"]["c"]) / b["atr15"], 2)},
        "confirm": {"t": b["confirm"]["t"], "o": b["confirm"]["o"],
                    "h": b["confirm"]["h"], "l": b["confirm"]["l"],
                    "c": b["confirm"]["c"], "move_x": b["confirm"]["move_x"],
                    "close_vs_probe_close_x": round(
                        (b["confirm"]["c"] - b["probe"]["c"]) / b["atr15"], 2)
                    if direction == -1 else round(
                        (b["probe"]["c"] - b["confirm"]["c"]) / b["atr15"], 2)},
        "structure_1h": struct,
        "pd": {"pct": b["pd_pct"], "txt": b["pd_txt"]},
        "near_fvg": b["near_fvg"],
        "played": {"distance_x": round(played_x, 2),
                   "note": "做空：(参考位−确认收盘)/ATR1h；做多：(确认收盘−参考位)/ATR1h；数字本身，是否'走完'由读者判断"},
        "failed_break_nums": {"probe_extreme": (b["probe"]["l"] if direction == -1
                                                else b["probe"]["h"]),
                              "last_1h_close": bars1h_closed[-1]["c"],
                              "near_fvg": failed_nums,
                              "note": "校准 7 的判断数：探针极值、附近 FVG 边、最近已收盘 1h 收盘；是否'破位失败'由读者判断"},
        "volume": volume,
        "book": book,
        "regime": regime,
        "mechanical_sl_tp": {"ref": ref, "sl": mech_sl, "tp": mech_tp,
                             "note": "执行层固定 1×/2×ATR（用户已定，读者不改）；止损止盈按实际入场开盘价由引擎重算"},
        "intervening": inter,
        "morning_plan": mplan,
        "lessons": lessons,
        "no_decision_fields": "本 packet 不含任何结论字段（无 decision/grade/write、无任何一项的通过/不通过、无量与盘口的 verdict、无'对齐/走完/破位失败'等判断词）；lessons 段是过去的教训与历史分组数（带笔数 n），不是本候选的定级建议；决定由读者按 rubric 做",
    }
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, f"packet_{coin}_{confirm_t}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(packet, f, ensure_ascii=False, indent=1)
        return packet, path
    return packet, None


def trigger_from_packet(packet, reason, vol_verdict=None, book_verdict=None):
    """读者定级为“强”时，把 packet 转成补充触发 dict（与机械层/v1.2 同形，
    调同一个 jr.write_trigger → supp_observer.append_supp_trigger，
    引擎接口一字不变）。
    机械格式化，不做决定：ref/止损/止盈 = 确认收盘 ±1×/∓2×ATR1h（执行层
    固定口径）；basis = 读者自己的叙事与理由（reason 参数）；量/盘口的
    verdict 由读者自己的叙事给（packet 里没有 verdict），只作记账用。
    返回 trigger dict（不写文件；写文件由调用方调 jr.write_trigger）。"""
    vol = dict(packet.get("volume") or {})
    vol["verdict"] = vol_verdict
    book = dict(packet.get("book") or {})
    if book.get("available"):
        book["verdict"] = book_verdict
    b = {
        "coin": packet["coin"], "direction": packet["direction"],
        "confirm_t": packet["confirm_t"], "probe_t": packet["probe_t"],
        "level": packet["level"]["value"],
        "tests": packet["level"]["tests"],
        "confirm": {"c": packet["confirm"]["c"],
                    "move_x": packet["confirm"]["move_x"]},
        "probe": {"wick_x": packet["probe"]["wick_x"]},
        "atr1h": packet["atr"]["atr1h"],
        "atr1h_source": packet["atr"]["atr1h_source"],
        "atr15": packet["atr"]["atr15"],
        "volume": vol, "book": book,
    }
    trig = jr.build_trigger(b, reason)
    trig["reader"] = "reasoning"
    return trig


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--coin", required=True)
    ap.add_argument("--direction", type=int, required=True, choices=[-1, 1])
    ap.add_argument("--confirm-t", type=int, required=True)
    ap.add_argument("--plan-file", default=None)
    ap.add_argument("--book", choices=["none", "fetch"], default="none")
    ap.add_argument("--book-json", default=None)
    ap.add_argument("--lessons-feed", default=None,
                    help="教训 feed 路径（默认 判断教训-feed.json；缺失时 lessons 段记 unavailable）")
    ap.add_argument("--ledger", default=None, help="判断账路径（默认 判断账.jsonl）")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    plan = args.plan_file
    if plan is None:
        d = datetime.fromtimestamp(args.confirm_t, tz=timezone.utc).strftime("%Y-%m-%d")
        plan = os.path.join(PLAN_DIR, f"{d}.md")
    packet, path = build_packet(args.coin, args.direction, args.confirm_t,
                                plan_path=plan, book_mode=args.book,
                                book_json=args.book_json, out_dir=args.out,
                                lessons_feed=args.lessons_feed,
                                ledger_path=args.ledger)
    print(json.dumps({"packet": path or "(stdout only)",
                      "coin": packet["coin"], "direction": packet["direction_txt"],
                      "confirm_utc": packet["confirm_utc"],
                      "level": packet["level"]["value"],
                      "tests": packet["level"]["test_count"],
                      "probe_wick_x": packet["probe"]["wick_x"],
                      "confirm_move_x": packet["confirm"]["move_x"],
                      "rej_x": packet["volume"].get("rej_x"),
                      "pd_pct": packet["pd"]["pct"],
                      "regime": packet["regime"].get("regime"),
                      "book_available": packet["book"].get("available")},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
