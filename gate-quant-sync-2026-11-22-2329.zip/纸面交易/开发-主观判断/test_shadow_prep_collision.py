#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""judge_shadow_prep 双向候选撞文件名回归测试（synthetic 夹具，不拉真实数据）。

回归：2026-11-22 23:01 tick，编排器列出 15 个候选，7 个做空方向 packet
文件缺失（packet_miss）。根因：build_packet 不含方向，写死到
packet_<COIN>_<confirm_t>.json；同币同确认根双向候选时，第二方向的
build 会覆盖第一方向的包，改名后 stdout 列出的首方向路径也不存在。
precheck 先报 -1 后报 +1，所以丢的全是做空。

断言：
  1. 双向候选：stdout 列出 2 条，两条路径都存在；
  2. _d-1.json 内容 direction == -1，_d1.json 内容 direction == 1；
  3. 不含方向的原名文件不存在（两边都已改名）；
  4. 单向候选：原名文件存在，内容方向正确，无改名文件。
"""
import contextlib
import io
import json
import os
import sys
import tempfile
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import judge_shadow_prep as prep  # noqa: E402

ASSERTS = []


def check(cond, msg):
    ASSERTS.append((bool(cond), msg))
    print(("  ok：" if cond else "  FAIL：") + msg)


FAKE_NOW = datetime(2026, 11, 22, 15, 5, tzinfo=timezone.utc)  # 15:05 UTC


class FakeDatetime(datetime):
    @classmethod
    def now(cls, tz=None):
        return FAKE_NOW


def fake_bars15(symbol):
    now_floor15 = int(FAKE_NOW.timestamp()) // 900 * 900
    # 最后一根已收盘：t + 900 == now_floor15
    return [{"t": now_floor15 - 900, "o": 100.0, "h": 101.0,
             "l": 99.0, "c": 100.5, "v": 10.0}]


def fake_bars1h(symbol):
    now_floor15 = int(FAKE_NOW.timestamp()) // 900 * 900
    return [{"t": now_floor15 - 3600, "o": 100.0, "h": 101.0,
             "l": 99.0, "c": 100.5, "v": 10.0}]


def fake_precheck_both(bars15, coin):
    if coin != "TESTA":
        return []
    return [{"direction": -1, "kinds": ["A"], "level": 99.0,
             "level_txt": "test", "reason": "synthetic short"},
            {"direction": 1, "kinds": ["A"], "level": 101.0,
             "level_txt": "test", "reason": "synthetic long"}]


def fake_precheck_single(bars15, coin):
    if coin != "TESTA":
        return []
    return [{"direction": 1, "kinds": ["A"], "level": 101.0,
             "level_txt": "test", "reason": "synthetic long"}]


def fake_build_packet(coin, direction, confirm_t, plan_path=None,
                      book_mode="fetch", out_dir=None, **kw):
    # 模拟真实 build_packet 的撞名行为：不含方向，写死到同一路径。
    path = os.path.join(out_dir, f"packet_{coin}_{confirm_t}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"coin": coin, "direction": direction,
                   "confirm_t": confirm_t}, f)
    return ({"write_by_utc": confirm_t + 1680}, path)


def run_prep(monkey_precheck):
    import judge_precheck as jp
    import judge_read as jr
    import judge_packet as jpk
    old = (prep.datetime, prep.PACKETS_DIR, prep.PLAN_DIR, prep.COINS,
           jp.fetch_gate_15m, jr.fetch_gate_1h, jp.precheck_coin,
           jpk.build_packet)
    tmp = tempfile.mkdtemp(prefix="prep_collision_")
    try:
        prep.datetime = FakeDatetime
        prep.PACKETS_DIR = tmp
        prep.PLAN_DIR = tmp
        prep.COINS = ["TESTA"]
        jp.fetch_gate_15m = fake_bars15
        jr.fetch_gate_1h = fake_bars1h
        jp.precheck_coin = monkey_precheck
        jpk.build_packet = fake_build_packet
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = prep.main()
        out = json.loads(buf.getvalue().strip().splitlines()[-1])
        return rc, out, tmp
    finally:
        (prep.datetime, prep.PACKETS_DIR, prep.PLAN_DIR, prep.COINS,
         jp.fetch_gate_15m, jr.fetch_gate_1h, jp.precheck_coin,
         jpk.build_packet) = old


def main():
    # 场景 1：双向候选（做空先、做多后，与 precheck 顺序一致）
    rc, out, tmp = run_prep(fake_precheck_both)
    check(rc == 0, "双向场景 main 返回 0")
    check(out.get("event") == "packets", "双向场景 event=packets")
    pkts = out.get("packets", [])
    check(len(pkts) == 2, "双向场景列出 2 条 packet")
    by_dir = {p["direction"]: p for p in pkts}
    check(-1 in by_dir and 1 in by_dir, "双向场景两方向都在 stdout 里")
    for d in (-1, 1):
        p = by_dir[d]
        check(os.path.exists(p["path"]), f"方向 {d} 的路径存在：{os.path.basename(p['path'])}")
        with open(p["path"], encoding="utf-8") as f:
            content = json.load(f)
        check(content["direction"] == d, f"方向 {d} 的文件内容 direction={d}")
    check(by_dir[-1]["path"].endswith("_d-1.json"), "做空包改名为 _d-1.json")
    check(by_dir[1]["path"].endswith("_d1.json"), "做多包改名为 _d1.json")
    confirm_t = pkts[0]["confirm_t"]
    plain = os.path.join(tmp, f"packet_TESTA_{confirm_t}.json")
    check(not os.path.exists(plain), "不含方向的原名文件不存在（两边都已改名）")

    # 场景 2：单向候选（不撞名，原名保留）
    rc, out, tmp = run_prep(fake_precheck_single)
    check(rc == 0, "单向场景 main 返回 0")
    pkts = out.get("packets", [])
    check(len(pkts) == 1, "单向场景列出 1 条 packet")
    p = pkts[0]
    check(os.path.exists(p["path"]), "单向场景路径存在")
    check(p["path"].endswith(f"packet_TESTA_{p['confirm_t']}.json"),
          "单向场景用原名文件，不改名")
    with open(p["path"], encoding="utf-8") as f:
        content = json.load(f)
    check(content["direction"] == 1, "单向场景文件内容 direction=1")

    failed = [m for ok, m in ASSERTS if not ok]
    if failed:
        print(f"断言失败 {len(failed)}/{len(ASSERTS)}：{failed}")
        return 1
    print(f"断言全部通过（{len(ASSERTS)} 个断言）。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
