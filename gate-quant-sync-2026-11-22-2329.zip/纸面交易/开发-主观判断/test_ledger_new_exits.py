#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""新平仓自动建账测试（update_judgment_ledger.py 的新平仓一趟）。

本文件全部数字均为 synthetic 夹具，仅用于测试断言，不代表任何真实交易。
币名用 TESTA/TESTB，与真实币种区分。

场景 1（完整联结 + 联结不到 + 幂等）：
  - TESTA：引擎日志 exit（20x 口径 fee_entry 0.15）+ 影子日志 read 行（显式
    q5_rr/q5_answered/rej_x/vol1h_x）+ packet（significant rr 与日志显式值不同，
    验显式优先）+ 计划表有更早的 TESTA 触发行（cap_blocked 应为 True；
    日志行里 cap_blocked 故意写 False，验计划表推导为准）。
  - TESTB：引擎日志 exit（1x 口径 fee_entry 7.5，须 x0.02）+ 无影子日志行 +
    无 packet → 决策字段全 null + reason，cap_blocked 由计划表推导为 False。
  - 重跑一遍新增 0 行（幂等）。
场景 2（packet 兜底 + 方向守卫）：
  - 无影子日志行；TESTB 的 packet 按约定文件名放在 packet-dir，方向/确认根全对上
    → q5_rr/rej_x/vol1h_x/regime 从 packet 兜底取到；TESTA 的 packet 方向写错
    （+1，与 exit 的 -1 不符）→ 整份 packet 弃用，字段全 null。

用法：python3 test_ledger_new_exits.py（断言全过打印“断言全部通过”，否则非 0 退出）。
"""
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
UPDATER = os.path.join(HERE, "update_judgment_ledger.py")

CONFIRM_T = 1795341600  # synthetic：2026-11-22 10:00 UTC
ENTRY_T = CONFIRM_T + 900
DATE = "2026-11-22"

N_ASSERT = [0]


def check(cond, msg):
    N_ASSERT[0] += 1
    if not cond:
        raise AssertionError(f"断言失败：{msg}")
    print(f"  ok：{msg}")


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)


def run_updater(root):
    """在 root 下跑更新器（全部路径指向夹具），返回 (returncode, stdout)。"""
    cmd = [sys.executable, UPDATER, "--dates", DATE,
           "--ledger", os.path.join(root, "ledger.jsonl"),
           "--feed", os.path.join(root, "feed.json"),
           "--engine-dir", os.path.join(root, "engine"),
           "--reader-log", os.path.join(root, "reader.log"),
           "--packet-dir", os.path.join(root, "packets"),
           "--plan-dir", os.path.join(root, "plans")]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    return p.returncode, p.stdout + p.stderr


def base_fixture(root, reader_rows, packets, plan_rows):
    """搭一套夹具目录：engine 日志（2 笔 exit）+ feed 空壳 + 空账本 + 计划表。
    reader_rows/packets/plan_rows 由各场景传入。"""
    os.makedirs(os.path.join(root, "engine"), exist_ok=True)
    os.makedirs(os.path.join(root, "packets"), exist_ok=True)
    os.makedirs(os.path.join(root, "plans"), exist_ok=True)
    exits = [
        {"ts": "2026-11-22T11:00:00Z", "type": "exit", "coin": "TESTA",
         "entry_t": ENTRY_T,
         "trade": {"coin": "TESTA", "layer": "subj", "direction": -1,
                   "entry_t": ENTRY_T, "entry": 100.0, "reason": "take_profit",
                   "net": 5.0, "fee_entry": 0.15}},
        {"ts": "2026-11-22T11:05:00Z", "type": "exit", "coin": "TESTB",
         "entry_t": ENTRY_T,
         "trade": {"coin": "TESTB", "layer": "subj", "direction": 1,
                   "entry_t": ENTRY_T, "entry": 50.0, "reason": "stop_loss",
                   "net": -100.0, "fee_entry": 7.5}},
    ]
    with open(os.path.join(root, "engine", f"paper_engine_{DATE}.log"),
              "w", encoding="utf-8") as f:
        for ev in exits:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")
    with open(os.path.join(root, "reader.log"), "w", encoding="utf-8") as f:
        for r in reader_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    for name, pkt in packets.items():
        write_json(os.path.join(root, "packets", name), pkt)
    plan = ["## 盘中补充触发（观察模块追加，计划原文不动；时间均为 UTC）", "",
            "| 币 | 方向 | 确认根UTC | 入场时间UTC | 参考位 | 参考入场价 | 止损 | 止盈 | 1h ATR | 确认依据 |",
            "|---|---|---|---|---|---|---|---|---|---|"]
    for row in plan_rows:
        plan.append(row)
    plan.append("")
    with open(os.path.join(root, "plans", f"{DATE}.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(plan))
    write_json(os.path.join(root, "feed.json"),
               {"lessons": [],
                "status_counts": {"rule": 0, "candidate": 0, "observation": 0,
                                  "revoked": 0, "struck": 0},
                "updated_at_utc": "2026-11-22T00:00:00Z"})
    open(os.path.join(root, "ledger.jsonl"), "w", encoding="utf-8").close()


def read_ledger(root):
    rows = []
    for line in open(os.path.join(root, "ledger.jsonl"), encoding="utf-8"):
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def scenario_1():
    print("场景 1：完整联结 + 联结不到 + 幂等")
    with tempfile.TemporaryDirectory() as root:
        reader_rows = [
            {"event": "read", "ts": "2026-11-22 10:05:00", "coin": "TESTA",
             "direction": -1, "confirm_t": CONFIRM_T,
             "packet": "packets/packet_TESTA_1795341600.json", "grade": "强",
             "narrative": {"q1": "synthetic", "q5": "synthetic"},
             "overrides": [{"item": "趋势", "reason": "synthetic", "evidence": []}],
             "watch": None, "read_seconds": 30,
             "trigger": {"written": False}, "vol_verdict": "confirm",
             "book_verdict": None, "q5_rr": 1.10, "q5_answered": True,
             "rej_x": 0.90, "vol1h_x": 0.40, "cap_blocked": False},
        ]
        packets = {
            "packet_TESTA_1795341600.json": {
                "coin": "TESTA", "direction": -1, "confirm_t": CONFIRM_T,
                "intervening": {"significant": {"level": 99.0, "rr": 0.36,
                                                "source": "synthetic",
                                                "t": "2026-11-22 09:00"},
                                "plus2": None, "plus6": None, "candidates": []},
                "volume": {"rej_x": 0.77, "vol1h_x": 1.03},
                "regime": {"regime": "震荡"}},
        }
        plan_rows = [
            "| TESTA | 做空 | 2026-11-22 09:30 | 2026-11-22 09:45 | synthetic | 100 | 101 | 98 | 1 | synthetic |",
        ]
        base_fixture(root, reader_rows, packets, plan_rows)
        rc, out = run_updater(root)
        check(rc == 0, f"更新器退出码 0（实得 {rc}）\n{out}")
        rows = read_ledger(root)
        new = [r for r in rows if r["coin"] in ("TESTA", "TESTB")]
        check(len(new) == 2, f"新增 TESTA/TESTB 各 1 行（实得 {len(new)} 行）")
        check(len(rows) == 8, f"账本共 8 行（6 行种子影子 + 2 行新平仓，实得 {len(rows)}）")
        a = [r for r in new if r["coin"] == "TESTA"][0]
        check(a["kind"] == "live" and a["direction"] == -1, "TESTA 行 kind=live、方向 -1")
        check(a["confirm_t"] == CONFIRM_T and a["entry_t"] == ENTRY_T,
              "TESTA confirm_t=entry_t−900")
        check(a["outcome"]["net_20x"] == 5.0 and a["outcome"]["reason"] == "take_profit",
              "TESTA 20x 口径不折算，net_20x=5.0")
        check(a["grade_reader"] == "强", "TESTA grade_reader 取自影子日志")
        check(a["q5_rr"] == 1.10, "TESTA q5_rr 取日志显式值 1.10（优先于 packet 的 0.36）")
        check(a["q5_answered"] is True, "TESTA q5_answered=True（日志显式）")
        check(a["rej_x"] == 0.90 and a["vol1h_x"] == 0.40,
              "TESTA rej_x/vol1h_x 取日志显式值（优先于 packet）")
        check(a["regime"] == "震荡", "TESTA regime 取自 packet")
        check(a["override"] == "趋势", "TESTA override 取自日志 overrides[0].item")
        check(a["cap_blocked"] is True,
              "TESTA cap_blocked=True（计划表有 09:30 更早触发行；日志里写的 False 不采用）")
        b = [r for r in new if r["coin"] == "TESTB"][0]
        check(b["outcome"]["net_20x"] == -2.0,
              "TESTB 1x 口径 x0.02，net_20x=-2.0（日志 -100.0）")
        check(b["grade_reader"] is None and "算不出" in (b["grade_reader_source"] or ""),
              "TESTB grade_reader=None + 算不出原因（无影子日志行）")
        check(b["q5_rr"] is None and b["rej_x"] is None and b["vol1h_x"] is None
              and b["regime"] is None, "TESTB 决策字段全 null（无日志行、无 packet）")
        check(b["q5_answered"] is None, "TESTB q5_answered=None")
        check(b["cap_blocked"] is False, "TESTB cap_blocked=False（计划表无该币触发行）")
        rc2, out2 = run_updater(root)
        check(rc2 == 0, "重跑退出码 0")
        check("新平仓建账：0 行" in out2, "重跑新平仓建账 0 行（幂等）")
        check(len(read_ledger(root)) == 8, "重跑后账本仍 8 行")


def scenario_2():
    print("场景 2：packet 兜底 + 方向守卫")
    with tempfile.TemporaryDirectory() as root:
        packets = {
            "packet_TESTB_1795341600.json": {
                "coin": "TESTB", "direction": 1, "confirm_t": CONFIRM_T,
                "intervening": {"significant": {"level": 49.0, "rr": 0.55,
                                                "source": "synthetic",
                                                "t": "2026-11-22 09:00"},
                                "plus2": None, "plus6": None, "candidates": []},
                "volume": {"rej_x": 0.44, "vol1h_x": 0.20},
                "regime": {"regime": "过渡"}},
            "packet_TESTA_1795341600.json": {
                "coin": "TESTA", "direction": 1, "confirm_t": CONFIRM_T,
                "intervening": {"significant": {"level": 99.0, "rr": 0.36,
                                                "source": "synthetic",
                                                "t": "2026-11-22 09:00"},
                                "plus2": None, "plus6": None, "candidates": []},
                "volume": {"rej_x": 0.77, "vol1h_x": 1.03},
                "regime": {"regime": "震荡"}},
        }
        base_fixture(root, [], packets, [])
        rc, out = run_updater(root)
        check(rc == 0, f"更新器退出码 0（实得 {rc}）\n{out}")
        rows = read_ledger(root)
        new = [r for r in rows if r["coin"] in ("TESTA", "TESTB")]
        check(len(new) == 2, "新增 TESTA/TESTB 各 1 行")
        b = [r for r in new if r["coin"] == "TESTB"][0]
        check(b["grade_reader"] is None, "TESTB grade_reader=None（无影子日志行）")
        check(b["q5_rr"] == 0.55, "TESTB q5_rr=0.55（packet 兜底，significant RR）")
        check(b["rej_x"] == 0.44 and b["vol1h_x"] == 0.20,
              "TESTB rej_x/vol1h_x 从 packet 兜底取到")
        check(b["regime"] == "过渡", "TESTB regime 从 packet 兜底取到")
        a = [r for r in new if r["coin"] == "TESTA"][0]
        check(a["q5_rr"] is None and a["rej_x"] is None and a["vol1h_x"] is None
              and a["regime"] is None,
              "TESTA packet 方向写错（+1 vs exit -1）→ 整份 packet 弃用，字段全 null")
        check(a["cap_blocked"] is False and b["cap_blocked"] is False,
              "两笔 cap_blocked 均为 False（计划表空）")


if __name__ == "__main__":
    scenario_1()
    scenario_2()
    print(f"断言全部通过（{N_ASSERT[0]} 个断言）。")
