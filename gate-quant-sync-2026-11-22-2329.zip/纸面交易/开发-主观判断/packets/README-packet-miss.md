# packet_miss 说明（2026-11-22 23:01 首 tick）

本 zip 的 packets 目录只含 8 个已读包（见下）。另有 7 笔做空候选没有对应文件，
不是漏打包——它们在影子首 tick 就丢了，特此说明。

## 7 笔 packet_miss

- 时间：2026-11-22 23:01 tick，读盘 23:12:50（北京时间）
- 币种与方向：BTC / ETH / SOL / DOGE / LINK / XRP / BNB，全部做空（direction -1）
- 确认根：confirm_t 1795358700（2026-11-22 22:45 北京时间确认的 15m 根）
- 原因：编排器撞文件名 bug——同币双向候选时，后建的包覆盖了先建的包；
  读盘时按编排器 stdout 列出的文件名（packets/packet_<COIN>_1795358700.json）
  去找文件，文件不存在，只能记 packet_miss，不编数、不写触发。
- 证据：`纸面交易/盘中主观判断-推理读盘.log` 里 7 行 packet_miss（本 zip 已含该日志）。

## 已修复，不可补建

- 修复：先改名保存首方向包（_d1 后缀），回归测试 test_shadow_prep_collision.py 16 断言通过；
  修复从 23:31 tick 起生效。
- 丢的 7 笔无法补建：盘口是决策时刻快照，事后没有当时的盘口数据；按设计记 packet_miss 保留。

## 本 zip 已含的 8 个已读包（23:01 tick）

- packet_ADA_1795358700.json（ADA 做多，唯一单向候选，故为平仓名）
- packet_BTC/ETH/SOL/DOGE/LINK/XRP/BNB_1795358700_d1.json（7 个做多包，首方向保存件）
- 读盘结果：8 读全部定级中/弱，无一写触发（见推理读盘日志）。
- 另：packet_ETH_1795313700_lessons.json 是演示包（packet 1.1，lessons 段实测），不是首 tick 的包。

## 未收入的包

- 23:16 tick 的 2 个已读包（ETH/BNB 做空，confirm 1795359600）与 22:49 等更早的包：
  只收首 tick 代表性包，其余不塞。
- 8 笔线下影子读盘的原型包（13:33 生成）：读盘结论已记在 shadow_reads_2026-11-22.md，
  包本身不重复收。
