#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
判断账更新器（原型）——学习回路的“平仓后写账 + 模式复核”一步。
见《判断层-学习回路-设计.md》§5。

只读引擎日志 + 推理读盘日志 + packet + 当日计划文件，写两个文件：
  1. 判断账.jsonl（每行一笔决策：live 已平仓 / 被拦影子 / 未写影子）；
  2. 判断教训-feed.json（模式重复出现时，observation → candidate 晋升；
     只改 status + history，不删记录；规则晋升不在本脚本里，在每日结算复核）。
  3. 判断教训-feed.md（feed 的人类可读镜像，每次运行后重生成）。

红线：
  - 不碰引擎、不碰 cron、不碰计划文件、不碰 v1.2 文件、不碰分系统；
  - outcome 一律取自引擎日志（live）或已发表的研究影子数（shadow，须注明来源），
    绝不编数；算不出的字段写 null + reason，不猜；
  - 决策侧字段（分级、Q5 RR、量数）来自两处：推理读盘日志（reader 时代，首选）
    或 SEED 表（v1.2 时代的手工补录，每值注明来源文档；仅用于 11-21/11-22 的
    初始建账，之后不再加新 seed 行——新交易一律从 reader log 取）。
  - 新平仓建账（2026-11-22 补）：引擎日志里主系统 exit 不在账本里即建 live 行，
    决策侧字段按 confirm_t=entry_t−900 联结影子日志 + packet，cap_blocked 从
    当日计划补充触发表推导；接不到的记 null + reason。
"""
import argparse
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
PAPER_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易")
ENGINE_DIR = os.path.expanduser(
    "~/workspace/goals/gate-intraday-perpetual-quant-strategy/hidden_files")
DEFAULT_LEDGER = os.path.join(PAPER_DIR, "判断账.jsonl")
DEFAULT_FEED = os.path.join(PAPER_DIR, "判断教训-feed.json")
DEFAULT_READER_LOG = os.path.join(PAPER_DIR, "盘中主观判断-推理读盘.log")
DEFAULT_PACKET_DIR = os.path.join(HERE, "packets")
DEFAULT_PLAN_DIR = PAPER_DIR

# ------------------------------------------------------------------ seed 表
# v1.2 时代的 11-21/11-22 决策侧字段手工补录。每个值都有来源文档；
# “算不出”一律记 None（不猜）。20x 净值：11-21 四笔 1x 口径按 x0.02 折算。
# 字段：coin, direction, confirm_t(UTC秒), entry_t(UTC秒，影子行无入场则 None),
#       kind(live/blocked_shadow/no_shadow),
#       grade_reader + grade_reader_source（读者自己的定级）, grade_v2 + grade_v2_source（v2 事后重分级，仅种子期）,
#       q5_rr, q5_rr_basis, rej_x, vol1h_x, regime, override, cap_blocked,
#       shadow_net_20x, shadow_reason, shadow_source, note
SEED = [
    {"coin": "DOGE", "direction": -1, "confirm_t": 1795223700, "entry_t": 1795224600,
     "kind": "live", "grade_reader": "强", "grade_reader_source": "影子读盘 #1",
     "grade_v2": "强", "grade_v2_source": "v2 附录 A #1",
     "q5_rr": 1.32, "q5_rr_basis": "最近显著结构 0.05348；锚点 0.05336 RR 1.52（跳更远后有回答）",
     "rej_x": 0.70, "vol1h_x": 0.58, "regime": "瀑布", "override": None,
     "cap_blocked": False, "note": "Q5 有回答（跳更远目标）"},
    {"coin": "ADA", "direction": -1, "confirm_t": 1795228200, "entry_t": 1795229100,
     "kind": "live", "grade_reader": None, "grade_reader_source": "算不出：读者没读过这笔（不在 8 笔影子读盘里）",
     "grade_v2": "强", "grade_v2_source": "v2 附录 A #2（事后重分级）",
     "q5_rr": None, "q5_rr_basis": "无介入结构（v2 附录 A #2）",
     "rej_x": None, "vol1h_x": None, "regime": "瀑布", "override": None,
     "cap_blocked": False, "note": "量数未提取，算不出"},
    {"coin": "ETH", "direction": 1, "confirm_t": 1795241700, "entry_t": 1795242600,
     "kind": "live", "grade_reader": "强", "grade_reader_source": "影子读盘 #2",
     "grade_v2": "强", "grade_v2_source": "v2 附录 A #3",
     "q5_rr": None, "q5_rr_basis": "止盈前无显著结构阻挡（影子读盘 #2 Q5）",
     "rej_x": 1.32, "vol1h_x": 0.67, "regime": "瀑布", "override": "趋势",
     "cap_blocked": False, "note": "带 1 次推翻（趋势项）"},
    {"coin": "BNB", "direction": -1, "confirm_t": 1795255200, "entry_t": 1795256100,
     "kind": "live", "grade_reader": None, "grade_reader_source": "算不出：读者没读过这笔",
     "grade_v2": "强", "grade_v2_source": "v2 附录 A #4（事后重分级）",
     "q5_rr": None, "q5_rr_basis": "无介入结构（v2 附录 A #4）",
     "rej_x": None, "vol1h_x": None, "regime": "瀑布", "override": None,
     "cap_blocked": False, "note": "量数未提取，算不出；v2 也会写的亏单"},
    {"coin": "BTC", "direction": -1, "confirm_t": 1795298400, "entry_t": 1795299300,
     "kind": "live", "grade_reader": None, "grade_reader_source": "算不出：读者没读过这笔",
     "grade_v2": "中", "grade_v2_source": "v2 附录 A #5（事后重分级）",
     "q5_rr": None, "q5_rr_basis": "算不出：没有任何来源算过这笔的介入结构 RR",
     "rej_x": 0.63, "vol1h_x": 0.13, "regime": "过渡", "override": None,
     "cap_blocked": False, "note": "量死寂，基本没动即被 23:00 强平"},
    {"coin": "BNB", "direction": -1, "confirm_t": 1795312800, "entry_t": 1795313700,
     "kind": "live", "grade_reader": "中", "grade_reader_source": "影子读盘 #3",
     "grade_v2": "中", "grade_v2_source": "v2 附录 A #6",
     "q5_rr": 0.82, "q5_rr_basis": "计划 ATR（v2 附录 B）；live ATR 口径 0.87（影子读盘 #3）",
     "rej_x": 0.68, "vol1h_x": 0.24, "regime": "过渡", "override": None,
     "cap_blocked": False, "note": "Q5 未回答（锚点是单根影线极值，质量弱）"},
    {"coin": "ETH", "direction": -1, "confirm_t": 1795313700, "entry_t": 1795314600,
     "kind": "live", "grade_reader": "强", "grade_reader_source": "影子读盘 #4",
     "grade_v2": "中", "grade_v2_source": "v2 §2.1（事后重判；与读者定级分歧，见设计 §8）",
     "q5_rr": 1.13, "q5_rr_basis": "计划 ATR（v2 附录 B）；live ATR 口径 1.17（影子读盘 #4）",
     "rej_x": 1.65, "vol1h_x": 0.24, "regime": "震荡", "override": None,
     "cap_blocked": False,
     "note": "Q5 回答事后证错：称 1647.38 不是新鲜支撑，价格停在 1647.23（离它 0.15 点）"},
    # --- 被拦 / 未写（影子，无引擎 outcome，影子数取自研究文件）---
    {"coin": "DOGE", "direction": -1, "confirm_t": 1795228200, "entry_t": None,
     "kind": "blocked_shadow", "grade_reader": None, "grade_reader_source": None,
     "grade_v2": None, "grade_v2_source": None,
     "q5_rr": None, "q5_rr_basis": None, "rej_x": None, "vol1h_x": None,
     "regime": "瀑布", "override": None, "cap_blocked": True,
     "cap_second_stronger": True,
     "shadow_net_20x": 4.34, "shadow_reason": "shadow take_profit 03:30 UTC",
     "shadow_source": "《规则太死板-研究.md》（确认 1.55×，与第 1 条不同位子）",
     "note": "第 2 条被上限拦掉；确认 1.55× 远强于第 1 条 0.52×"},
    {"coin": "ETH", "direction": -1, "confirm_t": 1795298400, "entry_t": None,
     "kind": "blocked_shadow", "grade_reader": None, "grade_reader_source": None,
     "grade_v2": None, "grade_v2_source": None,
     "q5_rr": None, "q5_rr_basis": None, "rej_x": None, "vol1h_x": None,
     "regime": "过渡", "override": None, "cap_blocked": True,
     "cap_second_stronger": False,
     "shadow_net_20x": -3.0, "shadow_reason": "shadow stop_loss 09:45 UTC 最高 1723.51",
     "shadow_source": "《规则太死板-研究.md》订正值（约 -3.0；11-21 计划 ATR 20.48）",
     "note": "06:00 北京时间的判断，ETH 当日已有补充触发行被拦；影子约 -3.0（约数，取 -3.0）"},
    {"coin": "LINK", "direction": 1, "confirm_t": 1795320000, "entry_t": None,
     "kind": "blocked_shadow", "grade_reader": "中", "grade_reader_source": "影子读盘 #5",
     "grade_v2": "中", "grade_v2_source": "v2 §2.3",
     "q5_rr": None, "q5_rr_basis": "锚点 8.784 RR 1.62 在 3 倍内（影子读盘 #5 Q5）",
     "rej_x": 1.38, "vol1h_x": None, "regime": "震荡", "override": None,
     "cap_blocked": False,
     "shadow_net_20x": 6.21, "shadow_reason": "shadow take_profit 10:45 UTC",
     "shadow_source": "影子读盘 #5 + 《规则太死板-研究.md》",
     "note": "被第 6 项拦下（早上计划 LINK 空已 stale_expired）；位子 1 次测试 + 确认 0.57× 未达震荡线"},
    {"coin": "ETH", "direction": 1, "confirm_t": 1795329000, "entry_t": None,
     "kind": "no_shadow", "grade_reader": "中", "grade_reader_source": "影子读盘 #6",
     "grade_v2": "中", "grade_v2_source": "v2 §2.2",
     "q5_rr": None, "q5_rr_basis": "锚点 1712.36 RR 1.82 在 3 倍内（影子读盘 #6 Q5）",
     "rej_x": 0.57, "vol1h_x": None, "regime": "震荡", "override": None,
     "cap_blocked": True,
     "shadow_net_20x": 6.29, "shadow_reason": "shadow take_profit 09:45 UTC",
     "shadow_source": "影子读盘 #6 + 《主观判断-完善与延迟-研究.md》",
     "note": "仅强度不通过（确认 0.37×）；上限也会拦（名额被 02:31 亏单占了）"},
    {"coin": "XRP", "direction": -1, "confirm_t": 1795284000, "entry_t": None,
     "kind": "no_shadow", "grade_reader": "弱", "grade_reader_source": "影子读盘 #7",
     "grade_v2": None, "grade_v2_source": None,
     "q5_rr": None, "q5_rr_basis": "无答案：入场到止盈之间无结构锚点（影子读盘 #7 Q5）",
     "rej_x": 0.52, "vol1h_x": None, "regime": "过渡", "override": None,
     "cap_blocked": False,
     "shadow_net_20x": 0.45, "shadow_reason": "shadow（延迟研究）",
     "shadow_source": "影子读盘 #7 + 《主观判断-完善与延迟-研究.md》",
     "note": "1h 明确上行 + Q5 无答案，定弱"},
    {"coin": "BTC", "direction": -1, "confirm_t": 1795296600, "entry_t": None,
     "kind": "no_shadow", "grade_reader": "中", "grade_reader_source": "影子读盘 #8",
     "grade_v2": None, "grade_v2_source": None,
     "q5_rr": None, "q5_rr_basis": "锚点 59356.8 RR 1.66 在 3 倍内（影子读盘 #8 Q5）",
     "rej_x": 0.64, "vol1h_x": 0.12, "regime": "瀑布", "override": None,
     "cap_blocked": False,
     "shadow_net_20x": 0.33, "shadow_reason": "shadow（延迟研究）",
     "shadow_source": "影子读盘 #8 + 《主观判断-完善与延迟-研究.md》",
     "note": "仅强度不通过（确认 0.14× < 瀑布线 0.3×）；量死寂 + 背离"},
]


def fmt_ts(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")


def read_engine_exits(dates, engine_dir=ENGINE_DIR):
    """从引擎日志读主系统（subj 层）平仓事件。返回 {(coin, entry_t): trade}。"""
    out = {}
    for d in dates:
        path = os.path.join(engine_dir, f"paper_engine_{d}.log")
        if not os.path.exists(path):
            print(f"  [跳过] 引擎日志缺失：{path}")
            continue
        for line in open(path, encoding="utf-8"):
            try:
                ev = json.loads(line)
            except (ValueError, TypeError):
                continue
            if ev.get("type") != "exit":
                continue
            t = ev.get("trade") or {}
            if t.get("layer") != "subj":
                continue  # 分系统（sub 层）不进主系统判断账
            out[(t["coin"], t["entry_t"])] = {
                "exit_ts": ev.get("ts"), "exit": t.get("exit"),
                "exit_ref": t.get("exit_ref"), "reason": t.get("reason"),
                "direction": t.get("direction"),
                "gross": t.get("gross"), "cost": t.get("cost"),
                "funding_cost": t.get("funding_cost", 0.0),
                "net": t.get("net"), "entry": t.get("entry"),
                "entry_ref": t.get("entry_ref"),
                "fee_entry": t.get("fee_entry"),
            }
    return out


def load_ledger(path):
    rows = []
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def net_20x_from_exit(ex):
    """引擎日志净值 → 20x 口径。口径按日志自身的 fee_entry 判，不按日期猜：
    fee_entry≈0.15 → 日志已是 20x 口径，不折算；≈7.5 → 1x 口径，x0.02。
    判不出（或 net 本身缺失）返回 None。"""
    net_log = ex.get("net")
    if net_log is None:
        return None
    fee_entry = ex.get("fee_entry")
    if fee_entry is not None and abs(fee_entry - 0.15) < 0.01:
        return net_log
    if fee_entry is not None and abs(fee_entry - 7.5) < 0.01:
        return round(net_log * 0.02, 4)
    return None


def read_reader_log(path):
    """读推理读盘日志（JSONL），返回 {(coin, confirm_t): row}，只取 event=='read'。
    文件不存在返回 {}（调用方在 note 里写清）。同键多行取最后一行。"""
    out = {}
    if not path or not os.path.exists(path):
        return out
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        try:
            r = json.loads(line)
        except (ValueError, TypeError):
            continue
        if r.get("event") != "read":
            continue
        try:
            key = (r["coin"], int(r["confirm_t"]))
        except (KeyError, TypeError, ValueError):
            continue
        out[key] = r
    return out


def resolve_packet_path(packet_ref, packet_dir):
    """packet 引用（绝对路径，或相对路径如 packets/packet_ETH_....json）→ 绝对路径。
    相对路径先按 packet_dir/<basename> 找，再按 HERE/<ref>、PAPER_DIR/<ref> 找；
    找不到返回 None。"""
    if not packet_ref:
        return None
    if os.path.isabs(packet_ref) and os.path.exists(packet_ref):
        return packet_ref
    cands = [os.path.join(packet_dir, os.path.basename(packet_ref)),
             os.path.join(HERE, packet_ref),
             os.path.join(PAPER_DIR, packet_ref)]
    for c in cands:
        if os.path.exists(c):
            return c
    return None


def packet_fields(packet):
    """从 packet 取决策侧测量值。返回 (q5_rr, q5_rr_basis, rej_x, vol1h_x, regime)，
    取不到的记 None（basis 里写清原因）。q5_rr 取 intervening.significant 的 rr。"""
    if not isinstance(packet, dict):
        return None, "packet 读不到", None, None, None
    iv = packet.get("intervening") or {}
    sig = iv.get("significant") if isinstance(iv, dict) else None
    if isinstance(sig, dict) and isinstance(sig.get("rr"), (int, float)):
        q5_rr = sig["rr"]
        q5_rr_basis = (f"显著结构 {sig.get('level')}（{sig.get('source')}，{sig.get('t')}）"
                       f"RR {sig['rr']}（packet intervening.significant）")
    elif sig is None:
        q5_rr, q5_rr_basis = None, "无显著结构（packet intervening.significant 为空）"
    else:
        q5_rr, q5_rr_basis = None, "packet significant 无 rr 数字"
    vol = packet.get("volume") or {}
    rej_x = vol.get("rej_x") if isinstance(vol.get("rej_x"), (int, float)) else None
    vol1h_x = vol.get("vol1h_x") if isinstance(vol.get("vol1h_x"), (int, float)) else None
    reg = packet.get("regime") or {}
    regime = reg.get("regime") if isinstance(reg, dict) else None
    return q5_rr, q5_rr_basis, rej_x, vol1h_x, regime


def cap_blocked_from_plan(coin, confirm_t, plan_dir):
    """从当日计划文件补充触发表推导 cap：该币在该 UTC 日、该确认根之前是否已有
    补充触发行（与机械层共用单币每天 1 条上限）。有 → True；无 → False；
    计划文件缺失或读不到 → None（推导不出）。表头/分隔行（第 3 列不是日期）自动跳过。"""
    date_str = datetime.fromtimestamp(confirm_t, tz=timezone.utc).strftime("%Y-%m-%d")
    path = os.path.join(plan_dir, f"{date_str}.md")
    if not os.path.exists(path):
        return None
    try:
        text = open(path, encoding="utf-8").read()
    except OSError:
        return None
    in_section = False
    earlier = False
    for line in text.splitlines():
        if line.startswith("## "):
            in_section = line.startswith("## 盘中补充触发")
            continue
        if not in_section or not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 3:
            continue
        try:
            t = int(datetime.strptime(cells[2], "%Y-%m-%d %H:%M").replace(
                tzinfo=timezone.utc).timestamp())
        except (ValueError, TypeError):
            continue
        if cells[0] == coin and t < confirm_t:
            earlier = True
    return earlier


def build_live_row_from_exit(coin, entry_t, ex, reader_rows, packet_dir, plan_dir):
    """一笔新平仓 → 判断账 live 行。outcome 取自引擎日志；决策侧字段联结影子日志 +
    packet + 计划表，接不到的记 None + reason（写进 note），绝不猜。
    联结键 confirm_t = entry_t − 900（entry_t 是入场根开盘，确认根是它前一根）。
    q5_rr 优先取影子日志显式字段，否则取 packet significant 的 rr；
    cap_blocked 一律以计划表推导为准（机械事实），日志里的同名字段只供读者自查。"""
    confirm_t = entry_t - 900
    direction = ex.get("direction")
    r = reader_rows.get((coin, confirm_t))
    packet = None
    packet_path = None
    if r is not None:
        packet_path = resolve_packet_path(r.get("packet"), packet_dir)
    if packet_path is None:
        # 无 reader 行时，按约定文件名兜底找 packet（须 coin/direction/confirm_t 全对上）
        guess = os.path.join(packet_dir, f"packet_{coin}_{confirm_t}.json")
        if os.path.exists(guess):
            packet_path = guess
    if packet_path is not None:
        try:
            packet = json.load(open(packet_path, encoding="utf-8"))
        except (ValueError, TypeError, OSError):
            packet = None
        if isinstance(packet, dict) and (
                packet.get("coin") != coin or packet.get("direction") != direction
                or packet.get("confirm_t") != confirm_t):
            packet = None  # 方向/确认根对不上，不用这份 packet
    pq5_rr, pq5_basis, prej_x, pvol1h_x, pregime = packet_fields(packet)
    if r is not None:
        grade_reader = r.get("grade")
        grade_reader_source = f"推理读盘日志 {r.get('ts')} + packet {r.get('packet')}"
        q5_rr = r.get("q5_rr") if isinstance(r.get("q5_rr"), (int, float)) else pq5_rr
        q5_rr_basis = ("推理读盘日志显式字段 q5_rr"
                       if isinstance(r.get("q5_rr"), (int, float)) else pq5_basis)
        q5_answered = r.get("q5_answered") if r.get("q5_answered") in (True, False) else None
        rej_x = r.get("rej_x") if isinstance(r.get("rej_x"), (int, float)) else prej_x
        vol1h_x = r.get("vol1h_x") if isinstance(r.get("vol1h_x"), (int, float)) else pvol1h_x
        regime = pregime
        overrides = r.get("overrides") or []
        override = "+".join(o.get("item") for o in overrides
                            if isinstance(o, dict) and o.get("item")) or None
        join_bits = [f"reader 行已联结（grade {grade_reader}）"]
    else:
        grade_reader = None
        grade_reader_source = "算不出：推理读盘日志里没有该币该确认根的 read 行"
        q5_rr, q5_rr_basis = pq5_rr, pq5_basis
        q5_answered = None
        rej_x, vol1h_x, regime = prej_x, pvol1h_x, pregime
        override = None
        join_bits = ["reader 行未联结（无该币该确认根的 read 行）"]
    if packet is not None and r is None:
        join_bits.append("packet 按约定文件名兜底找到")
    elif packet is None:
        join_bits.append("packet 未找到")
    cap = cap_blocked_from_plan(coin, confirm_t, plan_dir)
    join_bits.append("cap_blocked=" + ("True" if cap is True else
                                        "False" if cap is False else "null（计划表读不到）"))
    if q5_answered is None:
        join_bits.append("q5_answered 未显式记")
    net_20x = net_20x_from_exit(ex)
    date_str = datetime.fromtimestamp(entry_t, tz=timezone.utc).strftime("%Y-%m-%d")
    return {"coin": coin, "direction": direction, "confirm_t": confirm_t, "entry_t": entry_t,
            "kind": "live", "grade_reader": grade_reader,
            "grade_reader_source": grade_reader_source,
            "grade_v2": None, "grade_v2_source": "reader 时代不做 v2 事后重分级",
            "q5_rr": q5_rr, "q5_rr_basis": q5_rr_basis, "q5_answered": q5_answered,
            "rej_x": rej_x, "vol1h_x": vol1h_x, "regime": regime, "override": override,
            "cap_blocked": cap,
            "decision_source": "新平仓自动建账：引擎日志 + 推理读盘日志 + packet + 计划文件；接不到的字段记 null + reason",
            "note": "；".join(join_bits),
            "outcome": {"type": "live", "reason": ex.get("reason"),
                        "net_log_caliber": ex.get("net"), "net_20x": net_20x,
                        "exit_ts": ex.get("exit_ts"),
                        "source": f"引擎日志 paper_engine_{date_str}.log"},
            "ledger_ts_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}


def pattern_hits(row):
    """一笔账行命中哪些教训模式（返回 lesson id 列表）。只做字段匹配，不做判断。"""
    hits = []
    if row["kind"] == "live" and row.get("q5_rr") is not None and row["q5_rr"] < 1.5 \
            and row.get("q5_answered") is False \
            and row.get("outcome", {}).get("net_20x") is not None \
            and row["outcome"]["net_20x"] < 0:
        hits.append("L01")
    if row["kind"] == "live" and row.get("rej_x") is not None and row["rej_x"] < 0.8 \
            and row.get("vol1h_x") is not None and row["vol1h_x"] < 0.3:
        hits.append("L02")
    if row.get("cap_blocked") and row.get("cap_second_stronger") is True:
        hits.append("L03")
    return hits


def render_feed_md(feed):
    """feed JSON → 人类可读镜像（只读 feed，不改数字）。"""
    lines = ["# 判断教训 feed（人类可读镜像）",
             "",
             "> 由 update_judgment_ledger.py 从判断教训-feed.json 重生成；不要手工改本文件，改 JSON。",
             "> 状态：observation（观察，1 笔，只记录）→ candidate（候选，模式重复，值得多注意）→ rule（规则，已学到的方法，带着理解去用）→ revoked（撤销）/ struck（证伪）。教训是过去的经验，不是封顶：status 只表示出现了多少次，不表示它能强制改分级。",
             f"> 更新时间：{feed.get('updated_at_utc')}；规则 {feed['status_counts'].get('rule', 0)} 条 / "
             f"候选 {feed['status_counts'].get('candidate', 0)} 条 / 观察 {feed['status_counts'].get('observation', 0)} 条 / "
             f"撤销 {feed['status_counts'].get('revoked', 0)} 条 / 证伪 {feed['status_counts'].get('struck', 0)} 条。",
             "",
             "## 晋升阈值（见设计文档 §6）",
             "",
             "- 观察：n=1 笔交易（或 1 对拦/写对照），只记录，不改方法。",
             "- 候选：同一模式在 n≥2 笔交易里重复，或 1 笔 + 每日结算复核确认是结构性事实。",
             "- 规则：n≥3 笔，组净负（禁做类）或胜率≥40% 且净正（要做类），样本跨 ≥2 个交易日，候选存续 ≥24 小时。",
             "- 影子/被拦决策按半权计：2 笔影子 = 1 笔 live 等价量。",
             ""]
    for L in feed["lessons"]:
        g = L.get("group_so_far", {})
        lines += [f"## {L['id']} [{L['status']}] {L['title']}",
                  "",
                  f"- 挂接：{L.get('attaches_to')}；模式：{L['pattern']['condition']}",
                  f"- 组内：n={g.get('n') or g.get('n_pairs') or g.get('n_shadow') or '?'}，"
                  f"净值={g.get('net_20x') if g.get('net_20x') is not None else g.get('net_shadow_20x', '?')}（20x 口径）",
                  f"- 反思：{L.get('reflection', '')}",
                  f"- 证伪：{L['falsification']}",
                  ""]
        for e in L.get("evidence", []):
            lines.append(f"- 证据：{e.get('trade')}——净值 {e.get('outcome_net_20x', e.get('outcome_net_20x_shadow', '?'))}，"
                         f"来源：{e.get('source')}")
        lines.append("")
        for h in L.get("history", []):
            lines.append(f"- {h['at_utc']}：{h['event']}")
        lines.append("")
    cases = feed.get("cases", []) or []
    if cases:
        lines += ["## 平仓复盘案例（case，不是规则；见设计文档 §13）", ""]
        for c in cases:
            lines += [f"### {c.get('id')} {c.get('trade')}",
                      "",
                      f"- 平仓：{c.get('closed')}，净值 {c.get('net_20x')}（20x 口径）",
                      f"- 当时看错了哪一点：{c.get('misread')}",
                      f"- 以后读盘多看哪：{c.get('watch_next')}",
                      f"- 印证/反驳的教训：{c.get('related_lesson')}",
                      f"- 写于：{c.get('created_utc')}",
                      ""]
    pend = feed.get("pending_excluded") or []
    if pend:
        lines += ["## 未平仓（不进统计）", ""]
        for p in pend:
            lines.append(f"- {p['trade']}：{p['status']}")
        lines.append("")
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dates", nargs="*", default=["2026-11-21", "2026-11-22"],
                    help="要扫的引擎日志日期（默认 11-21/11-22 建账）")
    ap.add_argument("--ledger", default=DEFAULT_LEDGER)
    ap.add_argument("--feed", default=DEFAULT_FEED)
    ap.add_argument("--engine-dir", default=ENGINE_DIR)
    ap.add_argument("--reader-log", default=DEFAULT_READER_LOG)
    ap.add_argument("--packet-dir", default=DEFAULT_PACKET_DIR)
    ap.add_argument("--plan-dir", default=DEFAULT_PLAN_DIR)
    ap.add_argument("--dry-run", action="store_true", help="只打印，不写文件")
    args = ap.parse_args()

    exits = read_engine_exits(args.dates, args.engine_dir)
    print(f"引擎日志主系统平仓事件：{len(exits)} 笔")
    for k, v in sorted(exits.items()):
        print(f"  {k}: {v['reason']} net={v['net']}（日志口径）")
    rows = load_ledger(args.ledger)
    have = {(r["coin"], r.get("entry_t"), r["kind"]) for r in rows}
    new_rows = []
    for s in SEED:
        key = (s["coin"], s.get("entry_t"), s["kind"])
        if key in have:
            continue
        row = dict(s)
        row["decision_source"] = "seed:见各字段来源（v1.2 时代手工补录）"
        if s["kind"] == "live":
            ex = exits.get((s["coin"], s["entry_t"]))
            if ex is None:
                print(f"  [警告] seed 行 {s['coin']} {fmt_ts(s['confirm_t'])} 在引擎日志里没有平仓事件，跳过")
                continue
            # 20x 折算：口径按日志自身的 fee_entry 判，不按日期猜——
            # 11-21 的 BTC 一笔在日志里已是 20x 口径（fee_entry 0.15），
            # 其余四笔是 1x 口径（fee_entry 7.5），须 x0.02。
            # 直算值与 11-21 逐笔验证（ADA 4.4639 / BNB -2.3403）差 0.0001，
            # 是 4 位小数舍入，不影响任何结论；账本以直算值为准。
            net_log = ex["net"]
            net_20x = net_20x_from_exit(ex)
            if net_20x is None and net_log is not None:
                print(f"  [警告] {s['coin']} fee_entry={ex.get('fee_entry')}，口径判不出，net_20x 记 null")
            date_str = datetime.fromtimestamp(s["entry_t"], tz=timezone.utc).strftime("%Y-%m-%d")
            row["outcome"] = {"type": "live", "reason": ex["reason"],
                              "net_log_caliber": net_log,
                              "net_20x": net_20x,
                              "exit_ts": ex["exit_ts"],
                              "source": f"引擎日志 paper_engine_{date_str}.log"}
            row["q5_answered"] = None
            # Q5 是否有回答：按 seed 的 note 判定（DOGE 跳更远=有回答；ETH/BNB=无有效回答）
            if s["coin"] == "DOGE":
                row["q5_answered"] = True
            elif s["coin"] in ("ETH", "BNB") and s.get("q5_rr") is not None and s["confirm_t"] in (1795313700, 1795312800):
                row["q5_answered"] = False
        else:
            row["outcome"] = {"type": "shadow", "reason": s["shadow_reason"],
                              "net_20x": s["shadow_net_20x"],
                              "source": s["shadow_source"]}
            row["q5_answered"] = None
        row["ledger_ts_utc"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        new_rows.append(row)
    # 新平仓建账（2026-11-22 补）：引擎日志里主系统 exit 不在账本里即建 live 行。
    # 种子行已在上面处理过，这里只补种子之外的平仓；幂等（重跑新增 0 行）。
    reader_rows = read_reader_log(args.reader_log)
    have_keys = {(r["coin"], r.get("entry_t"), r["kind"]) for r in rows + new_rows}
    new_exit_rows = []
    for (coin, entry_t), ex in sorted(exits.items()):
        if (coin, entry_t, "live") in have_keys:
            continue
        row = build_live_row_from_exit(coin, entry_t, ex, reader_rows,
                                       args.packet_dir, args.plan_dir)
        new_exit_rows.append(row)
        have_keys.add((coin, entry_t, "live"))
    new_rows.extend(new_exit_rows)
    print(f"新平仓建账：{len(new_exit_rows)} 行")
    for r in new_exit_rows:
        print(f"  {r['coin']} {fmt_ts(r['confirm_t'])} live grade_reader={r.get('grade_reader')} "
              f"net_20x={r['outcome']['net_20x']} q5_rr={r.get('q5_rr')} "
              f"cap_blocked={r.get('cap_blocked')}")
    print(f"新增账行：{len(new_rows)} 行")
    for r in new_rows:
        print(f"  {r['coin']} {fmt_ts(r['confirm_t'])} {r['kind']} grade_reader={r.get('grade_reader')} grade_v2={r.get('grade_v2')} "
              f"net_20x={r['outcome']['net_20x']} q5_rr={r.get('q5_rr')}")

    # 模式复核：新行命中哪些模式（只报告晋升建议，不自动改规则）
    feed = json.load(open(args.feed, encoding="utf-8")) if os.path.exists(args.feed) else None
    if feed is not None:
        by_id = {L["id"]: L for L in feed["lessons"]}
        hits_count = {}
        for r in rows + new_rows:
            for lid in pattern_hits(r):
                hits_count[lid] = hits_count.get(lid, 0) + 1
        print("模式命中计数（live 行）：", hits_count)
        for lid, n in hits_count.items():
            L = by_id.get(lid)
            if L and L["status"] == "observation" and n >= 2:
                print(f"  [晋升建议] {lid} 已命中 {n} 笔，建议 observation → candidate（须人工确认后改 feed）")

    if args.dry_run:
        print("[dry-run] 不写文件")
        return 0
    all_rows = rows + new_rows
    with open(args.ledger, "w", encoding="utf-8") as f:
        for r in all_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"写判断账：{args.ledger}（共 {len(all_rows)} 行）")
    if feed is not None:
        md = render_feed_md(feed)
        md_path = args.feed.replace(".json", ".md")
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"重生成 feed 镜像：{md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
