#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
推理读盘影子——每 tick 的编排器（judge_shadow_prep.py）
====================================================
只做编排，不做决定。流程（与 judge_tick.py 的前两步同口径）：
  1. 只在交易日 00:00–23:00 UTC 内跑；之外打印 skip_eod 退出。
  2. 拉 Gate 15m/1h，截断至最近已收盘根，跑轻量预检（judge_precheck）。
  3. 每个候选调 judge_packet.build_packet 打事实包（--book fetch，
     决策时刻盘口），写进 开发-主观判断/packets/。
输出：stdout 一行 JSON：
  {"event": "packets", "time_utc": ..., "packets": [{coin, direction,
    confirm_t, path, write_by_utc}, ...]}
  无候选 → {"event": "no_candidate"}；23:00 后 → {"event": "skip_eod"}。
  某币拉数/打包失败 → stderr 一行 packet_fail/fetch_fail，不编数。
绝不写触发、不碰计划文件原文、不碰引擎、不调用 decide()。
"""
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import judge_precheck as jp  # noqa: E402
import judge_read as jr  # noqa: E402
import judge_packet as jpk  # noqa: E402

COINS = jp.COINS
PACKETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "packets")
PLAN_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易")


def main():
    now = datetime.now(timezone.utc)
    if now.hour >= 23:
        print(json.dumps({"event": "skip_eod"}, ensure_ascii=False))
        return 0
    now_floor15 = int(now.timestamp()) // 900 * 900
    d = now.strftime("%Y-%m-%d")
    plan = os.path.join(PLAN_DIR, f"{d}.md")
    plan_arg = plan if os.path.exists(plan) else None
    out_packets = []
    seen = {}  # (coin, confirm_t) -> 首个方向；同币同确认根双向候选时文件名会撞
    for coin in COINS:
        try:
            bars15 = jp.fetch_gate_15m(f"{coin}_USDT")
            bars1h = jr.fetch_gate_1h(f"{coin}_USDT")
        except Exception as e:
            print(json.dumps({"event": "fetch_fail", "coin": coin,
                              "error": str(e)}, ensure_ascii=False),
                  file=sys.stderr)
            continue
        bars15 = [b for b in bars15 if b["t"] + 900 <= now_floor15]
        bars1h = [b for b in bars1h if b["t"] + 3600 <= now_floor15]
        if not bars15:
            continue
        for cand in jp.precheck_coin(bars15, coin):
            confirm_t = bars15[-1]["t"]
            key = (coin, confirm_t)
            if key in seen:
                # 双向候选撞文件名：build_packet 不含方向，写死到
                # packet_<COIN>_<confirm_t>.json。先把已建好的首方向包
                # 改名保存，再建第二方向，否则首方向的包会被覆盖丢失、
                # stdout 列出的路径也不存在。2026-11-22 23:01 tick 七笔
                # 做空 packet_miss 就是这个 bug（precheck 先报 -1 后报 +1，
                # 做空是首方向，全丢了）。
                first_dir = seen[key]
                first_path = os.path.join(
                    PACKETS_DIR, f"packet_{coin}_{confirm_t}.json")
                if os.path.exists(first_path):
                    first_alt = first_path.replace(
                        ".json", f"_d{first_dir}.json")
                    os.replace(first_path, first_alt)
                    for p in out_packets:
                        if (p["coin"] == coin and p["confirm_t"] == confirm_t
                                and p["path"] == first_path):
                            p["path"] = first_alt
            try:
                packet, path = jpk.build_packet(
                    coin, cand["direction"], confirm_t,
                    plan_path=plan_arg, book_mode="fetch",
                    out_dir=PACKETS_DIR)
            except Exception as e:
                print(json.dumps({"event": "packet_fail", "coin": coin,
                                  "direction": cand["direction"],
                                  "error": str(e)}, ensure_ascii=False),
                      file=sys.stderr)
                continue
            # 同币同确认根出现两个方向时，build_packet 的文件名会撞
            # （packet_<COIN>_<confirm_t>.json 不含方向）；第二个改名。
            if key in seen:
                alt = path.replace(".json", f"_d{cand['direction']}.json")
                os.replace(path, alt)
                path = alt
            seen[key] = cand["direction"]
            out_packets.append({"coin": coin, "direction": cand["direction"],
                                "confirm_t": confirm_t, "path": path,
                                "write_by_utc": packet["write_by_utc"]})
    if not out_packets:
        print(json.dumps({"event": "no_candidate",
                          "time_utc": now.strftime("%H:%M")},
                         ensure_ascii=False))
    else:
        print(json.dumps({"event": "packets", "time_utc": now.strftime("%H:%M"),
                          "packets": out_packets}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
