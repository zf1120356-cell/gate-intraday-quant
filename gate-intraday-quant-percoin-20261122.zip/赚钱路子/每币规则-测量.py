#!/usr/bin/env python3
"""Per-coin DESCRIPTIVE measurement only (no signals, no trades, no P&L, no backtest).
Reads existing Gate candle caches in ~/workspace/赚钱路子/data/ and prints per-coin
volatility / session / structure-tendency statistics.
"""
import csv, json, math, os
from datetime import datetime, timezone

DATA = os.path.expanduser("~/workspace/赚钱路子/data")
COINS = ["BTC", "ETH", "SOL", "DOGE", "LINK", "XRP", "BNB", "ADA"]

def load(path):
    rows = []
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append({
                "t": int(row["t"]),
                "o": float(row["o"]), "h": float(row["h"]),
                "l": float(row["l"]), "c": float(row["c"]),
                "v": float(row["v"]),
            })
    rows.sort(key=lambda x: x["t"])
    return rows

def wilder_atr(rows, n=14):
    trs = []
    for i, b in enumerate(rows):
        if i == 0:
            trs.append(b["h"] - b["l"])
        else:
            pc = rows[i-1]["c"]
            trs.append(max(b["h"] - b["l"], abs(b["h"] - pc), abs(b["l"] - pc)))
    atr = []
    for i, tr in enumerate(trs):
        if i < n:
            atr.append(sum(trs[:i+1]) / (i+1))
        else:
            atr.append((atr[-1] * (n-1) + tr) / n)
    return atr

def median(xs):
    s = sorted(xs)
    m = len(s)
    return s[m//2] if m % 2 else (s[m//2-1] + s[m//2]) / 2

def mean(xs):
    return sum(xs) / len(xs) if xs else float("nan")

def autocorr1(xs):
    m = mean(xs)
    num = sum((xs[i]-m)*(xs[i-1]-m) for i in range(1, len(xs)))
    den = sum((x-m)**2 for x in xs)
    return num / den if den else float("nan")

out = {}
for coin in COINS:
    p1h = os.path.join(DATA, f"gate_1h_365d_{coin}_USDT.csv")
    p15 = os.path.join(DATA, f"gate_15m_103d_{coin}_USDT.csv")
    h1 = load(p1h)
    m15 = load(p15)
    # 1h ATR% (Wilder 14) median over full window and last 30d
    atr1h = wilder_atr(h1)
    atr1h_pct = [a / b["c"] * 100 for a, b in zip(atr1h, h1)]
    last30 = atr1h_pct[-720:]
    # 15m ATR%
    atr15 = wilder_atr(m15)
    atr15_pct = [a / b["c"] * 100 for a, b in zip(atr15, m15)]
    # 1h log returns
    rets = [math.log(h1[i]["c"] / h1[i-1]["c"]) for i in range(1, len(h1))]
    # big-move frequency: |1h ret| >= 1x ATR1h (use contemporaneous atr%)
    big = []
    for i in range(1, len(h1)):
        big.append(abs(rets[i-1]) >= atr1h_pct[i] / 100)
    # daily |return| >= 2% frequency (UTC days)
    days = {}
    for b in h1:
        d = datetime.fromtimestamp(b["t"], tz=timezone.utc).date().isoformat()
        days.setdefault(d, []).append(b)
    bigday = 0
    ndays = 0
    for d, bars in days.items():
        if len(bars) >= 20:
            ndays += 1
            dr = bars[-1]["c"] / bars[0]["o"] - 1
            if abs(dr) >= 0.02:
                bigday += 1
    # session profile: mean |1h ret| by UTC hour bucket
    buckets = {"london_08-11": [], "ny_13-16": [], "asia_17-23": [], "other": []}
    for i, b in enumerate(h1):
        if i == 0:
            continue
        hr = datetime.fromtimestamp(b["t"], tz=timezone.utc).hour
        r = abs(rets[i-1])
        if 8 <= hr < 11:
            buckets["london_08-11"].append(r)
        elif 13 <= hr < 16:
            buckets["ny_13-16"].append(r)
        elif 17 <= hr < 23:
            buckets["asia_17-23"].append(r)
        else:
            buckets["other"].append(r)
    sess = {k: round(mean(v) * 100, 3) for k, v in buckets.items()}
    # volume: coefficient of variation of 1h volume
    vols = [b["v"] for b in h1]
    vol_cv = (sum((x - mean(vols)) ** 2 for x in vols) / len(vols)) ** 0.5 / mean(vols)
    out[coin] = {
        "h1_bars": len(h1),
        "h1_from": datetime.fromtimestamp(h1[0]["t"], tz=timezone.utc).isoformat(),
        "h1_to": datetime.fromtimestamp(h1[-1]["t"], tz=timezone.utc).isoformat(),
        "m15_bars": len(m15),
        "m15_from": datetime.fromtimestamp(m15[0]["t"], tz=timezone.utc).isoformat(),
        "m15_to": datetime.fromtimestamp(m15[-1]["t"], tz=timezone.utc).isoformat(),
        "atr1h_pct_median": round(median(atr1h_pct), 3),
        "atr1h_pct_last30d_median": round(median(last30), 3),
        "atr15_pct_median": round(median(atr15_pct), 3),
        "atr1h_over_atr15": round(median(atr1h_pct) / median(atr15_pct), 2),
        "mean_abs_1h_ret_pct": round(mean([abs(r) for r in rets]) * 100, 3),
        "lag1_autocorr_1h_ret": round(autocorr1(rets), 3),
        "pct_1h_bars_ge_1atr": round(100 * sum(big) / len(big), 1),
        "pct_utc_days_ge_2pct": round(100 * bigday / ndays, 1) if ndays else None,
        "n_utc_days": ndays,
        "session_mean_abs_1h_ret_pct": sess,
        "vol_cv_1h": round(vol_cv, 2),
    }

print(json.dumps(out, indent=2, ensure_ascii=False))
with open("/tmp/percoin_measure.json", "w") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
