#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
判断层 v1.2 审计脚本 A：预检召回 + 完整读盘对照
====================================================
对读盘训练三期答案库里的每一道 YES 题：
  1. 用该题币种的 15m 缓存（train{N}_{coin}_15m.json），截到确认根（含），
     跑 judge_precheck.precheck_coin，看是否 flag 出参考方向的候选。
  2. 再跑 judge_read.brief + decide，看完整读盘是否判 write。
输出每题：预检是否命中（kinds）、decide 结果、不通过的项。
不写任何计划文件、不碰 live 引擎。
用法：python3 /tmp/audit_precheck.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.expanduser(
    "~/workspace/赚钱路子/纸面交易/开发-主观判断"))
import judge_precheck as jp
import judge_read as jr

TRAIN_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/读盘训练")


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def norm_bars(raw):
    bars = raw if isinstance(raw, list) else raw.get("bars", raw)
    return jp._norm(bars)


def audit_batch(n, cname):
    bank = load_json(os.path.join(TRAIN_DIR, f"{cname}期-20题.json"))
    print(f"\n===== 第 {n} 期（{len(bank['questions'])} 题）=====")
    yes_qs = [q for q in bank["questions"] if q.get("kind") == "YES"]
    print(f"YES 题 {len(yes_qs)} 道")
    results = []
    for q in yes_qs:
        coin = q["coin"]
        T = q["T"]  # 确认根时间戳（开盘）
        ref_dir = q["ref_direction"]
        d_txt = "做空" if ref_dir == -1 else "做多"
        b15 = norm_bars(load_json(os.path.join(TRAIN_DIR, f"train{n}_{coin}_15m.json")))
        b1h = norm_bars(load_json(os.path.join(TRAIN_DIR, f"train{n}_{coin}_1h.json")))
        bars15 = [b for b in b15 if b["t"] <= T]
        bars1h = [b for b in b1h if b["t"] + 3600 <= T + 900]
        if not bars15 or bars15[-1]["t"] != T:
            results.append((q["id"], coin, ref_dir, "NO_DATA",
                            f"缓存无确认根 T={T}（最后根 {bars15[-1]['t'] if bars15 else None}）",
                            "", ""))
            continue
        # 1. 预检
        cands = jp.precheck_coin(bars15, coin)
        hit = [c for c in cands if c["direction"] == ref_dir]
        pre = "HIT" if hit else "MISS"
        kinds = ",".join(hit[0]["kinds"]) if hit else (
            ",".join(f"{c['direction']}:{'/'.join(c['kinds'])}" for c in cands)
            or "无候选")
        # 2. 完整读盘
        b = jr.brief(coin, ref_dir, T, bars15, bars1h, plan_path=None)
        if "error" in b:
            dec, fails = "ERROR", b["error"]
        else:
            dec, reason, checks = jr.decide(b)
            fails = ",".join(k for k, (ok, _) in checks.items()
                             if k not in ("pd", "volume", "book") and not ok) or "-"
            # 对照参考事实：level/test_count/atr
            lvl = b.get("level")
            lvl_ref = q.get("level_idx")
            # 索引换算：indexed = real * (100 / first_stem_1h_close)；用 confirm 收盘反推因子
            factor = q["confirm_idx"]["c"] / bars15[-1]["c"] if bars15[-1]["c"] else None
            lvl_idx = lvl * factor if (lvl and factor) else None
            atr15_idx = b.get("atr15") * factor if (b.get("atr15") and factor) else None
            def _f(x):
                return f"{x:.4f}" if x is not None else "None"
            extra = (f"level_idx={_f(lvl_idx)} vs ref {lvl_ref} | "
                     f"atr15_idx={_f(atr15_idx)} vs ref {q.get('atr15_idx')} | "
                     f"tests={b.get('test_count')} vs ref {q.get('test_count')}")
        results.append((q["id"], coin, ref_dir, pre, kinds, dec, fails, extra))
    # 打印
    n_hit = sum(1 for r in results if r[3] == "HIT")
    n_write = sum(1 for r in results if r[5] == "write")
    for r in results:
        qid, coin, ref_dir, pre, kinds, dec, fails = r[:7]
        extra = r[7] if len(r) > 7 else ""
        print(f"{qid} {coin} {'空' if ref_dir==-1 else '多'} 预检={pre}({kinds}) "
              f"decide={dec} 不通过={fails}")
        if extra:
            print(f"    {extra}")
    print(f"小计：预检命中 {n_hit}/{len(results)}，decide=write {n_write}/{len(results)}")
    return results


if __name__ == "__main__":
    all_res = []
    for n, cname in ((1, "第一"), (2, "第二"), (3, "第三")):
        all_res += audit_batch(n, cname)
    n_hit = sum(1 for r in all_res if r[3] == "HIT")
    n_write = sum(1 for r in all_res if r[5] == "write")
    print(f"\n===== 总计：30 道 YES =====")
    print(f"预检命中 {n_hit}/30，decide=write {n_write}/30")
    print("漏检（预检 MISS）：", [r[0] for r in all_res if r[3] == "MISS"])
    print("decide 非 write：", [(r[0], r[6]) for r in all_res if r[5] != "write"])
