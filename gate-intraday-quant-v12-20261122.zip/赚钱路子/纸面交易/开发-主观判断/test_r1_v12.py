#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
判断层 v1.2 试验 R1：item 5 放宽分支回放对比
============================================
把 judge_read.RELAX_ITEM5 置 True，跑 11-17 与 11-20 回放，
与已修复的基线（11-17：4 条；11-20：7 条）对比：
  - 是否抓到 11-20 09:00 ETH（01:30 UTC）
  - 新增几条触发、分别是什么、有没有新增误报
不写 live 计划、不碰引擎。
用法：python3 /tmp/test_r1.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.expanduser(
    "~/workspace/赚钱路子/纸面交易/开发-主观判断"))
import judge_read as jr
jr.RELAX_ITEM5 = True
# 关键：回放必须用空 state，否则 write_trigger 会读 live state，
# 把 11-21 已成交的币（DOGE/ADA/ETH/BNB）全拦掉。
jr.STATE_PATH = "/tmp/judge_test/empty_state.json"
import test_judge_replay as tjr

BASE = {
    "2026-11-17": {("BTC", 1, "03:15"), ("DOGE", -1, "05:15"),
                    ("BNB", -1, "13:15"), ("ETH", -1, "15:00")},
    "2026-11-20": {("ADA", -1, "07:30"), ("BTC", -1, "02:00"),
                    ("DOGE", -1, "07:30"), ("ETH", -1, "14:45"),
                    ("LINK", -1, "07:30"), ("SOL", -1, "11:15"),
                    ("XRP", -1, "02:00")},
}


def run(day, data_dir, plan_file, traded, plan_copy):
    # 方向一致性（第 6 项）须显式传 plan_dirs，否则 replay_day 不拦反向触发
    plan_dirs = jr.plan_directions(plan_file) if plan_file else {}
    rep = tjr.replay_day(day, data_dir, plan_file, traded, plan_copy,
                         plan_dirs=plan_dirs)
    print(f"\n===== {day}（R1 开）===== closes:{rep['closes_replayed']} "
          f"candidates:{rep['candidates_total']} triggers:{len(rep['triggers_written'])}")
    for c, t in sorted(rep["triggers_written"].items()):
        d = -1 if t["sl"] > t["ref"] else 1
        key = (c, d, t["pending_entry"])
        mark = "" if key in BASE[day] else "  <-- 新增"
        print(f"  {c} {'空' if d==-1 else '多'} {t['pending_entry']} ref {t['ref']}{mark}")
    got = {(c, (-1 if t["sl"] > t["ref"] else 1), t["pending_entry"])
           for c, t in rep["triggers_written"].items()}
    new = got - BASE[day]
    missing = BASE[day] - got
    print(f"新增触发：{sorted(new) if new else '无'}；基线丢失：{sorted(missing) if missing else '无'}")
    # 09:00 ETH（11-20 01:30 UTC）是否写出
    if day == "2026-11-20":
        for e in rep["events"]:
            if e["coin"] == "ETH" and e["time_utc"] == "01:30":
                print(f"  ETH 09:00（01:30）：decision={e['decision']} "
                      f"write={e.get('write')} msg={e.get('write_msg', '')[:80]}")
                print(f"    reason={e['reason'][:160]}")
    return rep


if __name__ == "__main__":
    run("2026-11-20", "/tmp/judge_test/nov20",
        "/tmp/judge_test/plan_2026-11-20_clean.md", set(),
        "/tmp/judge_test/plan_copy_2026-11-20_r1.md")
    run("2026-11-17", "/tmp/judge_test/nov17",
        os.path.expanduser("~/workspace/赚钱路子/SMC主观分析-2026-11-17.md"),
        {"SOL", "LINK", "ADA", "XRP"},
        "/tmp/judge_test/plan_copy_2026-11-17_r1.md")
