#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
判断层 v1.2 审计脚本 B：NO 题对照
================================
对读盘训练三期答案库里的每一道 NO 题：
  跑 judge_read.brief + decide，看是否判 no，以及不通过的项
  是否与参考 fail_items 一致。
不写任何计划文件、不碰 live 引擎。
用法：python3 /tmp/audit_no.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.expanduser(
    "~/workspace/赚钱路子/纸面交易/开发-主观判断"))
import judge_precheck as jp
import judge_read as jr

TRAIN_DIR = os.path.expanduser("~/workspace/赚钱路子/纸面交易/读盘训练")
ITEM_MAP = {"structure": 1, "level": 2, "rejection": 3, "precheck": 4,
            "strength": 5}


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def norm_bars(raw):
    bars = raw if isinstance(raw, list) else raw.get("bars", raw)
    return jp._norm(bars)


def audit_batch(n, cname):
    bank = load_json(os.path.join(TRAIN_DIR, f"{cname}期-20题.json"))
    print(f"\n===== 第 {n} 期 NO 题 =====")
    no_qs = [q for q in bank["questions"] if q.get("kind") == "NO"]
    results = []
    for q in no_qs:
        coin = q["coin"]
        T = q["T"]
        # NO 题没有 ref_direction（无真 setup），用 direction（考虑方向）
        ref_dir = q["direction"]
        ref_fails = sorted(q.get("fail_items", []))
        b15 = norm_bars(load_json(os.path.join(TRAIN_DIR, f"train{n}_{coin}_15m.json")))
        b1h = norm_bars(load_json(os.path.join(TRAIN_DIR, f"train{n}_{coin}_1h.json")))
        bars15 = [b for b in b15 if b["t"] <= T]
        bars1h = [b for b in b1h if b["t"] + 3600 <= T + 900]
        if not bars15 or bars15[-1]["t"] != T:
            results.append((q["id"], coin, ref_dir, ref_fails, "NO_DATA", [], "缓存无确认根"))
            continue
        cands = jp.precheck_coin(bars15, coin)
        pre_hit = any(c["direction"] == ref_dir for c in cands)
        b = jr.brief(coin, ref_dir, T, bars15, bars1h, plan_path=None)
        if "error" in b:
            results.append((q["id"], coin, ref_dir, ref_fails, "ERROR", [],
                            b["error"], pre_hit))
            continue
        dec, reason, checks = jr.decide(b)
        my_fails = sorted(ITEM_MAP[k] for k, (ok, _) in checks.items()
                          if k in ITEM_MAP and not ok)
        match = "OK" if (dec == "no" and my_fails == ref_fails) else "DIFF"
        # 失败原因细节
        detail = "; ".join(f"{k}:{checks[k][1][:60]}" for k in checks
                           if k in ITEM_MAP and not checks[k][0])
        results.append((q["id"], coin, ref_dir, ref_fails, dec, my_fails,
                        detail, pre_hit, match))
    n_ok = sum(1 for r in results if r[8] == "OK") if results and len(results[0]) > 8 else 0
    for r in results:
        qid, coin, ref_dir, ref_fails, dec, my_fails = r[:6]
        detail, pre_hit = r[6], r[7]
        match = r[8] if len(r) > 8 else "?"
        print(f"{qid} {coin} {'空' if ref_dir==-1 else '多'} ref_fail={ref_fails} "
              f"decide={dec} my_fail={my_fails} 预检={'HIT' if pre_hit else 'MISS'} [{match}]")
        if match == "DIFF":
            print(f"    细节：{detail}")
            print(f"    参考：{r[0]} fail_reason={''}")
    print(f"小计：decide 与参考一致 {n_ok}/{len(results)}")
    return results


if __name__ == "__main__":
    all_res = []
    for n, cname in ((1, "第一"), (2, "第二"), (3, "第三")):
        all_res += audit_batch(n, cname)
    n_ok = sum(1 for r in all_res if len(r) > 8 and r[8] == "OK")
    print(f"\n===== 总计：30 道 NO =====")
    print(f"decide 与参考一致 {n_ok}/30")
    diffs = [r for r in all_res if len(r) > 8 and r[8] == "DIFF"]
    print("不一致：", [(r[0], r[3], r[5]) for r in diffs])
    # 预检对 NO 题的命中情况（仅作参考：预检是高召回，命中 NO 题不算错）
    n_pre = sum(1 for r in all_res if r[7])
    print(f"预检命中 NO 题 {n_pre}/30（高召回设计，命中后由 decide 过滤，不算错）")
